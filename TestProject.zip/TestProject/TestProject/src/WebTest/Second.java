package WebTest;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

public class Second {

	public static void main(String[] args) throws InterruptedException {

		// System Property for Gecko Driver
		System.setProperty("webdriver.gecko.driver",
				"D:\\Ajay\\Project-TopconChronos\\geckodriver-v0.24.0-win64\\geckodriver.exe");

		// Initialize Gecko Driver using Desired Capabilities Class
		DesiredCapabilities capabilities = DesiredCapabilities.firefox();
		capabilities.setCapability("marionette", true);
		WebDriver driver = new FirefoxDriver(capabilities);

		// Launch Website
		driver.get("http://localhost:8080/Web/sub/subjective.php");
		driver.manage().window().maximize();
		Thread.sleep(5000);
		driver.close();
		//driver.quit();

		/*// Click on the Custom Search text box and send value
		driver.findElement(By.id("gsc-i-id1")).sendKeys("Java");

		// Click on the Search button
		driver.findElement(By.className("gsc-search-button gsc-search-button-v2")).click();*/
		                                 
	}

}