package WebTest;


import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;  
import org.openqa.selenium.remote.DesiredCapabilities;


public class WebConnect {

	public static void main(String[] args) throws InterruptedException {

		/*System.setProperty("webDriver.chrome.driver",
				"D:\\Ajay\\Project-TopconChronos\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();*/
		System.setProperty("webdriver.gecko.driver",
		"D:\\Ajay\\Project-TopconChronos\\geckodriver-v0.24.0-win64\\geckodriver.exe");
		//WebDriver driver = new ChromeDriver();
		// Initialize Gecko Driver using Desired Capabilities Class  
	    //DesiredCapabilities capabilities = DesiredCapabilities.firefox();  
	    //capabilities.setCapability("marionette",true);  
	    //@SuppressWarnings("deprecation")
	    WebDriver driver= new FirefoxDriver(); //capabilities
		driver.get("http://google.com/");
		//long millis = 0;
		//Thread.sleep(millis, 2000);
		driver.quit();

	}

}
