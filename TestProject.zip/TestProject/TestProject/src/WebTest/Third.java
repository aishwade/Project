package WebTest;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

public class Third {
	
	public static void main(String[] args) throws InterruptedException {

		// System Property for Gecko Driver
		System.setProperty("webdriver.chrome.driver",
				"D:\\Ajay\\Project-TopconChronos\\chromedriver_win32\\chromedriver.exe");

		// Initialize Gecko Driver using Desired Capabilities Class
		DesiredCapabilities capabilities = DesiredCapabilities.chrome();
		capabilities.setCapability("marionette", true);
		WebDriver driver = new ChromeDriver(capabilities);

		// Launch Website
		driver.get("http://localhost:8080/Web/sub/subjective.php");
		driver.manage().window().maximize();
		Thread.sleep(5000);
		driver.close();		                                 
	}

}
