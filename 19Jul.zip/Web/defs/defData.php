<?php

//! @brief バージョン
class Version
{

	const Major = 0;
	const Minor = 0;
	const Build = 0;
//	const Revision = Version::GetRevision();

	/*!
	 * @brief リビジョン番号を得る
	 * revision.txt はデプロイ時のみ生成されるファイル
	 *
	 * @return int リビジョン番号
	 */
	public static function GetRevision()
	{
		$path = dirname(__FILE__) . '/revision.txt';
		if (!file_exists($path)) {
			return 0;
		}
		$revision = file_get_contents($path);
		if (false === $revision) {
			return 0;
		}
		return intval($revision);
	}

}//class Version

//! @brief 検査眼
class EyeType
{

	const Left  = 1;
	const Right = 2;
	const Bino  = 3;

}//class EyeType

//! @brief プライベート IP アドレス
class PrivateIpAdress
{

	const Left  = '192.168.1.1';
	const Right = '192.168.1.2';
	const Bino  = '127.0.0.1'; // 自身を指す

}//class PrivateIpAdress

//! @brief Maestro II プロトコル
class Maestro2Protocol
{

	const Port = 19200; // デフォルトポート

}//class Maestro2Protocol

?>
