<?php
/*! @file
 * @brief リクエストで受け取ったレンズメーターのXMLをJSON形式に変換してレスポンスを返す
 */

require_once 'convertXmlToJsonHelper.php';

$xmlString  = file_get_contents('php://input');
$jsonString = \Lensmeter\convertXmlToJsonString($xmlString);

header('Content-Type: application/json; charset=utf-8');
echo $jsonString;
