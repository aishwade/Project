<?php
/*! @file
 * @brief レンズメーターのXMLをJSON形式に変換する
 */

namespace Lensmeter;

/*!
 * @brief レンズメーターのXML(文字列)をJSON(配列)に変換する
 *
 * @param[in] string $xmlString レンズメーターのXML(文字列)
 * @return JSON(配列)
 */
function convertXmlToJson($xmlString)
{
	/*!
	 * 値の XPath を評価して値を更新する再帰関数
	 */
	function _setValueFromEvaluateRecursive($xpath, &$value)
	{
		if (is_array($value)) {
			$result = true;
			foreach ($value as &$child) {
				if (!_setValueFromEvaluateRecursive($xpath, $child)) {
					$result = false;
				}
			}
			return $result;
		} else {
			if (empty($value)) {
				return true;
			}
			$evaluateResult = $xpath->evaluate($value);
			if (false === $evaluateResult) {
				return false;
			}
			if (is_float($evaluateResult) && is_nan($evaluateResult)) {
				// XPath で値が取得できなかった場合など
				$value = '';
			} else {
				$value = $evaluateResult;
			}
			return true;
		}
		// ここに到達する場合、実装ミスかもしれない
		assert(false, "Implementation error!? \Lensmeter\convertXmlToJson::_setValueFromEvaluateRecursive");
		return false;
	}

	$domDoc = new \DOMDocument();
	if (!$domDoc) {
		return false;
	}

	if (!$domDoc->loadXML($xmlString)) {
		return false;
	}

	$xpath = new \DOMXPath($domDoc);
	if (!$xpath) {
		return false;
	}

	// 取り込みテンプレートファイルは、UTF-8(BOM無し)である事！
	$lensmeterTemplateJsonFilePath = __DIR__ . DIRECTORY_SEPARATOR . 'lensmeter.template.json';
	$lensmeterTemplateJsonString = file_get_contents($lensmeterTemplateJsonFilePath);
	$lensmeterTemplateJson = json_decode($lensmeterTemplateJsonString, true);
	if (!$lensmeterTemplateJson) {
		if (function_exists('json_last_error')) {
			// v5.3.0 以降
			fputs(STDERR, json_last_error() . "\n");
		}
		if (function_exists('json_last_error_msg')) {
			// v5.5.0 以降
			fputs(STDERR, json_last_error_msg() . "\n");
		}
		return false;
	}

	$json = $lensmeterTemplateJson;
	if (!_setValueFromEvaluateRecursive($xpath, $json)) {
		return false;
	}

	return $json;
}

/*!
 * @brief レンズメーターのXML(文字列)をJSON文字列に変換する
 *
 * @param[in] string $xmlString レンズメーターのXML(文字列)
 * @return JSON文字列
 */
function convertXmlToJsonString($xmlString)
{
	$json = convertXmlToJson($xmlString);
	if (!$json) {
		return '';
	}

	return json_encode($json);
}
