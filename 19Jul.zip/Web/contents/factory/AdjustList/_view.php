<div class="block-list">
	<div class="block-horizontal">
		<p>
			<h3>E2PROM Initialize</h3>
		</p>
		<p>
			Select target board:
			<?php
				$E2PROMinitUnitIdName = 'E2PROMinitUnitId';
				echo createRagio($E2PROMinitUnitIdName,    'BaseSub', 'BASE Sub', true);
				echo createRagio($E2PROMinitUnitIdName, 'OpticalSub',  'OPT Sub');
			?>
		</p>
		<p>
			<input type="button" id="E2PROMInitialize" value="Execute">
			<span id="E2PROMInitializeResult"></span>
		</p>
	</div>
</div>
<div class="block-list" style="margin-top: 3em;">
	<div class="block-horizontal">
		<input type="button" value="REF LED Adjust">
	</div>
	<div class="block-horizontal">
		<input type="button" value="CMOS Gain Adjust">
	</div>
	<div class="block-horizontal">
		<input type="button" value="XY LED Adjust">
	</div>
	<div class="block-horizontal">
		<input type="button" value="Fixation LED Adjust">
	</div>
	<div class="block-horizontal">
		<input type="button" value="Center Adjust">
	</div>
	<div class="block-horizontal">
		<input type="button" value="Zero Adjust">
	</div>
</div>
<div class="block-list">
	<div class="block-horizontal">
		<input type="button" value="KRT LED Adjust">
	</div>
	<div class="block-horizontal">
		<input type="button" value="Parallel Level">
	</div>
	<div class="block-horizontal">
		<input type="button" value="Parallel Bend">
	</div>
</div>
<div class="block-list">
	<div class="block-horizontal">
		<input type="button" value="Subjective VCC/Zero Adjust">
	</div>
	<div class="block-horizontal">
		<input type="button" value="Fixation LCD Adjust">
	</div>
	<div class="block-horizontal">
		<input type="button" value="LCD Center Adjust">
	</div>
	<div class="block-horizontal">
		<input type="button" value="LCD Magnification Adjust">
	</div>
</div>
<div class="block-list">
	<div class="block-horizontal">
		<input type="button" value="Camera R/L Pint Adjust">
	</div>
	<div class="block-horizontal">
		<input type="button" value="Camera R/L Gain Adjust">
	</div>
	<div class="block-horizontal">
		<input type="button" value="Anterior LED Adjust">
	</div>
</div>
<div class="block-list">
	<div class="block-horizontal">
		<input type="button" value="Get S0">
	</div>
	<div class="block-horizontal">
		<input type="button" value="Get P2D">
	</div>
	<div class="block-horizontal">
		<input type="button" value="Get SPD">
	</div>
	<div class="block-horizontal">
		<input type="button" value="Sph. Linearity">
	</div>
	<div class="block-horizontal">
		<input type="button" value="Cyl. Linearity">
	</div>
	<div class="block-horizontal">
		<input type="button" value="REF Axis Calibration">
	</div>
</div>
<div class="block-list">
	<div class="block-horizontal">
		<input type="button" value="Alpha Calculate">
	</div>
	<div class="block-horizontal">
		<input type="button" value="Zero Search">
	</div>
	<div class="block-horizontal">
		<input type="button" value="Z Alignment">
	</div>
	<div class="block-horizontal">
		<input type="button" value="Curvature Calibration">
	</div>
	<div class="block-horizontal">
		<input type="button" value="Kerato Axis Calibration">
	</div>
	<div class="block-horizontal">
		<input type="button" value="Cornea Calibration">
	</div>
</div>
<div class="block-list">
	<div class="block-horizontal">
		<input type="button" value="Subjective P2D Calibration">
	</div>
	<div class="block-horizontal">
		<input type="button" value="Subjective Cyl. Calibration">
	</div>
	<div class="block-horizontal">
		<input type="button" value="Fusion Theta Calibration">
	</div>
	<div class="block-horizontal">
		<input type="button" value="Fusion XYZ Calibration">
	</div>
</div>
<div class="block-list">
	<div class="block-horizontal">
		<input type="button" value="Stereo Orientation">
	</div>
	<div class="block-horizontal">
		<input type="button" value="Stereo Spot Calibration">
	</div>
	<div class="block-horizontal">
		<input type="button" value="Pupil Calibration">
	</div>
</div>
