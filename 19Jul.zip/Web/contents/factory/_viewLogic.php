<?php
/*! @file
 * @brief 工具ツール画面向けのロジック関数群
 */

require_once topDir() . 'views/_tags.php';

/*!
 * @brief ラジオ(ボタン)を作る
 *
 * @param[in] string $name      input の name  属性の値
 * @param[in] string $value     input の value 属性の値
 * @param[in] string $text      ラジオに表示する内容
 * @param[in] bool   $isChecked 項目を選択状態にするか？
 * @return string HTML文字列
 */
function createRagio($name, $value, $text, $isChecked = false)
{
	$id = $name . '-' . $value;

	$inputAtts = [
		'type'  => 'radio',
		'name'  => $name  ,
		'value' => $value ,
		'id'    => $id    ,
	];
	if ($isChecked) {
		$inputAtts += [ 'checked' => 'checked', ];
	}

	$labelAtts = [ 'for' => $id, ];

	return _input($inputAtts) . _label($labelAtts, $text);
}

/*!
 * @brief ラジオの ON 要素を出力
 * input の value は 1 固定。表示内容は"ON"固定
 *
 * @param[in] string $name  input の name  属性の値
 * @return void
 */
function _putRagio_ON($name)
{
	echo createRagio($name, 1, 'ON');
}

/*!
 * @brief ラジオの OFF 要素を出力
 * input の value は 0 固定。表示内容は"OFF"固定
 *
 * @param[in] string $name  input の name  属性の値
 * @return void
 */
function _putRagio_OFF($name)
{
	echo createRagio($name, 0, 'OFF');
}

/*!
 * @brief ラジオの ON / OFF 要素を出力
 *
 * @param[in] string $name  input の name  属性の値
 * @return void
 */
function _putRagio_ON_OFF($name)
{
	_putRagio_ON ($name);
	_putRagio_OFF($name);
}
