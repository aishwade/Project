<?php
/*! @file
 * @brief 工具ツール画面の中身
 */

require_once topDir() . 'models/modelUtil.php';
//require_once topDir() . 'contents/_head.php';
require_once topDir() . 'contents/factory/_head.php';
require_once topDir() . 'contents/factory/_viewLogic.php';

$ip   = \ModelUtil\array_get($_GET['ip'  ], $_SERVER['HTTP_HOST']);
$port = \ModelUtil\array_get($_GET['port'], $_SERVER['SERVER_PORT']);

?>
<!DOCTYPE html>
<html>
	<head>
		<?php outputHeadContents(); ?>
		<title>工具ツール</title>
	</head>

	<body>
		<header>
		</header>

		<div id="main">
			<form id="factory_form" action="./index.php" method="post">
				<label for="ip">Connection IP and port number.</label>
				<input type="text" id="ip" value="<?php echo $ip; ?>">:<input type="text" id="port" value="<?php echo $port; ?>" maxlength="6">
				<select id="pos">
					<option value="L">L</option>
					<option value="R">R</option>
				</select>
				<div id="tabs">
					<ul>
						<li><a href="#tabs-AdjustList"           >Adjust List            </a></li>
						<li><a href="#tabs-SingleFunctionCommand">Single Function Command</a></li>
						<li><a href="#tabs-FunctionCheck"        >Function Check         </a></li>
					</ul>
					<div id="tabs-AdjustList">
						<?php include 'AdjustList/_view.php'; ?>
					</div>
					<div id="tabs-SingleFunctionCommand">
						<ul>
							<li><a href="#tabs-SingleFunctionCommand-LED"         >LED          </a></li>
							<li><a href="#tabs-SingleFunctionCommand-Shutter"     >Shutter      </a></li>
							<li><a href="#tabs-SingleFunctionCommand-OptMotor"    >Opt Motor    </a></li>
							<li><a href="#tabs-SingleFunctionCommand-REFCamera"   >REF Camera   </a></li>
							<li><a href="#tabs-SingleFunctionCommand-StereoCamera">Stereo Camera</a></li>
							<li><a href="#tabs-SingleFunctionCommand-BaseMotor"   >Base Motor   </a></li>
							<li><a href="#tabs-SingleFunctionCommand-FactorySW"   >Factory SW   </a></li>
						</ul>
						<div id="tabs-SingleFunctionCommand-LED">
							<?php include 'SingleFunctionCommand/_viewLED.php'; ?>
						</div>
						<div id="tabs-SingleFunctionCommand-Shutter">
							<?php include 'SingleFunctionCommand/_viewShutter.php'; ?>
						</div>
						<div id="tabs-SingleFunctionCommand-OptMotor">
							<?php include 'SingleFunctionCommand/_viewOptMotor.php'; ?>
						</div>
						<div id="tabs-SingleFunctionCommand-REFCamera">
						</div>
						<div id="tabs-SingleFunctionCommand-StereoCamera">
							<?php include 'SingleFunctionCommand/_viewStereoCamera.php'; ?>
						</div>
						<div id="tabs-SingleFunctionCommand-BaseMotor">
							<?php include 'SingleFunctionCommand/_viewBaseMotor.php'; ?>
						</div>
						<div id="tabs-SingleFunctionCommand-FactorySW">
							<input type="file" name="file">
							<input type="button" id="postFile" value="送信">
						</div>
					</div>
					<div id="tabs-FunctionCheck">
					</div>
				</div>
			</form>
		</div>

		<footer><?php printDebug(); ?></footer>
	</body>
</html>

