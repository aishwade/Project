<div class="block-list">
	<div class="block-horizontal">
		<h3>Path change</h3>
		<?php _putRagio_ON_OFF('opticalPath'); ?>
	</div>
</div>
<div class="block-list">
	<div class="block-horizontal">
		<h3>RG Bandpass</h3>
		<?php _putRagio_ON_OFF('RGBandpass'); ?>
	</div>
</div>
