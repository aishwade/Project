<h3 class="block-list">Rotary</h3>
<div class="block-list">
	<div class="block-horizontal">
		<?php _putRagio_ON_OFF('rotaryPrism'); ?>
	</div>
</div>

<h3 class="block-list">TF</h3>
<div class="block-list">
	<div class="block-horizontal">
		<ul>
			<li>
				<?php _putRagio_ON_OFF('setTFPower'); ?>
				<div style="display: inline-block; margin-left: 3em;">
					<input type="button" id="initializeTF" value="Zero">
					<input type="button" id="getTFPosition" value="Get Pos">
					<div style="display: inline-block;">
						Pos:
						<span id="getTFPositionValue" style="margin-left: 0.5em; margin-right: 0.5em;">00000</span>
						pulse
					</div>
				</div>
				<div style="display: inline-block; margin-left: 3em;">
					<input type="button" id="moveTF_Fog" value="Fog">
				</div>
			</li>
			<li style="margin-top: 1em;">
				<div style="display: inline-block;">
					10^<input type="tel" id="TFExponent" value="0">
				</div>
				<div style="display: inline-block;">
					<input type="tel" id="TFMoveDiopter" value="0">D
				</div>
				<input type="button" id="moveTF_Normal" value="Move">
				<div style="display: inline-block; margin-left: 3em;">
					<input type="tel" id="TFOffsetPulse" value="0">pulse
				</div>
				<input type="button" id="setTFOffset" value="Set Offset">
			</li>
		</ul>
	</div>
</div>

<h3 class="block-list">VCC1</h3>
<div class="block-list">
	<div class="block-horizontal">
		<ul>
			<li>
				<?php _putRagio_ON_OFF('setVCCPower1'); ?>
				<div style="display: inline-block; margin-left: 3em;">
					<input type="button" id="initializeVCC1" value="Zero">
					<input type="button" id="getVCCPosition1" value="Get Pos">
					<div style="display: inline-block;">
						Pos:
						<span id="getVCCPositionValue1" style="margin-left: 0.5em; margin-right: 0.5em;">00000</span>
						deg
					</div>
				</div>
			</li>
			<li style="margin-top: 1em;">
				<div style="display: inline-block;">
					10^<input type="tel" id="VCCExponent1" value="0">
				</div>
				<div style="display: inline-block;">
					<input type="tel" id="VCCMoveDiopter1" value="0">degree
				</div>
				<input type="button" id="moveVCC1" value="Move">
				<div style="display: inline-block; margin-left: 3em;">
					<input type="tel" id="VCCOffsetPulse1" value="0">pulse
				</div>
				<input type="button" id="setVCCOffset1" value="Set Offset">
			</li>
		</ul>
	</div>
</div>

<h3 class="block-list">VCC2</h3>
<div class="block-list">
	<div class="block-horizontal">
		<ul>
			<li>
				<?php _putRagio_ON_OFF('setVCCPower2'); ?>
				<div style="display: inline-block; margin-left: 3em;">
					<input type="button" id="initializeVCC2" value="Zero">
					<input type="button" id="getVCCPosition2" value="Get Pos">
					<div style="display: inline-block;">
						Pos:
						<span id="getVCCPositionValue2" style="margin-left: 0.5em; margin-right: 0.5em;">00000</span>
						deg
					</div>
				</div>
			</li>
			<li style="margin-top: 1em;">
				<div style="display: inline-block;">
					10^<input type="tel" id="VCCExponent2" value="0">
				</div>
				<div style="display: inline-block;">
					<input type="tel" id="VCCMoveDiopter2" value="0">degree
				</div>
				<input type="button" id="moveVCC2" value="Move">
				<div style="display: inline-block; margin-left: 3em;">
					<input type="tel" id="VCCOffsetPulse2" value="0">pulse
				</div>
				<input type="button" id="setVCCOffset2" value="Set Offset">
			</li>
		</ul>
	</div>
</div>
