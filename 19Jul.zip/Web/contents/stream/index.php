<?php

$scaleDown = 4;

?>
<!DOCTYPE html>
<html>
	<body>
		<img src="http://10.140.19.30:8080/1.jpg?scaleDown=<?php echo $scaleDown; ?>">
		<img src="http://10.140.19.31:8080/1.jpg?scaleDown=<?php echo $scaleDown; ?>">
	</body>
</html>
