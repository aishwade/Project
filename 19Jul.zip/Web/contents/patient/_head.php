<?php
/*! @file
 * @brief patient 固有のスタイルシートとスクリプトの読み込み
 */

addStyles(
	[
		'css/patient.css',
	]
);

addScripts(
	[
		'js/patient.js',
	]
);
