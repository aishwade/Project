<?php
/*! @file
 * @brief バージョン情報出力
 */

require_once topDir() . 'defs/defData.php';
require_once topDir() . 'views/_tags.php';

/*!
 * @brief バージョン出力部分のレイアウトを構築
 *
 * @param[in] array $commandNames コマンド名郡
 * @param[in] array $firmwareNames ファームウェア名郡
 * @return string レイアウトのHTML
 */
function buildVersionLayout($commandNames, $firmwareNames)
{
	$html = '';

	// GUI のバージョンは即座に分かる
	$html .= _p(
		_label(
			[ 'class' => 'elementLabel' ],
			'GUI'
		) .
		_span(join('.', [ Version::Major, Version::Minor, Version::Build, Version::GetRevision() ]))
	);

	// 各コマンドのバージョンは Ajax を使って非同期に問い合わせる
	foreach ($commandNames as $commandName) {
		$baseName = 'labelCommandVersion' . $commandName;
		$html .= _p(
			_label(
				[ 'class' => 'elementLabel' ],
				$commandName
			) .
			_span(
				'L :' . _span( [ 'class' => 'labelVersion'          , 'id' => $baseName . 'L'    ]) .
				'R :' . _span( [ 'class' => 'labelVersion'          , 'id' => $baseName . 'R'    ]) .
				        _span( [ 'class' => 'labelVersion errorText', 'id' => $baseName . 'Warn' ])
			)
		);
	}

	// LiveStreamServer のバージョンはコマンドと異なる方法で問い合わせる
	{
		$baseName = 'labelLiveStreamServerVersion';
		$html .= _p(
			_label(
				[ 'class' => 'elementLabel' ],
				'LiveStreamServer'
			) .
			_span(
				'L :' . _span( [ 'class' => 'labelVersion'          , 'id' => $baseName . 'L'    ]) .
				'R :' . _span( [ 'class' => 'labelVersion'          , 'id' => $baseName . 'R'    ]) .
				        _span( [ 'class' => 'labelVersion errorText', 'id' => $baseName . 'Warn' ])
			)
		);
	}

	// 各ファームウェアのバージョンは Ajax を使って同期的に問い合わせる
	foreach ($firmwareNames as $firmwareName) {
		$baseName = 'labelCommandVersion' . $firmwareName;
		$html .= _p(
			_label(
				[ 'class' => 'elementLabel' ],
				$firmwareName
			) .
			_span(
				'L :' . _span( [ 'class' => 'labelVersion'          , 'id' => $baseName . 'L'    ]) .
				'R :' . _span( [ 'class' => 'labelVersion'          , 'id' => $baseName . 'R'    ]) .
				        _span( [ 'class' => 'labelVersion errorText', 'id' => $baseName . 'Warn' ])
			)
		);
	}

	return $html;
}
