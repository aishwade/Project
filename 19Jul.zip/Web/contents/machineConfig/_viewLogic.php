<?php
/*! @file
 * @brief 機器設定画面の保存や復元などを行う関数群
 */

require_once topDir() . 'models/systemUtil.php';
require_once topDir() . 'contents/machineConfig/machineConfigCategoryType.php';
require_once topDir() . 'contents/machineConfig/_machineConfigUtil.php';

/*!
 * @brief 機器設定カテゴリをキーに設定ファイルの接頭語を得るためのマップ(定数)
 * @todo 正式に定数(const)として定義したい。(配列を定数として使えるのは PHP 5.6 から)
 */
$mapFilePrefixByCategoryType = [
	\machineConfig\CategoryType::REGION        => 'region',
	\machineConfig\CategoryType::OBJECTIVE     => 'objective',
	\machineConfig\CategoryType::SUBJECTIVE    => 'subjective',
];

/*!
 * @brief 設定ファイルのパスを得る
 *
 * @param[in] string $filePrefix ファイルの接頭語
 * @return string 設定ファイルのパス
 */
function _getSettingFilePath($filePrefix)
{
	return topDir() . 'contents/settings/' . $filePrefix . '.setting.json';
}

/*!
 * @brief 機器設定を保存する
 * 複数のファイルへ保存
 *
 * @param[in] array $elements 機器設定要素郡
 * @return bool 成功可否
 *
 * @global array $mapFilePrefixByCategoryType 機器設定カテゴリをキーに設定ファイルの接頭語を得るためのマップ(定数)
 * @global array $_POST                       この連想配列に記録されている機器設定を保存する
 */
function doRegisterMachineConfig(array $elements)
{
	global $mapFilePrefixByCategoryType;

	$mapJsonArrayByFilePrefix = [];
	$filePrefixList = array_values($mapFilePrefixByCategoryType);
	foreach ($filePrefixList as $filePrefix) {
		$mapJsonArrayByFilePrefix += [ $filePrefix => [] ];
	}

	foreach ($elements as $element) {
		$category    = getCategory   ($element);
		$name        = getName       ($element);
		$controlType = getControlType($element);

		$filePrefix = $mapFilePrefixByCategoryType[$category];
		if (!$filePrefix) {
			return false;
		}
		if (!array_key_exists($filePrefix, $mapJsonArrayByFilePrefix)) {
			return false;
		}

		$postValue = $_POST[$name];

		switch ($controlType) {
			case \becky\ControlType::FIELDSET_BEGIN:
			case \becky\ControlType::FIELDSET_END:
			case \becky\ControlType::HEADING:
			case \becky\ControlType::BUTTON:
				continue 2; // foreach に対して continue
			case \becky\ControlType::RADIO:
			case \becky\ControlType::DROPDOWN_LIST:
			case \becky\ControlType::EDIT_BOX:
			case \becky\ControlType::EDIT_TIME:
				break;
			case \becky\ControlType::CHECKBOX:
				$postValue = is_null($postValue) ?
					\becky\CheckboxValueType::OFF :
					\becky\CheckboxValueType::ON;
				break;
			default:
				// 分岐処理を追加する必要がある。
				die('Error: It is necessary to add branch processing.' . $controlType);
				return false;
		}

		$jsonData = $mapJsonArrayByFilePrefix[$filePrefix];
		$jsonData += [ $name => $postValue ];
		$mapJsonArrayByFilePrefix[$filePrefix] = $jsonData;
	}
	foreach ($mapJsonArrayByFilePrefix as $key => $value) {
		if (\ModelUtil\empty_recursive($value)) {
			continue; // 保存する中身が存在しない
		}
		$settingFilePath = _getSettingFilePath($key);
		$valueString = json_encode($value);
		file_put_contents($settingFilePath, $valueString, LOCK_EX);
	}

	// sync で速やかに SD カードに書き込む
	\becky\System\sync();

	return true;
}

/*!
 * @brief 機器設定を読み込む
 * 複数のファイルから読み込む
 *
 * @param[in] array $elements 機器設定要素郡
 * @return bool 成功可否
 *
 * @global array $mapFilePrefixByCategoryType 機器設定カテゴリをキーに設定ファイルの接頭語を得るためのマップ(定数)
 * @global array $_POST                       この連想配列に機器設定を取り込む
 */
function loadMachineConfig(array $elements)
{
	global $mapFilePrefixByCategoryType;

	$filePrefixList = array_values($mapFilePrefixByCategoryType);
	foreach ($filePrefixList as $filePrefix) {
		$settingFilePath = _getSettingFilePath($filePrefix);
		if (!is_file($settingFilePath)) {
			continue;
		}

		$settingString = file_get_contents($settingFilePath);
		if (false === $settingString) {
			return false;
		}

		$settingJSON_Datas = json_decode($settingString, true);
		if (!$settingJSON_Datas) {
			return false;
		}

		foreach ($settingJSON_Datas as $key => $value) {
			$_POST[$key] = $value;
		}
	}

	return true;
}
