<?php
/*! @file
 * @brief machineConfig 固有のスタイルシートとスクリプトの読み込み
 */

addStyles(
	[
		'vendor/jqueryui/css/ui-darkness-custom/jquery-ui-1.12.1.custom.css',
		'vendor/normalize.css',
		'css/color-theme.css',
		'css/machineConfig.css',
	]
);

addScripts(
	[
		'vendor/jqueryui/js/jquery-3.2.1.min.js',
		'vendor/jquery.ui.touch-punch.min.js',
		'vendor/jqueryui/js/jquery-ui-1.12.1.custom.min.js',
		'js/all.js',
		'js/modelHelper.js',
		'js/viewHelper.js',
		'js/ajaxHelper.js',
		'js/beckyAssertion.js',
		'js/beckyDebug.js',
		'js/beckyAsyncAjax.js',
		'js/beckyLeanStartupAjax.js',
		'js/beckyWebStorageHelper.js',
		'js/beckyWebStorageIO.js',
		'js/machineConfig.js',
	]
);
