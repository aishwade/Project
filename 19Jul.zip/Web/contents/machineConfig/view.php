<?php
/*! @file
 * @brief 機器設定画面の中身
 */

require_once topDir() . 'views/beckyControlType.php';
//require_once topDir() . 'contents/_head.php';
require_once topDir() . 'contents/_live.php';
require_once topDir() . 'contents/machineConfig/machineConfigCategoryType.php';
require_once topDir() . 'contents/machineConfig/_head.php';
require_once topDir() . 'contents/machineConfig/_viewLogic.php';
require_once topDir() . 'contents/machineConfig/_viewVersions.php';
require_once topDir() . 'contents/machineConfig/_machineConfigUtil.php';

/*!
 * @brief 機器設定のすべての設定項目を定義
 */
$elements = [
	// カテゴリ                                 , コントロールタイプ                , 設定名称                              , デフォルト, 選択肢
	[ \machineConfig\CategoryType::REGION       , \becky\ControlType::DROPDOWN_LIST , 'regionID'                            , 1, [ 'JP', 'US' ] ],
	[ \machineConfig\CategoryType::OBJECTIVE    , \becky\ControlType::DROPDOWN_LIST , 'vd'                                  , 1, [ '0.00', '12.00',  '13.75' ] ],
	[ \machineConfig\CategoryType::SUBJECTIVE   , \becky\ControlType::EDIT_BOX      , 'examinationDistanceFarPoint'         , 5000, [ 400, 6096 ] ],
	[ \machineConfig\CategoryType::SUBJECTIVE   , \becky\ControlType::EDIT_BOX      , 'examinationDistanceNearPoint'        ,  400, [ 400, 6096 ] ],
	[ \machineConfig\CategoryType::SUBJECTIVE   , \becky\ControlType::CHECKBOX      , 'alignmentWhenSightMarksAreSelected'  , 0, ],
];

if (!empty($_POST['machineConfig_register'])) {
	// 保存前にトリムする
	\ModelUtil\array_trim($_POST);

	if (doRegisterMachineConfig($elements)) {
		header('Location: ' . topUri() . 'sub/machineConfig.php');
		exit;
	}
} else {
	loadMachineConfig($elements);
}

// コマンド名郡(バージョン取得)
$commandNames = [
	'ResetOpt',
	'ResetBase',
	'ChronosAlignment2',
	'ChronosRef2',
	'Chart',
	'Phoropter',
];

// ファームウェア名郡(バージョン取得)
$firmwareNames = [
	'GetBaseSubVer',
	'GetOptSubVer',
];

?>
<!DOCTYPE html>
<html>
	<head>
		<?php outputHeadContents(); ?>
		<title><?php echo _m('machineConfig', 'title'); ?></title>
	</head>

	<body>
		<script>
			<?php include_once topDir() . 'views/_datePicker.php'; ?>
		</script>

		<header>
		</header>

		<div id="main">
			<form id="machineConfig_form" action="./machineConfig.php" method="post">
				<input type="button" id="goBack" value="<?php echo _m('machineConfig', 'goBack' ); ?>">
				<input type="button" id="register" value="<?php echo _m('machineConfig', 'save' ); ?>">
				<div id="tabs">
					<ul>
						<li><a href="#tabs-generalSettings"><?php echo _m('machineConfig', 'generalSettings'); ?></a></li>
						<li><a href="#tabs-objective"      ><?php echo _m('machineConfig', 'objective'      ); ?></a></li>
						<li><a href="#tabs-subjective"     ><?php echo _m('machineConfig', 'subjective'     ); ?></a></li>
						<li><a href="#tabs-versions"       ><?php echo _m('machineConfig', 'versions'       ); ?></a></li>
					</ul>
					<div id="tabs-generalSettings">
						<?php echo buildConfigTags($elements, \machineConfig\CategoryType::REGION); ?>
						<p>
							<label class="elementLabel"><?php echo _m('networkConfig', 'title'); ?></label>
							<a href="./networkConfig.php" target="_blank"><?php echo _m('machineConfig', 'openSettingPage'); ?></a>
						</p>
					</div>
					<div id="tabs-objective">
						<?php echo buildConfigTags($elements, \machineConfig\CategoryType::OBJECTIVE); ?>
					</div>
					<div id="tabs-subjective">
						<?php echo buildConfigTags($elements, \machineConfig\CategoryType::SUBJECTIVE); ?>
					</div>
					<div id="tabs-versions">
						<?php echo buildVersionLayout($commandNames, $firmwareNames); ?>
					</div>
				</div>
			</form>
		</div>

		<footer><?php printDebug(); ?></footer>
		<script type="text/javascript">
		"use strict";
		// 名前空間
		var becky = becky || {};
		// ライブ像
		becky.liveHttpUri = {
			L: "<?php echo $liveHttpUri['L']; ?>",
			R: "<?php echo $liveHttpUri['R']; ?>",
		};
		// コマンド名郡
		becky.commandNames = <?php echo json_encode($commandNames); ?>;
		// ファームウェア名郡
		becky.firmwareNames = <?php echo json_encode($firmwareNames); ?>;
		</script>
	</body>
</html>
