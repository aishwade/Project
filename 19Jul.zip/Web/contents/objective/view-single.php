<?php
/*! @file
 * @brief 他覚-角膜直径 画面の中身
 */

require_once topDir() . 'models/modelUtil.php';
require_once topDir() . 'views/_tags.php';
require_once topDir() . 'contents/_head.php';
require_once topDir() . 'contents/_live.php';
require_once topDir() . 'contents/objective/_head-single.php';
require_once topDir() . 'contents/objective/_viewLogic.php';

$eye = \ModelUtil\array_get($_POST['eye'], 'R');
// _live.php で作り出した値を使用する
$liveHttpUriCurrent = $liveHttpUri[$eye];

$currentSuffix = '';
switch ($eye) {
	case "R":
		$currentSuffix = 'a';
		break;
	case "L":
		$currentSuffix = 'b';
		break;
	default:
		break;
}

?>
<!DOCTYPE html>
<!--[if lt IE 7]><html lang="ja-JP" class="no-js ie lt-ie9 lt-ie8 lt-ie7"><![endif]-->
<!--[if IE 7]><html lang="ja-JP" class="no-js ie lt-ie9 lt-ie8"  xmlns:og="http://ogp.me/ns#" xmlns:mixi="http://mixi-platform.com/ns#" xmlns:fb="http://www.facebook.com/2008/fbml"><![endif]-->
<!--[if IE 8]><html lang="ja-JP" class="no-js ie lt-ie9"  xmlns:og="http://ogp.me/ns#" xmlns:mixi="http://mixi-platform.com/ns#" xmlns:fb="http://www.facebook.com/2008/fbml"><![endif]-->
<!--[if IE 9]><html lang="ja-JP" class="no-js ie"  xmlns:og="http://ogp.me/ns#" xmlns:mixi="http://mixi-platform.com/ns#" xmlns:fb="http://www.facebook.com/2008/fbml"><![endif]-->
<!--[if gt IE 9]><!-->
<html lang="ja-JP" class="no-js" xmlns:og="http://ogp.me/ns#" xmlns:mixi="http://mixi-platform.com/ns#" xmlns:fb="http://www.facebook.com/2008/fbml">
<!--<![endif]-->
<head>
<?php outputHeadContents(); ?>
<title><?php echo _m('objective', 'title'); ?></title>
<!--[if lt IE 9]>
<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
<script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
</head>
<body>
<script>
	const liveHttpUri = {
		R: "<?php echo $liveHttpUri['R']; ?>",
		L: "<?php echo $liveHttpUri['L']; ?>",
	};
</script>
<div class="siteframe B-objective-single">
<div class="siteframe-inner">

<div class="siteframe-header">
<div class="siteframe-header-inner">
<div class="layout-header clearfix">
	<div class="header-prev">
		<a href="./objective.php" class="btn btn-prev"><span class="icon icon-arrow"></span>他覚検査画面へ戻る</a>
	</div>
	<div class="header-title">
		<p class="txt txt-header-title">角膜直径計測</p>
	</div>
</div><!--/.layout-header-->
</div><!--./siteframe-header-inner-->
</div><!--./siteframe-header-->

<div class="siteframe-body">
<div class="siteframe-body-inner">
<div class="layout-content clearfix">
	<div class="area-a">
		<div class="area-a-a">
			<div class="area-inner">
				<div class="eye-box"><img class="eye-img" src="<?php echo $liveHttpUriCurrent; ?>" id="imgLiveImage"></div>
			</div><!--/.area-inner-->
		</div><!--/.area-a-a-->
		<div class="area-a-c">
			<div class="area-inner">
				<div class="gauge">
					<div class="gauge-inner">
						<div class="gauge-left" style="width: 190px;">
							<div class="gauge-border"></div>
							<button type="button" class="btn btn-edit-gauge"><div class="btn-inner"></div></button>
						</div>
					</div>
					<div class="gauge-inner">
						<div class="gauge-right" style="width: 190px;">
							<div class="gauge-border"></div>
							<button type="button" class="btn btn-edit-gauge"><div class="btn-inner"></div></button>
						</div>
					</div>
				</div><!--/.gauge-->
			</div><!--/.area-inner-->
		</div><!--/.area-a-c-->
		<div class="area-a-b current-<?php echo $currentSuffix; ?>" id="areaAB">
			<div class="eye-value eye-value-a"><p class="txt txt-eye-value">R：9.50</p></div>
			<div class="btn-group btn-group-eye-select">
				<button type="button" class="btn btn-eye-select-a" id="btnEyeR"><div class="btn-inner"><span class="icon icon-eye-right"><?php echo _m('global', 'rightEye'); ?></span></div></button>
				<button type="button" class="btn btn-eye-select-b" id="btnEyeL"><div class="btn-inner"><span class="icon icon-eye-left" ><?php echo _m('global', 'leftEye'); ?></span></div></button>
			</div>
			<div class="eye-value eye-value-b"><p class="txt txt-eye-value">L：0.00</p></div>
		</div><!--/.area-a-b-->
	</div><!--/.area-a-->
	<div class="area-b">
		<div class="area-inner">
		<div class="area-b-c">
			<button type="button" class="btn btn-start-calc"><div class="btn-inner"><span class="icon icon-09"></span>計測</div></button>
		</div><!--/.area-b-c-->
		<div class="area-b-a">
			<div class="btn-group btn-group-editspan">
				<button type="button" class="btn"><div class="btn-inner"><span class="icon icon-06 icon-rotate-180"></span></div></button>
				<button type="button" class="btn"><div class="btn-inner"><span class="icon icon-06"></span></div></button>
				<div class="btn-group-separate"><span class="icon icon-07"></span></div>
			</div>
		</div><!--/.area-b-a-->
		<div class="area-b-b">
			<div class="btn-group btn-group-editspan">
				<button type="button" class="btn"><div class="btn-inner"><span class="icon icon-06 icon-rotate-180"></span></div></button>
				<button type="button" class="btn"><div class="btn-inner"><span class="icon icon-06"></span></div></button>
				<div class="btn-group-separate"><span class="icon icon-08"></span></div>
			</div>
		</div><!--/.area-b-b-->
		</div><!--/.area-inner-->
	</div><!--/.area-b-->
</div><!--/.layout-content-->
</div><!--./siteframe-body-inner-->
</div><!--./siteframe-body-->

<div class="siteframe-footer">
<div class="siteframe-footer-inner">

</div><!--./siteframe-footer-inner-->
</div><!--./siteframe-footer-->

</div><!--./siteframe-inner-->
</div><!--./siteframe-->



</body>
</html>
