<?php
/*! @file
 * @brief 他覚画面の中身
 */

require_once topDir() . 'views/messageHelper.php';
require_once topDir() . 'views/_tags.php';
require_once topDir() . 'contents/_head.php';
require_once topDir() . 'contents/_live.php';
require_once topDir() . 'contents/objective/_head.php';
require_once topDir() . 'contents/objective/_viewLogic.php';

$filenameFactorySettingJson = 'contents/settings/factory.setting.json';
$arrayFactorySetting = getMapFromJsonFile(topDir() . $filenameFactorySettingJson);
if (!$arrayFactorySetting) {
	// 工場設定ファイルが無いのでエラーページに飛ばす
	$_SESSION['error'] = [
		'redirectUri'  => topUri() . 'sub/factoryConfig.php',
		'redirectWait' => 30,
		'title'        => _m('error', 'title'),
		'msg'          => 'file not found!<br>' . $filenameFactorySettingJson,
	];
	header('Location: ' . topUri() . 'sub/error.php');
	return;
}

$filenameObjectiveSettingJson = 'contents/settings/objective.setting.json';
$arrayObjectiveSetting = getMapFromJsonFile(topDir() . $filenameObjectiveSettingJson);

if (!$arrayObjectiveSetting) {
	// 他覚の設定ファイルが無いのでエラーページに飛ばす
	$_SESSION['error'] = [
		'redirectUri'  => topUri() . 'sub/machineConfig.php',
		'redirectWait' => 30,
		'title'        => _m('error', 'title'),
		'msg'          => 'file not found!<br>' . $filenameObjectiveSettingJson,
	];
	header('Location: ' . topUri() . 'sub/error.php');
	return;
}

$pd = 65; // Todo. 機器のデフォルトが 32.5 x 2 らしい
$vd = $arrayObjectiveSetting['vd'];

?>
<!DOCTYPE html>
<!--[if lt IE 7]><html lang="ja-JP" class="no-js ie lt-ie9 lt-ie8 lt-ie7"><![endif]-->
<!--[if IE 7]><html lang="ja-JP" class="no-js ie lt-ie9 lt-ie8"  xmlns:og="http://ogp.me/ns#" xmlns:mixi="http://mixi-platform.com/ns#" xmlns:fb="http://www.facebook.com/2008/fbml"><![endif]-->
<!--[if IE 8]><html lang="ja-JP" class="no-js ie lt-ie9"  xmlns:og="http://ogp.me/ns#" xmlns:mixi="http://mixi-platform.com/ns#" xmlns:fb="http://www.facebook.com/2008/fbml"><![endif]-->
<!--[if IE 9]><html lang="ja-JP" class="no-js ie"  xmlns:og="http://ogp.me/ns#" xmlns:mixi="http://mixi-platform.com/ns#" xmlns:fb="http://www.facebook.com/2008/fbml"><![endif]-->
<!--[if gt IE 9]><!-->
<html lang="ja-JP" class="no-js" xmlns:og="http://ogp.me/ns#" xmlns:mixi="http://mixi-platform.com/ns#" xmlns:fb="http://www.facebook.com/2008/fbml">
<!--<![endif]-->
<head>
<?php outputHeadContents(); ?>
<title><?php echo _m('objective', 'title'); ?></title>
<!--[if lt IE 9]>
<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
<script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
</head>
<body>
<!-- メッセージの定義リスト(JavaScript向け) -->
<dl id="list_message" style="display: none;">
	<?php
		echoListMessageItem('factoryConfig', 'modelEyeAlignmentMode');
	?>
</dl>
<div id="currentEye" data-value="B" style="display: none;"></div>
<div class="siteframe B-objective">
<div class="siteframe-inner">

<?php include_once topDir() . 'contents/_nav.php'; ?>

<div class="siteframe-body">
<div class="siteframe-body-inner">
<div class="layout-content clearfix">
	<div class="area area-a clearfix">
		<div class="title">
			<p class="txt-title-inspection">&nbsp;</p>
			<p class="txt-title-course">&nbsp;</p>
		</div><!--/.title-->
	</div><!--/.area-a-->
	<div class="area area-b clearfix">
		<div class="eye-title"><p class="txt-eye-title">&nbsp;</p></div><!--/.eye-title-->
		<div class="eye-title eye-title-r"><p class="txt-scan-title"><?php echo _m('global', 'right'); ?></p></div>
		<div class="eye-title eye-title-l"><p class="txt-scan-title"><?php echo _m('global', 'left'); ?></p></div>
	</div><!--/.area-b-->
	<div class="area area-c clearfix">
		<div class="area-inner">
			<div class="area area-c-a">
				<div class="area area-c-a-a">
					<div class="scan">
						<div class="scan-inner">
							<div class="eye-box">
								<img class="eye-img" id="imgEyeR">
							</div>
							<div class="btn-group btn-group-left">
								<button type="button" class="btn btn-scan" id="btnCataractModeR" value="false"><div class="btn-inner"><span class="icon icon-01"></span></div></button>
								<button type="button" class="btn btn-scan" id="btnCornealDiameterR"><div class="btn-inner"><span class="icon icon-02"></span></div></button>
							</div>
						</div>
					</div>
				</div><!--/.area-c-a-a-->
				<div class="area area-c-a-c">
					<div id="imgHeadU"></div>
					<div id="imgHeadD"></div>
				</div><!--/.area-c-a-c-->
				<div class="area area-c-a-b">
					<div class="scan">
						<div class="scan-inner">
							<div class="eye-box">
								<img class="eye-img" id="imgEyeL">
							</div>
							<div class="btn-group btn-group-right">
								<button type="button" class="btn btn-scan" id="btnCataractModeL" value="false"><div class="btn-inner"><span class="icon icon-01"></span></div></button>
								<button type="button" class="btn btn-scan" id="btnCornealDiameterL"><div class="btn-inner"><span class="icon icon-02"></span></div></button>
							</div>
						</div>
					</div>
				</div><!--/.area-c-a-b-->
			</div><!--/.area-c-a-->
			<div class="area area-c-b clearfix">
				<div class="box-group clearfix">
					<div class="pd-box">
						<div class="pd-label"><p class="txt-pd-label">PD</p></div>
						<div class="pd-value"><p class="txt-pd-value" id="labelPD" data-text="<?php echo $pd; ?>" data-fixed="1">&nbsp;</p></div>
					</div>
					<div class="vd-box">
						<div class="vd-label"><p class="txt-vd-label">VD</p></div>
						<div class="vd-value"><p class="txt-vd-value" id="labelVD" data-text="<?php echo $vd; ?>" data-fixed="2">&nbsp;</p></div>
					</div>
				</div>
			</div><!--/.area-c-b-->
			<div class="area area-c-c clearfix">
				<table class="sca">
					<tr>
						<th class="background-backslash">&nbsp;</th>
						<th class="txt-val">AVE</th>
						<th class="txt-val">1</th>
						<th class="txt-val">2</th>
						<th class="txt-val">3</th>
					</tr>
					<tr>
						<td class="txt-sca">S：</td>
						<td class="txt-val text-right sph" id="labelSphR"  data-text="" data-fixed="2" data-class-plus="valuePlus"></td>
						<td class="txt-val text-right sph" id="labelSphR1" data-text="" data-fixed="2" data-class-plus="valuePlus"></td>
						<td class="txt-val text-right sph" id="labelSphR2" data-text="" data-fixed="2" data-class-plus="valuePlus"></td>
						<td class="txt-val text-right sph" id="labelSphR3" data-text="" data-fixed="2" data-class-plus="valuePlus"></td>
					</tr>
					<tr>
						<td class="txt-sca">C：</td>
						<td class="txt-val text-right cyl" id="labelCylR"  data-text="" data-fixed="2" data-class-plus="valuePlus"></td>
						<td class="txt-val text-right cyl" id="labelCylR1" data-text="" data-fixed="2" data-class-plus="valuePlus"></td>
						<td class="txt-val text-right cyl" id="labelCylR2" data-text="" data-fixed="2" data-class-plus="valuePlus"></td>
						<td class="txt-val text-right cyl" id="labelCylR3" data-text="" data-fixed="2" data-class-plus="valuePlus"></td>
					</tr>
					<tr>
						<td class="txt-sca">A：</td>
						<td class="txt-val text-right axs" id="labelAxsR"  data-text="" data-fixed="0"></td>
						<td class="txt-val text-right axs" id="labelAxsR1" data-text="" data-fixed="0"></td>
						<td class="txt-val text-right axs" id="labelAxsR2" data-text="" data-fixed="0"></td>
						<td class="txt-val text-right axs" id="labelAxsR3" data-text="" data-fixed="0"></td>
					</tr>
				</table>
			</div><!--/.area-c-c-->
			<div class="area area-c-d clearfix">
				<table class="sca">
					<tr>
						<th class="background-backslash">&nbsp;</th>
						<th class="txt-val">AVE</th>
						<th class="txt-val">1</th>
						<th class="txt-val">2</th>
						<th class="txt-val">3</th>
					</tr>
					<tr>
						<td class="txt-sca">S：</td>
						<td class="txt-val text-right sph" id="labelSphL"  data-text="" data-fixed="2" data-class-plus="valuePlus"></td>
						<td class="txt-val text-right sph" id="labelSphL1" data-text="" data-fixed="2" data-class-plus="valuePlus"></td>
						<td class="txt-val text-right sph" id="labelSphL2" data-text="" data-fixed="2" data-class-plus="valuePlus"></td>
						<td class="txt-val text-right sph" id="labelSphL3" data-text="" data-fixed="2" data-class-plus="valuePlus"></td>
					</tr>
					<tr>
						<td class="txt-sca">C：</td>
						<td class="txt-val text-right cyl" id="labelCylL"  data-text="" data-fixed="2" data-class-plus="valuePlus"></td>
						<td class="txt-val text-right cyl" id="labelCylL1" data-text="" data-fixed="2" data-class-plus="valuePlus"></td>
						<td class="txt-val text-right cyl" id="labelCylL2" data-text="" data-fixed="2" data-class-plus="valuePlus"></td>
						<td class="txt-val text-right cyl" id="labelCylL3" data-text="" data-fixed="2" data-class-plus="valuePlus"></td>
					</tr>
					<tr>
						<td class="txt-sca">A：</td>
						<td class="txt-val text-right axs" id="labelAxsL"  data-text="" data-fixed="0"></td>
						<td class="txt-val text-right axs" id="labelAxsL1" data-text="" data-fixed="0"></td>
						<td class="txt-val text-right axs" id="labelAxsL2" data-text="" data-fixed="0"></td>
						<td class="txt-val text-right axs" id="labelAxsL3" data-text="" data-fixed="0"></td>
					</tr>
				</table>
			</div><!--/.area-c-d-->
		</div><!--/.area-inner-->
	</div><!--/.area-c-->
	<div class="area area-d clearfix">
		<div class="area area-d-a clearfix">
			<div class="btn-group-triple controller-eye">
				<button type="button" class="btn"         id="btnControllerEyeR"><div class="btn-inner"><span class="icon icon-eye-right"><?php echo _m('global', 'rightEye'); ?></span></div></button>
				<button type="button" class="btn current" id="btnControllerEyeB"><div class="btn-inner"><span class="icon icon-eye-bino" ><?php echo _m('global', 'binoEye' ); ?></span></div></button>
				<button type="button" class="btn"         id="btnControllerEyeL"><div class="btn-inner"><span class="icon icon-eye-left" ><?php echo _m('global', 'leftEye' ); ?></span></div></button>
			</div>
		</div><!--/.area-d-a-->
	</div><!--/.area-d-->
</div><!--/.layout-content-->
</div><!--./siteframe-body-inner-->
</div><!--./siteframe-body-->

<div class="siteframe-footer">
<div class="siteframe-footer-inner">
<div class="layout-footer clearfix">
	<div class="menu">
		<div class="menu-item"><button type="button" class="btn btn-menu" id="btnFixationLevel" value="High"><div class="btn-inner"><span id="labelFixationLevelHigh">A</span>/<span id="labelFixationLevelLow">M</span></div></button></div>
		<div class="menu-item"><button type="button" class="btn btn-menu" id="btnFixationLevel" value="High"><div class="btn-inner"><span id="labelFixationLevelHigh">H</span>/<span id="labelFixationLevelLow">L</span></div></button></div>
		<div class="menu-item"><button type="button" class="btn btn-menu" id="btnClear"><div class="btn-inner"><span class="icon icon-05"></span></div></button></div>
		<div class="menu-item menu-item-large"><button type="button" class="btn btn-menu btn-menu-large" id="btnStart"><div class="btn-inner">
		<span class="icon icon-04"></span><?php echo _m('objective', 'menuStart'); ?></div></button></div>
		<div class="menu-item"><button type="button" class="btn btn-menu" id="btnAlignmentMode" value="A"><div class="btn-inner"><a id="labelA" href="<?php echo "http://" . $_SERVER['HTTP_HOST']."/topcon/sub/allDataDisplay.php"; ?>">All</a></div></button></div>
		<div class="menu-item"><button type="button" class="btn btn-menu" id="btnAlignmentMode" value="A"><div class="btn-inner"><span id="labelA">VD</span></div></button></div>
		<div class="menu-item"><button type="button" class="btn btn-menu" id="btnAlignmentMode" value="A"><div class="btn-inner"><span id="labelA">Clear</span></div></button></div>
	</div><!--/.menu-->
</div><!--/.layout-footer-->
</div><!--./siteframe-footer-inner-->
</div><!--./siteframe-footer-->

</div><!--./siteframe-inner-->
</div><!--./siteframe-->
<script type="text/javascript">
"use strict";
// 名前空間
var becky = becky || {};
// 全体設定
becky.settingJson = becky.settingJson || {};
becky.settingJson.factory = <?php echo json_encode($arrayFactorySetting); ?>;
becky.settingJson.objective = <?php echo json_encode($arrayObjectiveSetting); ?>;
// セッション
becky.session = becky.session || {};
becky.session.sessionDate = "<?php echo $_SESSION['sessionDate']; ?>";
becky.session.sessionTime = "<?php echo $_SESSION['sessionTime']; ?>";
becky.session.sessionPatientID = "<?php echo $_SESSION['sessionPatientID']; ?>";
// ライブ像
becky.liveHttpUri = {
	L: "<?php echo $liveHttpUri['L']; ?>",
	R: "<?php echo $liveHttpUri['R']; ?>",
};
//console.log(becky.settingJson.objective);
</script>
</body>
</html>
