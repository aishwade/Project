<?php
/*! @file
 * @brief 他覚画面向けのロジック関数群
 */

