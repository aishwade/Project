<?php
/*! @file
 * @brief objective 固有のスタイルシートとスクリプトの読み込み
 */

addStyles(
	[
		'css/objective.css',
	]
);

addScripts(
	[
		'js/objective.js',
	]
);
