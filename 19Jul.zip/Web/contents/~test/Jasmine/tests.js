describe("modelHelper", function() {
	it("isObject", function() {
		expect(modelHelper.isObject(new Object())).toBeTruthy('Objectを評価');
		expect(modelHelper.isObject(new Array())).toBeFalsy('配列を評価');
		expect(modelHelper.isObject(null)).toBeFalsy('nullを評価');
		expect(modelHelper.isObject(0)).toBeFalsy('0を評価');
		expect(modelHelper.isObject(1)).toBeFalsy('1を評価');
		expect(modelHelper.isObject(false)).toBeFalsy('falseを評価');
		expect(modelHelper.isObject( true)).toBeFalsy('trueを評価');
		let objUndefined;
		expect(modelHelper.isObject(objUndefined)).toBeFalsy('初期化していないオブジェクトを評価');
	});
	it("isBoolean", function() {
		expect(modelHelper.isBoolean( null)).toBeFalsy ('nullを評価');
		expect(modelHelper.isBoolean(    0)).toBeFalsy ('0を評価');
		expect(modelHelper.isBoolean(    1)).toBeFalsy ('1を評価');
		expect(modelHelper.isBoolean(    2)).toBeFalsy ('2を評価');
		expect(modelHelper.isBoolean(   '')).toBeFalsy ('空文字列を評価');
		expect(modelHelper.isBoolean(  ' ')).toBeFalsy ('半角スペースを評価');
		expect(modelHelper.isBoolean( '　')).toBeFalsy ('全角スペースを評価');
		expect(modelHelper.isBoolean(  '0')).toBeFalsy ('"0"を評価');
		expect(modelHelper.isBoolean(  '1')).toBeFalsy ('"1"を評価');
		expect(modelHelper.isBoolean(  '2')).toBeFalsy ('"2"を評価');
		expect(modelHelper.isBoolean(  'a')).toBeFalsy ('"a"を評価');
		expect(modelHelper.isBoolean(  'b')).toBeFalsy ('"b"を評価');
		expect(modelHelper.isBoolean(  'c')).toBeFalsy ('"c"を評価');
		expect(modelHelper.isBoolean(   [])).toBeFalsy ('空の配列を評価');
		expect(modelHelper.isBoolean(   {})).toBeFalsy ('空のObjectを評価');
		expect(modelHelper.isBoolean(false)).toBeTruthy('falseを評価');
		expect(modelHelper.isBoolean( true)).toBeTruthy('trueを評価');
		let objUndefined;
		expect(modelHelper.isBoolean(objUndefined)).toBeFalsy('初期化していないオブジェクトを評価');
	});
	it("isString", function() {
		expect(modelHelper.isString(null)).toBeFalsy('nullを評価');
		expect(modelHelper.isString(0)).toBeFalsy('0を評価');
		expect(modelHelper.isString(1)).toBeFalsy('1を評価');
		expect(modelHelper.isString(false)).toBeFalsy('falseを評価');
		expect(modelHelper.isString( true)).toBeFalsy('trueを評価');
		expect(modelHelper.isString([])).toBeFalsy('配列を評価');
		expect(modelHelper.isString({})).toBeFalsy('Objectを評価');
		expect(modelHelper.isString(new String())).toBeTruthy('String型を評価');
		expect(modelHelper.isString(  "")).toBeTruthy('空文字列を評価');
		expect(modelHelper.isString( " ")).toBeTruthy('半角スペースを評価');
		expect(modelHelper.isString("　")).toBeTruthy('全角スペースを評価');
	});
	it("isNull", function() {
		expect(modelHelper.isNull(null)).toBeTruthy('nullを評価');
		expect(modelHelper.isNull(   0)).toBeFalsy ('0を評価');
		expect(modelHelper.isNull(   1)).toBeFalsy ('1を評価');
		expect(modelHelper.isNull(   2)).toBeFalsy ('2を評価');
		expect(modelHelper.isNull(  '')).toBeFalsy ('空文字列を評価');
		expect(modelHelper.isNull( ' ')).toBeFalsy ('半角スペースを評価');
		expect(modelHelper.isNull('　')).toBeFalsy ('全角スペースを評価');
		expect(modelHelper.isNull( '0')).toBeFalsy ('"0"を評価');
		expect(modelHelper.isNull( '1')).toBeFalsy ('"1"を評価');
		expect(modelHelper.isNull( '2')).toBeFalsy ('"2"を評価');
		expect(modelHelper.isNull( 'a')).toBeFalsy ('"a"を評価');
		expect(modelHelper.isNull( 'b')).toBeFalsy ('"b"を評価');
		expect(modelHelper.isNull( 'c')).toBeFalsy ('"c"を評価');
		expect(modelHelper.isNull(  [])).toBeFalsy ('空の配列を評価');
		expect(modelHelper.isNull(  {})).toBeFalsy ('空のObjectを評価');
		let objUndefined;
		expect(modelHelper.isNull(objUndefined)).toBeFalsy('初期化していないオブジェクトを評価');
	});
	it("isNullOrEmpty", function() {
		expect(modelHelper.isNullOrEmpty(null)).toBeTruthy('nullを評価');
		expect(modelHelper.isNullOrEmpty(   0)).toBeFalsy ('0を評価');
		expect(modelHelper.isNullOrEmpty(   1)).toBeFalsy ('1を評価');
		expect(modelHelper.isNullOrEmpty(   2)).toBeFalsy ('2を評価');
		expect(modelHelper.isNullOrEmpty(  '')).toBeTruthy('空文字列を評価');
		expect(modelHelper.isNullOrEmpty( ' ')).toBeFalsy ('半角スペースを評価');
		expect(modelHelper.isNullOrEmpty('　')).toBeFalsy ('全角スペースを評価');
		expect(modelHelper.isNullOrEmpty( '0')).toBeFalsy ('"0"を評価');
		expect(modelHelper.isNullOrEmpty( '1')).toBeFalsy ('"1"を評価');
		expect(modelHelper.isNullOrEmpty( '2')).toBeFalsy ('"2"を評価');
		expect(modelHelper.isNullOrEmpty( 'a')).toBeFalsy ('"a"を評価');
		expect(modelHelper.isNullOrEmpty( 'b')).toBeFalsy ('"b"を評価');
		expect(modelHelper.isNullOrEmpty( 'c')).toBeFalsy ('"c"を評価');
		expect(modelHelper.isNullOrEmpty(  [])).toBeTruthy('空の配列を評価');
		expect(modelHelper.isNullOrEmpty(  {})).toBeTruthy('空のObjectを評価');
		let objUndefined;
		expect(modelHelper.isNullOrEmpty(objUndefined)).toBeTruthy('初期化していないオブジェクトを評価');
	});
	it("isNullOrEmpty(Array)", function() {
		const arr = new Array();
		expect(modelHelper.isNullOrEmpty(arr)).toBeTruthy('空の配列を評価');
		arr.push('');
		expect(modelHelper.isNullOrEmpty(arr)).toBeFalsy('空ではない配列を評価');
	});
	it("isNullOrEmpty(Object)", function() {
		const obj = new Object();
		expect(modelHelper.isNullOrEmpty(obj)).toBeTruthy('空のObjectを評価');
		obj['tmp'] = '';
		expect(modelHelper.isNullOrEmpty(obj)).toBeFalsy('空ではないObjectを評価');
		delete obj['tmp'];
		expect(modelHelper.isNullOrEmpty(obj)).toBeTruthy('空のObjectを評価');
		obj.tmp = '';
		expect(modelHelper.isNullOrEmpty(obj)).toBeFalsy('空ではないObjectを評価');
		delete obj.tmp;
		expect(modelHelper.isNullOrEmpty(obj)).toBeTruthy('空のObjectを評価');
	});
	it("isNullOrEmpty(jQuery)", function() {
		expect(modelHelper.isNullOrEmpty($('#hogehoge_mogemoge'))).toBeTruthy('存在しないjQueryセレクタを評価');
		expect(modelHelper.isNullOrEmpty($('body'))).toBeFalsy('存在するjQueryセレクタを評価');
	});
	it("isUndefined", function() {
		expect(modelHelper.isUndefined(null)).toBeFalsy('nullを評価');
		let objUndefined;
		expect(modelHelper.isUndefined(objUndefined)).toBeTruthy('初期化していないオブジェクトを評価');
		const arr = new Array();
		expect(modelHelper.isUndefined(arr.Hoge)).toBeTruthy('配列の無効なオブジェクトを評価');
		expect(modelHelper.isUndefined(0)).toBeFalsy('"0"を評価');
		expect(modelHelper.isUndefined('')).toBeFalsy('空文字列を評価');
	});
	it("hasUndefined(Array_Truthy)", function() {
		let C; // 初期化していないので undefined
		const arr1 = [
			"A",
			"B",
			 C,
		];
		expect(modelHelper.hasUndefined(arr1)).toBeTruthy('undefined が含まれる事を評価');
	});
	it("hasUndefined(Array_Falsy)", function() {
		const arr = [
			"A",
			"B",
			"C",
		];
		expect(modelHelper.hasUndefined(arr)).toBeFalsy('undefined が無い事を評価');
	});
	it("hasUndefined(Object_Truthy)", function() {
		const kEnum = {
			A: "A",
			B: "B",
		}
		const obj = {
			A: kEnum.A,
			B: kEnum.B,
			C: kEnum.C, // 存在しないものを参照
		};
		expect(modelHelper.hasUndefined(obj)).toBeTruthy('undefined が含まれる事を評価');
	});
	it("hasUndefined(Object_Falsy)", function() {
		const kEnum = {
			A: "A",
			B: "B",
			C: "C",
		}
		const obj = {
			A: kEnum.A,
			B: kEnum.B,
			C: kEnum.C,
		};
		expect(modelHelper.hasUndefined(obj)).toBeFalsy('undefined が無い事を評価');
	});
	it("toBoolean", function() {
		expect(modelHelper.toBoolean( "true")).toBeTruthy( '"true"を評価');
		expect(modelHelper.toBoolean("false")).toBeFalsy ('"false"を評価');
		expect(modelHelper.toBoolean("1")).toBeTruthy('"1"を評価');
		expect(modelHelper.toBoolean("0")).toBeFalsy ('"0"を評価');
		expect(modelHelper.toBoolean(1)).toBeTruthy('1を評価');
		expect(modelHelper.toBoolean(0)).toBeFalsy ('0を評価');
		// その他
		expect(modelHelper.toBoolean()).toBeFalsy('undefinedを評価');
		expect(modelHelper.toBoolean("")).toBeFalsy('空文字列を評価');
		expect(modelHelper.toBoolean("2")).toBeTruthy('"2"を評価');
		expect(modelHelper.toBoolean(2)).toBeTruthy('2を評価');
	});
	it("fround", function() {
		// 四捨五入
		expect(modelHelper.fround(0.124, 0.25)).toBe( 0.00);
		expect(modelHelper.fround(0.125, 0.25)).toBe( 0.25);

		expect(modelHelper.fround(-0.124, 0.25)).toBe( 0.00);
		expect(modelHelper.fround(-0.125, 0.25)).toBe(-0.25);

		expect(modelHelper.fround(0.374, 0.25)).toBe( 0.25);
		expect(modelHelper.fround(0.375, 0.25)).toBe( 0.50);

		expect(modelHelper.fround(-0.374, 0.25)).toBe(-0.25);
		expect(modelHelper.fround(-0.375, 0.25)).toBe(-0.50);

		expect(modelHelper.fround(0.4, 1)).toBe(0);
		expect(modelHelper.fround(0.5, 1)).toBe(1);

		expect(modelHelper.fround(-0.4, 1)).toBe( 0);
		expect(modelHelper.fround(-0.5, 1)).toBe(-1);
	});
	it("fbankersRound", function() {
		// 五捨六入
		expect(modelHelper.fbankersRound(0.124, 0.25)).toBe( 0.00);
		expect(modelHelper.fbankersRound(0.125, 0.25)).toBe( 0.00);
		expect(modelHelper.fbankersRound(0.126, 0.25)).toBe( 0.25);

		expect(modelHelper.fbankersRound(-0.124, 0.25)).toBe( 0.00);
		expect(modelHelper.fbankersRound(-0.125, 0.25)).toBe( 0.00);
		expect(modelHelper.fbankersRound(-0.126, 0.25)).toBe(-0.25);

		expect(modelHelper.fbankersRound(0.374, 0.25)).toBe( 0.25);
		expect(modelHelper.fbankersRound(0.375, 0.25)).toBe( 0.25);
		expect(modelHelper.fbankersRound(0.376, 0.25)).toBe( 0.50);

		expect(modelHelper.fbankersRound(-0.374, 0.25)).toBe(-0.25);
		expect(modelHelper.fbankersRound(-0.375, 0.25)).toBe(-0.25);
		expect(modelHelper.fbankersRound(-0.376, 0.25)).toBe(-0.50);

		expect(modelHelper.fbankersRound(0.4, 1)).toBe(0);
		expect(modelHelper.fbankersRound(0.5, 1)).toBe(0);
		expect(modelHelper.fbankersRound(0.6, 1)).toBe(1);

		expect(modelHelper.fbankersRound(-0.4, 1)).toBe( 0);
		expect(modelHelper.fbankersRound(-0.5, 1)).toBe( 0);
		expect(modelHelper.fbankersRound(-0.6, 1)).toBe(-1);
	});
});
describe("viewHelper", function() {
	it("repeatString", function(){
		// 1xn
		expect(viewHelper.repeatString("0", 1)).toBe("0");
		expect(viewHelper.repeatString("0", 2)).toBe("00");
		expect(viewHelper.repeatString("0", 3)).toBe("000");
		// nxn
		expect(viewHelper.repeatString("01"  , 2)).toBe("0101");
		expect(viewHelper.repeatString("0123", 4)).toBe("0123012301230123");
		// 繰り返し回数が0以下
		expect(viewHelper.repeatString("0",  0)).toBe("");
		expect(viewHelper.repeatString("0", -1)).toBe("");
	});
	it("zeroPadding", function(){
		// 整数
		expect(viewHelper.zeroPadding(1, 2)).toBe('01');
		expect(viewHelper.zeroPadding(3, 4)).toBe('0003');
		// 文字列
		expect(viewHelper.zeroPadding(  "F", 2)).toBe('0F');
		expect(viewHelper.zeroPadding("ABC", 4)).toBe('0ABC');
		// 入力が桁数よりも大きい場合
		// 欠損せずに出力される
		expect(viewHelper.zeroPadding(     256, 2)).toBe('256');
		expect(viewHelper.zeroPadding("ABCDEF", 4)).toBe('ABCDEF');
		// 入力が無効値の場合
		expect(viewHelper.zeroPadding(null, 2)).toBe('00');
	});
	it("getStrDate", function(){
		// 非常に紛らわしいがDateクラスの月は1減算して指定
		expect(viewHelper.getStrDate(new Date(2013, 3, 19))).toBe('2013-04-19');
		expect(viewHelper.getStrDate(new Date(2013, 6, 2), '/')).toBe('2013/07/02');
	});
	it("getStrTime", function(){
		expect(viewHelper.getStrTime(new Date(0, 0, 0, 7, 7, 7))).toBe('07:07:07');
		expect(viewHelper.getStrTime(new Date(0, 0, 0, 17, 34, 37))).toBe('17:34:37');
		expect(viewHelper.getStrTime(new Date(0, 0, 0, 18, 45, 36), '')).toBe('184536');
	});
	it("reloadImg", function(){
		const $img = $("<img/>");
		$img.attr("src", "http://127.0.0.1:60000/live.avi");
		let url = $img.attr("src");
		expect(url.length).toBe(31); // 31(http://127.0.0.1:60000/live.avi)
		viewHelper.reloadImg($img); // パラメータ付加
		url = $img.attr("src");
		expect(url.length).toBe(46); // 31 + 15(?YYYYMMDDhhmmss)
		viewHelper.reloadImg($img); // パラメータ付加(2回目)
		url = $img.attr("src");
		expect(url.length).toBe(46); // 31 + 15(?YYYYMMDDhhmmss)
		$img.removeAttr("src"); // これを忘れるとWebブラウザが上記のURLにアクセスしてしまう
	});
	it("getDefMessage", function(){
		expect(viewHelper.getDefMessage('1')).toBe('one');
		expect(viewHelper.getDefMessage('2')).toBe('two');
		expect(viewHelper.getDefMessage('3')).toBe(''); // 未定義は空文字が返る
	});
});
describe("asyncHelper", function() {
	it("delay", function(done){
		let value = 0;

		const delay10 = asyncHelper.delay(10);
		delay10.then(() => {
			++value;
		});

		expect(value).toBe(0); // 0 のまま

		asyncHelper.delay(10).then(() => {
			expect(value).toBe(1); // 1 に増えるはず
		});
		asyncHelper.delay(20).then(() => {
			expect(value).toBe(1); // 1 のまま
		});
		asyncHelper.delay(30).then(() => {
			expect(value).toBe(1); // 1 のまま
		});
		asyncHelper.delay(50).then(() => {
			expect(value).toBe(1); // 1 のまま
			done();
		});
	});
	it("delay(stop)", function(done){
		let value = 0;

		const delay10 = asyncHelper.delay(10);
		delay10.then(() => {
			++value;
		}).catch(() => {
			// 何もしない
		});
		delay10.stop();

		expect(value).toBe(0); // 0 のまま

		asyncHelper.delay(10).then(() => {
			expect(value).toBe(0); // 0 のまま
		});
		asyncHelper.delay(20).then(() => {
			expect(value).toBe(0); // 0 のまま
		});
		asyncHelper.delay(30).then(() => {
			expect(value).toBe(0); // 0 のまま
		});
		asyncHelper.delay(50).then(() => {
			expect(value).toBe(0); // 0 のまま
			done();
		});
	});
	it("delay(restart)", function(done){
		let value = 0;

		const delay10 = asyncHelper.delay(10);
		delay10.then(() => {
			++value;
		});

		expect(value).toBe(0); // 0 のまま

		asyncHelper.delay( 7).then(() => {
			delay10.restart();
		});
		asyncHelper.delay(10).then(() => {
			expect(value).toBe(0); // 0 のまま
		});
		asyncHelper.delay(14).then(() => {
			delay10.restart();
		});
		asyncHelper.delay(20).then(() => {
			expect(value).toBe(0); // 0 のまま
		});
		asyncHelper.delay(30).then(() => {
			expect(value).toBe(1); // 1 に増えるはず
		});
		asyncHelper.delay(50).then(() => {
			expect(value).toBe(1); // 1 のまま
			done();
		});
	});
	it("interval", function(done){
		let value = 0;

		const interval10 = asyncHelper.interval(10, () => {
			++value;
			if (3 === value) {
				interval10.stop(); // 停止
			}
		});
		interval10.catch(() => {
			expect(value).toBe(3); // 停止した時は 3 
		});

		expect(value).toBe(0); // 0 のまま

		asyncHelper.delay(10).then(() => {
			expect(value).toBe(1); // 1 に増えるはず
		});
		asyncHelper.delay(20).then(() => {
			expect(value).toBe(2); // 2 に増えるはず
		});
		asyncHelper.delay(30).then(() => {
			expect(value).toBe(3); // 3 に増えるはず
		});
		asyncHelper.delay(50).then(() => {
			expect(value).toBe(3); // 停止したので 3 のまま
			done();
		});
	});
});
describe("ajaxHelper", function() {
	it("getFailedArray(empty)", function(){
		const lines = ajaxHelper.getFailedArray();

		expect(lines.length).toBe(4);
		expect(lines[0]).toBeUndefined();
		expect(lines[1]).toBe(0);
		expect(lines[2]).toBeUndefined();
		expect(lines[3]).toBe("");
	});
	it("getFailedArray(404)", function(){
		const jqXHR = {
			status: 404,
		};
		const textStatus = "error";
		const errorThrown = "Not Found";
		const lines = ajaxHelper.getFailedArray(jqXHR, textStatus, errorThrown);

		expect(lines.length).toBe(4);
		expect(lines[0]).toBe("error");
		expect(lines[1]).toBe(404);
		expect(lines[2]).toBe("Not Found");
		expect(lines[3]).toBe("");
	});
	it("getFailedArray(RequestJson)", function(){
		const jqXHR = {
			status: 404,
		};
		const textStatus = "error";
		const errorThrown = "Not Found";
		const requestJson = {
			data: "OK",
		};
		const lines = ajaxHelper.getFailedArray(jqXHR, textStatus, errorThrown, requestJson);

		expect(lines.length).toBe(4);
		expect(lines[0]).toBe("error");
		expect(lines[1]).toBe(404);
		expect(lines[2]).toBe("Not Found");
		expect(lines[3]).toBe('{"data":"OK"}');
	});
});
describe("becky.ID", function() {
	it("createRequestID", function() {
		const arrayRequestID = [];
		for (let i = 0; i < 1000; ++i) {
			arrayRequestID.push(becky.ID.createRequestID());
		}
		let isDuplicate = false;
		{
			const mapRequestID = {};
			arrayRequestID.forEach(aRequestID => {
				if (isDuplicate) {
					return;
				}
				if (!modelHelper.isUndefined(mapRequestID[aRequestID])) {
					isDuplicate = true;
					return;
				}
				mapRequestID[aRequestID] = 0;
			});
		}
		expect(isDuplicate).toBeFalsy ('要求 ID が重複した');
	});
});
describe("becky.dataSync", function() {
	let observerDataValue = null;

	/*!
	 * @brief 前準備
	 *
	 * @return Promise 
	 */
	async function _prepare()
	{
		if (modelHelper.isNull(observerDataValue)) {
			observerDataValue = becky.dataSync.createChangeEvent();
		}
	}

	it("data-text", function(done){
		_prepare().then(() => {
			const txt = $("#becky_dataSync_data-text").text();
			expect(txt).toBe("1");
			done();
		});
	});
	it("data-fround", function(done){
		_prepare().then(() => {
			const txt = $("#becky_dataSync_data-fround").text();
			const val = parseFloat(txt);
			expect(val).toBe(0.50);
			done();
		});
	});
	it("data-fbankersRound", function(done){
		_prepare().then(() => {
			const txt = $("#becky_dataSync_data-fbankers-round").text();
			const val = parseFloat(txt);
			expect(val).toBe(0.25);
			done();
		});
	});
	it("data-fixed", function(done){
		_prepare().then(() => {
			const txt = $("#becky_dataSync_data-fixed").text();
			expect(txt).toBe("0.10");
			done();
		});
	});
	it("data-class-plus", function(done){
		_prepare().then(() => {
			const txt = $("#becky_dataSync_data-class-plus").text();
			expect(txt).toBe("+2");
			done();
		});
	});
	it("data-prefix", function(done){
		_prepare().then(() => {
			const txt = $("#becky_dataSync_data-prefix").text();
			expect(txt).toBe("fps3");
			done();
		});
	});
	it("data-suffix", function(done){
		_prepare().then(() => {
			const txt = $("#becky_dataSync_data-suffix").text();
			expect(txt).toBe("4ms");
			done();
		});
	});
	it("changeValue", function(done){
		// data-text に値を設定しても即座に変更イベントは発生しない
		const $target = $("#becky_dataSync_data-text");
		_prepare().then(() => {
			$target.attr("data-text", 10);
		}).then(() => {
			expect($target.text()).toBe("10");
		}).then(() => {
			$target.attr("data-text", 20);
		}).then(() => {
			expect($target.text()).toBe("20");
			done();
		});
	});
});
describe("becky.WebStorage.local", function(){
	it("setString/getString/removeItem", function() {
		const storageKey = "test.string";
		becky.WebStorage.local.setString(storageKey, "abc");

		const value = becky.WebStorage.local.getString(storageKey);
		expect(value).toBe("abc");

		becky.WebStorage.local.removeItem(storageKey);

		const valueNull = becky.WebStorage.local.getString(storageKey);
		expect(valueNull).toBeNull();
	});
	it("setJson/getJson/removeItem", function() {
		const storageKey = "test.Json";
		becky.WebStorage.local.setJson(storageKey, { a: 0, b: 1, c:2, });

		const value = becky.WebStorage.local.getJson(storageKey);
		expect(value).toEqual({ a: 0, b: 1, c:2, });

		becky.WebStorage.local.removeItem(storageKey);

		const valueNull = becky.WebStorage.local.getJson(storageKey);
		expect(valueNull).toBeNull();
	});
	it("IO(string)", function() {
		const webStorageIO = becky.WebStorage.local.IO("test.string");
		webStorageIO.setString("abc2");
		const value = webStorageIO.getString();
		expect(value).toBe("abc2");

		webStorageIO.removeItem();

		const valueNull = webStorageIO.getString();
		expect(valueNull).toBeNull();
	});
	it("IO(Json)", function() {
		const webStorageIO = becky.WebStorage.local.IO("test.Json");
		webStorageIO.setJson({ a: 1, b: 2, c:3, });
		const value = webStorageIO.getJson();
		expect(value).toEqual({ a: 1, b: 2, c:3, });

		webStorageIO.removeItem();

		const valueNull = webStorageIO.getJson();
		expect(valueNull).toBeNull();
	});
});
describe("becky.jsonHelper", function(){
	it("isEquals(true)", function(){
		const json1 = {
			X: 1,
			Y: 2,
			List: {
				X: 1,
				Y: 2,
			},
		};
		const json2 = {
			X: 1,
			Y: 2,
			List: {
				Y: 2,
				X: 1,
			},
		};
		expect(becky.jsonHelper.isEquals(json1, json2)).toBeTruthy();
	});
	it("isEquals(false)", function(){
		const json1 = {
			X: 1,
			Y: 2,
			List: {
				X: 1,
				Y: 2,
			},
		};
		const json2 = {
			X: 1,
			Y: 2,
			List: {
				X: 1,
				Y: 0,
			},
		};
		expect(becky.jsonHelper.isEquals(json1, json2)).toBeFalsy();
	});
	it("normalization", function(){
		const json = {
			stringHoge    :  "Hoge",
			stringTrueLow :  "true",
			stringFalseLow: "false",
			stringTrueUp  :  "TRUE",
			stringFalseUp : "FALSE",
			stringInt2    :     "2",
			stringIntM5   :    "-5",
			stringFloat34 :   "3.4",
			stringFloatM67:  "-6.7",
			integer0      :       0,
			integer1      :       1,
			sub: {
				stringHoge    :  "Hoge",
				stringTrueLow :  "true",
				stringFalseLow: "false",
				stringTrueUp  :  "TRUE",
				stringFalseUp : "FALSE",
				stringInt2    :     "2",
				stringIntM5   :    "-5",
				stringFloat34 :   "3.4",
				stringFloatM67:  "-6.7",
				integer0      :       0,
				integer1      :       1,
				sub: {
					stringHoge    :  "Hoge",
					stringTrueLow :  "true",
					stringFalseLow: "false",
					stringTrueUp  :  "TRUE",
					stringFalseUp : "FALSE",
					stringInt2    :     "2",
					stringIntM5   :    "-5",
					stringFloat34 :   "3.4",
					stringFloatM67:  "-6.7",
					integer0      :       0,
					integer1      :       1,
				},
			},
		};
		becky.jsonHelper.normalization(json);

		const expectedJson = {
			stringHoge    :  "Hoge",
			stringTrueLow :    true,
			stringFalseLow:   false,
			stringTrueUp  :    true,
			stringFalseUp :   false,
			stringInt2    :       2,
			stringIntM5   :      -5,
			stringFloat34 :     3.4,
			stringFloatM67:    -6.7,
			integer0      :       0,
			integer1      :       1,
			sub: {
				stringHoge    :  "Hoge",
				stringTrueLow :    true,
				stringFalseLow:   false,
				stringTrueUp  :    true,
				stringFalseUp :   false,
				stringInt2    :       2,
				stringIntM5   :      -5,
				stringFloat34 :     3.4,
				stringFloatM67:    -6.7,
				integer0      :       0,
				integer1      :       1,
				sub: {
					stringHoge    :  "Hoge",
					stringTrueLow :    true,
					stringFalseLow:   false,
					stringTrueUp  :    true,
					stringFalseUp :   false,
					stringInt2    :       2,
					stringIntM5   :      -5,
					stringFloat34 :     3.4,
					stringFloatM67:    -6.7,
					integer0      :       0,
					integer1      :       1,
				},
			},
		};
		// オブジェクトや配列の各要素をそれぞれ比較して、すべて同じであることをチェックする
		expect(json).toEqual(expectedJson);
	});
	it("normalization(ExclusionKeys)", function(){
		const json = {
			stringHoge    :  "Hoge",
			stringTrueLow :  "true",
			stringFalseLow: "false",
			stringTrueUp  :  "TRUE",
			stringFalseUp : "FALSE",
			stringInt2    :     "2",
			stringIntM5   :    "-5",
			stringFloat34 :   "3.4",
			stringFloatM67:  "-6.7",
			integer0      :       0,
			integer1      :       1,
			sub: {
				stringHoge    :  "Hoge",
				stringTrueLow :  "true",
				stringFalseLow: "false",
				stringTrueUp  :  "TRUE",
				stringFalseUp : "FALSE",
				stringInt2    :     "2",
				stringIntM5   :    "-5",
				stringFloat34 :   "3.4",
				stringFloatM67:  "-6.7",
				integer0      :       0,
				integer1      :       1,
				sub: {
					stringHoge    :  "Hoge",
					stringTrueLow :  "true",
					stringFalseLow: "false",
					stringTrueUp  :  "TRUE",
					stringFalseUp : "FALSE",
					stringInt2    :     "2",
					stringIntM5   :    "-5",
					stringFloat34 :   "3.4",
					stringFloatM67:  "-6.7",
					integer0      :       0,
					integer1      :       1,
				},
			},
		};
		becky.jsonHelper.normalization(json, [ "stringTrueLow", "stringFalseUp", "stringIntM5", "stringFloat34" ]);

		const expectedJson = {
			stringHoge    :  "Hoge",
			stringTrueLow :  "true",
			stringFalseLow:   false,
			stringTrueUp  :    true,
			stringFalseUp : "FALSE",
			stringInt2    :       2,
			stringIntM5   :    "-5",
			stringFloat34 :   "3.4",
			stringFloatM67:    -6.7,
			integer0      :       0,
			integer1      :       1,
			sub: {
				stringHoge    :  "Hoge",
				stringTrueLow :  "true",
				stringFalseLow:   false,
				stringTrueUp  :    true,
				stringFalseUp : "FALSE",
				stringInt2    :       2,
				stringIntM5   :    "-5",
				stringFloat34 :   "3.4",
				stringFloatM67:    -6.7,
				integer0      :       0,
				integer1      :       1,
				sub: {
					stringHoge    :  "Hoge",
					stringTrueLow :  "true",
					stringFalseLow:   false,
					stringTrueUp  :    true,
					stringFalseUp : "FALSE",
					stringInt2    :       2,
					stringIntM5   :    "-5",
					stringFloat34 :   "3.4",
					stringFloatM67:    -6.7,
					integer0      :       0,
					integer1      :       1,
				},
			},
		};
		// オブジェクトや配列の各要素をそれぞれ比較して、すべて同じであることをチェックする
		expect(json).toEqual(expectedJson);
	});
	it("normalization(PrefixDigit)", function(){
		const json = {
			string4Dots    :  "4 Dots",
		};
		becky.jsonHelper.normalization(json);

		const expectedJson = {
			string4Dots    :  "4 Dots",
		};
		// オブジェクトや配列の各要素をそれぞれ比較して、すべて同じであることをチェックする
		expect(json).toEqual(expectedJson);
	});
});
describe("becky.log", function(){
	// OSの時計を(UTC+09:00)日本に設定してからテスト
	it("toISO8601String(Tokyo)", function(){
		const date = new Date("Wed May 16 2018 10:22:56 GMT+0900 (東京 (標準時))");
		const strISO8601 = becky.log.toISO8601String(date);
		expect(strISO8601).toBe("20180516T102256+0900");
	});
	// OSの時計を(UTC)協定世界時に設定してからテスト
	//it("toISO8601String(UTC)", function(){
	//	const date = new Date("Thu May 17 2018 02:02:06 GMT+0000 (GMT Standard Time)");
	//	const strISO8601 = becky.log.toISO8601String(date);
	//	expect(strISO8601).toBe("20180517T020206+0000");
	//});
	// OSの時計を(UTC-03:30)ニューファンドランドに設定してからテスト
	//it("toISO8601String(NST)", function(){
	//	const date = new Date("Wed May 16 2018 23:33:54 GMT-0230 (Local Daylight Time)");
	//	const strISO8601 = becky.log.toISO8601String(date);
	//	expect(strISO8601).toBe("20180516T233354-0230");
	//});

	// OSの時計を(UTC+09:00)日本に設定してからテスト
	it("toISO8601ExtString(Tokyo)", function(){
		const date = new Date("Wed May 16 2018 10:22:56 GMT+0900 (東京 (標準時))");
		const strISO8601Ext = becky.log.toISO8601ExtString(date);
		expect(strISO8601Ext).toBe("2018-05-16T10:22:56+09:00");
	});
});
describe("subjective.js", function(){
	it("diffChecker00", function(){
		const diffChecker = {
			isExamDistance   : false,
			isCrossCylinderRG: false,
			//! 差があるか？
			someDiff: function(){
				return Object.keys(this).some(function(propertyName_){
					if (!modelHelper.isBoolean(this[propertyName_])) {
						return false;
					}
					return this[propertyName_];
				}, this);
			},
		};
		expect(diffChecker.someDiff()).toBeFalsy();
	});
	it("diffChecker01", function(){
		const diffChecker = {
			isExamDistance   : false,
			isCrossCylinderRG:  true,
			//! 差があるか？
			someDiff: function(){
				return Object.keys(this).some(function(propertyName_){
					if (!modelHelper.isBoolean(this[propertyName_])) {
						return false;
					}
					return this[propertyName_];
				}, this);
			},
		};
		expect(diffChecker.someDiff()).toBeTruthy();
	});
	it("diffChecker10", function(){
		const diffChecker = {
			isExamDistance   :  true,
			isCrossCylinderRG: false,
			//! 差があるか？
			someDiff: function(){
				return Object.keys(this).some(function(propertyName_){
					if (!modelHelper.isBoolean(this[propertyName_])) {
						return false;
					}
					return this[propertyName_];
				}, this);
			},
		};
		expect(diffChecker.someDiff()).toBeTruthy();
	});
	it("diffChecker11", function(){
		const diffChecker = {
			isExamDistance   :  true,
			isCrossCylinderRG:  true,
			//! 差があるか？
			someDiff: function(){
				return Object.keys(this).some(function(propertyName_){
					if (!modelHelper.isBoolean(this[propertyName_])) {
						return false;
					}
					return this[propertyName_];
				}, this);
			},
		};
		expect(diffChecker.someDiff()).toBeTruthy();
	});
});