describe("becky.WebSocket.stack", function() {

	/*!
	 * @brief 正常なデータを得る(架空の設定)
	 *
	 * @return object(json)
	 */
	function _getJsonOK()
	{
		return { test: "OK" };
	}

	/*!
	 * @brief 不正なデータを得る(架空の設定)
	 *
	 * @return object(json)
	 */
	function _getJsonNG()
	{
		return { test: "NG" };
	}

	it("post(ResultJson01)", function(done) {
		test.becky.WebSocket.prepare().then(() => {
			const arrayCalled = [];

			becky.WebSocket.stack.scope(beckyWebSocketStack => {
				becky.WebSocket.stack.post(beckyWebSocketStack, _getJsonNG()).then(requestJson => {
					arrayCalled.push(1);
				}).catch(() => {
					arrayCalled.push(2);
				}).then(() => {
					arrayCalled.push(3);
				});

				becky.WebSocket.stack.post(beckyWebSocketStack, _getJsonOK()).then(requestJson => {
					arrayCalled.push(4);
					expect(requestJson).not.toBeNull();
					expect(requestJson.return).toBeTruthy("結果JSONの return が false だった");
				}).catch(() => {
					arrayCalled.push(5);
				}).then(() => {
					arrayCalled.push(6);
				});

				expect(arrayCalled.length).toBe(0); // まだ呼び出されていない想定
			});

			asyncHelper.delay(15).then(() => {
				expect(arrayCalled.length).toBe(2); // 呼び出し回数
				expect(arrayCalled[0]    ).toBe(4);
				expect(arrayCalled[1]    ).toBe(6);
				// arrayCalled[2, 3]が呼び出されていないのが間違いの様に思えるが、
				// 次の becky.WebSocket.stack.post が成功(done)している為、最初のは無かった事にされる。
				done();
			});
		});
	});

	it("post(ResultJson10)", function(done) {
		test.becky.WebSocket.prepare().then(() => {
			const arrayCalled = [];

			becky.WebSocket.stack.scope(beckyWebSocketStack => {
				becky.WebSocket.stack.post(beckyWebSocketStack, _getJsonOK()).then(requestJson => {
					arrayCalled.push(1);
					expect(requestJson).not.toBeNull();
					expect(requestJson.return).toBeTruthy("結果JSONの return が false だった");
				}).catch(() => {
					arrayCalled.push(2);
				}).then(() => {
					arrayCalled.push(3);
				});

				becky.WebSocket.stack.post(beckyWebSocketStack, _getJsonNG()).then(() => {
					arrayCalled.push(4);
				}).catch(requestJson => {
					arrayCalled.push(5);
					expect(requestJson).not.toBeNull();
					expect(requestJson.return).toBeFalsy("結果JSONの return が true だった");
				}).then(() => {
					arrayCalled.push(6);
				});

				expect(arrayCalled.length).toBe(0); // まだ呼び出されていない想定
			});

			asyncHelper.delay(15).then(() => {
				expect(arrayCalled.length).toBe(4); // 呼び出し回数
				expect(arrayCalled[0]    ).toBe(1);
				expect(arrayCalled[1]    ).toBe(5);
				expect(arrayCalled[2]    ).toBe(3);
				expect(arrayCalled[3]    ).toBe(6);
				done();
			});
		});
	});

	// 成功時呼び出し関数 - 全て失敗
	it("post(Succeed_000)", function(done) {
		test.becky.WebSocket.prepare().then(() => {
			const arrayCalled = [];

			becky.WebSocket.stack.scope(beckyWebSocketStack => {
				becky.WebSocket.stack.post(beckyWebSocketStack, _getJsonNG()).then(() => {
					arrayCalled.push(1);
				}).catch(() => {
					// このテストでは何もしない
				});

				becky.WebSocket.stack.post(beckyWebSocketStack, _getJsonNG()).then(() => {
					arrayCalled.push(2);
				}).catch(() => {
					// このテストでは何もしない
				});

				becky.WebSocket.stack.post(beckyWebSocketStack, _getJsonNG()).then(() => {
					arrayCalled.push(3);
				}).catch(() => {
					// このテストでは何もしない
				});

				expect(arrayCalled.length).toBe(0); // まだ呼び出されていない想定
			});

			asyncHelper.delay(15).then(() => {
				expect(arrayCalled.length).toBe(0); // 呼び出し回数は0回
				done();
			});
		});
	});

	// 成功時呼び出し関数 - 1回成功
	it("post(Succeed_001)", function(done) {
		test.becky.WebSocket.prepare().then(() => {
			const arrayCalled = [];

			becky.WebSocket.stack.scope(beckyWebSocketStack => {
				becky.WebSocket.stack.post(beckyWebSocketStack, _getJsonOK()).then(() => {
					arrayCalled.push(1);
				});

				becky.WebSocket.stack.post(beckyWebSocketStack, _getJsonNG()).then(() => {
					arrayCalled.push(2);
				}).catch(() => {
					// このテストでは何もしない
				});

				becky.WebSocket.stack.post(beckyWebSocketStack, _getJsonNG()).then(() => {
					arrayCalled.push(3);
				}).catch(() => {
					// このテストでは何もしない
				});

				expect(arrayCalled.length).toBe(0); // まだ呼び出されていない想定
			});

			asyncHelper.delay(15).then(() => {
				expect(arrayCalled.length).toBe(1); // 呼び出し回数
				expect(arrayCalled[0]    ).toBe(1);
				done();
			});
		});
	});

	// 成功時呼び出し関数 - 1回成功
	it("post(Succeed_010)", function(done) {
		test.becky.WebSocket.prepare().then(() => {
			const arrayCalled = [];

			becky.WebSocket.stack.scope(beckyWebSocketStack => {
				becky.WebSocket.stack.post(beckyWebSocketStack, _getJsonNG()).then(() => {
					arrayCalled.push(1);
				});

				becky.WebSocket.stack.post(beckyWebSocketStack, _getJsonOK()).then(() => {
					arrayCalled.push(2);
				});

				becky.WebSocket.stack.post(beckyWebSocketStack, _getJsonNG()).then(() => {
					arrayCalled.push(3);
				}).catch(() => {
					// このテストでは何もしない
				});

				expect(arrayCalled.length).toBe(0); // まだ呼び出されていない想定
			});

			asyncHelper.delay(15).then(() => {
				expect(arrayCalled.length).toBe(1); // 呼び出し回数
				expect(arrayCalled[0]    ).toBe(2);
				done();
			});
		});
	});

	// 成功時呼び出し関数 - 2回成功
	it("post(Succeed_011)", function(done) {
		test.becky.WebSocket.prepare().then(() => {
			const arrayCalled = [];

			becky.WebSocket.stack.scope(beckyWebSocketStack => {
				becky.WebSocket.stack.post(beckyWebSocketStack, _getJsonOK()).then(() => {
					arrayCalled.push(1);
				});

				becky.WebSocket.stack.post(beckyWebSocketStack, _getJsonOK()).then(() => {
					arrayCalled.push(2);
				});

				becky.WebSocket.stack.post(beckyWebSocketStack, _getJsonNG()).then(() => {
					arrayCalled.push(3);
				}).catch(() => {
					// このテストでは何もしない
				});

				expect(arrayCalled.length).toBe(0); // まだ呼び出されていない想定
			});

			asyncHelper.delay(15).then(() => {
				expect(arrayCalled.length).toBe(2); // 呼び出し回数
				expect(arrayCalled[0]    ).toBe(1);
				expect(arrayCalled[1]    ).toBe(2);
				done();
			});
		});
	});

	// 成功時呼び出し関数 - 1回成功
	it("post(Succeed_100)", function(done) {
		test.becky.WebSocket.prepare().then(() => {
			const arrayCalled = [];

			becky.WebSocket.stack.scope(beckyWebSocketStack => {
				becky.WebSocket.stack.post(beckyWebSocketStack, _getJsonNG()).then(() => {
					arrayCalled.push(1);
				});

				becky.WebSocket.stack.post(beckyWebSocketStack, _getJsonNG()).then(() => {
					arrayCalled.push(2);
				});

				becky.WebSocket.stack.post(beckyWebSocketStack, _getJsonOK()).then(() => {
					arrayCalled.push(3);
				});

				expect(arrayCalled.length).toBe(0); // まだ呼び出されていない想定
			});

			asyncHelper.delay(15).then(() => {
				expect(arrayCalled.length).toBe(1); // 呼び出し回数
				expect(arrayCalled[0]    ).toBe(3);
				done();
			});
		});
	});

	// 成功時呼び出し関数 - 2回成功
	it("post(Succeed_101)", function(done) {
		test.becky.WebSocket.prepare().then(() => {
			const arrayCalled = [];

			becky.WebSocket.stack.scope(beckyWebSocketStack => {
				becky.WebSocket.stack.post(beckyWebSocketStack, _getJsonOK()).then(() => {
					arrayCalled.push(1);
				});

				becky.WebSocket.stack.post(beckyWebSocketStack, _getJsonNG()).then(() => {
					arrayCalled.push(2);
				});

				becky.WebSocket.stack.post(beckyWebSocketStack, _getJsonOK()).then(() => {
					arrayCalled.push(3);
				});

				expect(arrayCalled.length).toBe(0); // まだ呼び出されていない想定
			});

			asyncHelper.delay(15).then(() => {
				expect(arrayCalled.length).toBe(2); // 呼び出し回数
				expect(arrayCalled[0]    ).toBe(1);
				expect(arrayCalled[1]    ).toBe(3);
				done();
			});
		});
	});

	// 成功時呼び出し関数 - 2回成功
	it("post(Succeed_110)", function(done) {
		test.becky.WebSocket.prepare().then(() => {
			const arrayCalled = [];

			becky.WebSocket.stack.scope(beckyWebSocketStack => {
				becky.WebSocket.stack.post(beckyWebSocketStack, _getJsonNG()).then(() => {
					arrayCalled.push(1);
				});

				becky.WebSocket.stack.post(beckyWebSocketStack, _getJsonOK()).then(() => {
					arrayCalled.push(2);
				});

				becky.WebSocket.stack.post(beckyWebSocketStack, _getJsonOK()).then(() => {
					arrayCalled.push(3);
				});

				expect(arrayCalled.length).toBe(0); // まだ呼び出されていない想定
			});

			asyncHelper.delay(15).then(() => {
				expect(arrayCalled.length).toBe(2); // 呼び出し回数
				expect(arrayCalled[0]    ).toBe(2);
				expect(arrayCalled[1]    ).toBe(3);
				done();
			});
		});
	});

	// 成功時呼び出し関数 - 全て成功
	it("post(Succeed_111)", function(done) {
		test.becky.WebSocket.prepare().then(() => {
			const arrayCalled = [];

			becky.WebSocket.stack.scope(beckyWebSocketStack => {
				becky.WebSocket.stack.post(beckyWebSocketStack, _getJsonOK()).then(() => {
					arrayCalled.push(1);
				});

				becky.WebSocket.stack.post(beckyWebSocketStack, _getJsonOK()).then(() => {
					arrayCalled.push(2);
				});

				becky.WebSocket.stack.post(beckyWebSocketStack, _getJsonOK()).then(() => {
					arrayCalled.push(3);
				});

				expect(arrayCalled.length).toBe(0); // まだ呼び出されていない想定
			});

			asyncHelper.delay(15).then(() => {
				expect(arrayCalled.length).toBe(3); // 呼び出し回数
				expect(arrayCalled[0]    ).toBe(1);
				expect(arrayCalled[1]    ).toBe(2);
				expect(arrayCalled[2]    ).toBe(3);
				done();
			});
		});
	});

	// 失敗時呼び出し関数 - 全て失敗
	it("post(Failed_000)", function(done) {
		test.becky.WebSocket.prepare().then(() => {
			const arrayCalled = [];

			becky.WebSocket.stack.scope(beckyWebSocketStack => {
				becky.WebSocket.stack.post(beckyWebSocketStack, _getJsonNG()).catch(() => {
					arrayCalled.push(1);
				});

				becky.WebSocket.stack.post(beckyWebSocketStack, _getJsonNG()).catch(() => {
					arrayCalled.push(2);
				});

				becky.WebSocket.stack.post(beckyWebSocketStack, _getJsonNG()).catch(() => {
					arrayCalled.push(3);
				});

				expect(arrayCalled.length).toBe(0); // まだ呼び出されていない想定
			});

			asyncHelper.delay(15).then(() => {
				expect(arrayCalled.length).toBe(3); // 呼び出し回数
				expect(arrayCalled[0]    ).toBe(3);
				expect(arrayCalled[1]    ).toBe(2);
				expect(arrayCalled[2]    ).toBe(1);
				done();
			});
		});
	});

	// 失敗時呼び出し関数 - 1回成功
	it("post(Failed_001)", function(done) {
		test.becky.WebSocket.prepare().then(() => {
			const arrayCalled = [];

			becky.WebSocket.stack.scope(beckyWebSocketStack => {
				becky.WebSocket.stack.post(beckyWebSocketStack, _getJsonOK()).catch(() => {
					arrayCalled.push(1);
				});

				becky.WebSocket.stack.post(beckyWebSocketStack, _getJsonNG()).catch(() => {
					arrayCalled.push(2);
				});

				becky.WebSocket.stack.post(beckyWebSocketStack, _getJsonNG()).catch(() => {
					arrayCalled.push(3);
				});

				expect(arrayCalled.length).toBe(0); // まだ呼び出されていない想定
			});

			asyncHelper.delay(15).then(() => {
				expect(arrayCalled.length).toBe(2); // 呼び出し回数
				expect(arrayCalled[0]    ).toBe(3);
				expect(arrayCalled[1]    ).toBe(2);
				done();
			});
		});
	});

	// 失敗時呼び出し関数 - 1回成功
	it("post(Failed_010)", function(done) {
		test.becky.WebSocket.prepare().then(() => {
			const arrayCalled = [];

			becky.WebSocket.stack.scope(beckyWebSocketStack => {
				becky.WebSocket.stack.post(beckyWebSocketStack, _getJsonNG()).catch(() => {
					arrayCalled.push(1);
				});

				becky.WebSocket.stack.post(beckyWebSocketStack, _getJsonOK()).catch(() => {
					arrayCalled.push(2);
				});

				becky.WebSocket.stack.post(beckyWebSocketStack, _getJsonNG()).catch(() => {
					arrayCalled.push(3);
				});

				expect(arrayCalled.length).toBe(0); // まだ呼び出されていない想定
			});

			asyncHelper.delay(15).then(() => {
				expect(arrayCalled.length).toBe(1); // 呼び出し回数
				expect(arrayCalled[0]    ).toBe(3);
				done();
			});
		});
	});

	// 失敗時呼び出し関数 - 2回成功
	it("post(Failed_011)", function(done) {
		test.becky.WebSocket.prepare().then(() => {
			const arrayCalled = [];

			becky.WebSocket.stack.scope(beckyWebSocketStack => {
				becky.WebSocket.stack.post(beckyWebSocketStack, _getJsonOK()).catch(() => {
					arrayCalled.push(1);
				});

				becky.WebSocket.stack.post(beckyWebSocketStack, _getJsonOK()).catch(() => {
					arrayCalled.push(2);
				});

				becky.WebSocket.stack.post(beckyWebSocketStack, _getJsonNG()).catch(() => {
					arrayCalled.push(3);
				});

				expect(arrayCalled.length).toBe(0); // まだ呼び出されていない想定
			});

			asyncHelper.delay(15).then(() => {
				expect(arrayCalled.length).toBe(1); // 呼び出し回数
				expect(arrayCalled[0]    ).toBe(3);
				done();
			});
		});
	});

	// 失敗時呼び出し関数 - 1回成功
	it("post(Failed_100)", function(done) {
		test.becky.WebSocket.prepare().then(() => {
			const arrayCalled = [];

			becky.WebSocket.stack.scope(beckyWebSocketStack => {
				becky.WebSocket.stack.post(beckyWebSocketStack, _getJsonNG()).catch(() => {
					arrayCalled.push(1);
				});

				becky.WebSocket.stack.post(beckyWebSocketStack, _getJsonNG()).catch(() => {
					arrayCalled.push(2);
				});

				becky.WebSocket.stack.post(beckyWebSocketStack, _getJsonOK()).catch(() => {
					arrayCalled.push(3);
				});

				expect(arrayCalled.length).toBe(0); // まだ呼び出されていない想定
			});

			asyncHelper.delay(15).then(() => {
				expect(arrayCalled.length).toBe(0); // 呼び出し回数は0回
				done();
			});
		});
	});

	// 失敗時呼び出し関数 - 2回成功
	it("post(Failed_101)", function(done) {
		test.becky.WebSocket.prepare().then(() => {
			const arrayCalled = [];

			becky.WebSocket.stack.scope(beckyWebSocketStack => {
				becky.WebSocket.stack.post(beckyWebSocketStack, _getJsonOK()).catch(() => {
					arrayCalled.push(1);
				});

				becky.WebSocket.stack.post(beckyWebSocketStack, _getJsonNG()).catch(() => {
					arrayCalled.push(2);
				});

				becky.WebSocket.stack.post(beckyWebSocketStack, _getJsonOK()).catch(() => {
					arrayCalled.push(3);
				});

				expect(arrayCalled.length).toBe(0); // まだ呼び出されていない想定
			});

			asyncHelper.delay(15).then(() => {
				expect(arrayCalled.length).toBe(0); // 呼び出し回数は0回
				done();
			});
		});
	});

	// 失敗時呼び出し関数 - 2回成功
	it("post(Failed_110)", function(done) {
		test.becky.WebSocket.prepare().then(() => {
			const arrayCalled = [];

			becky.WebSocket.stack.scope(beckyWebSocketStack => {
				becky.WebSocket.stack.post(beckyWebSocketStack, _getJsonNG()).catch(() => {
					arrayCalled.push(1);
				});

				becky.WebSocket.stack.post(beckyWebSocketStack, _getJsonOK()).catch(() => {
					arrayCalled.push(2);
				});

				becky.WebSocket.stack.post(beckyWebSocketStack, _getJsonOK()).catch(() => {
					arrayCalled.push(3);
				});

				expect(arrayCalled.length).toBe(0); // まだ呼び出されていない想定
			});

			asyncHelper.delay(15).then(() => {
				expect(arrayCalled.length).toBe(0); // 呼び出し回数は0回
				done();
			});
		});
	});

	// 失敗時呼び出し関数 - 全て成功
	it("post(Failed_111)", function(done) {
		test.becky.WebSocket.prepare().then(() => {
			const arrayCalled = [];

			becky.WebSocket.stack.scope(beckyWebSocketStack => {
				becky.WebSocket.stack.post(beckyWebSocketStack, _getJsonOK()).catch(() => {
					arrayCalled.push(1);
				});

				becky.WebSocket.stack.post(beckyWebSocketStack, _getJsonOK()).catch(() => {
					arrayCalled.push(2);
				});

				becky.WebSocket.stack.post(beckyWebSocketStack, _getJsonOK()).catch(() => {
					arrayCalled.push(3);
				});

				expect(arrayCalled.length).toBe(0); // まだ呼び出されていない想定
			});

			asyncHelper.delay(15).then(() => {
				expect(arrayCalled.length).toBe(0); // 呼び出し回数は0回
				done();
			});
		});
	});

	// 失敗時呼び出し関数 - 連打して全て成功(100回)
	it("post(Failed_RepeatedHitsSucceedAll)", function(done) {
		test.becky.WebSocket.prepare().then(() => {
			const repeatCount = 100;
			let json = _getJsonOK();
			json.value = 0;

			becky.WebSocket.stack.scope(beckyWebSocketStack => {
				for (let i = 0; i < repeatCount; ++i) {
					const jsonBak = $.extend(true, {}, json); // バックアップ
					json = _getJsonOK();
					json.value = i; // 値を書き換える

					becky.WebSocket.stack.post(beckyWebSocketStack, json).catch(() => {
						json = jsonBak; // 失敗時に復元
					});
				}
			});

			asyncHelper.delay(100).then(() => {
				expect(json.value).toBe(repeatCount - 1); // 最後の状態
				done();
			});
		});
	});

	// 失敗時呼び出し関数 - 連打して25回毎に成功(100回)
	it("post(Failed_RepeatedHitsEvery25Count)", function(done) {
		test.becky.WebSocket.prepare().then(() => {
			const repeatCount = 100;
			let json = _getJsonOK();
			json.value = 0;

			becky.WebSocket.stack.scope(beckyWebSocketStack => {
				for (let i = 0; i < repeatCount; ++i) {
					const jsonBak = $.extend(true, {}, json); // バックアップ
					if (0 == i % 25) {
						json = _getJsonOK();
					} else {
						json = _getJsonNG();
					}
					json.value = i; // 値を書き換える

					becky.WebSocket.stack.post(beckyWebSocketStack, json).catch(() => {
						json = jsonBak; // 失敗時に復元
					});
				}
			});

			asyncHelper.delay(100).then(() => {
				expect(json.value).toBe(repeatCount - 25); // 最後の成功
				done();
			});
		});
	});

	// 失敗時呼び出し関数 - 連打して全て失敗(100回)
	it("post(Failed_RepeatedHitsFailedAll)", function(done) {
		test.becky.WebSocket.prepare().then(() => {
			const repeatCount = 100;
			let json = _getJsonNG();
			json.value = 0;

			becky.WebSocket.stack.scope(beckyWebSocketStack => {
				for (let i = 0; i < repeatCount; ++i) {
					const jsonBak = $.extend(true, {}, json); // バックアップ
					json = _getJsonNG();
					json.value = i; // 値を書き換える

					becky.WebSocket.stack.post(beckyWebSocketStack, json).catch(() => {
						json = jsonBak; // 失敗時に復元
					});
				}
			});

			asyncHelper.delay(100).then(() => {
				expect(json.value).toBe(0); // 最初の状態
				done();
			});
		});
	});

});
