describe("becky.operatorLog(Exam)", function() {

	// 成功という結果を返す
	function _fncSucceedResultJsonSuccess()
	{
		const d = $.Deferred();
		d.resolve({ return: true });
		return d.promise();
	}

	// 失敗という結果を返す
	function _fncSucceedResultJsonFailure()
	{
		const d = $.Deferred();
		const lr = {
			return: false,
			error: {
				code   : 418,
				message: "I'm a teapot",
			},
		};
		d.resolve({
			return: false,
			L: lr,
			R: lr,
		 });
		return d.promise();
	}

	// ネットワークのエラーを返す
	function _fncFailed()
	{
		const d = $.Deferred();
		d.reject([ { status: 500 }, "error", "Internal Server Error" ]);
		return d.promise();
	}

	// JSON をエコーする
	function _fncEchoJson(aUri, aJson)
	{
		const d = $.Deferred();
		d.resolve(aJson.json);
		return d.promise();
	}

	function _fncGetWebStorageKey()
	{
		return "unittest.operator.log";
	}

	it("one cycle sequence", function(done) {
		spyOn(becky.async      , "ajax").and.callFake(_fncSucceedResultJsonSuccess);
		spyOn(becky.LeanStartup, "ajax").and.callFake(_fncSucceedResultJsonSuccess);
		spyOn(becky.operatorLog, "getWebStorageKey").and.callFake(_fncGetWebStorageKey);
		(async function(){
			const sessionDateFirst = new Date("2018-05-25T00:00:00+09:00");
			const sessionDateLast  = new Date("2018-05-26T00:00:00+09:00");
			// 被検者情報
			await becky.operatorLog.serialize();
			becky.operatorLog.createOneCycleNode("20180525000000", sessionDateFirst);
			// 他覚検査
			{
				const measurementDateFirst = new Date("2018-05-25T00:01:00+09:00");
				const measurementDateLast  = new Date("2018-05-25T00:01:09+09:00");
				const measurementNode = becky.operatorLog.createObjectiveMeasurementNode(measurementDateFirst);
				const alignmentJson = {
					RangeXY: 0.2  ,
					RangeZ : 0.375,
				};
				{
					const dateFirst = new Date("2018-05-25T00:01:01+09:00");
					const dateLast  = new Date("2018-05-25T00:01:02+09:00");
					await becky.LeanStartup.postWithOperatorLog("ChronosAlignment2",
						alignmentJson, "", dateFirst, measurementNode.children);
					modelHelper.getLast(measurementNode.children).date.last = dateLast; // 終了時間を改竄
				}
				{
					const dateFirst = new Date("2018-05-25T00:01:03+09:00");
					const dateLast  = new Date("2018-05-25T00:01:04+09:00");
					await becky.LeanStartup.postWithOperatorLog("ChronosRef2",
						{ RoughMeasure: true }, "", dateFirst, measurementNode.children);
					modelHelper.getLast(measurementNode.children).date.last = dateLast; // 終了時間を改竄
				}
				{
					const dateFirst = new Date("2018-05-25T00:01:05+09:00");
					const dateLast  = new Date("2018-05-25T00:01:06+09:00");
					await becky.LeanStartup.postWithOperatorLog("ChronosAlignment2",
						alignmentJson, "", dateFirst, measurementNode.children);
					modelHelper.getLast(measurementNode.children).date.last = dateLast; // 終了時間を改竄
				}
				{
					const dateFirst = new Date("2018-05-25T00:01:07+09:00");
					const dateLast  = new Date("2018-05-25T00:01:08+09:00");
					await becky.LeanStartup.postWithOperatorLog("ChronosRef2",
						{ RoughMeasure: false }, "", dateFirst, measurementNode.children);
					modelHelper.getLast(measurementNode.children).date.last = dateLast; // 終了時間を改竄
				}
				becky.operatorLog.pushObjectiveMeasurementNode(measurementNode, measurementDateLast);
			}
			// 自覚検査
			{
				becky.operatorLog.createSubjectiveNode();
				const commandNodes = [];
				{
					const dateFirst = new Date("2018-05-25T00:02:01+09:00");
					const dateLast  = new Date("2018-05-25T00:02:02+09:00");
					await becky.LeanStartup.postWithOperatorLog("Chart",
						{}, "", dateFirst, commandNodes);
					modelHelper.getLast(commandNodes).date.last = dateLast; // 終了時間を改竄
				}
				{
					const dateFirst = new Date("2018-05-25T00:02:03+09:00");
					const dateLast  = new Date("2018-05-25T00:02:04+09:00");
					await becky.LeanStartup.postWithOperatorLog("Phoropter",
						{}, "", dateFirst, commandNodes);
					modelHelper.getLast(commandNodes).date.last = dateLast; // 終了時間を改竄
				}
				becky.operatorLog.pushSubjectiveCommandNodes(commandNodes);
			}
			// 出力
			becky.operatorLog.closeOneCycleNode(sessionDateLast);
			// 検証
			{
				const json = becky.WebStorage.local.getJson(becky.operatorLog.getWebStorageKey());
				expect(json).not.toBeNull();
				const oneCycleJson = modelHelper.getLast(json);
				expect(oneCycleJson).not.toBeNull();

				expect(oneCycleJson.name).toBe("One cycle of eye examination");
				expect(oneCycleJson.date.first).toBe("2018-05-25T00:00:00+09:00");
				expect(oneCycleJson.date.last ).toBe("2018-05-26T00:00:00+09:00");
				expect(oneCycleJson.private.sessionDate).toBe("20180525");
				expect(oneCycleJson.private.sessionTime).toBe("000000");
				expect(oneCycleJson.private.patientID  ).toBe("20180525000000");
				expect(oneCycleJson.children).toBeDefined();
				expect(oneCycleJson.children.length).toBe(2);

				const measurementNode = oneCycleJson.children[0];
				expect(measurementNode.name).toBe("objective measurement");
				expect(measurementNode.date.first).toBe("2018-05-25T00:01:00+09:00");
				expect(measurementNode.date.last ).toBe("2018-05-25T00:01:09+09:00");
				expect(measurementNode.private).toBeUndefined();
				expect(measurementNode.children).toBeDefined();
				expect(measurementNode.children.length).toBe(4);
				expect(measurementNode.children[0].name).toBe("ChronosAlignment2");
				expect(measurementNode.children[2].name).toBe("ChronosAlignment2");
				expect(measurementNode.children[1].name).toBe("ChronosRef2");
				expect(measurementNode.children[3].name).toBe("ChronosRef2");
				measurementNode.children.forEach(child_ =>
					expect(child_.private.result.return).toBeTruthy());

				const subjectiveNode = oneCycleJson.children[1];
				expect(subjectiveNode.name).toBe("subjective");
				expect(subjectiveNode.date.first).toBe("2018-05-25T00:02:01+09:00");
				expect(subjectiveNode.date.last ).toBe("2018-05-25T00:02:04+09:00");
				expect(subjectiveNode.private).toBeUndefined();
				expect(subjectiveNode.children).toBeDefined();
				expect(subjectiveNode.children.length).toBe(2);
				expect(subjectiveNode.children[0].name).toBe("Chart");
				expect(subjectiveNode.children[1].name).toBe("Phoropter");
				subjectiveNode.children.forEach(child_ =>
					expect(child_.private.result.return).toBeTruthy());
			}
			// 被検者情報
			await becky.operatorLog.serialize();
			// テスト終了
			done();
		}());
	});
	it("post failed (return false)", function(done) {
		spyOn(becky.async      , "ajax").and.callFake(_fncSucceedResultJsonSuccess);
		spyOn(becky.LeanStartup, "ajax").and.callFake(_fncSucceedResultJsonFailure);
		spyOn(becky.operatorLog, "getWebStorageKey").and.callFake(_fncGetWebStorageKey);
		(async function(){
			// 被検者情報
			await becky.operatorLog.serialize();
			becky.operatorLog.createOneCycleNode("");
			// 他覚検査
			{
				const measurementNode = becky.operatorLog.createObjectiveMeasurementNode();
				try {
					await becky.LeanStartup.postWithOperatorLog("ChronosAlignment",
						{}, "", new Date(), measurementNode.children);
					await becky.LeanStartup.postWithOperatorLog("ChronosRef",
						{}, "", new Date(), measurementNode.children);
					await becky.LeanStartup.postWithOperatorLog("ChronosAlignment2",
						{}, "", new Date(), measurementNode.children);
					await becky.LeanStartup.postWithOperatorLog("ChronosRef2",
						{}, "", new Date(), measurementNode.children);
				} catch (resultJson) {
					// 何もしない
				} finally {
					becky.operatorLog.pushObjectiveMeasurementNode(measurementNode);
				}
			}
			// 自覚検査
			{
				becky.operatorLog.createSubjectiveNode();
				const commandNodes = [];
				try {
					await becky.LeanStartup.postWithOperatorLog("Chart",
						{}, "", new Date(), commandNodes);
					await becky.LeanStartup.postWithOperatorLog("Phoropter",
						{}, "", new Date(), commandNodes);
				} catch (resultJson) {
					// 何もしない
				} finally {
					becky.operatorLog.pushSubjectiveCommandNodes(commandNodes);
				}
			}
			// 出力
			becky.operatorLog.closeOneCycleNode();
			// 検証
			{
				const json = becky.WebStorage.local.getJson(becky.operatorLog.getWebStorageKey());
				expect(json).not.toBeNull();
				const oneCycleJson = modelHelper.getLast(json);
				expect(oneCycleJson).not.toBeNull();

				expect(oneCycleJson.name).toBe("One cycle of eye examination");
				expect(oneCycleJson.private.patientID).toBe("");
				expect(oneCycleJson.children).toBeDefined();
				expect(oneCycleJson.children.length).toBe(2);

				const measurementNode = oneCycleJson.children[0];
				expect(measurementNode.name).toBe("objective measurement");
				expect(measurementNode.private).toBeUndefined();
				expect(measurementNode.children).toBeDefined();
				expect(measurementNode.children.length).toBe(1); // 最初で失敗したので1つ
				{
					const firstChild = measurementNode.children[0];
					expect(firstChild.name).toBe("ChronosAlignment");
					expect(modelHelper.isNullOrEmpty(firstChild.date.first)).toBeFalsy();
					expect(modelHelper.isNullOrEmpty(firstChild.date.last )).toBeFalsy();
					expect(firstChild.private).toBeDefined();
					expect(firstChild.private.result).toBeDefined();
					expect(firstChild.private.result.return).toBeFalsy();
					["L", "R"].forEach(pos_ => {
						expect(firstChild.private.result[pos_]).toBeDefined();
						expect(firstChild.private.result[pos_].return).toBeFalsy();
						expect(firstChild.private.result[pos_].error).toBeDefined();
						expect(firstChild.private.result[pos_].error.code).toBe(418);
						expect(firstChild.private.result[pos_].error.message).toBe("I'm a teapot");
					});
				}

				const subjectiveNode = oneCycleJson.children[1];
				expect(subjectiveNode.name).toBe("subjective");
				expect(subjectiveNode.private).toBeUndefined();
				expect(subjectiveNode.children).toBeDefined();
				expect(subjectiveNode.children.length).toBe(1); // 最初で失敗したので1つ
				{
					const firstChild = subjectiveNode.children[0];
					expect(firstChild.name).toBe("Chart");
					expect(modelHelper.isNullOrEmpty(firstChild.date.first)).toBeFalsy();
					expect(modelHelper.isNullOrEmpty(firstChild.date.last )).toBeFalsy();
					expect(firstChild.private).toBeDefined();
					expect(firstChild.private.result).toBeDefined();
					expect(firstChild.private.result.return).toBeFalsy();
					["L", "R"].forEach(pos_ => {
						expect(firstChild.private.result[pos_]).toBeDefined();
						expect(firstChild.private.result[pos_].return).toBeFalsy();
						expect(firstChild.private.result[pos_].error).toBeDefined();
						expect(firstChild.private.result[pos_].error.code).toBe(418);
						expect(firstChild.private.result[pos_].error.message).toBe("I'm a teapot");
					});
				}
			}
			// 被検者情報
			await becky.operatorLog.serialize();
			// テスト終了
			done();
		}());
	});
	it("post failed (network error)", function(done) {
		spyOn(becky.async      , "ajax").and.callFake(_fncSucceedResultJsonSuccess);
		spyOn(becky.LeanStartup, "ajax").and.callFake(_fncFailed);
		spyOn(becky.operatorLog, "getWebStorageKey").and.callFake(_fncGetWebStorageKey);
		(async function(){
			// 被検者情報
			await becky.operatorLog.serialize();
			becky.operatorLog.createOneCycleNode("");
			// 他覚検査
			{
				const measurementNode = becky.operatorLog.createObjectiveMeasurementNode();
				try {
					await becky.LeanStartup.postWithOperatorLog("ChronosAlignment",
						{}, "", new Date(), measurementNode.children);
					await becky.LeanStartup.postWithOperatorLog("ChronosRef",
						{}, "", new Date(), measurementNode.children);
					await becky.LeanStartup.postWithOperatorLog("ChronosAlignment2",
						{}, "", new Date(), measurementNode.children);
					await becky.LeanStartup.postWithOperatorLog("ChronosRef2",
						{}, "", new Date(), measurementNode.children);
				} catch (resultJson) {
					// 何もしない
				} finally {
					becky.operatorLog.pushObjectiveMeasurementNode(measurementNode);
				}
			}
			// 自覚検査
			{
				becky.operatorLog.createSubjectiveNode();
				const commandNodes = [];
				try {
					await becky.LeanStartup.postWithOperatorLog("Chart",
						{}, "", new Date(), commandNodes);
					await becky.LeanStartup.postWithOperatorLog("Phoropter",
						{}, "", new Date(), commandNodes);
				} catch (resultJson) {
					// 何もしない
				} finally {
					becky.operatorLog.pushSubjectiveCommandNodes(commandNodes);
				}
			}
			// 出力
			becky.operatorLog.closeOneCycleNode();
			// 検証
			{
				const json = becky.WebStorage.local.getJson(becky.operatorLog.getWebStorageKey());
				expect(json).not.toBeNull();
				const oneCycleJson = modelHelper.getLast(json);
				expect(oneCycleJson).not.toBeNull();

				expect(oneCycleJson.name).toBe("One cycle of eye examination");
				expect(oneCycleJson.private.patientID).toBe("");
				expect(oneCycleJson.children).toBeDefined();
				expect(oneCycleJson.children.length).toBe(2);

				const measurementNode = oneCycleJson.children[0];
				expect(measurementNode.name).toBe("objective measurement");
				expect(measurementNode.private).toBeUndefined();
				expect(measurementNode.children).toBeDefined();
				expect(measurementNode.children.length).toBe(1); // 最初で失敗したので1つ
				{
					const firstChild = measurementNode.children[0];
					expect(firstChild.name).toBe("ChronosAlignment");
					expect(modelHelper.isNullOrEmpty(firstChild.date.first)).toBeFalsy();
					expect(modelHelper.isNullOrEmpty(firstChild.date.last )).toBeFalsy();
					expect(modelHelper.isString(firstChild.private.result)).toBeTruthy();
					expect(firstChild.private.result).toBe("error 500 Internal Server Error");
				}

				const subjectiveNode = oneCycleJson.children[1];
				expect(subjectiveNode.name).toBe("subjective");
				expect(subjectiveNode.private).toBeUndefined();
				expect(subjectiveNode.children).toBeDefined();
				expect(subjectiveNode.children.length).toBe(1); // 最初で失敗したので1つ
				{
					const firstChild = subjectiveNode.children[0];
					expect(firstChild.name).toBe("Chart");
					expect(modelHelper.isNullOrEmpty(firstChild.date.first)).toBeFalsy();
					expect(modelHelper.isNullOrEmpty(firstChild.date.last )).toBeFalsy();
					expect(modelHelper.isString(firstChild.private.result)).toBeTruthy();
					expect(firstChild.private.result).toBe("error 500 Internal Server Error");
				}
			}
			// 被検者情報
			await becky.operatorLog.serialize();
			// テスト終了
			done();
		}());
	});
	it("post failed (error trial 2)", function(done) {
		spyOn(becky.async      , "ajax").and.callFake(_fncSucceedResultJsonSuccess);
		spyOn(becky.LeanStartup, "ajax").and.callFake(_fncEchoJson);
		spyOn(becky.operatorLog, "getWebStorageKey").and.callFake(_fncGetWebStorageKey);
		(async function(){
			// 被検者情報
			await becky.operatorLog.serialize();
			becky.operatorLog.createOneCycleNode("");
			// 他覚検査
			{
				const measurementNode = becky.operatorLog.createObjectiveMeasurementNode();
				try {
					await becky.LeanStartup.postWithOperatorLog("ChronosAlignment",
						{ return:  true }, "", new Date(), measurementNode.children);
					await becky.LeanStartup.postWithOperatorLog("ChronosRef",
						{ return: false }, "", new Date(), measurementNode.children);
					await becky.LeanStartup.postWithOperatorLog("ChronosAlignment2",
						{ return:  true }, "", new Date(), measurementNode.children);
					await becky.LeanStartup.postWithOperatorLog("ChronosRef2",
						{ return:  true }, "", new Date(), measurementNode.children);
				} catch (resultJson) {
					// 何もしない
				} finally {
					becky.operatorLog.pushObjectiveMeasurementNode(measurementNode);
				}
			}
			// 自覚検査
			{
				becky.operatorLog.createSubjectiveNode();
				const commandNodes = [];
				try {
					await becky.LeanStartup.postWithOperatorLog("Chart",
						{ return:  true }, "", new Date(), commandNodes);
					await becky.LeanStartup.postWithOperatorLog("Phoropter",
						{ return: false }, "", new Date(), commandNodes);
				} catch (resultJson) {
					// 何もしない
				} finally {
					becky.operatorLog.pushSubjectiveCommandNodes(commandNodes);
				}
			}
			// 出力
			becky.operatorLog.closeOneCycleNode();
			// 検証
			{
				const json = becky.WebStorage.local.getJson(becky.operatorLog.getWebStorageKey());
				expect(json).not.toBeNull();
				const oneCycleJson = modelHelper.getLast(json);
				expect(oneCycleJson).not.toBeNull();

				expect(oneCycleJson.name).toBe("One cycle of eye examination");
				expect(oneCycleJson.private.patientID).toBe("");
				expect(oneCycleJson.children).toBeDefined();
				expect(oneCycleJson.children.length).toBe(2);

				const measurementNode = oneCycleJson.children[0];
				expect(measurementNode.name).toBe("objective measurement");
				expect(measurementNode.private).toBeUndefined();
				expect(measurementNode.children).toBeDefined();
				expect(measurementNode.children.length).toBe(2); // 2番目で失敗したので2つ
				{
					const firstChild = measurementNode.children[0];
					expect(firstChild.name).toBe("ChronosAlignment");
					expect(modelHelper.isNullOrEmpty(firstChild.date.first)).toBeFalsy();
					expect(modelHelper.isNullOrEmpty(firstChild.date.last )).toBeFalsy();
					expect(firstChild.private.result).toBeDefined();
					expect(firstChild.private.result.return).toBeTruthy();
				}
				{
					const secondChild = measurementNode.children[1];
					expect(secondChild.name).toBe("ChronosRef");
					expect(modelHelper.isNullOrEmpty(secondChild.date.first)).toBeFalsy();
					expect(modelHelper.isNullOrEmpty(secondChild.date.last )).toBeFalsy();
					expect(secondChild.private.result).toBeDefined();
					expect(secondChild.private.result.return).toBeFalsy();
				}

				const subjectiveNode = oneCycleJson.children[1];
				expect(subjectiveNode.name).toBe("subjective");
				expect(subjectiveNode.private).toBeUndefined();
				expect(subjectiveNode.children).toBeDefined();
				expect(subjectiveNode.children.length).toBe(2); // 2番目で失敗したので2つ
				{
					const firstChild = subjectiveNode.children[0];
					expect(firstChild.name).toBe("Chart");
					expect(modelHelper.isNullOrEmpty(firstChild.date.first)).toBeFalsy();
					expect(modelHelper.isNullOrEmpty(firstChild.date.last )).toBeFalsy();
					expect(firstChild.private.result).toBeDefined();
					expect(firstChild.private.result.return).toBeTruthy();
				}
				{
					const secondChild = subjectiveNode.children[1];
					expect(secondChild.name).toBe("Phoropter");
					expect(modelHelper.isNullOrEmpty(secondChild.date.first)).toBeFalsy();
					expect(modelHelper.isNullOrEmpty(secondChild.date.last )).toBeFalsy();
					expect(secondChild.private.result).toBeDefined();
					expect(secondChild.private.result.return).toBeFalsy();
				}
			}
			// 被検者情報
			await becky.operatorLog.serialize();
			// テスト終了
			done();
		}());
	});
});
