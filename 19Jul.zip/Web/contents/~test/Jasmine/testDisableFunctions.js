/*! @file
 * @brief テスト用に機能を無効にする
 *
 * アサーションはテストの邪魔になるので抑止
 */

// 名前空間
var becky = becky || {};
becky.assertion = becky.assertion || {};
becky.debug = becky.debug || {};
becky.dynamic = becky.dynamic || {};

becky.assertion.assert = function(aAssertion, ...aObjN)
{
	// 何もしない
}

becky.assertion.failure = function(...aObjN)
{
	// 何もしない
}

becky.assertion.isNull = function(aObj)
{
	return modelHelper.isNull(aObj);
}

becky.assertion.isNullOrEmpty = function(aObj)
{
	return modelHelper.isNullOrEmpty(aObj);
}

becky.assertion.isUndefined = function(aObj)
{
	return modelHelper.isUndefined(aObj);
}

becky.assertion.hasUndefined = function(aObj)
{
	return modelHelper.hasUndefined(aObj);
}

becky.assertion.isTrue = function(aValue)
{
	return aValue;
}

becky.assertion.isFalse = function(aValue)
{
	return !aValue;
}

becky.debug.scope = function(aFunc)
{
	// 何もしない
}

becky.dynamic.getClientIpAddress = function()
{
	return "127.0.0.1";
}
