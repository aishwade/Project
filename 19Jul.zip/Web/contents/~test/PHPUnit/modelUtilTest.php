<?php

require_once '_common.php';
require_once topDir() . 'models/modelUtil.php';

class ModelUtilTest extends PHPUnit_Framework_TestCase {

	public function test_is_vector() {
		$arr = array('a', 'b');
		$this->assertTrue(\ModelUtil\is_vector($arr));
	}

	public function test_is_vector2() {
		$arr = array('a' => 1, 'b' => 2);
		$this->assertFalse(\ModelUtil\is_vector($arr));
	}

	public function test_empty_recursive0() {
		$target1 = '';
		$this->assertTrue(\ModelUtil\empty_recursive($target1));
		$target2 = 'a';
		$this->assertFalse(\ModelUtil\empty_recursive($target2));
	}

	public function test_empty_recursive1() {
		$target1 = array('', '', '');
		$this->assertTrue(\ModelUtil\empty_recursive($target1));
		$target2 = array('', 'b', '');
		$this->assertFalse(\ModelUtil\empty_recursive($target2));
	}

	public function test_empty_recursive2() {
		$target1 = array('', '', array('', '', ''));
		$this->assertTrue(\ModelUtil\empty_recursive($target1));
		$target2 = array('', '', array('', 'c', ''));
		$this->assertFalse(\ModelUtil\empty_recursive($target2));
	}

	public function test_empty_recursive3() {
		$target1 = array('', '', array('', '', array('', '', '')));
		$this->assertTrue(\ModelUtil\empty_recursive($target1));
		$target2 = array('', '', array('', '', array('', 'd', '')));
		$this->assertFalse(\ModelUtil\empty_recursive($target2));
	}

	public function test_array_trim() {
		$actual = array(
			'a' => '123                 ',
			'b' => '                 123',
			'c' => '        1 2 3       ',
		);
		\ModelUtil\array_trim($actual);
		$this->assertCount(3, $actual);
		$expected = array(
			'a' => '123',
			'b' => '123',
			'c' => '1 2 3',
		);
		$this->assertEquals($expected, $actual);
	}

	public function test_toNumericIfPossible() {
		// 数値に変換できるケース
		$this->assertSame(  0   , \ModelUtil\toNumericIfPossible('   0   '));

		$this->assertSame(  1   , \ModelUtil\toNumericIfPossible('   1   '));
		$this->assertSame(  1   , \ModelUtil\toNumericIfPossible('  +1   '));
		$this->assertSame( -1   , \ModelUtil\toNumericIfPossible('  -1   '));

		$this->assertSame( 12   , \ModelUtil\toNumericIfPossible('  12   '));
		$this->assertSame( 12   , \ModelUtil\toNumericIfPossible(' +12   '));
		$this->assertSame(-12   , \ModelUtil\toNumericIfPossible(' -12   '));

		$this->assertSame(  0.1 , \ModelUtil\toNumericIfPossible('   0.1 '));
		$this->assertSame(  0.1 , \ModelUtil\toNumericIfPossible('  +0.1 '));
		$this->assertSame( -0.1 , \ModelUtil\toNumericIfPossible('  -0.1 '));

		$this->assertSame(  0.12, \ModelUtil\toNumericIfPossible('   0.12'));
		$this->assertSame(  0.12, \ModelUtil\toNumericIfPossible('  +0.12'));
		$this->assertSame( -0.12, \ModelUtil\toNumericIfPossible('  -0.12'));

		$this->assertSame( 10.1 , \ModelUtil\toNumericIfPossible('  10.1 '));
		$this->assertSame( 10.1 , \ModelUtil\toNumericIfPossible(' +10.1 '));
		$this->assertSame(-10.1 , \ModelUtil\toNumericIfPossible(' -10.1 '));

		$this->assertSame( 10.12, \ModelUtil\toNumericIfPossible('  10.12'));
		$this->assertSame( 10.12, \ModelUtil\toNumericIfPossible(' +10.12'));
		$this->assertSame(-10.12, \ModelUtil\toNumericIfPossible(' -10.12'));

		$this->assertSame( 0.1, \ModelUtil\toNumericIfPossible(' .1'));
		$this->assertSame( 0.1, \ModelUtil\toNumericIfPossible('+.1'));
		$this->assertSame(-0.1, \ModelUtil\toNumericIfPossible('-.1'));

		// 数値に変換できないケース
		$this->assertSame(''   , \ModelUtil\toNumericIfPossible(''));
		$this->assertSame('dig', \ModelUtil\toNumericIfPossible('dig'));
		$this->assertSame('+-1', \ModelUtil\toNumericIfPossible('+-1'));
		$this->assertSame('1.' , \ModelUtil\toNumericIfPossible('1.'));
		$this->assertSame('01' , \ModelUtil\toNumericIfPossible('01')); // 先頭が0(8進数?)
	}

	//public function test_ceiling() {
	//	$this->assertEquals(0, \ModelUtil\ceiling(0.0));
	//	$this->assertEquals(1, \ModelUtil\ceiling(0.1));
	//	$this->assertEquals(1, \ModelUtil\ceiling(0.9));
	//	$this->assertEquals(2, \ModelUtil\ceiling(1.1));
	//	$this->assertEquals(2, \ModelUtil\ceiling(1.9));
	//	$this->assertEquals(0.00, \ModelUtil\ceiling(0.124, 0.25));
	//	$this->assertEquals(0.25, \ModelUtil\ceiling(0.125, 0.25));
	//	$this->assertEquals(0.25, \ModelUtil\ceiling(0.1, 0.25));
	//	$this->assertEquals(0.75, \ModelUtil\ceiling(0.7, 0.25));
	//}
	//
	public function test_fround() {
		$this->assertEquals( 0.00, \ModelUtil\fround(0.124, 0.25));
		$this->assertEquals( 0.25, \ModelUtil\fround(0.125, 0.25));

		$this->assertEquals( 0.00, \ModelUtil\fround(-0.124, 0.25));
		$this->assertEquals(-0.25, \ModelUtil\fround(-0.125, 0.25));

		$this->assertEquals( 0.25, \ModelUtil\fround(0.374, 0.25));
		$this->assertEquals( 0.50, \ModelUtil\fround(0.375, 0.25));

		$this->assertEquals(-0.25, \ModelUtil\fround(-0.374, 0.25));
		$this->assertEquals(-0.50, \ModelUtil\fround(-0.375, 0.25));

		$this->assertEquals( 0, \ModelUtil\fround(0.4, 1));
		$this->assertEquals( 1, \ModelUtil\fround(0.5, 1));

		$this->assertEquals( 0, \ModelUtil\fround(-0.4, 1));
		$this->assertEquals(-1, \ModelUtil\fround(-0.5, 1));
	}

}// class ModelUtilTest

?>
