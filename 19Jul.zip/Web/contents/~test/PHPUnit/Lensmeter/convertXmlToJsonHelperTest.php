<?php
namespace Lensmeter;

require_once '_common.php';
require_once topDir() . 'contents/lensmeter/convertXmlToJsonHelper.php';

class ConvertXmlToJsonHelperTest extends \PHPUnit_Framework_TestCase {

	// \\10.140.10.154\CLDataTest 内に保管してあるデータを元にテスト向けに値を調整
	public function test_convertXmlToJson() {
		$input = <<<'EOF'
<?xml version="1.0" encoding="UTF-8" standalone="no"?>
<Ophthalmology xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:nsCommon="http://www.joia.or.jp/standardized/namespaces/Common" xmlns:nsREF="http://www.joia.or.jp/standardized/namespaces/REF" xmlns:nsKM="http://www.joia.or.jp/standardized/namespaces/KM" xmlns:nsLM="http://www.joia.or.jp/standardized/namespaces/LM" xmlns:nsTM="http://www.joia.or.jp/standardized/namespaces/TM" xsi:schemaLocation="http://www.joia.or.jp/standardized/namespaces/Common Common_schema.xsd http://www.joia.or.jp/standardized/namespaces/REF REF_schema.xsd http://www.joia.or.jp/standardized/namespaces/KM KM_schema.xsd http://www.joia.or.jp/standardized/namespaces/TM TM_schema.xsd">
	<nsCommon:Common>
		<nsCommon:Company>TOPCON</nsCommon:Company>
		<nsCommon:ModelName>CL-100</nsCommon:ModelName>
		<nsCommon:MachineNo>03</nsCommon:MachineNo>
		<nsCommon:ROMVersion>1.0</nsCommon:ROMVersion>
		<nsCommon:Version>1.2</nsCommon:Version>
		<nsCommon:Date>2008-09-01</nsCommon:Date>
		<nsCommon:Time>19:36:28</nsCommon:Time>
		<nsCommon:Patient>
			<nsCommon:No.>123456</nsCommon:No.>
			<nsCommon:ID>ABCDEFG</nsCommon:ID>
			<nsCommon:FirstName>TANAKA</nsCommon:FirstName>
			<nsCommon:MiddleName/>
			<nsCommon:LastName>TAROU</nsCommon:LastName>
			<nsCommon:Sex>Male</nsCommon:Sex>
			<nsCommon:Age>18</nsCommon:Age>
			<nsCommon:DOB>1975-08-16</nsCommon:DOB>
			<nsCommon:NameJ1>TANAKA</nsCommon:NameJ1>
			<nsCommon:NameJ2>TAROU</nsCommon:NameJ2>
		</nsCommon:Patient>
		<nsCommon:Operator>
			<nsCommon:No.>123456</nsCommon:No.>
			<nsCommon:ID>ABCDEFG</nsCommon:ID>
		</nsCommon:Operator>
	</nsCommon:Common>
	<nsLM:Measure type="LM">
		<nsLM:DiopterStep unit="D">0.250</nsLM:DiopterStep>
		<nsLM:AxisStep unit="deg">5</nsLM:AxisStep>
		<nsLM:PrismStep unit="D">0.100</nsLM:PrismStep>
		<nsLM:CylinderMode>-</nsLM:CylinderMode>
		<nsLM:LensType>glass</nsLM:LensType>
		<nsLM:AbbeNumber>2</nsLM:AbbeNumber>
		<nsLM:Wavelength>e</nsLM:Wavelength>
		<nsLM:LM>
			<nsLM:R>
				<nsLM:Sphere unit="D">-2.50</nsLM:Sphere>
				<nsLM:Cylinder unit="D">0.25</nsLM:Cylinder>
				<nsLM:Axis unit="deg">180</nsLM:Axis>
				<nsLM:Add1 unit="D">0.50</nsLM:Add1>
				<nsLM:Add2 unit="D">1.25</nsLM:Add2>
				<nsLM:H Prism="P">0.30</nsLM:H>
				<nsLM:V Prism="P">0.20</nsLM:V>
			</nsLM:R>
			<nsLM:L>
				<nsLM:Sphere unit="D">-3.50</nsLM:Sphere>
				<nsLM:Cylinder unit="D">1.25</nsLM:Cylinder>
				<nsLM:Axis unit="deg">5</nsLM:Axis>
				<nsLM:Add1 unit="D">1.50</nsLM:Add1>
				<nsLM:Add2 unit="D">2.25</nsLM:Add2>
				<nsLM:H Prism="P">1.30</nsLM:H>
				<nsLM:V Prism="P">1.20</nsLM:V>
			</nsLM:L>
		</nsLM:LM>
		<nsLM:PD>
			<nsLM:B>
				<nsLM:Distance unit="mm">62.5</nsLM:Distance>
			</nsLM:B>
			<nsLM:R>
				<nsLM:Distance unit="mm">31.5</nsLM:Distance>
			</nsLM:R>
			<nsLM:L>
				<nsLM:Distance unit="mm">31.0</nsLM:Distance>
			</nsLM:L>
		</nsLM:PD>
	</nsLM:Measure>
</Ophthalmology>
EOF;
		$actual = convertXmlToJsonString($input);
		$expected = <<<'EOD'
{
  "lensmeter": {
    "MeasureMode": "",
    "DiopterStep": {
      "unit": "D",
      "value": 0.25
    },
    "AxisStep": {
      "unit": "deg",
      "value": 5
    },
    "CylinderMode": "-",
    "PrismDiopterStep": {
      "unit": "",
      "value": ""
    },
    "PrismBaseStep": {
      "unit": "",
      "value": ""
    },
    "PrismMode": "",
    "AddMode": "",
    "LM": {
      "S": {
        "Sphere": {
          "unit": "",
          "value": ""
        },
        "Cylinder": {
          "unit": "",
          "value": ""
        },
        "Axis": {
          "unit": "",
          "value": ""
        },
        "SE": {
          "unit": "",
          "value": ""
        },
        "ADD": {
          "unit": "",
          "value": ""
        },
        "ADD2": {
          "unit": "",
          "value": ""
        },
        "NearSphere": {
          "unit": "",
          "value": ""
        },
        "NearSphere2": {
          "unit": "",
          "value": ""
        },
        "Prism": {
          "unit": "",
          "value": ""
        },
        "PrismBase": {
          "unit": "",
          "value": ""
        },
        "PrismX": {
          "unit": "",
          "base": "",
          "value": ""
        },
        "PrismY": {
          "unit": "",
          "base": "",
          "value": ""
        },
        "UVTransmittance": {
          "unit": "",
          "value": ""
        },
        "ConfidenceIndex": "",
        "Error": ""
      },
      "R": {
        "Sphere": {
          "unit": "D",
          "value": -2.5
        },
        "Cylinder": {
          "unit": "D",
          "value": 0.25
        },
        "Axis": {
          "unit": "deg",
          "value": 180
        },
        "SE": {
          "unit": "",
          "value": ""
        },
        "ADD": {
          "unit": "D",
          "value": 0.5
        },
        "ADD2": {
          "unit": "D",
          "value": 1.25
        },
        "NearSphere": {
          "unit": "",
          "value": ""
        },
        "NearSphere2": {
          "unit": "",
          "value": ""
        },
        "Prism": {
          "unit": "",
          "value": ""
        },
        "PrismBase": {
          "unit": "",
          "value": ""
        },
        "PrismX": {
          "unit": "",
          "base": "",
          "value": ""
        },
        "PrismY": {
          "unit": "",
          "base": "",
          "value": ""
        },
        "UVTransmittance": {
          "unit": "",
          "value": ""
        },
        "ConfidenceIndex": "",
        "Error": ""
      },
      "L": {
        "Sphere": {
          "unit": "D",
          "value": -3.5
        },
        "Cylinder": {
          "unit": "D",
          "value": 1.25
        },
        "Axis": {
          "unit": "deg",
          "value": 5
        },
        "SE": {
          "unit": "",
          "value": ""
        },
        "ADD": {
          "unit": "D",
          "value": 1.5
        },
        "ADD2": {
          "unit": "D",
          "value": 2.25
        },
        "NearSphere": {
          "unit": "",
          "value": ""
        },
        "NearSphere2": {
          "unit": "",
          "value": ""
        },
        "Prism": {
          "unit": "",
          "value": ""
        },
        "PrismBase": {
          "unit": "",
          "value": ""
        },
        "PrismX": {
          "unit": "",
          "base": "",
          "value": ""
        },
        "PrismY": {
          "unit": "",
          "base": "",
          "value": ""
        },
        "UVTransmittance": {
          "unit": "",
          "value": ""
        },
        "ConfidenceIndex": "",
        "Error": ""
      }
    },
    "PD": {
      "Distance": {
        "unit": "mm",
        "value": 62.5
      },
      "DistanceR": {
        "unit": "mm",
        "value": 31.5
      },
      "DistanceL": {
        "unit": "mm",
        "value": 31
      },
      "Near": {
        "unit": "",
        "value": ""
      },
      "NearR": {
        "unit": "",
        "value": ""
      },
      "NearL": {
        "unit": "",
        "value": ""
      }
    }
  }
}
EOD;
		// ズバリ JSON として等しいか？
		$this->assertJsonStringEqualsJsonString($expected, $actual);
	}

}// class ConvertXmlToJsonHelperTest

?>
