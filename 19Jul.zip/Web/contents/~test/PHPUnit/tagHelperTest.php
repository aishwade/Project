<?php

require_once '_common.php';
require_once topDir() . 'views/tagHelper.php';

class TagHelperTest extends PHPUnit_Framework_TestCase {

	public function test_createHTML_1() {
		$element = \TagHelper\createHTML('a');
		$this->assertEquals('<a></a>', $element);
	}

	public function test_createHTML_2() {
		$element = \TagHelper\createHTML('img', array('src' => 'http://www.hoge.com/'));
		$this->assertEquals('<img src="http://www.hoge.com/">', $element);
	}

	public function test_createHTML_3() {
		$element = \TagHelper\createHTML('a', array('href' => 'http://www.yahoo.co.jp/'), 'Yahoo!');
		$this->assertEquals('<a href="http://www.yahoo.co.jp/">Yahoo!</a>', $element);
	}

	public function test_createHTML_4() {
		$element = \TagHelper\createHTML('a', null, 'a<br>b<br>c');
		$this->assertEquals('<a>a<br>b<br>c</a>', $element);
	}

	public function test_createHTML_5() {
		$element = \TagHelper\createHTML('input', array('type'=>'text','name'=>'hoge','value'=>'a<b>c</b>'));
		$this->assertEquals('<input type="text" name="hoge" value="a&lt;b&gt;c&lt;/b&gt;">', $element);
	}

	public function test_createHTML_6() {
		$element = \TagHelper\createHTML('input', array('type'=>'text','name'=>'hoge','value'=>'a"b"c'));
		$this->assertEquals('<input type="text" name="hoge" value=\'a"b"c\'>', $element);
	}

	public function test_createHTML_7() {
		$element = \TagHelper\createHTML('li', ['class' => ['a','b']], 'c');
		$this->assertEquals('<li class="a b">c</li>', $element);
	}

	public function test_createXML_1() {
		$elementA = \TagHelper\createXML('a');
		$this->assertEquals('<a/>', $elementA);
	}

	public function test_createXML_2() {
		$element = \TagHelper\createXML('img', array('src' => 'http://www.hoge.com/'));
		$this->assertEquals('<img src="http://www.hoge.com/"/>', $element);
	}

	public function test_createXML_3() {
		$element = \TagHelper\createXML('a', array('href' => 'http://www.yahoo.co.jp/'), 'Yahoo!');
		$this->assertEquals('<a href="http://www.yahoo.co.jp/">Yahoo!</a>', $element);
	}

	public function test_createXML_4() {
		$element = \TagHelper\createXML('a', null, 'a<br>b<br>c');
		$this->assertEquals('<a>a&lt;br&gt;b&lt;br&gt;c</a>', $element);
	}

	public function test_createXML_5() {
		$element = \TagHelper\createXML('input', array('type'=>'text','name'=>'hoge','value'=>'a<b>c</b>'));
		$this->assertEquals('<input type="text" name="hoge" value="a&lt;b&gt;c&lt;/b&gt;"/>', $element);
	}

	public function test_createXML_6() {
		$element = \TagHelper\createXML('input', array('type'=>'text','name'=>'hoge','value'=>'a"b"c'));
		$this->assertEquals('<input type="text" name="hoge" value="a&quot;b&quot;c"/>', $element);
	}

}// class TagHelperTest

?>
