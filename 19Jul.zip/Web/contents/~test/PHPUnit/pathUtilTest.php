<?php

require_once '_common.php';
require_once topDir() . 'models/pathUtil.php';

class PathUtilTest extends PHPUnit_Framework_TestCase {

	// 特殊
	public function test_combine1() {
		$path = \becky\Path\combine('C:\\');
		$this->assertEquals('C:', $path);
	}

	// 基本形
	public function test_combine2() {
		$path = \becky\Path\combine('C:', '\\Windows');
		$this->assertEquals('C:\\Windows', $path);
	}

	// 基本形+1
	public function test_combine3() {
		$path = \becky\Path\combine('C:\\', 'Windows', 'System32\\');
		$this->assertEquals('C:\\Windows\\System32', $path);
	}

	// URL
	public function test_combine_url1() {
		$url = \becky\Path\combine('http://piranha', 'becky', 'index.html');
		$this->assertEquals('http://piranha/becky/index.html', $url);
	}

	// ドキュメントルート
	public function test_combine_url2() {
		$url = \becky\Path\combine('/becky', 'index.html');
		$this->assertEquals('/becky/index.html', $url);
	}

}// class PathUtilTest

?>
