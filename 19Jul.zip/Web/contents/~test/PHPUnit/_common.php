<?php
/*! @file
 * @brief 単体テストの共通項目
 */

require_once dirname(__FILE__) . '/../../../vendorComposer/Autoload.php';

function topDir()
{
	return dirname(__FILE__) . '/../../../';
}
