<?php
/*! @file
 * @brief result 固有のスタイルシートとスクリプトの読み込み
 */

addStyles(
	[
		'css/result.css',
	]
);

addScripts(
	[
		'js/result.js',
	]
);
