<?php
/*! @file
 * @brief 結果画面の中身
 */

require_once topDir() . 'models/modelUtil.php';
require_once topDir() . 'views/_tags.php';
require_once topDir() . 'contents/_head.php';
require_once topDir() . 'contents/result/_head.php';
require_once topDir() . 'contents/result/_viewLogic.php';

/*!
 * @brief 変数に対し sprintf して値を直接更新する
 *
 * @param[in] string $format フォーマット
 * @param[in,out] string $value 対象
 */
function sprintfRef($format, &$value)
{
	if ("" === $value) {
		// 入力が空文字列の場合、何もしない
		return;
	}

	$isZero = 0 == $value;
	$value = sprintf($format, $value);

	if ($isZero) {
		// 入力が 0 だった場合、符号が付いていたら取り除く
		$value = ltrim($value, '+-');
	}
}

/*!
 * @brief 単位出力向けの echo
 *
 * @param[in] mixed $value 対象(Notice エラーを回避するため参照渡し)
 * @return void
 */
function echoUnit(&$value)
{
	$unit = \ModelUtil\array_get($value, '');
	if ('' === $unit) {
		return;
	}
	// 単位表記にかぎ括弧を付加する
	echo ' [' . $unit . ']';
}

$map = getMapFromPatientJsonFile();
if ($map) {
	$_POST += $map;
}

$json = [];

$filenameObjectiveRefJson = 'objective.refraction.json'; 
$arrayObjectiveRef = getMapFromJsonFile(tempDir() . $filenameObjectiveRefJson);
if ($arrayObjectiveRef) {
	foreach (['R', 'L'] as $eye) {
		$median = @$arrayObjectiveRef['refraction'][$eye]['Median'];
		if (empty($median)) {
			continue;
		}
		$json['objective'][$eye]['sph'][0] = @$median['Sphere'  ]['value'];
		$json['objective'][$eye]['cyl'][0] = @$median['Cylinder']['value'];
		$json['objective'][$eye]['axs'][0] = @$median['Axis'    ]['value'];
		foreach([1, 2, 3] as $trial) {
			$sca = @$arrayObjectiveRef['refraction'][$eye]['List'][$trial];
			$json['objective'][$eye]['sph'][$trial] = @$sca['Sphere'  ]['value'];
			$json['objective'][$eye]['cyl'][$trial] = @$sca['Cylinder']['value'];
			$json['objective'][$eye]['axs'][$trial] = @$sca['Axis'    ]['value'];
		}

		$targetEye = @$arrayObjectiveRef['refraction'][$eye]['TargetEye'];
		if (!empty($targetEye)) {
			switch ($targetEye) {
				case 'L':
				case 'R':
					$targetEyeText = _m('result', 'monoValue');
					break;
				case 'Bino':
					$targetEyeText = _m('result', 'binoValue');
					break;
				default:
					break;
			}
			$json['objective'][$eye]['targetEye'] = $targetEyeText;
		}
	}
	$json['objective']['vd']['value'] = @$arrayObjectiveRef['refraction']['VD']['value'];
	$json['objective']['vd']['unit' ] = @$arrayObjectiveRef['refraction']['VD']['unit' ];
	$json['objective']['pd']['value'] = @$arrayObjectiveRef['PD']['Distance']['value'];
	$json['objective']['pd']['unit' ] = @$arrayObjectiveRef['PD']['Distance']['unit' ];

	// 整形
	foreach (['R', 'L'] as $eye) {
		foreach([0, 1, 2, 3] as $trial) {
			sprintfRef('%+.2f', $json['objective'][$eye]['sph'][$trial]);
			sprintfRef('%+.2f', $json['objective'][$eye]['cyl'][$trial]);
			sprintfRef('%d'   , $json['objective'][$eye]['axs'][$trial]);
		}
	}
	sprintfRef('%.2f', $json['objective']['vd']['value']);
	sprintfRef('%.1f', $json['objective']['pd']['value']);

	if (0 == $json['objective']['pd']['value']) {
		$json['objective']['pd']['value'] = 'ERR';
	}
}

$filenameSubjectiveJson = 'subjective.json'; 
$arraySubjective = getMapFromJsonFile(tempDir() . $filenameSubjectiveJson);
if ($arraySubjective) {
	foreach (['1', '2'] as $listNum) {
		$listItem = @$arraySubjective['subjective']['RefractionTest']['List']['1']['Full Correction']['ExamDistance']['List'][$listNum];
		$d = @$listItem['Distance'];
		$json['subjective'][$listNum]['distance']['value'] = @$d['value'];
		$json['subjective'][$listNum]['distance']['unit' ] = @$d['unit' ];
		foreach (['R', 'L', 'B'] as $eye) {
			$rd = @$listItem['RefractionData'][$eye];
			$va = @$listItem['VA'][$eye];
			$json['subjective'][$listNum][$eye]['va'] = @$va['value'];
			if ('B' !== $eye) {
				$json['subjective'][$listNum][$eye]['sph'] = @$rd['Sphere'  ]['value'];
				$json['subjective'][$listNum][$eye]['cyl'] = @$rd['Cylinder']['value'];
				$json['subjective'][$listNum][$eye]['axs'] = @$rd['Axis'    ]['value'];
			}
		}
	}

	// 加入値そのものは記録されていないので算出する
	foreach (['R', 'L'] as $eye) {
		$json['subjective']['1'][$eye]['add'] = $json['subjective']['2'][$eye]['sph'] - $json['subjective']['1'][$eye]['sph'];
		$json['subjective']['2'][$eye]['add'] = 0; // 近見は加入値が Sph に加算済みなので常に 0
	}

	// 整形
	// VA は整形不要
	foreach (['1', '2'] as $listNum) {
		foreach (['R', 'L'] as $eye) {
			sprintfRef('%+.2f', $json['subjective'][$listNum][$eye]['sph']);
			sprintfRef('%+.2f', $json['subjective'][$listNum][$eye]['cyl']);
			sprintfRef('%d'   , $json['subjective'][$listNum][$eye]['axs']);
			sprintfRef('%+.2f', $json['subjective'][$listNum][$eye]['add']);
		}
	}
}

?>
<!DOCTYPE html>
<!--[if lt IE 7]><html lang="ja-JP" class="no-js ie lt-ie9 lt-ie8 lt-ie7"><![endif]-->
<!--[if IE 7]><html lang="ja-JP" class="no-js ie lt-ie9 lt-ie8"  xmlns:og="http://ogp.me/ns#" xmlns:mixi="http://mixi-platform.com/ns#" xmlns:fb="http://www.facebook.com/2008/fbml"><![endif]-->
<!--[if IE 8]><html lang="ja-JP" class="no-js ie lt-ie9"  xmlns:og="http://ogp.me/ns#" xmlns:mixi="http://mixi-platform.com/ns#" xmlns:fb="http://www.facebook.com/2008/fbml"><![endif]-->
<!--[if IE 9]><html lang="ja-JP" class="no-js ie"  xmlns:og="http://ogp.me/ns#" xmlns:mixi="http://mixi-platform.com/ns#" xmlns:fb="http://www.facebook.com/2008/fbml"><![endif]-->
<!--[if gt IE 9]><!-->
<html lang="ja-JP" class="no-js" xmlns:og="http://ogp.me/ns#" xmlns:mixi="http://mixi-platform.com/ns#" xmlns:fb="http://www.facebook.com/2008/fbml">
<!--<![endif]-->
<head>
<?php outputHeadContents(); ?>
<title><?php echo _m('result', 'title'); ?></title>
<!--[if lt IE 9]>
<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
<script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
</head>
<body>
<div class="siteframe D-result">
<div class="siteframe-inner">

<?php include_once topDir() . 'contents/_nav.php'; ?>

<div class="siteframe-body">
<div class="siteframe-body-inner">
<div class="layout-content clearfix">
	<div class="area-a">
		<div class="area-inner">
		
			<div class="userdata-table userdata-A">
				<div class="tr">
					<div class="th"><?php echo _m('patient', 'patientID'); ?></div><div class="td"><?php echo_POST_Safe('patientID'); ?></div>
				</div>
				<div class="tr">
					<div class="th"><?php echo _m('patient', 'patientName'); ?></div><div class="td"><?php echo_POST_Safe('patientName'); ?></div>
				</div>
				<div class="tr">
					<div class="th"><?php echo _m('patient', 'patientDOB'); ?></div><div class="td"><?php echo_POST_Safe('patientDOB'); ?></div>
				</div>
				<div class="separater"></div>
			</div><!--/.userdata-table-->
			
			<div class="userdata-table userdata-B">
				<div class="tr">
					<div class="th"><?php echo _m('patient', 'operatorID'); ?></div><div class="td td-w-m"><?php echo_POST_Safe('operatorID'); ?></div>
				</div>
				<div class="separater"></div>
			</div><!--/.userdata-table-->
			
			<div class="userdata-table userdata-C">
				<div class="tr">
					<div class="th"><?php echo _m('global', 'far'); ?></div><div class="td td-w-s" data-text="<?php echo $json['subjective']['1']['distance']['value']; ?>" data-suffix="<?php echoUnit($json['subjective']['1']['distance']['unit']); ?>"></div>
				</div>
				<div class="tr">
					<div class="th"><?php echo _m('global', 'near'); ?></div><div class="td td-w-s" data-text="<?php echo $json['subjective']['2']['distance']['value']; ?>" data-suffix="<?php echoUnit($json['subjective']['2']['distance']['unit']); ?>"></div>
				</div>
				<div class="separater"></div>
			</div><!--/.userdata-table-->
			
			<div class="userdata-table userdata-D">
				<div class="tr">
					<div class="th">PD</div><div class="td td-w-s" data-text="<?php echo $json['objective']['pd']['value']; ?>" data-suffix="<?php echoUnit($json['objective']['pd']['unit']); ?>"></div>
				</div>
				<div class="tr">
					<div class="th">VD</div><div class="td td-w-s" data-text="<?php echo $json['objective']['vd']['value']; ?>" data-suffix="<?php echoUnit($json['objective']['vd']['unit']); ?>"></div>
				</div>
			</div><!--/.userdata-table-->
			
		</div><!--/.area-inner-->
	</div><!--/.area-a-->
	<div class="area-b">
		<div class="area-inner">

		<div class="tab-box" id="tabResult" data-tab-index="0">
			<div class="tab-header-group">
				<div class="tab-header current"><p class="txt-tab-header">Result 1</p></div>
				<div class="tab-header"        ><p class="txt-tab-header">Result 2</p></div>
				<div class="tab-header"        ><p class="txt-tab-header">Result 3</p></div>
				<div class="tab-header"        ><p class="txt-tab-header">Result 4</p></div>
				<div class="tab-header"        ><p class="txt-tab-header">Result 5</p></div>
			</div>
			<div class="tab-content-group">
			
				<div class="tab-content current">

					<table class="result">
						<tr>
							<td colspan="3"><?php echo _m('result', 'objectiveMeasurementMode'); ?></td>
						</tr>
						<tr class="right">
							<td rowspan="2" class="far near" >&nbsp;</td>
							<td class="text-center eye"      ><?php echo _m('global', 'rightEye'); ?></td>
							<td class="text-center targetEye"><?php echo $json['objective']['R']['targetEye']; ?></td>
						</tr>
						<tr class="left">
							<td class="text-center eye"      ><?php echo _m('global', 'leftEye'); ?></td>
							<td class="text-center targetEye"><?php echo $json['objective']['L']['targetEye']; ?></td>
						</tr>
					</table>

					<table class="result">
						<tr>
							<td colspan="2"                    ><?php echo _m('result', 'objectiveShort'); ?></td>
							<td             class="text-center">SPH</td>
							<td             class="text-center">CYL</td>
							<td             class="text-center">AXS</td>
						</tr>
						<?php $eye = 'R'; ?>
						<tr class="right">
							<td rowspan="2" class="far near"       >&nbsp;</td>
							<td             class="text-center eye"><?php echo _m('global', 'rightEye'); ?></td>
							<td             class="text-right  sph"><?php echo $json['objective'][$eye]['sph'][0]; ?></td>
							<td             class="text-right  cyl"><?php echo $json['objective'][$eye]['cyl'][0]; ?></td>
							<td             class="text-right  axs"><?php echo $json['objective'][$eye]['axs'][0]; ?></td>
						</tr>
						<?php $eye = 'L'; ?>
						<tr class="left">
							<td class="text-center eye"><?php echo _m('global', 'leftEye'); ?></td>
							<td class="text-right  sph"><?php echo $json['objective'][$eye]['sph'][0]; ?></td>
							<td class="text-right  cyl"><?php echo $json['objective'][$eye]['cyl'][0]; ?></td>
							<td class="text-right  axs"><?php echo $json['objective'][$eye]['axs'][0]; ?></td>
						</tr>
					</table>

					<table class="result">
						<tr>
							<td colspan="2"                    ><?php echo _m('result', 'subjectiveShort'); ?></td>
							<td             class="text-center">SPH</td>
							<td             class="text-center">CYL</td>
							<td             class="text-center">AXS</td>
							<td             class="text-center">ADD</td>
							<td colspan="2" class="text-center">VA </td>
						</tr>
						<?php $listNum = '1'; ?>
						<?php $eye     = 'R'; ?>
						<tr class="right">
							<td rowspan="2" class="text-center far"><?php echo _m('global', 'far'); ?></td>
							<td             class="text-center eye"><?php echo _m('global', 'rightEye'); ?></td>
							<td             class="text-right  sph"><?php echo $json['subjective'][$listNum][$eye]['sph']; ?></td>
							<td             class="text-right  cyl"><?php echo $json['subjective'][$listNum][$eye]['cyl']; ?></td>
							<td             class="text-right  axs"><?php echo $json['subjective'][$listNum][$eye]['axs']; ?></td>
							<td             class="text-right  add"><?php echo $json['subjective'][$listNum][$eye]['add']; ?></td>
							<td             class="text-right  va" ><?php echo $json['subjective'][$listNum][$eye]['va' ]; ?></td>
							<td rowspan="2" class="text-right  va" ><?php echo $json['subjective'][$listNum][ 'B']['va' ]; ?></td>
						</tr>
						<?php $eye     = 'L'; ?>
						<tr class="left">
							<!-- rowspan の分 -->
							<td             class="text-center eye"><?php echo _m('global', 'leftEye'); ?></td>
							<td             class="text-right  sph"><?php echo $json['subjective'][$listNum][$eye]['sph']; ?></td>
							<td             class="text-right  cyl"><?php echo $json['subjective'][$listNum][$eye]['cyl']; ?></td>
							<td             class="text-right  axs"><?php echo $json['subjective'][$listNum][$eye]['axs']; ?></td>
							<td             class="text-right  add"><?php echo $json['subjective'][$listNum][$eye]['add']; ?></td>
							<td             class="text-right  va" ><?php echo $json['subjective'][$listNum][$eye]['va' ]; ?></td>
							<!-- rowspan の分 -->
						</tr>
						<?php $listNum = '2'; ?>
						<?php $eye     = 'R'; ?>
						<tr class="right">
							<td rowspan="2" class="text-center near"><?php echo _m('global', 'near'); ?></td>
							<td             class="text-center eye" ><?php echo _m('global', 'rightEye'); ?></td>
							<td             class="text-right  sph" ><?php echo $json['subjective'][$listNum][$eye]['sph']; ?></td>
							<td             class="text-right  cyl" ><?php echo $json['subjective'][$listNum][$eye]['cyl']; ?></td>
							<td             class="text-right  axs" ><?php echo $json['subjective'][$listNum][$eye]['axs']; ?></td>
							<td             class="text-right  add" ><?php echo $json['subjective'][$listNum][$eye]['add']; ?></td>
							<td             class="text-right  va"  ><?php echo $json['subjective'][$listNum][$eye]['va' ]; ?></td>
							<td rowspan="2" class="text-right  va"  ><?php echo $json['subjective'][$listNum][ 'B']['va' ]; ?></td>
						</tr>
						<?php $eye     = 'L'; ?>
						<tr class="left">
							<!-- rowspan の分 -->
							<td             class="text-center eye"><?php echo _m('global', 'leftEye'); ?></td>
							<td             class="text-right  sph"><?php echo $json['subjective'][$listNum][$eye]['sph']; ?></td>
							<td             class="text-right  cyl"><?php echo $json['subjective'][$listNum][$eye]['cyl']; ?></td>
							<td             class="text-right  axs"><?php echo $json['subjective'][$listNum][$eye]['axs']; ?></td>
							<td             class="text-right  add"><?php echo $json['subjective'][$listNum][$eye]['add']; ?></td>
							<td             class="text-right  va" ><?php echo $json['subjective'][$listNum][$eye]['va' ]; ?></td>
							<!-- rowspan の分 -->
						</tr>
					</table>

				</div>

				<div class="tab-content">

					<table class="result">
						<tr>
							<td colspan="2"                    ><?php echo _m('result', 'objectiveShort'); ?></td>
							<td             class="text-center">SPH</td>
							<td             class="text-center">CYL</td>
							<td             class="text-center">AXS</td>
						</tr>
						<?php $trial = 1; ?>
						<?php $eye = 'R'; ?>
						<tr class="right">
							<td rowspan="2" class="trial"          ><?php echo $trial; ?></td>
							<td             class="text-center eye"><?php echo _m('global', 'rightEye'); ?></td>
							<td             class="text-right  sph"><?php echo $json['objective'][$eye]['sph'][$trial]; ?></td>
							<td             class="text-right  cyl"><?php echo $json['objective'][$eye]['cyl'][$trial]; ?></td>
							<td             class="text-right  axs"><?php echo $json['objective'][$eye]['axs'][$trial]; ?></td>
						</tr>
						<?php $eye = 'L'; ?>
						<tr class="left">
							<td class="text-center eye"><?php echo _m('global', 'leftEye'); ?></td>
							<td class="text-right  sph"><?php echo $json['objective'][$eye]['sph'][$trial]; ?></td>
							<td class="text-right  cyl"><?php echo $json['objective'][$eye]['cyl'][$trial]; ?></td>
							<td class="text-right  axs"><?php echo $json['objective'][$eye]['axs'][$trial]; ?></td>
						</tr>
						<?php $trial = 2; ?>
						<?php $eye = 'R'; ?>
						<tr class="right">
							<td rowspan="2" class="trial"          ><?php echo $trial; ?></td>
							<td             class="text-center eye"><?php echo _m('global', 'rightEye'); ?></td>
							<td             class="text-right  sph"><?php echo $json['objective'][$eye]['sph'][$trial]; ?></td>
							<td             class="text-right  cyl"><?php echo $json['objective'][$eye]['cyl'][$trial]; ?></td>
							<td             class="text-right  axs"><?php echo $json['objective'][$eye]['axs'][$trial]; ?></td>
						</tr>
						<?php $eye = 'L'; ?>
						<tr class="left">
							<td class="text-center eye"><?php echo _m('global', 'leftEye'); ?></td>
							<td class="text-right  sph"><?php echo $json['objective'][$eye]['sph'][$trial]; ?></td>
							<td class="text-right  cyl"><?php echo $json['objective'][$eye]['cyl'][$trial]; ?></td>
							<td class="text-right  axs"><?php echo $json['objective'][$eye]['axs'][$trial]; ?></td>
						</tr>
						<?php $trial = 3; ?>
						<?php $eye = 'R'; ?>
						<tr class="right">
							<td rowspan="2" class="trial"          ><?php echo $trial; ?></td>
							<td             class="text-center eye"><?php echo _m('global', 'rightEye'); ?></td>
							<td             class="text-right  sph"><?php echo $json['objective'][$eye]['sph'][$trial]; ?></td>
							<td             class="text-right  cyl"><?php echo $json['objective'][$eye]['cyl'][$trial]; ?></td>
							<td             class="text-right  axs"><?php echo $json['objective'][$eye]['axs'][$trial]; ?></td>
						</tr>
						<?php $eye = 'L'; ?>
						<tr class="left">
							<td class="text-center eye"><?php echo _m('global', 'leftEye'); ?></td>
							<td class="text-right  sph"><?php echo $json['objective'][$eye]['sph'][$trial]; ?></td>
							<td class="text-right  cyl"><?php echo $json['objective'][$eye]['cyl'][$trial]; ?></td>
							<td class="text-right  axs"><?php echo $json['objective'][$eye]['axs'][$trial]; ?></td>
						</tr>
					</table>

				</div>

				<div class="tab-content">

				</div>

				<div class="tab-content">

				</div>

				<div class="tab-content">

				</div>

			</div>

		</div><!--/.tab-box-->

		</div><!--/.area-inner-->
	</div><!--/.area-b-->
</div><!--/.layout-content-->
</div><!--./siteframe-body-inner-->
</div><!--./siteframe-body-->

<div class="siteframe-footer">
<div class="siteframe-footer-inner">
<div class="layout-footer clearfix">
	<div class="menu">
		<?php
		//<div class="menu-item"><button type="button" class="btn btn-menu"><div class="btn-inner"><span class="icon icon-10"></span>読込み</div></button></div>
		//<div class="menu-item"><button type="button" class="btn btn-menu"><div class="btn-inner"><span class="icon icon-11"></span>出力</div></button></div>
		?>
	</div><!--/.menu-->
</div><!--/.layout-footer-->
</div><!--./siteframe-footer-inner-->
</div><!--./siteframe-footer-->

</div><!--./siteframe-inner-->
</div><!--./siteframe-->



</body>
</html>
