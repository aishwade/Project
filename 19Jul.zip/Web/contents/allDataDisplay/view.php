<?php
/*! @file
 * @brief 自覚画面の中身
 */

require_once topDir() . 'models/modelUtil.php';
require_once topDir() . 'models/pathUtil.php';
require_once topDir() . 'models/fileUtil.php';
require_once topDir() . 'views/messageHelper.php';
require_once topDir() . 'views/_tags.php';
require_once topDir() . 'contents/_head.php';
require_once topDir() . 'contents/_live.php';
require_once topDir() . 'contents/allDataDisplay/_head.php';
require_once topDir() . 'contents/allDataDisplay/_viewLogic.php';
require_once topDir() . 'contents/machineConfig/_machineConfigUtil.php';
require_once topDir() . 'contents/machineConfig/machineConfigCategoryType.php';
$elements = [
	// カテゴリ                                 , コントロールタイプ                , 設定名称                              , デフォルト, 選択肢
	
	[ \machineConfig\CategoryType::OBJECTIVE    , \becky\ControlType::DROPDOWN_LIST , 'vd'                                  , 1, [ '0.00', '12.00',  '13.75' ] ]
	
];


// デフォルト値の定義
define('SPH_DEFALUT_VALUE',   0);
define('CYL_DEFALUT_VALUE',   0);
define('AXS_DEFALUT_VALUE', 180);
define( 'PD_DEFALUT_VALUE',  65);

function createAutoID($keyChartPageParam, $chart)
{
	$layoutID = $chart['layoutID'];
	return join('_', [ $keyChartPageParam, 'layoutID' . $layoutID ] );
}


$filenameRefractometerJson = 'contents/settings/objective.refraction.json';
$arrayRefractometerSetting = getMapFromJsonFile(topDir() . $filenameRefractometerJson);
if (!$arrayRefractometerSetting) {
	// 他覚の設定ファイルが無いのでエラーページに飛ばす
	$_SESSION['error'] = [
		'redirectUri'  => topUri() . 'sub/machineConfig.php',
		'redirectWait' => 30,
		'title'        => _m('error', 'title'),
		'msg'          => 'file not found!<br>' . $filenameRefractometerJson,
	];
	header('Location: ' . topUri() . 'sub/error.php');
	return;
	
}
$refractojson = [];

$refractoright = $arrayRefractometerSetting['refraction']['R']['List'];
$refractoleft = $arrayRefractometerSetting['refraction']['L']['List'];
$refractorightmedian = $arrayRefractometerSetting['refraction']['R']['Median'];
$refractoleftmedian = $arrayRefractometerSetting['refraction']['L']['Median'];
$RefractoList = array();
$keys = array_keys($refractoright);
foreach ($keys as $key) {
    $RefractoList[$key] = array($refractoright[$key], $refractoleft[$key]);
}



$filenamekeratometryJson = 'contents/settings/objective.keratometry.json';
$arraykeratometrySetting = getMapFromJsonFile(topDir() . $filenamekeratometryJson);

if (!$arraykeratometrySetting) {
	// 他覚の設定ファイルが無いのでエラーページに飛ばす
	$_SESSION['error'] = [
		'redirectUri'  => topUri() . 'sub/machineConfig.php',
		'redirectWait' => 30,
		'title'        => _m('error', 'title'),
		'msg'          => 'file not found!<br>' . $filenamekeratometryJson,
	];
	header('Location: ' . topUri() . 'sub/error.php');
	return;
	
}
$json = [];
$keratoright = $arraykeratometrySetting['keratometry']['R']['List'];
$keratoleft = $arraykeratometrySetting['keratometry']['L']['List'];
$keratoList = array();
$keys = array_keys($keratoright);
foreach ($keys as $key) {
    $keratoList[$key] = array($keratoright[$key], $keratoleft[$key]);
}
//echo "<pre>";
//print_r($keratoList);
//exit;

?>

<html lang="ja-JP" class="no-js" xmlns:og="http://ogp.me/ns#" xmlns:mixi="http://mixi-platform.com/ns#" xmlns:fb="http://www.facebook.com/2008/fbml">
<!--<![endif]-->
<head>
<?php outputHeadContents(); ?>
<title><?php echo _m('allDataDisplay', 'title'); ?></title>
<!--[if lt IE 9]>
<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
<script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
<?php outputHeadContents(); ?>
</head>
<body>
<!-- メッセージの定義リスト(JavaScript向け) -->
<dl id="list_message" style="display: none;">
	<?php
		echoListMessageItem('global'    , 'far' );
		echoListMessageItem('global'    , 'near');
		echoListMessageItem('global'    , 'va'  );
		echoListMessageItem('subjective', 'titleExamID1000');
		echoListMessageItem('subjective', 'titleExamID1010');
		echoListMessageItem('subjective', 'titleExamID1020');
		echoListMessageItem('subjective', 'titleExamID1021');
		echoListMessageItem('subjective', 'titleExamID1092');
		echoListMessageItem('subjective', 'titleExamID2030');
		echoListMessageItem('subjective', 'controllerSPH');
		echoListMessageItem('subjective', 'controllerCYL');
		echoListMessageItem('subjective', 'controllerAXS');
		echoListMessageItem('subjective', 'controllerPowerAxis');
		echoListMessageItem('subjective', 'controllerADD');
	?>
</dl>
<div id="currentEye" data-value="B" style="display: none;"></div>
<div id="currentSCA" data-value="Sph" style="display: none;"></div>
<div id="currentAutoID" data-value="<?php echo createAutoID('chartPage1', $arrayChartPageParam['chartPage1'][0]); ?>" style="display: none;"></div>
<div class="siteframe B-objective">
<div class="siteframe-inner">

<?php include_once topDir() . 'contents/_nav.php'; ?>

<div class="siteframe-body">
<div class="siteframe-body-inner">
<div class="layout-content mode-left clearfix">
	<div class="area area-a clearfix">
		<div class="title">
			<p class="txt-title-inspection" id="labelExamTitle" data-text="<?php echo $firstExamTitle; ?>"></p>
			<p class="txt-title-course"></p>
		</div><!--/.title-->
	</div><!--/.area-a-->
	<div class="area background clearfix">
	
	<body>
		<div class="all-data-table">
			<div class="list-items">
			<div class="tab-box" id="tabChart" data-tab-index="0">
			<div class="tab-header-group tabs">
				<div class="rm1 tab-link current tab-header" data-tab="tab-1"><p class="txt-tab-header">RM1</p></div>
				<div class="rm2 tab-link tab-header" data-tab="tab-2"><p class="txt-tab-header">RM2</p></div>
				<div class="km tab-link tab-header" data-tab="tab-3"><p class="txt-tab-header">KR</p></div>
			</div>
			</div>
			</div>
			<div class="flex-table">
			<div class="rm1-table tab-content current" id="tab-1">
				<div class="distance-block"><label class="distance">Distance = <?php echo $arrayRefractometerSetting['PD']['Distance']['value']; ?>m Ft(xx.x)</label></div>
				<div class="divTable">
					<div class="divTableBody">
						<div class="divTableRow">
							<div class="divTableCell topCell">R</div>
							<div class="divTableCell topCell">L</div>
						</div>
					</div>
				</div>
				<div class="divTable2">
					<div class="divTableBody">
						<div class="divTableRow">
							<div class="divTableCell">S(D)</div>
							<div class="divTableCell">C(D)</div>
							<div class="divTableCell">A(Deg)</div>
							<div class="divTableCell">S(D)</div>
							<div class="divTableCell">C(D)</div>
							<div class="divTableCell">A(Deg)</div>
						</div>
					</div>
				</div>
				<table class="custom-data-table">
					<tbody>
					<?php foreach($RefractoList as $rkey=>$listitem){ ?>
					<tr>
					<td><?php echo $rkey; ?></td>
					<?php foreach($listitem as $eye): ?>
					<td> <?php echo $eye['Sphere']['value']; ?></td>
					<td> <?php echo $eye['Cylinder']['value']; ?></td>
					<td> <?php echo $eye['Axis']['value']; ?></td>
					<?php endforeach; ?>
					</tr>
					
					<?php } ?>
					<tr>
					
					<td>Average</td>
					<td><?php echo $refractorightmedian['Sphere']['value']; ?>&nbsp;</td>
					<td><?php echo $refractorightmedian['Cylinder']['value']; ?>&nbsp;</td>
					<td><?php echo $refractorightmedian['Axis']['value']; ?>&nbsp;</td>
					
					<td><?php echo $refractoleftmedian['Sphere']['value']; ?>&nbsp;</td>
					<td><?php echo $refractoleftmedian['Cylinder']['value']; ?>&nbsp;</td>
					<td><?php echo $refractoleftmedian['Axis']['value']; ?>&nbsp;</td>
					</tr>
					</tbody>
				</table>
			</div>	
			<div class="rm2-table tab-content" id="tab-2">
			<div class="distance-block"><label class="distance">Distance = <?php echo $arrayRefractometerSetting['PD']['Distance']['value']; ?>m</label></div>
				<div class="divTable">
					<div class="divTableBody">
						<div class="divTableRow">
							<div class="divTableCell">R</div>
							<div class="divTableCell">L</div>
						</div>
					</div>
				</div>
				<div class="divTable2">
					<div class="divTableBody">
						<div class="divTableRow">
							<div class="divTableCell">S(D)</div>
							<div class="divTableCell">C(D)</div>
							<div class="divTableCell">A(Deg)</div>
							<div class="divTableCell">S(D)</div>
							<div class="divTableCell">C(D)</div>
							<div class="divTableCell">A(Deg)</div>
						</div>
					</div>
				</div>
				<table class="custom-data-table">
					<tbody>
					<?php foreach($RefractoList as $rkey=>$listitem){ ?>
					<tr>
					<td><?php echo $rkey; ?></td>
					<?php foreach($listitem as $eye): ?>
					<td> <?php echo $eye['Sphere']['value']; ?></td>
					<td> <?php echo $eye['Cylinder']['value']; ?></td>
					<td> <?php echo $eye['Axis']['value']; ?></td>
					<?php endforeach; ?>
					</tr>
					<?php } ?>
					<tr>
					
					<td>Average</td>
					
					
					<td><?php echo $refractorightmedian['Sphere']['value']; ?>&nbsp;</td>
					<td><?php echo $refractorightmedian['Cylinder']['value']; ?>&nbsp;</td>
					<td><?php echo $refractorightmedian['Axis']['value']; ?>&nbsp;</td>
					
					<td><?php echo $refractoleftmedian['Sphere']['value']; ?>&nbsp;</td>
					<td><?php echo $refractoleftmedian['Cylinder']['value']; ?>&nbsp;</td>
					<td><?php echo $refractoleftmedian['Axis']['value']; ?>&nbsp;</td>
					</tr>
					</tbody>
				</table>
			</div>	
			<div class="kr-table tab-content" id="tab-3">
				<div class="divTable">
					<div class="divTableBody">
						<div class="divTableRow">
							<div class="divTableCell topCell">R</div>
							<div class="divTableCell topCell">L</div>
						</div>
					</div>
				</div>
				<div class="divTable2">
					<div class="divTableBody">
						<div class="divTableRow">
							<div class="divTableCell">R(mm)</div>
							<div class="divTableCell">D(D)</div>
							<div class="divTableCell">A(Deg)</div>
							<div class="divTableCell">R(mm)</div>
							<div class="divTableCell">D(D)</div>
							<div class="divTableCell">A(Deg)</div>
						</div>
					</div>
				</div>
				<table class="custom-data-table">
					<tbody>
					<?php foreach($keratoright as $kkey => $rightvalue): ?>
					
					<tr>
						
			<th rowspan="4"><?php echo $kkey; ?> </th>
			
		<td>Weak</td>
		<?php $type = 'R1'; ?>
        <td><?php echo $rightvalue[$type]['Radius']['value']; ?></td>
		<td><?php echo $rightvalue[$type]['Power']['value']; ?></td>
		<td><?php echo $rightvalue[$type]['Axis']['value']; ?></td>
		<td><?php echo $keratoleft[$kkey][$type]['Radius']['value']; ?></td>
		<td><?php echo $keratoleft[$kkey][$type]['Power']['value']; ?></td>
		<td><?php echo $keratoleft[$kkey][$type]['Axis']['value']; ?></td>
			</tr>
			<tr>
						
			
			
		<td>Strong</td>
		<?php $type = 'R2'; ?>
        <td><?php echo $rightvalue[$type]['Radius']['value']; ?></td>
		<td><?php echo $rightvalue[$type]['Power']['value']; ?></td>
		<td><?php echo $rightvalue[$type]['Axis']['value']; ?></td>
		<td><?php echo $keratoleft[$kkey][$type]['Radius']['value']; ?></td>
		<td><?php echo $keratoleft[$kkey][$type]['Power']['value']; ?></td>
		<td><?php echo $keratoleft[$kkey][$type]['Axis']['value']; ?></td>
			</tr>
			<tr>
		
	
		
		<td>Average</td>
		<?php $type = 'Average'; ?>
        <td><?php echo $rightvalue[$type]['Radius']['value']; ?></td>
		<td><?php echo $rightvalue[$type]['Power']['value']; ?></td>
		<td><?php echo $rightvalue[$type]['Axis']['value']; ?></td>
		<td><?php echo $keratoleft[$kkey][$type]['Radius']['value']; ?></td>
		<td><?php echo $keratoleft[$kkey][$type]['Power']['value']; ?></td>
		<td><?php echo $keratoleft[$kkey][$type]['Axis']['value']; ?></td>
			</tr>
			<td>Cylinder</td>
		<?php $type = 'Cylinder'; ?>
        <td><?php echo $rightvalue[$type]['Radius']['value']; ?></td>
		<td><?php echo $rightvalue[$type]['Power']['value']; ?></td>
		<td><?php echo $rightvalue[$type]['Axis']['value']; ?></td>
		<td><?php echo $keratoleft[$kkey][$type]['Radius']['value']; ?></td>
		<td><?php echo $keratoleft[$kkey][$type]['Power']['value']; ?></td>
		<td><?php echo $keratoleft[$kkey][$type]['Axis']['value']; ?></td>
			</tr>
<?php endforeach; ?>

									
				
					
					</tbody>
				</table>
			</div>	
			</div>
		</div>
		</div>
		
		</div><!--/.layout-content-->
</div><!--./siteframe-body-inner-->
</div><!--./siteframe-body-->

</div><!--./siteframe-inner-->
<div class="siteframe-footer">
<div class="siteframe-footer-inner">
<div class="layout-footer clearfix">
	<div class="menu">
		<div class="menu-item"><button type="button" class="btn btn-menu" id="btnFixationLevel" value="High"><div class="btn-inner"><span id="labelFixationLevelHigh">A</span>/<span id="labelFixationLevelLow">M</span></div></button></div>
		<div class="menu-item"><button type="button" class="btn btn-menu" id="btnFixationLevel" value="High"><div class="btn-inner"><span id="labelFixationLevelHigh">H</span>/<span id="labelFixationLevelLow">L</span></div></button></div>
		<div class="menu-item"><button type="button" class="btn btn-menu" id="btnClear"><div class="btn-inner"><span class="icon icon-05"></span></div></button></div>
		<div class="menu-item menu-item-large"><button type="button" class="btn btn-menu btn-menu-large" id="btnStart"><div class="btn-inner">
		
		<a class="backButton" href="<?php echo "http://" . $_SERVER['HTTP_HOST']."/topcon/sub/objective.php"; ?>">Back</a></div></button></div>
		<div class="menu-item"><button type="button" class="btn btn-menu" id="btnAlignmentMode" value="A"><div class="btn-inner"><span id="labelA">All</span></div></button></div>
		<div class="menu-item"><button type="button" class="btn btn-menu" id="btnAlignmentMode" value="A"><div class="btn-inner">
		<div class="dropdown custom-select">
		<select class="dropdown-menu">
		<!-- <?php echo buildConfigTags($elements, \machineConfig\CategoryType::OBJECTIVE); ?> -->
			<option value=""  disabled selected hidden><a href="#"class="dropbtn">VD</a></option>
			<option value="" >12.00mm</option>
			<option value="" ><p class="options">13.75 mm</p></option>
			<option value="" ><p class="options">0.0 mm</p></option>
		</select>

		</div></button></div>
		<div class="menu-item"><button type="button" class="btn btn-menu" id="btnAlignmentMode" value="A"><div class="btn-inner"><span id="labelA">Clear</span></div></button></div>
	</div><!--/.menu-->
</div><!--/.layout-footer-->
</div><!--./siteframe-footer-inner-->
</div>
</div><!--./siteframe-->
<!--./siteframe-footer-->


</body>
</html>