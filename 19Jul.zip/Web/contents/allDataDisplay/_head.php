<?php
/*! @file
 * @brief result 固有のスタイルシートとスクリプトの読み込み
 */

addStyles(
	[
		'css/allDataDisplay.css',
		'css/objective.css',
	]
);

addScripts(
	[
		'js/result.js',
		'js/alldata.js', 
	]
);
