<?php
/*! @file
 * @brief ネットワーク設定ファイルの入出力
 */

require_once topDir() . 'models/systemUtil.php';

/*!
 * @brief ネットワーク設定ファイルのパスを得る
 *
 * @return string ネットワーク設定ファイルのパス
 */
function getNetworkFilePath()
{
	return '/etc/network/interfaces';
}

/*!
 * @brief NIC の eth1 の設定箇所を得る
 *
 * @param[in] string $networkFilePath ネットワーク設定ファイルのパス
 * @retval array 設定箇所
 * @retval false 失敗
 */
function getIfaceEth1($networkFilePath)
{
	if (!file_exists($networkFilePath)) {
		return false;
	}
	$networkFileLines = file($networkFilePath);

	$eth1 = [];
	$state = 0;
	foreach ($networkFileLines as $index => $line) {
		$line = trim($line);
		if (empty($line) || 0 === strpos($line, '#')) {
			continue;
		}
		switch ($state) {
			case 0:
				if (1 === preg_match('/iface\s+eth1\s+inet\s+static/i', $line)) {
					$eth1[$index] = $line;
					++$state;
				}
				break;
			case 1:
				if (1 === preg_match('/(address|netmask|gateway)/i', $line)) {
					$eth1[$index] = $line;
				} else {
					++$state;
				}
				break;
			default:
				break(2); // switch の break と foreach の break
		}
	}
	if (empty($eth1)) {
		return false;
	}

	return $eth1;
}

/*!
 * @brief ネットワーク情報を得る
 *
 * @param[out] string $ipAddress IPアドレス
 * @param[out] string $subnetMask サブネットマスク
 * @param[out] string $defaultGateway デフォルトゲートウェイ
 * @retval true 成功
 * @retval false 失敗
 */
function getNetworkInterfaces(&$ipAddress, &$subnetMask, &$defaultGateway)
{
	$networkFilePath = getNetworkFilePath();
	$eth1 = getIfaceEth1($networkFilePath);
	if (!$eth1) {
		return false;
	}

	$pattern = '/(address|netmask|gateway)\s+(\d{1,3})\s*\.\s*(\d{1,3})\s*\.\s*(\d{1,3})\s*\.\s*(\d{1,3})/i';
	foreach ($eth1 as $eth1Line) {
		$matches = [];
		if (!preg_match($pattern, $eth1Line, $matches)) {
			continue;
		}
		$type = $matches[1];
		$ip = join('.', array_slice($matches, 2));
		switch ($type) {
			case 'address':
				$ipAddress = $ip;
				break;
			case 'netmask':
				$subnetMask = $ip;
				break;
			case 'gateway':
				$defaultGateway = $ip;
				break;
			default:
				break;
		}
	}

	return true;
}

/*!
 * @brief sed コマンドを生成する
 *
 * @param[in] string $ipAddress IPアドレス
 * @param[in] string $subnetMask サブネットマスク
 * @param[in] string $defaultGateway デフォルトゲートウェイ
 * @retval string 成功
 * @retval false 失敗
 */
function createNetworkInterfacesSedCommand($ipAddress, $subnetMask, $defaultGateway)
{
	$networkFilePath = getNetworkFilePath();
	$eth1 = getIfaceEth1($networkFilePath);
	if (!$eth1) {
		return false;
	}

	$eth1LineNumber = array_keys($eth1);
	// 行番号を扱うので1加算
	$first = current($eth1LineNumber) + 1;
	$begin = next   ($eth1LineNumber) + 1;
	$end   = end    ($eth1LineNumber) + 1;
	$i = $first;

	$cmdLines = array('sed', '-i');
	$cmdLines[] = '-e "' . $begin . ',' . $end . 'd"';
	{
		$networkSettings = [];
		if (!empty($ipAddress)) {
			$networkSettings['address'] = $ipAddress;
		}
		if (!empty($subnetMask)) {
			$networkSettings['netmask'] = $subnetMask;
		}
		if (!empty($defaultGateway)) {
			$networkSettings['gateway'] = $defaultGateway;
		}
		$optEAs = [];
		foreach ($networkSettings as $key => $value) {
			$optEAs[] = '-e "' . $i . 'a ' . '\        ' . $key . ' ' . $value . '"';
		}
		$cmdLines = array_merge($cmdLines, $optEAs);
	}
	$cmdLines[] = '"' . $networkFilePath . '"';
	$cmdLine = join(' ', $cmdLines);

	return $cmdLine;
}

/*!
 * @brief ネットワーク設定ファイルに書き込む
 *
 * @param[in] string $ipAddress IPアドレス
 * @param[in] string $subnetMask サブネットマスク
 * @param[in] string $defaultGateway デフォルトゲートウェイ
 * @retval true 成功
 * @retval false 失敗
 */
function writeFileNetworkInterfaces($ipAddress, $subnetMask, $defaultGateway)
{
	$command = createNetworkInterfacesSedCommand($ipAddress, $subnetMask, $defaultGateway);
	if (!$command) {
		return false;
	}

	$output = [];
	$return_var = 0;
	exec($command, $output, $return_var);

	// sync で速やかに SD カードに書き込む
	\becky\System\sync();

	return 0 === $return_var;
}

/*!
 * @brief バックアップコマンドを生成
 *
 * @retval string 成功
 * @retval false 失敗
 */
function createBackupCommand()
{
	$networkFilePath = getNetworkFilePath();
	if (!file_exists($networkFilePath)) {
		return false;
	}

	$from = '"' . $networkFilePath          . '"';
	$to   = '"' . $networkFilePath . '.bak' . '"';

	$cmdLines = array('cp', '-fp', $from, $to);
	$cmdLine = join(' ', $cmdLines);

	return $cmdLine;
}

/*!
 * @brief ネットワーク設定ファイルのバックアップを行う
 *
 * @retval true 成功
 * @retval false 失敗
 */
function backupFileNetworkInterfaces()
{
	$command = createBackupCommand();
	if (!$command) {
		return false;
	}

	$output = [];
	$return_var = 0;
	exec($command, $output, $return_var);

	return 0 === $return_var;
}
