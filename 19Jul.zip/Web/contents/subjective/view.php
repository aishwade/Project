<?php
/*! @file
 * @brief 自覚画面の中身
 */

require_once topDir() . 'models/modelUtil.php';
require_once topDir() . 'views/messageHelper.php';
require_once topDir() . 'views/_tags.php';
require_once topDir() . 'contents/_head.php';
require_once topDir() . 'contents/_live.php';
require_once topDir() . 'contents/subjective/_head.php';
require_once topDir() . 'contents/subjective/_viewLogic.php';

// デフォルト値の定義
define('SPH_DEFALUT_VALUE',   0);
define('CYL_DEFALUT_VALUE',   0);
define('AXS_DEFALUT_VALUE', 180);
define('PD_DEFALUT_VALUE',  65);

/*!
 * @brief 0.25 単位に丸める
 *
 * @param[in,out] mixed $value 対象
 * @return void
 */
function round025(&$value)
{
	$value = floatval($value);
	if (0 === $value) {
		return;
	}
	$value = \ModelUtil\fround($value, 0.25);
}

/*!
 * @brief 整数値に丸める
 *
 * @param[in,out] mixed $value 対象
 * @return void
 */
function round1(&$value)
{
	$value = floatval($value);
	if (0 === $value) {
		return;
	}
	$value = \ModelUtil\fround($value, 1);
	$value = intval($value);
}

/*!
 * @brief 自動 ID を生成する
 * 視表を区別する精度があれば良い
 *
 * @param[in] string $keyChartPageParam
 * @param[in] object $chart
 * @return string
 */
function createAutoID($keyChartPageParam, $chart)
{
	$layoutID = $chart['layoutID'];
	return join('_', [$keyChartPageParam, 'layoutID' . $layoutID]);
}

if (!empty($_POST['subjective_register'])) {
	// 保存前にトリムする
	\ModelUtil\array_trim($_POST);

	if (doRegisterSubjective()) {
		header('Location: ' . topUri() . 'sub/result.php');
		exit;
	}
}
$lang = getRegionIDFromSetting();
$filenameObjectiveSettingJson = 'contents/settings/objective.setting.json';
$arrayObjectiveSetting = getMapFromJsonFile(topDir() . $filenameObjectiveSettingJson);
if (!$arrayObjectiveSetting) {
	// 他覚の設定ファイルが無いのでエラーページに飛ばす
	$_SESSION['error'] = [
		'redirectUri'  => topUri() . 'sub/machineConfig.php',
		'redirectWait' => 30,
		'title'        => _m('error', 'title'),
		'msg'          => 'file not found!<br>' . $filenameObjectiveSettingJson,
	];
	header('Location: ' . topUri() . 'sub/error.php');
	return;
}

$filenameSubjectiveSettingJson = 'contents/settings/subjective.setting.json';
$arraySubjectiveSetting = getMapFromJsonFile(topDir() . $filenameSubjectiveSettingJson);
if (!$arraySubjectiveSetting) {
	// 自覚の設定ファイルが無いのでエラーページに飛ばす
	$_SESSION['error'] = [
		'redirectUri'  => topUri() . 'sub/machineConfig.php',
		'redirectWait' => 30,
		'title'        => _m('error', 'title'),
		'msg'          => 'file not found!<br>' . $filenameSubjectiveSettingJson,
	];
	header('Location: ' . topUri() . 'sub/error.php');
	return;
}

$filenameChartParamJson = 'contents/settings/chart.parameter.json';
$arrayChartParam = getMapFromJsonFile(topDir() . $filenameChartParamJson);
if (!$arrayChartParam) {
	// 視力表の定義ファイルが無いのでエラーページに飛ばす
	$_SESSION['error'] = [
		'redirectUri'  => topUri(),
		//	'redirectWait' => 30,
		'title'        => _m('error', 'title'),
		'msg'          => 'file not found!<br>' . $filenameChartParamJson,
	];
	header('Location: ' . topUri() . 'sub/error.php');
	return;
}

$filenameChartPageParamJson = 'contents/settings/chartPage.parameter.json';
$arrayChartPageParam = getMapFromJsonFile(topDir() . $filenameChartPageParamJson);
if (!$arrayChartPageParam) {
	// 視力表の定義ファイルが無いのでエラーページに飛ばす
	$_SESSION['error'] = [
		'redirectUri'  => topUri(),
		//	'redirectWait' => 30,
		'title'        => _m('error', 'title'),
		'msg'          => 'file not found!<br>' . $filenameChartPageParamJson,
	];
	header('Location: ' . topUri() . 'sub/error.php');
	return;
}

$filenameExamParamJson = 'contents/settings/exam.parameter.json';

$arrayExamParam = getMapFromJsonFile(topDir() . $filenameExamParamJson);
if (!$arrayExamParam) {
	// 視力表の定義ファイルが無いのでエラーページに飛ばす
	$_SESSION['error'] = [
		'redirectUri'  => topUri(),
		//	'redirectWait' => 30,
		'title'        => _m('error', 'title'),
		'msg'          => 'file not found!<br>' . $filenameExamParamJson,
	];
	header('Location: ' . topUri() . 'sub/error.php');
	return;
}
$firstExamID  = $arrayChartPageParam['chartPage1'][0]['examID'];
//var_dump($firstExamID);
$examdata = $arrayExamParam['examParameter'];
foreach ($examdata as $exam) {
	if ($exam['examID'] == $firstExamID) {
		
		if($lang=="US"){
		$firstExamTitle = $exam["titleExam"];
		}
		if($lang=="JP"){
			$firstExamTitle = $exam["jptitleExam"];
		}
	}
}

// fetching exam from language file
//$firstExamTitle = _m('subjective', 'titleExamID' . $firstExamID);

$json = [];

$filenameObjectiveRefJson = 'objective.refraction.json';
$arrayObjectiveRef = getMapFromJsonFile(tempDir() . $filenameObjectiveRefJson);
// var_dump($arrayObjectiveRef); 
// var_dump($_SESSION);
// exit;
if ($arrayObjectiveRef) {
	foreach (['R', 'L'] as $eye) {
		$median = @$arrayObjectiveRef['refraction'][$eye]['Median'];
		if (empty($median)) {
			$json['subjective'][$eye]['sph'] = SPH_DEFALUT_VALUE;
			$json['subjective'][$eye]['cyl'] = CYL_DEFALUT_VALUE;
			$json['subjective'][$eye]['axs'] = AXS_DEFALUT_VALUE;
			continue;
		}
		$json['objective'][$eye]['sph'] = @$median['Sphere']['value'];
		$json['objective'][$eye]['cyl'] = @$median['Cylinder']['value'];
		$json['objective'][$eye]['axs'] = @$median['Axis']['value'];
		$json['subjective'][$eye]['sph'] = \ModelUtil\array_get($json['objective'][$eye]['sph'], SPH_DEFALUT_VALUE);
		$json['subjective'][$eye]['cyl'] = \ModelUtil\array_get($json['objective'][$eye]['cyl'], CYL_DEFALUT_VALUE);
		$json['subjective'][$eye]['axs'] = \ModelUtil\array_get($json['objective'][$eye]['axs'], AXS_DEFALUT_VALUE);
		if (0 < $json['subjective'][$eye]['cyl']) {
			// 例外:通常ありえないが……
			$json['subjective'][$eye]['cyl'] = CYL_DEFALUT_VALUE;
			$json['subjective'][$eye]['axs'] = AXS_DEFALUT_VALUE;
		}
		// 補正
		round025($json['subjective'][$eye]['sph']);
		round025($json['subjective'][$eye]['cyl']);
		round1($json['subjective'][$eye]['axs']);
	}
	$pd = \ModelUtil\array_get($arrayObjectiveRef['PD']['Distance']['value'], PD_DEFALUT_VALUE);
	if (0 >= $pd) {
		// PD が上手く計測できていない
		$pd = PD_DEFALUT_VALUE; // 遠見/近見の切り替えに使用する値なのでデフォルト値を設定する
	}
	$json['subjective']['pd'] = $pd;
} else {
	foreach (['R', 'L'] as $eye) {
		$json['subjective'][$eye]['sph'] = SPH_DEFALUT_VALUE;
		$json['subjective'][$eye]['cyl'] = CYL_DEFALUT_VALUE;
		$json['subjective'][$eye]['axs'] = AXS_DEFALUT_VALUE;
	}
	$json['subjective']['pd'] = PD_DEFALUT_VALUE;
}

$filenameLensmeterJson = 'lensmeter.json';
$arrayLensmeter = getMapFromJsonFile(tempDir() . $filenameLensmeterJson);
if ($arrayLensmeter) {
	foreach (['R', 'L'] as $eye) {
		$lmData = @$arrayLensmeter['lensmeter']['LM'][$eye];
		$json['lensmeter'][$eye]['sph'] = @$lmData['Sphere']['value'];
		$json['lensmeter'][$eye]['cyl'] = @$lmData['Cylinder']['value'];
		$json['lensmeter'][$eye]['axs'] = @$lmData['Axis']['value'];
		$json['lensmeter'][$eye]['add'] = @$lmData['ADD']['value'];
	}
}

?>
<!DOCTYPE html>
<!--[if lt IE 7]><html lang="ja-JP" class="no-js ie lt-ie9 lt-ie8 lt-ie7"><![endif]-->
<!--[if IE 7]><html lang="ja-JP" class="no-js ie lt-ie9 lt-ie8"  xmlns:og="http://ogp.me/ns#" xmlns:mixi="http://mixi-platform.com/ns#" xmlns:fb="http://www.facebook.com/2008/fbml"><![endif]-->
<!--[if IE 8]><html lang="ja-JP" class="no-js ie lt-ie9"  xmlns:og="http://ogp.me/ns#" xmlns:mixi="http://mixi-platform.com/ns#" xmlns:fb="http://www.facebook.com/2008/fbml"><![endif]-->
<!--[if IE 9]><html lang="ja-JP" class="no-js ie"  xmlns:og="http://ogp.me/ns#" xmlns:mixi="http://mixi-platform.com/ns#" xmlns:fb="http://www.facebook.com/2008/fbml"><![endif]-->
<!--[if gt IE 9]><!-->
<html lang="ja-JP" class="no-js" xmlns:og="http://ogp.me/ns#" xmlns:mixi="http://mixi-platform.com/ns#" xmlns:fb="http://www.facebook.com/2008/fbml">
<!--<![endif]-->

<head>
	<?php outputHeadContents(); ?>
	<title><?php echo _m('subjective', 'title'); ?></title>
	<!--[if lt IE 9]>
<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
<script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
</head>

<body>
	<!-- メッセージの定義リスト(JavaScript向け) -->
	<dl id="list_message" style="display: none;">
		<?php
		echoListMessageItem('global', 'far');
		echoListMessageItem('global', 'near');
		echoListMessageItem('global', 'va');
		echoListMessageItem('subjective', 'titleExamID1000');
		echoListMessageItem('subjective', 'titleExamID1010');
		echoListMessageItem('subjective', 'titleExamID1020');
		echoListMessageItem('subjective', 'titleExamID1021');
		echoListMessageItem('subjective', 'titleExamID1092');
		echoListMessageItem('subjective', 'titleExamID2030');
		echoListMessageItem('subjective', 'controllerSPH');
		echoListMessageItem('subjective', 'controllerCYL');
		echoListMessageItem('subjective', 'controllerAXS');
		echoListMessageItem('subjective', 'controllerPowerAxis');
		echoListMessageItem('subjective', 'controllerADD');
		?>
	</dl>
	<div id="currentEye" data-value="B"></div>
	<div id="currentSCA" data-value="Sph"></div>
	<div id="currentAutoID" data-value="<?php echo createAutoID('chartPage1', $arrayChartPageParam['chartPage1'][0]); ?>" style="display: none;"></div>
	<div class="siteframe C-subjective">
		<div class="siteframe-inner">

			<?php include_once topDir() . 'contents/_nav.php'; ?>

			<div class="siteframe-body">
				<div class="siteframe-body-inner">
					<div class="layout-content mode-left clearfix">
						<div class="area area-a clearfix">
							<div class="title">
								<p class="txt-title-inspection" id="labelExamTitle" data-text="<?php echo $firstExamTitle; ?>"></p>
								<p class="txt-title-course"></p>
							</div>
							<!--/.title-->
						</div>
						<!--/.area-a-->
						<div class="area area-c clearfix">
							<div class="area-inner">
								<div class="area area-side-a">
									<div class="reference-table reference-table-b">
										<div class="reference-table-header">
											<div class="select-box">
												<div class="select-title">
													<p class="txt-select-title"></p>
												</div>
												<select class="select-selector">
													<option selected><?php echo _m('subjective', 'objectiveData'); ?></option>
												</select>
											</div>
										</div>
										<div class="reference-table-contents">
											<div class="reference-table-tr">
												<div class="reference-table-td">
													<span class="txt-value" data-text="<?php echo $json['objective']['R']['sph']; ?>" data-fixed="2" data-class-plus="valuePlus"></span>
												</div>
												<div class="reference-table-td">
													<span class="txt-single">S</span>
												</div>
												<div class="reference-table-td">
													<span class="txt-value" data-text="<?php echo $json['objective']['L']['sph']; ?>" data-fixed="2" data-class-plus="valuePlus"></span>
												</div>
											</div>
											<div class="reference-table-tr">
												<div class="reference-table-td">
													<span class="txt-value" data-text="<?php echo $json['objective']['R']['cyl']; ?>" data-fixed="2" data-class-plus="valuePlus"></span></div>
												<div class="reference-table-td">
													<span class="txt-single">C</span>
												</div>
												<div class="reference-table-td">
													<span class="txt-value" data-text="<?php echo $json['objective']['L']['cyl']; ?>" data-fixed="2" data-class-plus="valuePlus"></span>
												</div>
											</div>
											<div class="reference-table-tr">
												<div class="reference-table-td">
													<span class="txt-value" data-text="<?php echo $json['objective']['R']['axs']; ?>" data-fixed="0"></span>
												</div>
												<div class="reference-table-td">
													<span class="txt-single">A</span></div>
												<div class="reference-table-td">
													<span class="txt-value" data-text="<?php echo $json['objective']['L']['axs']; ?>" data-fixed="0"></span>
												</div>
											</div>
											<div class="reference-table-tr">
												<div class="reference-table-td">
													<span class="txt-value"></span>
												</div>
												<div class="reference-table-td">
													<span class="txt-triple">ADD</span>
												</div>
												<div class="reference-table-td">
													<span class="txt-value"></span>
												</div>
											</div>
											<div class="reference-table-tr">
												<div class="reference-table-td">
													<span class="txt-value"></span>
												</div>
												<div class="reference-table-td">
													<span class="txt-double">VA</span>
												</div>
												<div class="reference-table-td">
													<span class="txt-value"></span>
												</div>
											</div>
										</div>
									</div>
								</div>
								<!--./area-side-a-->
								<div class="area area-center">
									<div class="data-table current-a current-b">
										<div class="table-header">
											<div class="header-left">
												<p class="txt-header-title"><?php echo _m('global', 'right'); ?></p>
											</div>
											<div class="header-center">
												<!--
							<div class="select-box">
								<div class="select-title"><p class="txt-select-title"></p></div>
								<select class="select-selector">
									<option selected><?php echo _m('subjective', 'subjectiveData'); ?></option>
									<option><?php echo _m('subjective', 'objectiveData'); ?></option>
									<option><?php echo _m('subjective', 'rxData'); ?></option>
									<option><?php echo _m('subjective', 'finalData'); ?></option>
									<option><?php echo _m('subjective', 'uncorrectedData'); ?></option>
									<option><?php echo _m('subjective', 'oldData'); ?></option>
									<option><?php echo _m('subjective', 'm1Data'); ?></option>
									<option><?php echo _m('subjective', 'm2Data'); ?></option>
									<option><?php echo _m('subjective', 'm3Data'); ?></option>
								</select>
							</div>
							-->
												<div class="inline-block-recursive">
													<div class="txt-header-title padding-top02 far-near" id="labelHeaderCenter"></div>
													<div class="exam-distance">
														<input type="tel" class="form form-input inputExaminationDistancePoint" autocomplete="off" required="required" id="inputExaminationDistancePoint_far" min="400" max="6096" value="<?php echo $arraySubjectiveSetting['examinationDistanceFarPoint']; ?>">
														<input type="tel" class="form form-input inputExaminationDistancePoint" autocomplete="off" required="required" id="inputExaminationDistancePoint_near" min="400" max="6096" value="<?php echo $arraySubjectiveSetting['examinationDistanceNearPoint']; ?>" style="display: none;">
														<div class="form">mm</div>
													</div>
												</div>
											</div>
											<div class="header-right">
												<p class="txt-header-title"><?php echo _m('global', 'left'); ?></p>
											</div>
										</div>
										<div class="table-contents">
											<div class="tr" id="trMainSph">
												<div class="td">
													<p class="txt-data-value" id="labelMainSphR" data-text="<?php echo $json['subjective']['R']['sph']; ?>" data-fixed="2" data-class-plus="valuePlus" data-class-minus="valueMinus"></p>
													<div class="btn-group btn-group-data-value">
														<button type="button" class="btn">
															<div class="btn-inner"></div>
														</button>
														<button type="button" class="btn">
															<div class="btn-inner"></div>
														</button>
													</div>
												</div>
												<div class="td">
													<p class="txt-data-kind" id="labelMainSphCaption"><?php echo _m('subjective', 'mainS'); ?></p>
												</div>
												<div class="td">
													<p class="txt-data-value" id="labelMainSphL" data-text="<?php echo $json['subjective']['L']['sph']; ?>" data-fixed="2" data-class-plus="valuePlus" data-class-minus="valueMinus"></p>
													<div class="btn-group btn-group-data-value">
														<button type="button" class="btn">
															<div class="btn-inner"></div>
														</button>
														<button type="button" class="btn">
															<div class="btn-inner"></div>
														</button>
													</div>
												</div>
											</div>
											<div class="tr" id="trMainCyl">
												<div class="td">
													<p class="txt-data-value" id="labelMainCylR" data-text="<?php echo $json['subjective']['R']['cyl']; ?>" data-fixed="2" data-class-plus="valuePlus" data-class-minus="valueMinus"></p>
													<div class="btn-group btn-group-data-value">
														<button type="button" class="btn">
															<div class="btn-inner"></div>
														</button>
														<button type="button" class="btn">
															<div class="btn-inner"></div>
														</button>
													</div>
												</div>
												<div class="td">
													<p class="txt-data-kind" id="labelMainCylCaption"><?php echo _m('subjective', 'mainC'); ?></p>
												</div>
												<div class="td">
													<p class="txt-data-value" id="labelMainCylL" data-text="<?php echo $json['subjective']['L']['cyl']; ?>" data-fixed="2" data-class-plus="valuePlus" data-class-minus="valueMinus"></p>
													<div class="btn-group btn-group-data-value">
														<button type="button" class="btn">
															<div class="btn-inner"></div>
														</button>
														<button type="button" class="btn">
															<div class="btn-inner"></div>
														</button>
													</div>
												</div>
											</div>
											<div class="tr" id="trMainAxs">
												<div class="td">
													<p class="txt-data-value" id="labelMainAxsR" data-text="<?php echo $json['subjective']['R']['axs']; ?>" data-fixed="0" data-min="1" data-max="180" data-loop="data-loop"></p>
													<div class="btn-group btn-group-data-value">
														<button type="button" class="btn">
															<div class="btn-inner"></div>
														</button>
														<button type="button" class="btn">
															<div class="btn-inner"></div>
														</button>
													</div>
												</div>
												<div class="td">
													<p class="txt-data-kind txt-notes" id="labelMainAxsCaption"><?php echo _m('subjective', 'mainA'); ?><div class="txt-notes-small">(<span id="labelMainAxsStep">5</span>)</div>
													</p>
												</div>
												<div class="td">
													<p class="txt-data-value" id="labelMainAxsL" data-text="<?php echo $json['subjective']['L']['axs']; ?>" data-fixed="0" data-min="1" data-max="180" data-loop="data-loop"></p>
													<div class="btn-group btn-group-data-value">
														<button type="button" class="btn">
															<div class="btn-inner"></div>
														</button>
														<button type="button" class="btn">
															<div class="btn-inner"></div>
														</button>
													</div>
												</div>
											</div>
											<div class="tr">
												<div class="td">
													<p class="txt-data-value" id="labelMainADD_R" data-text="0" data-fixed="2" data-class-plus="valuePlus" data-class-minus="valueMinus"></p>
													<div class="btn-group btn-group-data-value">
														<button type="button" class="btn">
															<div class="btn-inner"></div>
														</button>
														<button type="button" class="btn">
															<div class="btn-inner"></div>
														</button>
													</div>
												</div>
												<div class="td">
													<p class="txt-data-kind" id="labelMainADD_Caption"><?php echo _m('subjective', 'mainADD'); ?></p>
												</div>
												<div class="td">
													<p class="txt-data-value" id="labelMainADD_L" data-text="0" data-fixed="2" data-class-plus="valuePlus" data-class-minus="valueMinus"></p>
													<div class="btn-group btn-group-data-value">
														<button type="button" class="btn">
															<div class="btn-inner"></div>
														</button>
														<button type="button" class="btn">
															<div class="btn-inner"></div>
														</button>
													</div>
												</div>
											</div>
											<div id="labelMainPrismHor" class="tr tr-small" style="display: none;">
												<div class="td">
													<div class="prism-heading-inner-hor-R-BI" data-fixed="0" style="display: none;">BI </div>
													<p class="txt-data-value" id="labelMainPrismHorR" data-text="0" data-fixed="2" data-min="0" data-max="20"></p>
													<div class="btn-group btn-group-data-value">
														<button type="button" class="btn">
															<div class="btn-inner"></div>
														</button>
														<button type="button" class="btn">
															<div class="btn-inner"></div>
														</button>
													</div>
												</div>
												<div class="td">
													<p id="labelMainPrismHorCaption" class="txt-data-kind"><?php echo _m('subjective', 'mainH'); ?></p>
												</div>
												<div class="td">
													<div class="prism-heading-inner-hor-L-BI" data-fixed="0" style="display: none;"> BI </div>
													<p class="txt-data-value" id="labelMainPrismHorL" data-text="0" data-fixed="2" data-min="0" data-max="20"></p>
													<div class="btn-group btn-group-data-value">
														<button type="button" class="btn">
															<div class="btn-inner"></div>
														</button>
														<button type="button" class="btn">
															<div class="btn-inner"></div>
														</button>
													</div>
												</div>
											</div>
											<div id="labelMainPrismVer" class="tr tr-small" style="display: none;">
												<div class="td">
													<div class="prism-heading-inner-ver-R-BD" data-fixed="0" style="display: none;"> BD </div>
													<p class="txt-data-value" id="labelMainPrismVerR" data-text="0" data-fixed="2" data-min="0" data-max="20"></p>
													<div class="btn-group btn-group-data-value">
														<button type="button" class="btn">
															<div class="btn-inner"></div>
														</button>
														<button type="button" class="btn">
															<div class="btn-inner"></div>
														</button>
													</div>
												</div>
												<div class="td">
													<p id="labelMainPrismVerCaption" class="txt-data-kind"><?php echo _m('subjective', 'mainV'); ?></p>
												</div>
												<div class="td">
													<div class="prism-heading-inner-ver-L-BD" data-fixed="0" style="display: none;"> BU </div>
													<p class="txt-data-value" id="labelMainPrismVerL" data-text="0" data-fixed="2" data-min="0" data-max="20"></p>
													<div class="btn-group btn-group-data-value">
														<button type="button" class="btn">
															<div class="btn-inner"></div>
														</button>
														<button type="button" class="btn">
															<div class="btn-inner"></div>
														</button>
													</div>
												</div>
											</div>
											<div class="tr" id="trMainVAfar">
												<div class="td">
													<p class="txt-data-value" id="labelMainVA_FarR" data-text="" data-unit=""></p>
													<div class="btn-group btn-group-data-value">
														<button type="button" class="btn">
															<div class="btn-inner"></div>
														</button>
														<button type="button" class="btn">
															<div class="btn-inner"></div>
														</button>
													</div>
												</div>
												<div class="td">
													<p class="txt-data-kind" id="labelMainVA_FarB" data-text="" data-unit=""></p>
												</div>
												<div class="td">
													<p class="txt-data-value" id="labelMainVA_FarL" data-text="" data-unit=""></p>
													<div class="btn-group btn-group-data-value">
														<button type="button" class="btn">
															<div class="btn-inner"></div>
														</button>
														<button type="button" class="btn">
															<div class="btn-inner"></div>
														</button>
													</div>
												</div>
											</div>
											<div class="tr" id="trMainVAnear" style="display: none;">
												<div class="td">
													<p class="txt-data-value" id="labelMainVA_NearR" data-text="" data-unit=""></p>
													<div class="btn-group btn-group-data-value">
														<button type="button" class="btn">
															<div class="btn-inner"></div>
														</button>
														<button type="button" class="btn">
															<div class="btn-inner"></div>
														</button>
													</div>
												</div>
												<div class="td">
													<p class="txt-data-kind" id="labelMainVA_NearB" data-text="" data-unit=""></p>
												</div>
												<div class="td">
													<p class="txt-data-value" id="labelMainVA_NearL" data-text="" data-unit=""></p>
													<div class="btn-group btn-group-data-value">
														<button type="button" class="btn">
															<div class="btn-inner"></div>
														</button>
														<button type="button" class="btn">
															<div class="btn-inner"></div>
														</button>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
								<!--./area-center-->
								<div class="area area-side-b">
									<div class="reference-table reference-table-b">
										<div class="reference-table-header">
											<div class="select-box">
												<div class="select-title">
													<p class="txt-select-title"></p>
												</div>
												<select class="select-selector">
													<option selected><?php echo _m('subjective', 'rxData'); ?></option>
												</select>
											</div>
										</div>
										<div class="reference-table-contents">
											<div class="reference-table-tr">
												<div class="reference-table-td">
													<span class="txt-value" data-text="<?php echo $json['lensmeter']['R']['sph']; ?>" data-fixed="2" data-class-plus="valuePlus"></span>
												</div>
												<div class="reference-table-td">
													<span class="txt-single">S</span>
												</div>
												<div class="reference-table-td">
													<span class="txt-value" data-text="<?php echo $json['lensmeter']['L']['sph']; ?>" data-fixed="2" data-class-plus="valuePlus"></span>
												</div>
											</div>
											<div class="reference-table-tr">
												<div class="reference-table-td">
													<span class="txt-value" data-text="<?php echo $json['lensmeter']['R']['cyl']; ?>" data-fixed="2" data-class-plus="valuePlus"></span>
												</div>
												<div class="reference-table-td">
													<span class="txt-single">C</span>
												</div>
												<div class="reference-table-td">
													<span class="txt-value" data-text="<?php echo $json['lensmeter']['L']['cyl']; ?>" data-fixed="2" data-class-plus="valuePlus"></span>
												</div>
											</div>
											<div class="reference-table-tr">
												<div class="reference-table-td">
													<span class="txt-value" data-text="<?php echo $json['lensmeter']['R']['axs']; ?>" data-fixed="0"></span>
												</div>
												<div class="reference-table-td">
													<span class="txt-single">A</span>
												</div>
												<div class="reference-table-td">
													<span class="txt-value" data-text="<?php echo $json['lensmeter']['L']['axs']; ?>" data-fixed="0"></span>
												</div>
											</div>
											<div class="reference-table-tr">
												<div class="reference-table-td">
													<span class="txt-value" data-text="<?php echo $json['lensmeter']['R']['add']; ?>" data-fixed="2" data-class-plus="valuePlus"></span>
												</div>
												<div class="reference-table-td">
													<span class="txt-triple">ADD</span>
												</div>
												<div class="reference-table-td">
													<span class="txt-value" data-text="<?php echo $json['lensmeter']['L']['add']; ?>" data-fixed="2" data-class-plus="valuePlus"></span>
												</div>
											</div>
											<div class="reference-table-tr">
												<div class="reference-table-td">
													<span class="txt-value" data-text="<?php echo $json['lensmeter']['R']['va']; ?>"></span>
												</div>
												<div class="reference-table-td">
													<span class="txt-double">VA</span>
												</div>
												<div class="reference-table-td">
													<span class="txt-value" data-text="<?php echo $json['lensmeter']['L']['va']; ?>"></span>
												</div>
											</div>
										</div>
									</div>
								</div>
								<!--/.area-side-b-->
								<div class="area area-bottom-a">
									<div class="eye-box">
										<img class="eye-img" id="imgEyeR">
										<div class="eye-mark" style="display: none;"><span class="icon icon-eyemark-b" id="iconEyeMarkR" data-rotate="0"></span></div>
									</div>
								</div>
								<!--/.area-bottom-a-->
								<div class="area area-bottom-b">
									<div class="eye-box">
										<img class="eye-img" id="imgEyeL">
										<div class="eye-mark" style="display: none;"><span class="icon icon-eyemark-a" id="iconEyeMarkL" data-rotate="0"></span></div>
									</div>
								</div>
								<!--/.area-bottom-b-->
								<div class="area area-bottom">
									<div class="pd-box">
										<div class="pd-label">
											<p class="txt-pd-label">PD</p>
										</div>
										<div class="pd-value">
											<p class="txt-pd-value" id="labelPD" data-text="<?php echo $json['subjective']['pd']; ?>" data-fixed="1">&nbsp;</p>
										</div>
									</div>
								</div>
								<!--/.area-bottom-->
								<div class="area area-bottom-auto-alignment">
									<div class="auto-alignment-box">
										<button type="button" class="btn btn-auto-alignment" id="btnAutoAlignment">
											<div class="btn-inner"><?php echo _m('subjective', 'btnAutoAlignment'); ?></div>
										</button>
										<button type="button" class="btn btn-auto-alignment" id="btnResetBaseXYZ">
											<div class="btn-inner"><?php echo _m('subjective', 'btnResetBase'); ?></div>
										</button>
									</div>
								</div>
								<!--/.area-bottom-auto-alignment-->
							</div>
							<!--/.area-inner-->
						</div>
						<!--/.area-c-->
						<div class="area area-d clearfix">
							<div class="tab-box" id="tabChart" data-tab-index="0">
								<div class="tab-header-group">
									<div class="tab-header current">
										<p class="txt-tab-header">Decimal</p>
									</div>
									<div class="tab-header">
										<p class="txt-tab-header">Feet</p>
									</div>
									<div class="tab-header">
										<p class="txt-tab-header">Metre</p>
									</div>
									<div class="tab-header">
										<p class="txt-tab-header">Bino/Add</p>
									</div>
									<div class="tab-header">
										<p class="txt-tab-header">Feet for clinic</p>
									</div>
								</div>
								<div class="tab-content-group">
									<div class="tab-content current">
										<?php
										$indent = '					';
										$keyChartPageParam = 'chartPage1';
										include '_viewChartThumbnail.php';
										?>
									</div>
									<div class="tab-content">
										<?php
										$keyChartPageParam = 'chartPage2';
										include '_viewChartThumbnail.php';
										?>
									</div>
									<div class="tab-content">
										<?php
										$keyChartPageParam = 'chartPage3';
										include '_viewChartThumbnail.php';
										?>
									</div>
									<div class="tab-content">
										<?php
										$keyChartPageParam = 'chartPage4';
										include '_viewChartThumbnail.php';
										?>
									</div>
									<div class="tab-content">
										<?php
										$keyChartPageParam = 'chartPage5';
										include '_viewChartThumbnail.php';
										?>
									</div>
								</div>
							</div>
							<!--/.tab-box-->
						</div>
						<!--/.area-d-->
						<div class="area area-e clearfix">
							<div class="confirm-box">
								<div class="btn-group-a">
									<button type="button" class="btn btn-confirm" id="btnChartInvert">
										<div class="btn-inner"><span class="icon icon-wb"></span></div>
									</button>
									<button type="button" class="btn btn-confirm" id="btnChartRG">
										<div class="btn-inner"><span class="icon icon-gr"></span></div>
									</button>
								</div>
								<div class="confirm-content">
									<div class="btn-group-va btn-group-c" style="display: none;">
										<!-- JavaScript で動的生成 -->
									</div>
									<div class="default-chart-far"></div>
									<div class="default-chart-near"></div>
									<div class="chart-table">
										<div class="top" style="display: none;">
											<!-- JavaScript で動的生成 -->
										</div>
										<div class="side" style="display: none;">
											<!-- JavaScript で動的生成 -->
										</div>
										<div class="sidecursors">
											<div class="chart-cursors">
												<div class="chart-shift">
													<div class="cursor-btn btn btn-confirm">
														<div class="up"></div>
														<div class="updummy"></div>
													</div>
													<div class="cursor-btn btn btn-confirm">
														<div class="down"></div>
														<div class="downdummy"></div>
													</div>
												</div>

												<div class=" chart-buttons flex-container">
													<div class="cursor-btn btn btn-confirm">
														<div class="left"></div>
														<div class="leftdummy"></div>
													</div>

													<div class="cursor-btn btn btn-confirm">
														<div class="right"></div>
														<div class="rightdummy"></div>
													</div>

												</div>
											</div>
										</div>
										<div class="hitarea" style="display: none;">
											<!-- JavaScript で動的生成 -->
										</div>
										<div class="image">
											<img src="../img/subjective_chart_loader.gif">
										</div>
										<div class="bg">
										</div>
									</div>
								</div>
								<div class="prism-buttons">
									<div class="btn btn-confirm btn-clear">
										<div class="btn-inner"><span>Mem/ Clear</span></div>
									</div>
									<div class="btn btn-confirm btn-restore">
										<div class="btn-inner"><span>Restore</span></div>
									</div>
									<div class="btn btn-confirm btn-allclear">
										<div class="btn-inner"><span>All Clear</span></div>
									</div>
								</div>
								<div class="btn-group-va btn-group-b">
									<!-- JavaScript で動的生成 -->
								</div>
							</div>
							<!--/.confirm-box-->
						</div>
						<!--/.area-e-->
					</div>
					<!--/.layout-content-->
					<div class="area area-b mode-left clearfix">
						<div class="controller-box">
							<div class="controller-change">
								<button type="button" class="btn btn-changelayout">
									<div class="btn-inner"><span class="icon icon-layoutchange"></span></div>
								</button>
							</div>
							<div class="controller-inner">
								<div class="controller-a">
									<div class="btn-group btn-group-triple">
										<button type="button" class="btn" id="btnControllerEyeR">
											<div class="btn-inner"><span class="icon icon-eye-right"><?php echo _m('global', 'rightEye'); ?></span></div>
										</button>
										<button type="button" class="btn current" id="btnControllerEyeB">
											<div class="btn-inner"><span class="icon icon-eye-bino"><?php echo _m('global', 'binoEye'); ?></span></div>
										</button>
										<button type="button" class="btn" id="btnControllerEyeL">
											<div class="btn-inner"><span class="icon icon-eye-left"><?php echo _m('global', 'leftEye'); ?></span></div>
										</button>
									</div>
								</div>
								<div class="controller-default">
									<div class="btn-group btn-group-double">
										
										<button type="button" class="btn" id="btnControllerAdjustL" value="+1">
											<div class="btn-inner"><span class="defaultOp-Left"></span></div>
										</button>
										<button type="button" class="btn" id="btnControllerAdjustR" value="-1">
										<div class="btn-inner"><span class="defaultOp-Right"></span></div>
										</button>
										<p class="btn-group-centerline"><span class="icon icon-axis"></span></p>
									</div>
								</div>
								<div class="controller-b">
									<div class="btn-group btn-group-double">
										
										<button type="button" class="btn" id="btnControllerAdjustL" value="+1">
											<div class="btn-inner"><span class="icon icon-G"></span><span class="icon icon-plus-brackets"></span></div>
										</button>
										<button type="button" class="btn" id="btnControllerAdjustR" value="-1">
											<div class="btn-inner"><span class="icon icon-R"></span><span class="icon icon-plus-brackets"></span></div>
										</button>
										<p class="btn-group-centerline"><span class="icon icon-axis"></span></p>
									</div>
								</div>
								<div class="controller-c">
									<div class="btn-group btn-group-switch-circle" id="groupCrossCylinder" data-select-index="0">
										<button type="button" class="btn current">
											<div class="btn-inner"><span class="icon icon-one">1</span></div>
										</button>
										<button type="button" class="btn">
											<div class="btn-inner"><span class="icon icon-two">2</span></div>
										</button>
									</div>
								</div>
								<div class="controller-d">
									<button type="button" class="btn btn-astigmat-axis">
										<div class="btn-inner"><span class="icon icon-astigmat-axis"></span></div>
									</button>
								</div>
								<div class="controller-e">
									<div class="btn-group btn-group-pagenation">
										<button type="button" class="btn">
											<div class="btn-inner"><span class="icon icon-prev"><?php echo _m('subjective', 'controllerPrev'); ?></span></div>
										</button>
										<button type="button" class="btn">
											<div class="btn-inner"><span class="icon icon-next"><?php echo _m('subjective', 'controllerNext'); ?></span></div>
										</button>
										<p class="btn-group-centerline"></p>
									</div>
								</div>

								<div class="controller-prism">
									<button type="button" class="btn btn-astigmat-axis prism-hv-control">
										<div class="btn-inner "><label class="icon icon-astigmat-axis prism-hv"><span class="labelMenu_H">H</span>/<span class="labelMenu_V">V</span></label></div>
									</button>
								</div>
							</div>
						</div>
						<!--/.controller-box-->
					</div>
					<!--/.area-b-->
				</div>
				<!--./siteframe-body-inner-->
			</div>
			<!--./siteframe-body-->

			<div class="siteframe-footer">
				<div class="siteframe-footer-inner">
					<div class="layout-footer clearfix">
						<div class="menu">
							<?php
							//<div class="menu-item">
							//	<div class="menu-slidenavi" data-for="btnMenu1">
							//		<ul class="slidenavi">
							//			<li class="slidenavi-item">SPHspt</li>
							//			<li class="slidenavi-item">SPHspt</li>
							//			<li class="slidenavi-item">コントラスト</li>
							//			<li class="slidenavi-item">遮蔽種</li>
							//			<li class="slidenavi-item">シェアード</li>
							//			<li class="slidenavi-item">シミュレーション</li>
							//			<li class="slidenavi-item">AC/A</li>
							//		</ul><!--/.slidenavi-->
							//		<ul class="slidenavi">
							//			<li class="slidenavi-item">SPHspt</li>
							//			<li class="slidenavi-item">SPHspt</li>
							//			<li class="slidenavi-item">コントラスト</li>
							//			<li class="slidenavi-item">遮蔽種</li>
							//			<li class="slidenavi-item">シェアード</li>
							//			<li class="slidenavi-item">シミュレーション</li>
							//			<li class="slidenavi-item">AC/A</li>
							//		</ul><!--/.slidenavi-->
							//		<ul class="slidenavi">
							//			<li class="slidenavi-item">SPHspt</li>
							//			<li class="slidenavi-item">SPHspt</li>
							//			<li class="slidenavi-item">コントラスト</li>
							//			<li class="slidenavi-item">遮蔽種</li>
							//			<li class="slidenavi-item">シェアード</li>
							//			<li class="slidenavi-item">シミュレーション</li>
							//			<li class="slidenavi-item">AC/A</li>
							//		</ul><!--/.slidenavi-->
							//	</div><!--/.menu-slidenavi-->
							//	<button type="button" class="btn btn-menu-bar" id="btnMenu1"><div class="btn-inner"><span class="icon icon-menu"></span></div></button>
							//</div>
							?>
							<!-- Sph step -->
							<div class="menu-item">
								<div class="menu-slidenavi" data-for="btnMenuS">
									<ul class="slidenavi">
										<?php
										$values = [
											'3.00',
											'2.00',
											'1.00',
											'0.50',
											'0.25',
											'0.125',
										];
										foreach ($values as $value) {
											echo _li(['class' => 'slidenavi-item', 'data-value' => \ModelUtil\toNumericIfPossible($value)], 'S:' . $value);
										}
										?>
									</ul>
									<!--/.slidenavi-->
								</div>
								<!--/.menu-slidenavi-->
								<button type="button" class="btn btn-menu" id="btnMenuS" data-value="0.25">
									<div class="btn-inner" data-text="">S</div>
								</button>
							</div>
							<!-- Cyl step -->
							<div class="menu-item" style="display: none;">
								<div class="menu-slidenavi" data-for="btnMenuC">
									<ul class="slidenavi">
										<?php
										$values = [
											'1.00',
											'0.50',
											'0.25',
											'0.125',
										];
										foreach ($values as $value) {
											echo _li(['class' => 'slidenavi-item', 'data-value' => \ModelUtil\toNumericIfPossible($value)], 'C:' . $value);
										}
										?>
									</ul>
									<!--/.slidenavi-->
								</div>
								<!--/.menu-slidenavi-->
								<button type="button" class="btn btn-menu" id="btnMenuC" data-value="0.25">
									<div class="btn-inner" data-text="">C</div>
								</button>
							</div>
							<!-- Axs step -->
							<div class="menu-item" style="display: none;">
								<div class="menu-slidenavi" data-for="btnMenuA">
									<ul class="slidenavi">
										<?php
										$values = [
											'1',
											'5',
										];
										foreach ($values as $value) {
											echo _li(['class' => 'slidenavi-item', 'data-value' => \ModelUtil\toNumericIfPossible($value)], 'A:' . $value);
										}
										?>
									</ul>
									<!--/.slidenavi-->
								</div>
								<!--/.menu-slidenavi-->
								<button type="button" class="btn btn-menu" id="btnMenuA" data-value="5">
									<div class="btn-inner" data-text="">A</div>
								</button>
							</div>
							<?php
							//<div class="menu-item">
							//	<div class="menu-slidenavi" data-for="btnMenu3">
							//		<ul class="slidenavi">
							//			<li class="slidenavi-item current">遮蔽</li>
							//			<li class="slidenavi-item">雲霧:+2.00</li>
							//			<li class="slidenavi-item">雲霧:+1.50</li>
							//			<li class="slidenavi-item">雲霧:+0.75</li>
							//			<li class="slidenavi-item">雲霧:手動</li>
							//		</ul><!--/.slidenavi-->
							//	</div><!--/.menu-slidenavi-->
							//	<button type="button" class="btn btn-menu" id="btnMenu3"><div class="btn-inner">遮蔽/雲霧</div></button>
							//</div>
							?>
							<div class="menu-item"><button type="button" class="btn btn-menu" id="btnMenuReferenceData">
									<div class="btn-inner"><?php echo _m('subjective', 'menuReferenceData'); ?></div>
								</button></div>
							<?php
							//<div class="menu-item"><button type="button" class="btn btn-menu" id="btnMenu5"><div class="btn-inner">処方:セット</div></button></div>
							//<div class="menu-item">
							//	<div class="menu-slidenavi" data-for="btnMenu6">
							//		<ul class="slidenavi">
							//			<li class="slidenavi-item">オープン</li>
							//			<li class="slidenavi-item">RGフィルタ</li>
							//			<li class="slidenavi-item">ピンホール</li>
							//		</ul><!--/.slidenavi-->
							//		<ul class="slidenavi">
							//			<li class="slidenavi-item">水平マドックス</li>
							//			<li class="slidenavi-item">垂直マドックス</li>
							//			<li class="slidenavi-item">クロスシリンダー
							//	(±0.5)</li>
							//		</ul><!--/.slidenavi-->
							//		<ul class="slidenavi">
							//			<li class="slidenavi-item">偏光(45°)</li>
							//			<li class="slidenavi-item">偏光(135°)</li>
							//			<li class="slidenavi-item">遮蔽</li>
							//		</ul><!--/.slidenavi-->
							//		<ul class="slidenavi">
							//			<li class="slidenavi-item">6ΔBU</li>
							//			<li class="slidenavi-item">10ΔBI</li>
							//			<li class="slidenavi-item">&nbsp;</li>
							//		</ul><!--/.slidenavi-->
							//		<ul class="slidenavi">
							//			<li class="slidenavi-item">レチノ(+1.5)</li>
							//			<li class="slidenavi-item">レチノ(+2.0)</li>
							//			<li class="slidenavi-item">&nbsp;</li>
							//		</ul><!--/.slidenavi-->
							//	</div><!--/.menu-slidenavi-->
							//	<button type="button" class="btn btn-menu" id="btnMenu6"><div class="btn-inner">補助レンズ</div></button>
							//</div>
							//<div class="menu-item">
							//	<div class="menu-slidenavi" data-for="btnMenu7">
							//		<ul class="slidenavi">
							//			<li class="slidenavi-item">-2</li>
							//			<li class="slidenavi-item">-1</li>
							//			<li class="slidenavi-item">+1</li>
							//			<li class="slidenavi-item">+2</li>
							//			<li class="slidenavi-item"> 0</li>
							//		</ul><!--/.slidenavi-->
							//	</div><!--/.menu-slidenavi-->
							//	<button type="button" class="btn btn-menu" id="btnMenu7"><div class="btn-inner">視力値スコア</div></button>
							//</div>
							?>
							<!-- ウォース4点テスト 専用 -->
							<div class="menu-item" style="display: none;">
								<div class="menu-slidenavi" data-for="btnMenuChartID9">
									<ul class="slidenavi">
										<li class="slidenavi-item" data-value="4 Dots"><?php echo _m('subjective', 'menuExamID1092_4Dots'); ?></li>
										<li class="slidenavi-item" data-value="2 Red"><?php echo _m('subjective', 'menuExamID1092_2Red'); ?></li>
										<li class="slidenavi-item" data-value="3 Green"><?php echo _m('subjective', 'menuExamID1092_3Green'); ?></li>
										<li class="slidenavi-item" data-value="5 Dots"><?php echo _m('subjective', 'menuExamID1092_5Dots'); ?></li>
										<li class="slidenavi-item" data-value="2R 3G Alter"><?php echo _m('subjective', 'menuExamID1092_2R3G_Alter'); ?></li>
										<li class="slidenavi-item" data-value=""><?php echo _m('subjective', 'menuExamID1092_DataClear'); ?></li>
									</ul>
									<!--/.slidenavi-->
								</div>
								<!--/.menu-slidenavi-->
								<button type="button" class="btn btn-menu" id="btnMenuChartID9">
									<div class="btn-inner"><?php echo _m('subjective', 'menuExamID1092_Result'); ?></div>
								</button>
							</div>
							<div class="menu-item" style="display: none;">
								<button type="button" class="btn btn-menu" id="btnMenuChartID9_ResultValue" data-value="">
									<div class="btn-inner" data-text=""></div>
								</button>
							</div>
							<!-- 遠見/近見 -->
							<div class="menu-item"><button type="button" class="btn btn-menu" id="btnMenuFarNear" value="far">
									<div class="btn-inner"><span id="labelMenu_far"><?php echo _m('global', 'far'); ?></span>/<span id="labelMenu_near"><?php echo _m('global', 'near'); ?></span></div>
								</button></div>
							<!-- 両眼開放/片眼遮蔽 -->
							<div class="menu-item"><button type="button" class="btn btn-menu" id="btnMenuBinoMono" value="bino">
									<div class="btn-inner"><span id="labelMenu_bino"><?php echo _m('subjective', 'menuBinocularRelease'); ?></span>/<span id="labelMenu_mono"><?php echo _m('subjective', 'menuOneEyeShield'); ?></span></div>
								</button></div>
							<!-- ジャクソンクロスシリンダー 専用 -->
							<div class="menu-item" style="display: none;">
								<div class="menu-slidenavi" data-for="btnMenuCC_Power">
									<ul class="slidenavi">
										<?php
										$values = [
											'0.50',
											'0.25',
										];
										foreach ($values as $value) {
											echo _li(['class' => 'slidenavi-item', 'data-value' => \ModelUtil\toNumericIfPossible($value)], 'CC:' . $value);
										}
										?>
									</ul>
									<!--/.slidenavi-->
								</div>
								<!--/.menu-slidenavi-->
								<button type="button" class="btn btn-menu" id="btnMenuCC_Power" data-value="0.5">
									<div class="btn-inner" data-text=""></div>
								</button>
							</div>
							<div class="menu-item" style="display: none;">
								<div class="menu-slidenavi" data-for="btnMenuPrism_Stap">
									<ul class="slidenavi">
										<?php
										$values = [
											'1.0',
											'0.5',
											'0.2',
											'0.1',
										];
										foreach ($values as $value) {
											echo _li(['class' => 'slidenavi-item', 'data-value' => \ModelUtil\toNumericIfPossible($value)], 'Step P:' . $value);
										}
										?>
									</ul>
									<!--/.slidenavi-->
								</div>
								<!--/.menu-slidenavi-->
								<button type="button" class="btn btn-menu" id="btnMenuPrism_Stap" data-value="0.1">
									<div class="btn-inner" data-text=""></div>
								</button>
							</div>
							<!-- <div class="menu-item"><button type="button" class="btn btn-menu" id="btnOccludeFog" value="A">
									<div class="btn-inner"><span id="labelA">Occlude/Fog</span></div>
								</button></div> -->
							<div class="menu-item"><button type="button" class="btn btn-menu" id="btnFinalMemSet" value="A">
									<div class="btn-inner"><span id="labelA">Final :Mem/Set</span></div>
								</button></div>
							<!-- <div class="menu-item"><button type="button" class="btn btn-menu" id="btnAuxLens" value="A">
									<div class="btn-inner"><span id="labelA">Aux. Lens</span></div>
								</button></div> -->
								<div class="menu-item"><button type="button" class="btn btn-menu" id="btnSheard" value="A">
									<div class="btn-inner"><span id="labelA">Sheard</span></div>
								</button></div>
								<div class="menu-item"><button type="button" class="btn btn-menu" id="btnAca" value="A">
									<div class="btn-inner"><span id="labelA">AC/A</span></div>
								</button></div>
								<div class="menu-item"><button type="button" class="btn btn-menu" id="btn10Pin" value="A">
									<div class="btn-inner"><span id="labelA">10PIN(L)</span></div>
								</button></div>
								<div class="menu-item"><button type="button" class="btn btn-menu" id="btnPrismStimulate" value="A">
									<div class="btn-inner"><span id="labelA">Prism Stimulate</span></div>
								</button></div>
								<div class="menu-item"><button type="button" class="btn btn-menu" id="btn6Up" value="A">
									<div class="btn-inner"><span id="labelA">6P UP(R)</span></div>
								</button></div>
								<div class="menu-item"><button type="button" class="btn btn-menu" id="btn10Up" value="A">
									<div class="btn-inner"><span id="labelA">10 UP (R)</span></div>
								</button></div>
								<div class="menu-item"><button type="button" class="btn btn-menu" id="btn15Pin" value="A">
									<div class="btn-inner"><span id="labelA">15PIN(L)</span></div>
								</button></div>
								<div class="menu-item"><button type="button" class="btn btn-menu" id="btnBlurredBI" value="A">
									<div class="btn-inner  "><span id="labelABI" data-text="Blurred (BI)"></span></div>
								</button></div>
								<div class="menu-item"><button type="button" class="btn btn-menu" id="btnBreakBI" value="A">
									<div class="btn-inner"><span id="labelABR" data-text="Break (BI)">Break (BI)</span></div>
								</button></div>
								<div class="menu-item"><button type="button" class="btn btn-menu" id="btnRecoveryBI" value="A">
									<div class="btn-inner"><span id="labelAR" data-text="Recovery (BI)">Recovery (BI)</span></div>
								</button></div>	
								<div class="menu-item"><button type="button" class="btn btn-menu" id="btnBlurredBI2" value="A">
									<div class="btn-inner  "><span id="labelABI2" data-text="Blurred (BI)"></span></div>
								</button></div>
								<div class="menu-item"><button type="button" class="btn btn-menu" id="btnBreakBI2" value="A">
									<div class="btn-inner"><span id="labelABR2" data-text="Break (BI)">Break (BI)</span></div>
								</button></div>
								<div class="menu-item"><button type="button" class="btn btn-menu" id="btnRecoveryBI2" value="A">
									<div class="btn-inner"><span id="labelAR2" data-text="Recovery (BI)">Recovery (BI)</span></div>
								</button></div>	
								<div class="menu-item"><button type="button" class="btn btn-menu" id="btnBreakBU" value="A">
									<div class="btn-inner"><span id="labelBreakBU" data-text="Break (BU)">Break (BU)</span></div>
								</button></div>
								<div class="menu-item"><button type="button" class="btn btn-menu" id="btnRecoveryBU" value="A">
									<div class="btn-inner"><span id="labelRecoveryBU" data-text="Recovery (BU)">Recovery (BU)</span></div>
								</button></div>
								<div class="menu-item"><button type="button" class="btn btn-menu" id="btnBreakBU2" value="A">
									<div class="btn-inner"><span id="labelBreakBU2" data-text="Break (BU)">Break (BU)</span></div>
								</button></div>
								<div class="menu-item"><button type="button" class="btn btn-menu" id="btnRecoveryBU2" value="A">
									<div class="btn-inner"><span id="labelRecoveryBU2" data-text="Recovery (BU)">Recovery (BU)</span></div>
								</button></div>
								<div class="menu-item"><button type="button" class="btn btn-menu" id="prismClear" value="A">
									<div class="btn-inner"><span id="labelPrismClear">Clear</span></div>
								</button></div>
								<div class="menu-item"><button type="button" class="btn btn-menu" id="btnBreakBD" value="A">
									<div class="btn-inner"><span id="labelBreakBD" data-text="Break (BD)">Break (BD)</span></div>
								</button></div>
								<div class="menu-item"><button type="button" class="btn btn-menu" id="btnRecoveryBD" value="A">
									<div class="btn-inner"><span id="labelRecoveryBD" data-text="Recovery (BD)">Recovery (BD)</span></div>
								</button></div>	
								<div class="menu-item"><button type="button" class="btn btn-menu" id="btnBreakBD2" value="A">
									<div class="btn-inner"><span id="labelBreakBD2" data-text="Break (BD)">Break (BD)</span></div>
								</button></div>
								<div class="menu-item"><button type="button" class="btn btn-menu" id="btnRecoveryBD2" value="A">
									<div class="btn-inner"><span id="labelRecoveryBD2" data-text="Recovery (BD)">Recovery (BD)</span></div>
								</button></div>	
								
								
								<div class="menu-item"><button type="button" class="btn btn-menu" id="btnBlurredBO" value="A">
									<div class="btn-inner"><span id="labelABO" data-text="Blurred (BO)" >Blurred (BO)</span></div>
								</button></div>
								<div class="menu-item"><button type="button" class="btn btn-menu" id="btnBreakBO" value="A">
									<div class="btn-inner"><span id="labelABRO" data-text="Break (BO)">Break (BO)</span></div>
								</button></div>
								<div class="menu-item"><button type="button" class="btn btn-menu" id="btnRecoveryBO" value="A">
									<div class="btn-inner"><span id="labelARO" data-text="Recovery (BO)">Recovery (BO)</span></div>
								</button></div>
								<div class="menu-item"><button type="button" class="btn btn-menu" id="btnBlurredBO2" value="A">
									<div class="btn-inner"><span id="labelABO2" data-text="Blurred (BO)" >Blurred (BO)</span></div>
								</button></div>
								<div class="menu-item"><button type="button" class="btn btn-menu" id="btnBreakBO2" value="A">
									<div class="btn-inner"><span id="labelABRO2" data-text="Break (BO)">Break (BO)</span></div>
								</button></div>
								<div class="menu-item"><button type="button" class="btn btn-menu" id="btnRecoveryBO2" value="A">
									<div class="btn-inner"><span id="labelARO2" data-text="Recovery (BO)">Recovery (BO)</span></div>
								</button></div>
															
								
								
								<div class="menu-item"><button type="button" class="btn btn-menu" id="btnDLU" value="A">
									<div class="btn-inner"><span id="labelDLU" data-text="U > D 1.0"> U > D 1.0</span></div>
								</button></div>
								<div class="menu-item"><button type="button" class="btn btn-menu" id="btnDLUHalf" value="A">
									<div class="btn-inner"><span id="labelDLUHalf" data-text=" U > D 0.5"> U > D 0.5</span></div>
								</button></div>
								<div class="menu-item"><button type="button" class="btn btn-menu" id="btnUisD" value="A">
									<div class="btn-inner"><span id="labelUisD" data-text="U = D">U = D</span></div>
								</button></div>
								<div class="menu-item"><button type="button" class="btn btn-menu" id="btnULDHalf" value="A">
									<div class="btn-inner"><span id="labelULDHalf" data-text="U < D 0.5">U < D 0.5</span></div>
								</button></div>
								<div class="menu-item"><button type="button" class="btn btn-menu" id="btnULD" value="A">
									<div class="btn-inner"><span id="labelULD" data-text="U < D 1.0">U < D 1.0</span></div>
								</button></div>
								<div class="menu-item"><button type="button" class="btn btn-menu" id="btnRLL" value="A">
									<div class="btn-inner"><span id="labelRLL" data-text="L > R 1.0"> L > R 1.0</span></div>
								</button></div>
								<div class="menu-item"><button type="button" class="btn btn-menu" id="btnRLLhalf" value="A">
									<div class="btn-inner"><span id="labelRLLHalf" data-text="L > R 0.5">L > R 0.5</span></div>
								</button></div>
								<div class="menu-item"><button type="button" class="btn btn-menu" id="btnLisR" value="A">
									<div class="btn-inner"><span id="labelLisR" data-text="L = R">L = R</span></div>
								</button></div>
								<div class="menu-item"><button type="button" class="btn btn-menu" id="btnLLRHalf" value="A">
									<div class="btn-inner"><span id="labelLLRHalf" data-text="L < R 0.5"> L < R 0.5</span></div>
								</button></div>
								<div class="menu-item"><button type="button" class="btn btn-menu" id="btnLLR" value="A">
									<div class="btn-inner"><span id="labelLLR" data-text="L < R 1.0">L < R 1.0</span></div>
								</button></div>
								<div class="menu-item"><button type="button" class="btn btn-menu" id="btnScaleStimulate" value="A">
									<div class="btn-inner"><span id="labelScaleStimulate">Scale Stimulate</span></div>
								</button></div>
								<div class="menu-item"><button type="button" class="btn btn-menu" id="btnDataClear" value="A">
									<div class="btn-inner"><span id="labelDataClear">Data Clear</span></div>
								</button></div>
								<div class="menu-item"><button type="button" class="btn btn-menu" id="btnDataClear1" value="A">
									<div class="btn-inner"><span id="labelDataClear">Data Clear</span></div>
								</button></div>
								<div class="menu-item"><button type="button" class="btn btn-menu" id="btnDataClear2" value="A">
									<div class="btn-inner"><span id="labelDataClear">Data Clear</span></div>
								</button></div>
								<div class="menu-item"><button type="button" class="btn btn-menu" id="btnDataClear3" value="A">
									<div class="btn-inner"><span id="labelDataClear">Data Clear</span></div>
								</button></div>
								<div class="menu-item"><button type="button" class="btn btn-menu" id="btnDataClear4" value="A">
									<div class="btn-inner"><span id="labelDataClear">Data Clear</span></div>
								</button></div>
								<div class="menu-item"><button type="button" class="btn btn-menu" id="btnDataClear5" value="A">
									<div class="btn-inner"><span id="labelDataClear">Data Clear</span></div>
								</button></div>
								<div class="menu-item"><button type="button" class="btn btn-menu" id="btnDataClear6" value="A">
									<div class="btn-inner"><span id="labelDataClear">Data Clear</span></div>
								</button></div>


						</div>
						<!--/.menu-->
					</div>
					<!--/.layout-footer-->
				</div>
				<!--./siteframe-footer-inner-->
			</div>
			<!--./siteframe-footer-->

		</div>
		<!--./siteframe-inner-->
	</div>
	<!--./siteframe-->
	<script type="text/javascript">
		"use strict";
		// 名前空間
		var becky = becky || {};
		// 全体設定
		becky.settingJson = becky.settingJson || {};
		becky.settingJson.objective = <?php echo json_encode($arrayObjectiveSetting); ?>;
		becky.settingJson.subjective = <?php echo json_encode($arraySubjectiveSetting); ?>;
		// セッション
		becky.session = becky.session || {};
		becky.session.sessionDate = "<?php echo $_SESSION['sessionDate']; ?>";
		becky.session.sessionTime = "<?php echo $_SESSION['sessionTime']; ?>";
		becky.session.sessionPatientID = "<?php echo $_SESSION['sessionPatientID']; ?>";
		// 自覚情報
		becky.subjective = becky.subjective || {};
		becky.subjective.langParameter = "<?php echo $lang; ?>";
		becky.subjective.arrayExamParameter = <?php echo json_encode($arrayExamParam); ?>;
		becky.subjective.arrayChartParameter = <?php echo json_encode($arrayChartParam); ?>;
		

		becky.subjective.arrayFlatChartPageParameter =
			<?php
			// $arrayChartPageParam をフラットな構造にする
			$flatCharts = [];
			foreach ($arrayChartPageParam as $keyChartPageParam => $charts) {
				foreach ($charts as $chart) {
					$chart['autoID'] = createAutoID($keyChartPageParam, $chart);
					$flatCharts[] = $chart;
				}
			}
			echo json_encode($flatCharts);
			?>;
		// ライブ像
		becky.liveHttpUri = {
			L: "<?php echo $liveHttpUri['L']; ?>",
			R: "<?php echo $liveHttpUri['R']; ?>",
		};
	</script>
</body>

</html>