<?php
/*! @file
 * @brief 自覚画面向けのロジック関数群
 */

require_once topDir() . 'models/modelUtil.php';
require_once topDir() . 'models/pathUtil.php';
require_once topDir() . 'models/fileUtil.php';

/*!
 * @breif 他覚の設定情報を得る
 *
 * @return array
 */
function getObjectiveSettingJson()
{
	$filenameObjectiveSettingJson = 'contents/settings/objective.setting.json';
	$arrayObjectiveSetting = getMapFromJsonFile(topDir() . $filenameObjectiveSettingJson);
	return $arrayObjectiveSetting;
}

/*!
 * @breif ポストデータ($_POST)から値を取得する
 *
 * @param[in] string $key 取得するキー
 * @return float or string
 */
function getValueFromPOST($key)
{
	
	$value = \ModelUtil\array_get($_POST[$key], '');
	return \ModelUtil\toNumericIfPossible($value);
}

/*!
 * @breif ポストデータ($_POST)からVAの単位を取得する
 *
 * @param[in] string $key 取得するキー
 * @return float or string
 */
function getVA_UnitFromPOST($key)
{
	$value = \ModelUtil\array_get($_POST[$key], '');
	$unit = '';
	switch ($value) {
		case 'd':
			$unit = 'decimal';
			break;
		case 'f':
			$unit = 'feet';
			break;
		case 'm':
			$unit = 'meter';
			break;
		default:
			break;
	}
	return $unit;
}

/*!
 * @brief 自覚を登録する
 * 登録先はファイル
 *
 * @return bool 成功可否
 */
function doRegisterSubjective()
{
	$objectiveSettingJson  = getObjectiveSettingJson();
	if (!$objectiveSettingJson) {
		return false;
	}

	$subjectiveFileDir = tempDir();
	if (!file_exists($subjectiveFileDir) &&
	    !mkdir($subjectiveFileDir, 0777, true)) {
		return false;
	}
	$subjectiveFileName = 'subjective.json';
	$subjectiveFilePath = \becky\Path\combine($subjectiveFileDir, $subjectiveFileName);

	if (file_exists($subjectiveFilePath)) {
		// 同名のファイルが存在する場合
		$backupFileName = $subjectiveFileName;

		$backupSuffix = '.His'; // 時分秒
		$backupSuffix = date($backupSuffix); // 時間フォーマットを適用
		if (!empty($backupSuffix)) {
			$pathInfos = pathinfo($backupFileName);
			$backupFileName = $pathInfos['filename'] . $backupSuffix . '.' . $pathInfos['extension'];
		}

		// リネームする
		$backupFilePath = $subjectiveFileDir . $backupFileName;
		rename($subjectiveFilePath, $backupFilePath);
	}

	$fVD = \ModelUtil\toNumericIfPossible($objectiveSettingJson['vd']);
	
	
	
	$subjectiveJSON = [
		'subjective' => [
			'RefractionTest' => [
				'List' => [
					'1' => [
						'Full Correction' => [
							'ExamDistance' => [
								'List' => [
									'1' =>  [// 遠見
										'Distance' => [
											'unit' => 'mm',
											'value' => getValueFromPOST('examTitle'),
										],
										'RefractionData' => [
											'R' => [
												'Sphere' => [
													'unit' => 'D',
													'value' => getValueFromPOST('SphR'),
												],
												'Cylinder' => [
													'unit' => 'D',
													'value' => getValueFromPOST('CylR'),
												],
												'Axis' => [
													'unit' => 'deg',
													'value' => getValueFromPOST('AxsR'),
												],
											],
											'L' => [
												'Sphere' => [
													'unit' => 'D',
													'value' => getValueFromPOST('SphL'),
												],
												'Cylinder' => [
													'unit' => 'D',
													'value' => getValueFromPOST('CylL'),
												],
												'Axis' => [
													'unit' => 'deg',
													'value' => getValueFromPOST('AxsL'),
												],
											],
											'VD' => [
												'unit' => 'mm',
												'value' => $fVD,
											],
											'PD' => [
												'B' => [
													'unit' => 'mm',
													'value' => getValueFromPOST('PD'),
												],
											],
										],
										'VA' => [
											'R' => [
												'unit'  => getVA_UnitFromPOST('VA_UnitFarR'),
												'value' => getValueFromPOST('VA_FarR'),
											],
											'L' => [
												'unit'  => getVA_UnitFromPOST('VA_UnitFarL'),
												'value' => getValueFromPOST('VA_FarL'),
											],
											'B' => [
												'unit'  => getVA_UnitFromPOST('VA_UnitFarB'),
												'value' => getValueFromPOST('VA_FarB'),
											],
										],
									],
									'2' =>  [// 近見
										'Distance' => [
											'unit' => 'mm',
											'value' => getValueFromPOST('ExamDistanceNear'),
										],
										'RefractionData' => [
											'R' => [
												'Sphere' => [
													'unit' => 'D',
													'value' => getValueFromPOST('SphR') + getValueFromPOST('ADD_R'),
												],
												'Cylinder' => [
													'unit' => 'D',
													'value' => getValueFromPOST('CylR'),
												],
												'Axis' => [
													'unit' => 'deg',
													'value' => getValueFromPOST('AxsR'),
												],
											],
											'L' => [
												'Sphere' => [
													'unit' => 'D',
													'value' => getValueFromPOST('SphL') + getValueFromPOST('ADD_L'),
												],
												'Cylinder' => [
													'unit' => 'D',
													'value' => getValueFromPOST('CylL'),
												],
												'Axis' => [
													'unit' => 'deg',
													'value' => getValueFromPOST('AxsL'),
												],
											],
											'VD' => [
												'unit' => 'mm',
												'value' => $fVD,
											],
											'PD' => [
												'B' => [
													'unit' => 'mm',
													'value' => getValueFromPOST('PD'),
												],
											],
										],
										'VA' => [
											'R' => [
												'unit'  => getVA_UnitFromPOST('VA_UnitNearR'),
												'value' => getValueFromPOST('VA_NearR'),
											],
											'L' => [
												'unit'  => getVA_UnitFromPOST('VA_UnitNearL'),
												'value' => getValueFromPOST('VA_NearL'),
											],
											'B' => [
												'unit'  => getVA_UnitFromPOST('VA_UnitNearB'),
												'value' => getValueFromPOST('VA_NearB'),
											],
										],
									],
								],
							],
						],
					],
				],
			'21Test' =>[
					'3' =>[
						'FAR'=>[
							'R' => [
									'HUnit'  => getValueFromPOST('prism3FHRunit'),
									'HValue'  => getValueFromPOST('prism3FHR'),
									'VUnit' => getValueFromPOST('prism3FVRunit'),
									'VValue' => getValueFromPOST('prism3FVR'),
									],
							'L' => [
									'HUnit'  => getValueFromPOST('prism3FHLunit'),
									'HValue'  => getValueFromPOST('prism3FHL'),
									'VUnit' => getValueFromPOST('prism3FVLunit'),
									'VValue' => getValueFromPOST('prism3FVL'),
									]
							 ],
						'NEAR'=>[
							'R' => [
									'HUnit'  => getValueFromPOST('prism3NHRunit'),
									'HValue'  => getValueFromPOST('prism3NHR'),
									'VUnit' => getValueFromPOST('prism3NVRunit'),
									'VValue' => getValueFromPOST('prism3NVR'),
									],
							'L' => [
									'HUnit'  => getValueFromPOST('prism3NHLunit'),
									'HValue'  => getValueFromPOST('prism3NHL'),
									'VUnit' => getValueFromPOST('prism3NVLunit'),
									'VValue' => getValueFromPOST('prism3NVL'),
									]
							 ],
						],
					'8' =>[
							'FAR'=>[
								'R' => [
										'HUnit'  => getValueFromPOST('prism8FHRunit'),
										'HValue'  => getValueFromPOST('prism8FHR'),
										'VUnit' => getValueFromPOST('prism8FVRunit'),
										'VValue' => getValueFromPOST('prism8FVR'),
										
										],
								'L' => [
										'HUnit'  => getValueFromPOST('prism8FHLunit'),
										'HValue'  => getValueFromPOST('prism8FHL'),
										'VUnit' => getValueFromPOST('prism8FVLunit'),
										'VValue' => getValueFromPOST('prism8FVL'),
										]
								 ],
							'NEAR'=>[
								'R' => [
										'HUnit'  => getValueFromPOST('prism8NHRunit'),
										'HValue'  => getValueFromPOST('prism8NHR'),
										'VUnit' => getValueFromPOST('prism8NVRunit'),
										'VValue' => getValueFromPOST('prism8NVR'),
										],
								'L' => [
										'HUnit'  => getValueFromPOST('prism8NHLunit'),
										'HValue'  => getValueFromPOST('prism8NHL'),
										'VUnit' => getValueFromPOST('prism8NVLunit'),
										'VValue' => getValueFromPOST('prism8NVL'),
										]
								 ],
							],
					'9' =>[
						'FAR'=>[
							'R' => [
									'HUnit'  => getValueFromPOST('prism9FHRunit'),
									'HValue'  => getValueFromPOST('prism9FHR'),
									'VUnit' => getValueFromPOST('prism9FVRunit'),
									'VValue' => getValueFromPOST('prism9FVR'),
									],
							'L' => [
									'HUnit'  => getValueFromPOST('prism9FHLunit'),
									'HValue'  => getValueFromPOST('prism9FHL'),
									'VUnit' => getValueFromPOST('prism9FVLunit'),
									'VValue' => getValueFromPOST('prism9FVL'),
									]
							 ],
						'NEAR'=>[
							'R' => [
									'HUnit'  => getValueFromPOST('prism9NHRunit'),
									'HValue'  => getValueFromPOST('prism9NHR'),
									'VUnit' => getValueFromPOST('prism9NVRunit'),
									'VValue' => getValueFromPOST('prism9NVR'),
									],
							'L' => [
									'HUnit'  => getValueFromPOST('prism9NHLunit'),
									'HValue'  => getValueFromPOST('prism9NHL'),
									'VUnit' => getValueFromPOST('prism9NVLunit'),
									'VValue' => getValueFromPOST('prism9NVL'),
									]
							 ],
						],
					'10' =>[
						'FAR'=>[
							'R' => [
									'HUnit'  => getValueFromPOST('prism10FHRunit'),
									'HValue'  => getValueFromPOST('prism10FHR'),
									'VUnit' => getValueFromPOST('prism10FVRunit'),
									'VValue' => getValueFromPOST('prism10FVR'),
									],
							'L' => [
									'HUnit'  => getValueFromPOST('prism10FHLunit'),
									'HValue'  => getValueFromPOST('prism10FHL'),
									'VUnit' => getValueFromPOST('prism10FVLunit'),
									'VValue' => getValueFromPOST('prism10FVL'),
									]
							 ],
						'NEAR'=>[
							'R' => [
									'HUnit'  => getValueFromPOST('prism10NHRunit'),
									'HValue'  => getValueFromPOST('prism10NHR'),
									'VUnit' => getValueFromPOST('prism10NVRunit'),
									'VValue' => getValueFromPOST('prism10NVR'),
									],
							'L' => [
									'HUnit'  => getValueFromPOST('prism10NHLunit'),
									'HValue'  => getValueFromPOST('prism10NHL'),
									'VUnit' => getValueFromPOST('prism10NVLunit'),
									'VValue' => getValueFromPOST('prism10NVL'),
									]
							 ],
						],
					'12A' =>[
						'FAR'=>[
							'R' => [
									'HUnit'  => getValueFromPOST('prism12AFHRunit'),
									'HValue'  => getValueFromPOST('prism12AFHR'),
									'VUnit' => getValueFromPOST('prism12AFVRunit'),
									'VValue' => getValueFromPOST('prism12AFVR'),
									],
							'L' => [
									'HUnit'  => getValueFromPOST('prism12AFHLunit'),
									'HValue'  => getValueFromPOST('prism12AFHL'),
									'VUnit' => getValueFromPOST('prism12AFVLunit'),
									'VValue' => getValueFromPOST('prism12AFVL'),
									]
							 ],
						'NEAR'=>[
							'R' => [
									'HUnit'  => getValueFromPOST('prism12ANHRunit'),
									'HValue'  => getValueFromPOST('prism12ANHR'),
									'VUnit' => getValueFromPOST('prism12ANVRunit'),
									'VValue' => getValueFromPOST('prism12ANVR'),
									],
							'L' => [
									'HUnit'  => getValueFromPOST('prism12ANHLunit'),
									'HValue'  => getValueFromPOST('prism12ANHL'),
									'VUnit' => getValueFromPOST('prism12ANVLunit'),
									'VValue' => getValueFromPOST('prism12ANVL'),
									]
							 ],
						],
					'12B' =>[
						'FAR'=>[
							'R' => [
									'HUnit'  => getValueFromPOST('prism12BFHRunit'),
									'HValue'  => getValueFromPOST('prism12BFHR'),
									'VUnit' => getValueFromPOST('prism12BFVRunit'),
									'VValue' => getValueFromPOST('prism12BFVR'),
									],
							'L' => [
									'HUnit'  => getValueFromPOST('prism12BFHLunit'),
									'HValue'  => getValueFromPOST('prism12BFHL'),
									'VUnit' => getValueFromPOST('prism12BFVLunit'),
									'VValue' => getValueFromPOST('prism12BFVL'),
									]
							 ],
						'NEAR'=>[
							'R' => [
									'HUnit'  => getValueFromPOST('prism12BNHRunit'),
									'HValue'  => getValueFromPOST('prism12BNHR'),
									'VUnit' => getValueFromPOST('prism12BNVRunit'),
									'VValue' => getValueFromPOST('prism12BNVR'),
									],
							'L' => [
									'HUnit'  => getValueFromPOST('prism12BNHLunit'),
									'HValue'  => getValueFromPOST('prism12BNHL'),
									'VUnit' => getValueFromPOST('prism12BNVLunit'),
									'VValue' => getValueFromPOST('prism12BNVL'),
									]
							 ],
						],
					'13A' =>[
						'FAR'=>[
							'R' => [
									'HUnit'  => getValueFromPOST('prism13AFHRunit'),
									'HValue'  => getValueFromPOST('prism13AFHR'),
									'VUnit' => getValueFromPOST('prism13AFVRunit'),
									'VValue' => getValueFromPOST('prism13AFVR'),
									],
							'L' => [
									'HUnit'  => getValueFromPOST('prism13AFHLunit'),
									'HValue'  => getValueFromPOST('prism13AFHL'),
									'VUnit' => getValueFromPOST('prism13AFVLunit'),
									'VValue' => getValueFromPOST('prism13AFVL'),
									]
							 ],
						'NEAR'=>[
							'R' => [
									'HUnit'  => getValueFromPOST('prism13ANHRunit'),
									'HValue'  => getValueFromPOST('prism13ANHR'),
									'VUnit' => getValueFromPOST('prism13ANVRunit'),
									'VValue' => getValueFromPOST('prism13ANVR'),

									],
							'L' => [
									'HUnit'  => getValueFromPOST('prism13ANHLunit'),
									'HValue'  => getValueFromPOST('prism13ANHL'),
									'VUnit' => getValueFromPOST('prism13ANVLunit'),
									'VValue' => getValueFromPOST('prism13ANVL'),
									]
							 ],
						],
					'13B' =>[
						'FAR'=>[
							'R' => [
									'HUnit'  => getValueFromPOST('prism13BFHRunit'),
									'HValue'  => getValueFromPOST('prism13BFHR'),
									'VUnit' => getValueFromPOST('prism13BFVRunit'),
									'VValue' => getValueFromPOST('prism13BFVR'),
									],
							'L' => [
									'HUnit'  => getValueFromPOST('prism13BFHLunit'),
									'HValue'  => getValueFromPOST('prism13BFHL'),
									'VUnit' => getValueFromPOST('prism13BFVLunit'),
									'VValue' => getValueFromPOST('prism13BFVL'),
									]
							 ],
						'NEAR'=>[
							'R' => [
									'HUnit'  => getValueFromPOST('prism13BNHRunit'),
									'HValue'  => getValueFromPOST('prism13BNHR'),
									'VUnit' => getValueFromPOST('prism13BNVRunit'),
									'VValue' => getValueFromPOST('prism13BNVR'),
									],
							'L' => [
									'HUnit'  => getValueFromPOST('prism13BNHLunit'),
									'HValue'  => getValueFromPOST('prism13BNHL'),
									'VUnit' => getValueFromPOST('prism13BNVLunit'),
									'VValue' => getValueFromPOST('prism13BNVL'),
									]
							 ],
						],
					'14A' =>[
						'FAR'=>[
							'R' => [
									'HUnit'  => getValueFromPOST('prism14AFHRunit'),
									'HValue'  => getValueFromPOST('prism14AFHR'),
									'VUnit' => getValueFromPOST('prism14AFVRunit'),
									'VValue' => getValueFromPOST('prism14AFVR'),
									],
							'L' => [
									'HUnit' => getValueFromPOST('prism14AFHLunit'),
									'HValue'  => getValueFromPOST('prism14AFHL'),
									'VUnit' => getValueFromPOST('prism14AFVLunit'),
									'VValue' => getValueFromPOST('prism14AFVL'),
									]
							 ],
						'NEAR'=>[
							'R' => [
									'HUnit'  => getValueFromPOST('prism14ANHRunit'),
									'HValue'  => getValueFromPOST('prism14ANHR'),
									'VUnit' => getValueFromPOST('prism14ANVRunit'),
									'VValue' => getValueFromPOST('prism14ANVR'),
									],
							'L' => [
									'HUnit'  => getValueFromPOST('prism14ANHLunit'),
									'HValue'  => getValueFromPOST('prism14ANHL'),
									'VUnit' => getValueFromPOST('prism14ANVLunit'),
									'VValue' => getValueFromPOST('prism14ANVL'),
									]
							 ],
						],
					'14B' =>[
						'FAR'=>[
							'R' => [
									'HUnit'  => getValueFromPOST('prism14BFHRunit'),
									'HValue'  => getValueFromPOST('prism14BFHR'),
									'VUnit' => getValueFromPOST('prism14BFVRunit'),
									'VValue' => getValueFromPOST('prism14BFVR'),
									],
							'L' => [
									'HUnit'  => getValueFromPOST('prism14BFHLunit'),
									'HValue'  => getValueFromPOST('prism14BFHL'),
									'VUnit' => getValueFromPOST('prism14BFVLunit'),
									'VValue' => getValueFromPOST('prism14BFVL'),
									]
							 ],
						'NEAR'=>[
							'R' => [
									'HUnit'  => getValueFromPOST('prism14BNHRunit'),
									'HValue'  => getValueFromPOST('prism14BNHR'),
									'VUnit' => getValueFromPOST('prism14BNVRunit'),
									'VValue' => getValueFromPOST('prism14BNVR'),
									],
							'L' => [
									'HUnit'  => getValueFromPOST('prism14BNHLunit'),
									'HValue'  => getValueFromPOST('prism14BNHL'),
									'VUnit' => getValueFromPOST('prism14BNVLunit'),
									'VValue' => getValueFromPOST('prism14BNVL'),
									]
							 ],
						],
					'15A' =>[
						'FAR'=>[
							'R' => [
									'HUnit'  => getValueFromPOST('prism15AFHRunit'),
									'HValue'  => getValueFromPOST('prism15AFHR'),
									'VUnit' => getValueFromPOST('prism15AFVRunit'),
									'VValue' => getValueFromPOST('prism15AFVR'),
									],
							'L' => [
									'HUnit'  => getValueFromPOST('prism15AFHLunit'),
									'HValue'  => getValueFromPOST('prism15AFHL'),
									'VUnit' => getValueFromPOST('prism15AFVLunit'),
									'VValue' => getValueFromPOST('prism15AFVL'),
									]
							 ],
						'NEAR'=>[
							'R' => [
									'HUnit'  => getValueFromPOST('prism15ANHRunit'),
									'HValue'  => getValueFromPOST('prism15ANHR'),
									'VUnit' => getValueFromPOST('prism15ANVRunit'),
									'VValue' => getValueFromPOST('prism15ANVR'),
									],
							'L' => [
									'HUnit'  => getValueFromPOST('prism15ANHLunit'),
									'HValue'  => getValueFromPOST('prism15ANHL'),
									'VUnit' => getValueFromPOST('prism15ANVLunit'),
									'VValue' => getValueFromPOST('prism15ANVL'),
									]
							 ],
						],
					'15B' =>[
						'FAR'=>[
							'R' => [
									'HUnit'  => getValueFromPOST('prism15BFHRunit'),
									'HValue'  => getValueFromPOST('prism15BFHR'),
									'VUnit' => getValueFromPOST('prism15BFVRunit'),
									'VValue' => getValueFromPOST('prism15BFVR'),
									],
							'L' => [
									'HUnit'  => getValueFromPOST('prism15BFHLunit'),
									'HValue'  => getValueFromPOST('prism15BFHL'),
									'VUnit' => getValueFromPOST('prism15BFVLunit'),
									'VValue' => getValueFromPOST('prism15BFVL'),
									]
							 ],
						'NEAR'=>[
							'R' => [
									'HUnit'  => getValueFromPOST('prism15BNHRunit'),
									'HValue'  => getValueFromPOST('prism15BNHR'),
									'VUnit' => getValueFromPOST('prism15BNVRunit'),
									'VValue' => getValueFromPOST('prism15BNVR'),
									],
							'L' => [
									'HUnit'  => getValueFromPOST('prism15BNHLunit'),
									'HValue'  => getValueFromPOST('prism15BNHL'),
									'VUnit' => getValueFromPOST('prism15BNVLunit'),
									'VValue' => getValueFromPOST('prism15BNVL'),
									]
							 ],
						],
					'16' =>[
						'FAR'=>[
							'R' => [
									'HUnit'  => getValueFromPOST('prism16FHRunit'),
									'HValue'  => getValueFromPOST('prism16FHR'),
									'VUnit' => getValueFromPOST('prism16FVRunit'),
									'VValue' => getValueFromPOST('prism16FVR'),
									],
							'L' => [
									'HUnit'  => getValueFromPOST('prism16FHLunit'),
									'HValue'  => getValueFromPOST('prism16FHL'),
									'VUnit' => getValueFromPOST('prism16FVLunit'),
									'VValue' => getValueFromPOST('prism16FVL'),
									]
							 ],
						'NEAR'=>[
							'R' => [
									'HUnit'  => getValueFromPOST('prism16NHRunit'),
									'HValue'  => getValueFromPOST('prism16FHL'),
									'VUnit' => getValueFromPOST('prism16NVRunit'),
									'VValue' => getValueFromPOST('prism16FVL'),
									],
							'L' => [
									'HUnit'  => getValueFromPOST('prism16NHLunit'),
									'HValue'  => getValueFromPOST('prism16NHL'),
									'VUnit' => getValueFromPOST('prism16NVLunit'),
									'VValue' => getValueFromPOST('prism16NVL'),
									]
							 ],
						],
					'17' =>[
						'FAR'=>[
							'R' => [
									'HUnit'  => getValueFromPOST('prism17FHRunit'),
									'HValue'  => getValueFromPOST('prism17FHR'),
									'VUnit' => getValueFromPOST('prism17FVRunit'),
									'VValue' => getValueFromPOST('prism17FVR'),
									],
							'L' => [
									'HUnit'  => getValueFromPOST('prism17FHLunit'),
									'HValue'  => getValueFromPOST('prism17FHL'),
									'VUnit' => getValueFromPOST('prism17FVLunit'),
									'VValue' => getValueFromPOST('prism17FVL'),
									]
							 ],
						'NEAR'=>[
							'R' => [
									'HUnit'  => getValueFromPOST('prism17NHRunit'),
									'HValue'  => getValueFromPOST('prism17NHR'),
									'VUnit' => getValueFromPOST('prism17NVRunit'),
									'VValue' => getValueFromPOST('prism17NVR'),
									],
							'L' => [
									'HUnit'  => getValueFromPOST('prism17NHLunit'),
									'HValue'  => getValueFromPOST('prism17NHL'),
									'VUnit' => getValueFromPOST('prism17NVLunit'),
									'VValue' => getValueFromPOST('prism17NVL'),
									]
							 ],
						],
						'18A' =>[
							'FAR'=>[
								'R' => [
										'HUnit'  => getValueFromPOST('prism18AFHRunit'),
										'HValue'  => getValueFromPOST('prism18AFHR'),
										'VUnit' => getValueFromPOST('prism18AFVRunit'),
										'VValue' => getValueFromPOST('prism18AFVR'),
										],
								'L' => [
										'HUnit'  => getValueFromPOST('prism18AFHLunit'),
										'HValue'  => getValueFromPOST('prism18AFHL'),
										'VUnit' => getValueFromPOST('prism18AFVLunit'),
										'VValue' => getValueFromPOST('prism18AFVL'),
										]
								 ],
							'NEAR'=>[
								'R' => [
										'HUnit'  => getValueFromPOST('prism18ANHRunit'),
										'HValue'  => getValueFromPOST('prism18ANHR'),
										'VUnit' => getValueFromPOST('prism18ANVRunit'),
										'VValue' => getValueFromPOST('prism18ANVR'),
										],
								'L' => [
										'HUnit'  => getValueFromPOST('prism18ANHLunit'),
										'HValue'  => getValueFromPOST('prism18ANHL'),
										'VUnit' => getValueFromPOST('prism18ANVLunit'),
										'VValue' => getValueFromPOST('prism18ANVL'),
										]
								 ],
							],
					
					
					],
				],
			],
			'BinoTest' =>
			[
				'Stereo(Floating)' =>[
					'FAR'=>[
						'R' => [
								'HUnit'  => getValueFromPOST('bino1FHRunit'),
								'HValue'  => getValueFromPOST('bino1FHR'),
								'VUnit' => getValueFromPOST('bino1FVRunit'),
								'VValue' => getValueFromPOST('bino1FVR'),
								],
						'L' => [
								'HUnit'  => getValueFromPOST('bino1FHLunit'),
								'HValue'  => getValueFromPOST('bino1FHL'),
								'VUnit' => getValueFromPOST('bino1FVLunit'),
								'VValue' => getValueFromPOST('bino1FVL'),
								]
						 ],
					'NEAR'=>[
						'R' => [
								'HUnit'  => getValueFromPOST('bino1NHRunit'),
								'HValue'  => getValueFromPOST('bino1NHR'),
								'VUnit' => getValueFromPOST('bino1NVRunit'),
								'VValue' => getValueFromPOST('bino1NVR'),
								],
						'L' => [
								'HUnit'  => getValueFromPOST('bino1NHLunit'),
								'HValue'  => getValueFromPOST('bino1NHL'),
								'VUnit' => getValueFromPOST('bino1NVLunit'),
								'VValue' => getValueFromPOST('bino1NVL'),
								]
						],
				],
				'Stereo(Sinking)' =>[
					'FAR'=>[
						'R' => [
								'HUnit'  => getValueFromPOST('bino2FHRunit'),
								'HValue'  => getValueFromPOST('bino2FHR'),
								'VUnit' => getValueFromPOST('bino2FVRunit'),
								'VValue' => getValueFromPOST('bino2FVR'),
								],
						'L' => [
								'HUnit'  => getValueFromPOST('bino2FHLunit'),
								'HValue'  => getValueFromPOST('bino2FHL'),
								'VUnit' => getValueFromPOST('bino2FVLunit'),
								'VValue' => getValueFromPOST('bino2FVL'),
								]
						 ],
					'NEAR'=>[
						'R' => [
								'HUnit'  => getValueFromPOST('bino2NHRunit'),
								'HValue'  => getValueFromPOST('bino2NHR'),
								'VUnit' => getValueFromPOST('bino2NVRunit'),
								'VValue' => getValueFromPOST('bino2NVR'),
								],
						'L' => [
								'HUnit'  => getValueFromPOST('bino2NHLunit'),
								'HValue'  => getValueFromPOST('bino2NHL'),
								'VUnit' => getValueFromPOST('bino2NVLunit'),
								'VValue' => getValueFromPOST('bino2NVL'),
								]
						 ],
				],
				'Fixation Disparity' =>[
					'FAR'=>[
						'R' => [
								'HUnit'  => getValueFromPOST('bino3FHRunit'),
								'HValue'  => getValueFromPOST('bino3FHR'),
								'VUnit' => getValueFromPOST('bino3FVRunit'),
								'VValue' => getValueFromPOST('bino3FVR'),
								],
						'L' => [
								'HUnit'  => getValueFromPOST('bino3FHLunit'),
								'HValue'  => getValueFromPOST('bino3FHL'),
								'VUnit' => getValueFromPOST('bino3FVLunit'),
								'VValue' => getValueFromPOST('bino3FVL'),
								]
						 ],
					'NEAR'=>[
						'R' => [
								'HUnit'  => getValueFromPOST('bino3NHRunit'),
								'HValue'  => getValueFromPOST('bino3NHR'),
								'VUnit' => getValueFromPOST('bino3NVRunit'),
								'VValue' => getValueFromPOST('bino3NVR'),
								],
						'L' => [
								'HUnit'  => getValueFromPOST('bino3NHLunit'),
								'HValue'  => getValueFromPOST('bino3NHL'),
								'VUnit' => getValueFromPOST('bino3NVLunit'),
								'VValue' => getValueFromPOST('bino3NVL'),
								]
						 ],
			],
		'Worth 4Dots' =>[
					'FAR'=>[
						'R' => [
								'HUnit'  => getValueFromPOST('bino4FHRunit'),
								'HValue'  => getValueFromPOST('bino4FHR'),
								'VUnit' => getValueFromPOST('bino4FVRunit'),
								'VValue' => getValueFromPOST('bino4FVR'),
								],
						'L' => [
								'HUnit'  => getValueFromPOST('bino4FHLunit'),
								'HValue'  => getValueFromPOST('bino4FHL'),
								'VUnit' => getValueFromPOST('bino4FVLunit'),
								'VValue' => getValueFromPOST('bino4FVL'),
								]
						 ],
					'NEAR'=>[
						'R' => [
								'HUnit'  => getValueFromPOST('bino4NHRunit'),
								'HValue'  => getValueFromPOST('bino4NHR'),
								'VUnit' => getValueFromPOST('bino4NVRunit'),
								'VValue' => getValueFromPOST('bino4NVR'),
								],
						'L' => [
								'HUnit'  => getValueFromPOST('bino4NHLunit'),
								'HValue'  => getValueFromPOST('bino4NHL'),
								'VUnit' => getValueFromPOST('bino4NVLunit'),
								'VValue' => getValueFromPOST('bino4NVL'),
								]
						 ],
			],
		'Coincidence(H)' =>[
					'FAR'=>[
						'R' => [
								'HUnit'  => getValueFromPOST('bino5FHRunit'),
								'HValue'  => getValueFromPOST('bino5FHR'),
								'VUnit' => getValueFromPOST('bino5FVRunit'),
								'VValue' => getValueFromPOST('bino5FVR'),
								],
						'L' => [
								'HUnit'  => getValueFromPOST('bino5FHLunit'),
								'HValue'  => getValueFromPOST('bino5FHL'),
								'VUnit' => getValueFromPOST('bino5FVLunit'),
								'VValue' => getValueFromPOST('bino5FVL'),
						],
								'RUnit' => getValueFromPOST('bino5FHRR1unit'),
								'RValue' => getValueFromPOST('bino5FHRR1')
						 ],
					'NEAR'=>[
						'R' => [
								'HUnit'  => getValueFromPOST('bino5NHRunit'),
								'HValue'  => getValueFromPOST('bino5NHR'),
								'VUnit' => getValueFromPOST('bino5NVRunit'),
								'VValue' => getValueFromPOST('bino5NVR'),
								],
						'L' => [
								'HUnit'  => getValueFromPOST('bino5NHLunit'),
								'HValue'  => getValueFromPOST('bino5NHL'),
								'VUnit' => getValueFromPOST('bino5NVLunit'),
								'VValue' => getValueFromPOST('bino5NVL'),
						],
						'RUnit' => getValueFromPOST('bino5NHRR1unit'),
								'RValue' => getValueFromPOST('bino5NHRR1')
						 ],
			],
			'Coincidence(V)' =>[
					'FAR'=>[
						'R' => [
								'HUnit'  => getValueFromPOST('bino6FHRunit'),
								'HValue'  => getValueFromPOST('bino6FHR'),
								'VUnit' => getValueFromPOST('bino6FVRunit'),
								'VValue' => getValueFromPOST('bino6FVR'),
								],
						'L' => [
								'HUnit'  => getValueFromPOST('bino6FHLunit'),
								'HValue'  => getValueFromPOST('bino6FHL'),
								'VUnit' => getValueFromPOST('bino6FVLunit'),
								'VValue' => getValueFromPOST('bino6FVL'),
						],
						'RUnit' => getValueFromPOST('bino6FHRR1unit'),
								'RValue' => getValueFromPOST('bino6FHRR1')
						 ],
						 
					'NEAR'=>[
						'R' => [
								'HUnit'  => getValueFromPOST('bino6NHRunit'),
								'HValue'  => getValueFromPOST('bino6NHR'),
								'VUnit' => getValueFromPOST('bino6NVRunit'),
								'VValue' => getValueFromPOST('bino6NVR'),
								],
						'L' => [
								'HUnit'  => getValueFromPOST('bino6NHLunit'),
								'HValue'  => getValueFromPOST('bino6NHL'),
								'VUnit' => getValueFromPOST('bino6NVLunit'),
								'VValue' => getValueFromPOST('bino6NVL'),
						],
						'RUnit' => getValueFromPOST('bino6NHRR1unit'),
								'RValue' => getValueFromPOST('bino6NHRR1')
						 ],
			],
		'Sheard\'s Criteria' =>[
					'FAR'=>[
						'R' => [
								'HUnit'  => getValueFromPOST('bino7FHRunit'),
								'HValue'  => getValueFromPOST('bino7FHR'),
								'VUnit' => getValueFromPOST('bino7FVRunit'),
								'VValue' => getValueFromPOST('bino7FVR'),
								],
						'L' => [
								'HUnit'  => getValueFromPOST('bino7FHLunit'),
								'HValue'  => getValueFromPOST('bino7FHL'),
								'VUnit' => getValueFromPOST('bino7FVLunit'),
								'VValue' => getValueFromPOST('bino7FVL'),
								]
						 ],
					'NEAR'=>[
						'R' => [
								'HUnit'  => getValueFromPOST('bino7NHRunit'),
								'HValue'  => getValueFromPOST('bino7NHR'),
								'VUnit' => getValueFromPOST('bino7NVRunit'),
								'VValue' => getValueFromPOST('bino7NVR'),
								],
						'L' => [
								'HUnit'  => getValueFromPOST('bino7NHLunit'),
								'HValue'  => getValueFromPOST('bino7NHL'),
								'VUnit' => getValueFromPOST('bino7NVLunit'),
								'VValue' => getValueFromPOST('bino7NVL'),
								]
						 ],
			],
		'AC/A' =>[
					'FAR'=>[
						'R' => [
								'HUnit'  => getValueFromPOST('bino8FHRunit'),
								'HValue'  => getValueFromPOST('bino8FHR'),
								'VUnit' => getValueFromPOST('bino8FVRunit'),
								'VValue' => getValueFromPOST('bino8FVR'),
								],
						'L' => [
								'HUnit'  => getValueFromPOST('bino8FHLunit'),
								'HValue'  => getValueFromPOST('bino8FHL'),
								'VUnit' => getValueFromPOST('bino8FVLunit'),
								'VValue' => getValueFromPOST('bino8FVL'),
								]
						 ],
					'NEAR'=>[
						'R' => [
								'HUnit'  => getValueFromPOST('bino8NHRunit'),
								'HValue'  => getValueFromPOST('bino8NHR'),
								'VUnit' => getValueFromPOST('bino8NVRunit'),
								'VValue' => getValueFromPOST('bino8NVR'),
								],
						'L' => [
								'HUnit'  => getValueFromPOST('bino8NHLunit'),
								'HValue'  => getValueFromPOST('bino8NHL'),
								'VUnit' => getValueFromPOST('bino8NVLunit'),
								'VValue' => getValueFromPOST('bino8NVL'),
								]
						 ],
			],
			'#9,10,11' =>[
					'FAR'=>[
						'R' => [
								'HUnit'  => getValueFromPOST('bino9FHRunit'),
								'HValue'  => getValueFromPOST('bino9FHR'),
								'VUnit' => getValueFromPOST('bino9FVRunit'),
								'VValue' => getValueFromPOST('bino9FVR'),
								],
						
						'L' => [
								'HUnit'  => getValueFromPOST('bino9FHLunit'),
								'HValue'  => getValueFromPOST('bino9FHL'),
								'VUnit' => getValueFromPOST('bino9FVLunit'),
								'VValue' => getValueFromPOST('bino9FVL'),
						],
								'R1Unit' => getValueFromPOST('bino9FHRR1unit'),
								'R1Value' => getValueFromPOST('bino9FHRR1'),
								'R2Unit' => getValueFromPOST('bino9FHRR2unit'),
								'R2Value' => getValueFromPOST('bino9FHRR2'),
								'R3Unit' => getValueFromPOST('bino9FHRR3unit'),
								'R3Value' => getValueFromPOST('bino9FHRR3'),
								'R4Unit' => getValueFromPOST('bino9FHRR4unit'),
								'R4Value' => getValueFromPOST('bino9FHRR4'),
								'R5Unit' => getValueFromPOST('bino9FHRR5unit'),
								'R5Value' => getValueFromPOST('bino9FHRR5'),
								'R6Unit' => getValueFromPOST('bino9FHRR6unit'),
								'R6Value' => getValueFromPOST('bino9FHRR6')

						 ],
					'NEAR'=>[
						'R' => [
								'HUnit'  => getValueFromPOST('bino9NHRunit'),
								'HValue'  => getValueFromPOST('bino9NHR'),
								'VUnit' => getValueFromPOST('bino9NVRunit'),
								'VValue' => getValueFromPOST('bino9NVR'),
								],
						'L' => [
								'HUnit'  => getValueFromPOST('bino9NHLunit'),
								'HValue'  => getValueFromPOST('bino9NHL'),
								'VUnit' => getValueFromPOST('bino9NVLunit'),
								'VValue' => getValueFromPOST('bino9NVL'),
								]
						 ],
			],
			'Accomodation Power' =>[
					'FAR'=>[
						'R' => [
								'HUnit'  => getValueFromPOST('bino11FHRunit'),
								'HValue'  => getValueFromPOST('bino11FHR'),
								'VUnit' => getValueFromPOST('bino11FVRunit'),
								'VValue' => getValueFromPOST('bino11FVR'),
								],
						'L' => [
								'HUnit'  => getValueFromPOST('bino11FHLunit'),
								'HValue'  => getValueFromPOST('bino11FHL'),
								'VUnit' => getValueFromPOST('bino11FVLunit'),
								'VValue' => getValueFromPOST('bino11FVL'),
								]
						 ],
					'NEAR'=>[
						'R' => [
								'HUnit'  => getValueFromPOST('bino11NHRunit'),
								'HValue'  => getValueFromPOST('bino11NHR'),
								'VUnit' => getValueFromPOST('bino11NVRunit'),
								'VValue' => getValueFromPOST('bino11NVR'),
								],
						'L' => [
								'HUnit'  => getValueFromPOST('bino11NHLunit'),
								'HValue'  => getValueFromPOST('bino11NHL'),
								'VUnit' => getValueFromPOST('bino11NVLunit'),
								'VValue' => getValueFromPOST('bino11NVL'),
								]
						 ],
			],
			'12B_SUPRA' =>[
					'FAR'=>[
						'R' => [
								'HUnit'  => getValueFromPOST('bino12FHRunit'),
								'HValue'  => getValueFromPOST('bino12FHR'),
								'VUnit' => getValueFromPOST('bino12FVRunit'),
								'VValue' => getValueFromPOST('bino12FVR'),
								],
								
						'L' => [
								'HUnit'  => getValueFromPOST('bino12FHLunit'),
								'HValue'  => getValueFromPOST('bino12FHL'),
								'VUnit' => getValueFromPOST('bino12FVLunit'),
								'VValue' => getValueFromPOST('bino12FVL'),
						],
						'R1Unit' => getValueFromPOST('bino12FHRR1unit'),
								'R1Value' => getValueFromPOST('bino12FHRR1'),
								'R2Unit' => getValueFromPOST('bino12FHRR2unit'),
								'R2Value' => getValueFromPOST('bino12FHRR2'),
						 ],
					'NEAR'=>[
						'R' => [
								'HUnit'  => getValueFromPOST('bino12NHRunit'),
								'HValue'  => getValueFromPOST('bino12NHR'),
								'VUnit' => getValueFromPOST('bino12NVRunit'),
								'VValue' => getValueFromPOST('bino12NVR'),
								],
						'L' => [
								'HUnit'  => getValueFromPOST('bino12NHLunit'),
								'HValue'  => getValueFromPOST('bino12NHL'),
								'VUnit' => getValueFromPOST('bino12NVLunit'),
								'VValue' => getValueFromPOST('bino12NVL'),
								]
						 ],
			],
			'12B_INFRA' =>[
					'FAR'=>[
						'R' => [
								'HUnit'  => getValueFromPOST('bino13FHRunit'),
								'HValue'  => getValueFromPOST('bino13FHR'),
								'VUnit' => getValueFromPOST('bino13FVRunit'),
								'VValue' => getValueFromPOST('bino13FVR'),
								],
						'L' => [
								'HUnit'  => getValueFromPOST('bino13FHLunit'),
								'HValue'  => getValueFromPOST('bino13FHL'),
								'VUnit' => getValueFromPOST('bino13FVLunit'),
								'VValue' => getValueFromPOST('bino13FVL'),
						],
						'R3Unit' => getValueFromPOST('bino13FHRR3unit'),
								'R3Value' => getValueFromPOST('bino13FHRR3'),
								'R4Unit' => getValueFromPOST('bino13FHRR4unit'),
								'R4Value' => getValueFromPOST('bino13FHRR4')
						 ],
					'NEAR'=>[
						'R' => [
								'HUnit'  => getValueFromPOST('bino13NHRunit'),
								'HValue'  => getValueFromPOST('bino13NHR'),
								'VUnit' => getValueFromPOST('bino13NVRunit'),
								'VValue' => getValueFromPOST('bino13NVR'),
								],
						'L' => [
								'HUnit'  => getValueFromPOST('bino13NHLunit'),
								'HValue'  => getValueFromPOST('bino13NHL'),
								'VUnit' => getValueFromPOST('bino13NVLunit'),
								'VValue' => getValueFromPOST('bino13NVL'),
								]
						 ],
			],
			'#16' =>[
					'FAR'=>[
						'R' => [
								'HUnit'  => getValueFromPOST('bino14FHRunit'),
								'HValue'  => getValueFromPOST('bino14FHR'),
								'VUnit' => getValueFromPOST('bino14FVRunit'),
								'VValue' => getValueFromPOST('bino14FVR'),
								],
						'L' => [
								'HUnit'  => getValueFromPOST('bino14FHLunit'),
								'HValue'  => getValueFromPOST('bino14FHL'),
								'VUnit' => getValueFromPOST('bino14FVLunit'),
								'VValue' => getValueFromPOST('bino14FVL'),
							],
							'R1Unit' => getValueFromPOST('bino14FHRR1unit'),
							'R1Value' => getValueFromPOST('bino14FHRR1'),
							'R2Unit' => getValueFromPOST('bino14FHRR2unit'),
							'R2Value' => getValueFromPOST('bino14FHRR2'),
							'R3Unit' => getValueFromPOST('bino14FHRR3unit'),
							'R3Value' => getValueFromPOST('bino14FHRR3'),

						 ],
					'NEAR'=>[
						'R' => [
								'HUnit'  => getValueFromPOST('bino14NHRunit'),
								'HValue'  => getValueFromPOST('bino14NHR'),
								'VUnit' => getValueFromPOST('bino14NVRunit'),
								'VValue' => getValueFromPOST('bino14NVR'),
								],
						'L' => [
								'HUnit'  => getValueFromPOST('bino14NHLunit'),
								'HValue'  => getValueFromPOST('bino14NHL'),
								'VUnit' => getValueFromPOST('bino14NVLunit'),
								'VValue' => getValueFromPOST('bino14NVL'),
								]
						 ],
			],
		'#17' =>[
					'FAR'=>[
						'R' => [
								'HUnit'  => getValueFromPOST('bino15FHRunit'),
								'HValue'  => getValueFromPOST('bino15FHR'),
								'VUnit' => getValueFromPOST('bino15FVRunit'),
								'VValue' => getValueFromPOST('bino15FVR'),
								],
						'L' => [
								'HUnit'  => getValueFromPOST('bino15FHLunit'),
								'HValue'  => getValueFromPOST('bino15FHL'),
								'VUnit' => getValueFromPOST('bino15FVLunit'),
								'VValue' => getValueFromPOST('bino15FVL'),
						],
						'R4Unit' => getValueFromPOST('bino15FHRR4unit'),
						'R4Value' => getValueFromPOST('bino15FHRR4'),
						'R5Unit' => getValueFromPOST('bino15FHRR5unit'),
						'R5Value' => getValueFromPOST('bino15FHRR5'),
						'R6Unit' => getValueFromPOST('bino15FHRR6unit'),
						'R6Value' => getValueFromPOST('bino15FHRR6'),
						 ],
					'NEAR'=>[
						'R' => [
								'HUnit'  => getValueFromPOST('bino15NHRunit'),
								'HValue'  => getValueFromPOST('bino15NHR'),
								'VUnit' => getValueFromPOST('bino15NVRunit'),
								'VValue' => getValueFromPOST('bino15NVR'),
								],
						'L' => [
								'HUnit'  => getValueFromPOST('bino15NHLunit'),
								'HValue'  => getValueFromPOST('bino15NHL'),
								'VUnit' => getValueFromPOST('bino15NVLunit'),
								'VValue' => getValueFromPOST('bino15NVL'),
								]
						 ],
			],
			'18B_SUPRA' =>[
					'FAR'=>[
						'R' => [
								'HUnit'  => getValueFromPOST('bino16FHRunit'),
								'HValue'  => getValueFromPOST('bino16FHR'),
								'VUnit' => getValueFromPOST('bino16FVRunit'),
								'VValue' => getValueFromPOST('bino16FVR'),
								],
						'L' => [
								'HUnit'  => getValueFromPOST('bino16FHLunit'),
								'HValue'  => getValueFromPOST('bino16FHL'),
								'VUnit' => getValueFromPOST('bino16FVLunit'),
								'VValue' => getValueFromPOST('bino16FVL'),
								]
						 ],
					'NEAR'=>[
						'R' => [
								'HUnit'  => getValueFromPOST('bino16NHRunit'),
								'HValue'  => getValueFromPOST('bino16NHR'),
								'VUnit' => getValueFromPOST('bino16NVRunit'),
								'VValue' => getValueFromPOST('bino16NVR'),
								],
						'L' => [
								'HUnit'  => getValueFromPOST('bino16NHLunit'),
								'HValue'  => getValueFromPOST('bino16NHL'),
								'VUnit' => getValueFromPOST('bino16NVLunit'),
								'VValue' => getValueFromPOST('bino16NVL'),
								]
						 ],
			],
			'18B_INFRA' =>[
					'FAR'=>[
						'R' => [
								'HUnit'  => getValueFromPOST('bino17FHRunit'),
								'HValue'  => getValueFromPOST('bino17FHR'),
								'VUnit' => getValueFromPOST('bino17FVRunit'),
								'VValue' => getValueFromPOST('bino17FVR'),
								],
						'L' => [
								'HUnit'  => getValueFromPOST('bino17FHLunit'),
								'HValue'  => getValueFromPOST('bino17FHL'),
								'VUnit' => getValueFromPOST('bino17FVLunit'),
								'VValue' => getValueFromPOST('bino17FVL'),
								]
						 ],
					'NEAR'=>[
						'R' => [
								'HUnit'  => getValueFromPOST('bino17NHRunit'),
								'HValue'  => getValueFromPOST('bino17NHR'),
								'VUnit' => getValueFromPOST('bino17NVRunit'),
								'VValue' => getValueFromPOST('bino17NVR'),
								],
						'L' => [
								'HUnit'  => getValueFromPOST('bino17NHLunit'),
								'HValue'  => getValueFromPOST('bino17NHL'),
								'VUnit' => getValueFromPOST('bino17NVLunit'),
								'VValue' => getValueFromPOST('bino17NVL'),
								]
						 ],
			],
			]
		
	];

	// ウォース4点テスト
	$worth4DotsResult = getValueFromPOST('Worth4DotsResult');
	if (!empty($worth4DotsResult)) {
		$subjectiveJSON['subjective']['Worth4Dots'] = [
			'ExamDistance' => [
				'List' => [
					'1' => [ // 遠見
						'Distance' => [
							'unit' => 'mm',
							'value' => getValueFromPOST('ExamDistanceFar'),
						],
						'Result' => $worth4DotsResult,
					],
					'2' => [ // 近見
						'Distance' => [
							'unit' => 'mm',
							'value' => getValueFromPOST('ExamDistanceNear'),
						],
						'Result' => $worth4DotsResult,
					],
				],
			],
		];
	}
	
	$subjectiveJSON_String = json_encode($subjectiveJSON);
	return false !== \becky\file_put_contents_and_sync($subjectiveFilePath, $subjectiveJSON_String, LOCK_EX);
}	 	
