<?php
/*
 * ライブ像を表示する表示するページで使う
 */

require_once topDir() . 'defs/defData.php';

//$liveHttpUri['R'] = topUri() . 'img/right001.jpg';
//$liveHttpUri['L'] = topUri() . 'img/left001.jpg';
$liveProtocol = $_SERVER['REQUEST_SCHEME'];
$liveHost     = $_SERVER['HTTP_HOST'];
$livePort['R'] = 60002;
$livePort['L'] = 60001;
$liveHttpUri['R'] = $liveProtocol . '://' . $liveHost . ':' . $livePort['R'] . '/live.avi';
$liveHttpUri['L'] = $liveProtocol . '://' . $liveHost . ':' . $livePort['L'] . '/live.avi';

/*!
 * @brief LiveStreamServer の共有画像メモリの有効/無効の切り替え
 *
 * @param[in] bool $enable true: 有効, false: 無効
 * @return void
 */
function LiveStreamServer_setSharedImage($enable)
{
	global $liveProtocol;
	if (empty($liveProtocol)) {
		return;
	}

	$strEnable = $enable ? '1' : '0';
	$urlL = $liveProtocol . '://' . PrivateIpAdress::Left  . ':' . 60000 . '/setSharedImage.json?enable=' . $strEnable;
	$urlR = $liveProtocol . '://' . PrivateIpAdress::Right . ':' . 60000 . '/setSharedImage.json?enable=' . $strEnable;
	// とりあえず結果は取得しない
	@get_headers($urlL);
	@get_headers($urlR);
}
