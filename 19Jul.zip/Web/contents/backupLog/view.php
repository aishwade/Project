<?php
/*! @file
 * @brief ログのバックアップ画面の中身
 */

//require_once topDir() . 'contents/_head.php';
require_once topDir() . 'contents/backupLog/_head.php';

?>
<!DOCTYPE html>
<html>
	<head>
		<?php outputHeadContents(); ?>
		<title><?php echo _m('backupLog', 'title'); ?></title>
	</head>

	<body style="margin: 1em;">
		<div id="running" data-value="true" style="display: none;"></div>
		<h1><?php echo _m('backupLog', 'title'); ?></h1>
		<div>
			<input type="button" id="btnBackup" value="<?php echo _m('backupLog', 'backup'); ?>">
		</div>
		<div style="margin-top: 0.5em;">
			<textarea id="textareaMain" style="width: 100%; height: 40em;" readonly></textarea>
		</div>
	</body>
</html>
