<?php
/*! @file
 * @brief 工場設定画面の中身
 */

require_once topDir() . 'views/beckyControlType.php';
//require_once topDir() . 'contents/_head.php';
//require_once topDir() . 'contents/factoryConfig/factoryConfigCategoryType.php';
require_once topDir() . 'contents/factoryConfig/_head.php';
require_once topDir() . 'contents/factoryConfig/_viewLogic.php';
require_once topDir() . 'contents/factoryConfig/_factoryConfigUtil.php';

/*!
 * @brief 工場設定のすべての設定項目を定義
 */
$elements = [
	// コントロールタイプ               , 設定名称                              , デフォルト, 選択肢
	[ \becky\ControlType::EDIT_BOX      , 'diopterShift'                        , '0.00' ],
	[ \becky\ControlType::RADIO         , 'objectiveAlignmentMethod'            , 0, [ 'pupil', 'cornea' ] ],
	[ \becky\ControlType::CHECKBOX      , 'modelEyeAlignmentMode'               ,      0 ],
];

if (!empty($_POST['factoryConfig_register'])) {
	// 保存前にトリムする
	\ModelUtil\array_trim($_POST);

	if (doRegisterFactoryConfig($elements)) {
		header('Location: ' . topUri() . 'sub/factoryConfig.php');
		exit;
	}
} else {
	loadFactoryConfig($elements);
}

?>
<!DOCTYPE html>
<html>
	<head>
		<?php outputHeadContents(); ?>
		<title><?php echo _m('factoryConfig', 'title'); ?></title>
	</head>

	<body>
		<div id="main">
			<form id="factoryConfig_form" action="./factoryConfig.php" method="post">
				<button type="button" id="goBack"><?php echo _m('factoryConfig', 'goBack' ); ?></button>
				<button type="button" id="register"><?php echo _m('factoryConfig', 'save' ); ?></button>
				<div>
					<?php echo buildConfigTags($elements); ?>
				</div>
				<!-- 項目が一つしかない場合に、Enterキー押下で送信されてしまう対策 -->
				<input type="text" name="dummy" style="display:none;">
			</form>
		</div>
		<datalist id="listDiopterShift">
			<option value="0">
			<option value="0.375">
		</datalist>
	</body>
</html>
