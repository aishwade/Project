/*! @file
 * @brief becky の操作ログで具体的な処理
 */
"use strict";

// 名前空間
var becky = becky || {};
becky.operatorLog = becky.operatorLog || {};

/*!
 * @brief WebStorage の I/O キーを得る
 * 
 * @return string WebStorage の I/O キー
 */
becky.operatorLog.getWebStorageKey = function()
{
	return "operator.log";
}

/*!
 * @brief WebStorage の I/O オブジェクトを得る
 * 
 * @return object WebStorage の I/O オブジェクト
 */
becky.operatorLog.getWebStorageIO = function()
{
	return becky.WebStorage.local.IO(becky.operatorLog.getWebStorageKey());
}

/*!
 * @brief 端末のデータをサーバーに保存する
 * 非同期関数
 * 
 * @return Promise
 */
becky.operatorLog.serialize = async function()
{
	const webStorageIO = becky.operatorLog.getWebStorageIO();
	const json = webStorageIO.getJson();
	if (modelHelper.isNullOrEmpty(json)) {
		return;
	}
	// サーバー側に保存する
	try {
		await becky.async.ajax({
			url: "../ls/writeOperatorLog.php",
			type: "post",
			dataType: "json",
			data: JSON.stringify(json),
		});
		// 保存に成功したら端末から削除
		webStorageIO.removeItem();
	} catch (resultJson) {
		// 保存に失敗した場合は、次回まで保留
		// エラーメッセージ等は出さない
		becky.assertion.failure(becky.LeanStartup.getErrorMessage(resultJson));
	}
}

/*!
 * @brief 1サイクル分の記録を開始
 * 
 * @param[in] string aPatientID 患者ID
 * @param[in] Date aDateNow サイクルが開始した日付時間(未指定の場合、自動入力)
 * @return void
 */
becky.operatorLog.createOneCycleNode = function(aPatientID, aDateNow)
{
	if (modelHelper.isUndefined(aDateNow)) {
		aDateNow = new Date();
	}
	const webStorageIO = becky.operatorLog.getWebStorageIO();
	let json = webStorageIO.getJson();
	if (modelHelper.isNull(json)) {
		json = [];
	}
	{
		const operatorLogNode = becky.operatorLog.createBaseNode();
		operatorLogNode.date.first = aDateNow;
		operatorLogNode.name = "One cycle of eye examination";
		operatorLogNode.private.sessionDate = viewHelper.getStrDate(aDateNow, "");
		operatorLogNode.private.sessionTime = viewHelper.getStrTime(aDateNow, "");
		operatorLogNode.private.patientID   = aPatientID;
		becky.operatorLog.normalization(operatorLogNode);
		json.push(operatorLogNode);
	}
	webStorageIO.setJson(json);
}

/*!
 * @brief 他覚の計測データを生成
 *
 * @param[in] Date aDateNow 計測が開始した日付時間(未指定の場合、自動入力)
 * @return object
 */
becky.operatorLog.createObjectiveMeasurementNode = function(aDateNow)
{
	if (modelHelper.isUndefined(aDateNow)) {
		aDateNow = new Date();
	}
	const operatorLogMeasurementNode = becky.operatorLog.createBaseNode();
	operatorLogMeasurementNode.date.first = aDateNow;
	operatorLogMeasurementNode.name = "objective measurement";
	return operatorLogMeasurementNode;
}

/*!
 * @brief 他覚の計測データを追加する
 * 
 * @param[in] object aOperatorLogMeasurementNode 
 * @param[in] Date aDateNow 計測が終了した日付時間(未指定の場合、自動入力)
 * @return void
 */
becky.operatorLog.pushObjectiveMeasurementNode = function(aOperatorLogMeasurementNode, aDateNow)
{
	if (modelHelper.isUndefined(aDateNow)) {
		aDateNow = new Date();
	}
	const webStorageIO = becky.operatorLog.getWebStorageIO();
	const json = webStorageIO.getJson();
	const oneCycleJson = modelHelper.getLast(json);
	if (becky.assertion.isNull(oneCycleJson)) {
		// 被検者情報まで戻るべき
		return;
	}
	aOperatorLogMeasurementNode.date.last = aDateNow;
	becky.operatorLog.normalization(aOperatorLogMeasurementNode);
	oneCycleJson.children.push(aOperatorLogMeasurementNode);
	webStorageIO.setJson(json);
}

/*!
 * @brief 自覚のノードを生成
 * 
 * @return void
 */
becky.operatorLog.createSubjectiveNode = function()
{
	const webStorageIO = becky.operatorLog.getWebStorageIO();
	const json = webStorageIO.getJson();
	const oneCycleJson = modelHelper.getLast(json);
	if (becky.assertion.isNull(oneCycleJson)) {
		// 被検者情報まで戻るべき
		return;
	}
	const lastChild = modelHelper.getLast(oneCycleJson.children);
	const nodeName = "subjective";
	if (modelHelper.isNullOrEmpty(lastChild) ||
	    nodeName != lastChild.name) {
		// 追加先の自覚検査が無い場合のみ生成
		const operatorLogSubjectiveNode = becky.operatorLog.createBaseNode();
//		operatorLogSubjectiveNode.date.first = new Date();
		operatorLogSubjectiveNode.name = nodeName;
//		becky.operatorLog.normalization(operatorLogSubjectiveNode);
		oneCycleJson.children.push(operatorLogSubjectiveNode);
		webStorageIO.setJson(json);
	}
}

/*!
 * @brief 自覚のコマンドノードを追加する
 * 
 * @param[in] array aOperatorLogCommandNodes 
 * @return void
 */
becky.operatorLog.pushSubjectiveCommandNodes = function(aOperatorLogCommandNodes)
{
	const webStorageIO = becky.operatorLog.getWebStorageIO();
	const json = webStorageIO.getJson();
	const oneCycleJson = modelHelper.getLast(json);
	if (becky.assertion.isNull(oneCycleJson)) {
		return;
	}
	const subjectiveJson = modelHelper.getLast(oneCycleJson.children);
	subjectiveJson.children.push(...aOperatorLogCommandNodes);
	becky.operatorLog.buildDateRecursively(subjectiveJson);
	becky.operatorLog.normalization       (subjectiveJson);
	webStorageIO.setJson(json);
}

/*!
 * @brief 1サイクル分の記録を閉じる
 * 
 * @param[in] Date aDateNow サイクルが閉じた日付時間(未指定の場合、自動入力)
 * @return void
 */
becky.operatorLog.closeOneCycleNode = function(aDateNow)
{
	if (modelHelper.isUndefined(aDateNow)) {
		aDateNow = new Date();
	}
	const webStorageIO = becky.operatorLog.getWebStorageIO();
	const json = webStorageIO.getJson();
	const oneCycleJson = modelHelper.getLast(json);
	if (becky.assertion.isNull(oneCycleJson)) {
		return;
	}
	oneCycleJson.date.last = aDateNow;
	becky.operatorLog.buildDateRecursively(oneCycleJson);
	becky.operatorLog.normalization       (oneCycleJson);
	becky.operatorLog.removeEmptyField    (oneCycleJson);
	webStorageIO.setJson(json);
}