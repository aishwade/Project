$(document).ready(function(){
	
	$('.tabs div').click(function(){
		var tab_id = $(this).attr('data-tab');

		$('.tabs div').removeClass('current');
		$('.tab-content').removeClass('current');

		$(this).addClass('current');
		$("#"+tab_id).addClass('current');
	})

});
$("option").mouseover(function(){
  $("option").css("background-color", "yellow");
});