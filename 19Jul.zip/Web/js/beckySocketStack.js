/*! @file
 * @brief becky のソケットI/F関数郡(スタック機能)
 *
 * 以下の条件を満たすコマンドで使用可能
 * ・同種のコマンドを、結果を受け取る前に連続して呼び出す事ができる
 * ・コマンドが成功した場合、過去の失敗については問わない上書きタイプ
 */
"use strict";

// 名前空間
var becky = becky || {};
becky.Socket = becky.Socket || {};
becky.Socket.stack = becky.Socket.stack || {};

/*!
 * @brief スタックを開始する
 *
 * @return スタック オブジェクト
 */
becky.Socket.stack.begin = function()
{
	return {
		resultWaitCount :  0,
		arrayPostHist   : [],
	};
}

/*!
 * @brief スタックを終了する
 *
 * @param[in,out] array aStack スタック オブジェクト
 */
becky.Socket.stack.end = function(aStack)
{
	becky.Socket.stack.cleanup(aStack);
}

/*!
 * @brief 成功/失敗/完了時に呼び出す Deferred を登録する
 *
 * @param[in,out] array aStack スタック オブジェクト
 * @param[in,out] object aDeferred Deferred オブジェクト
 * @return object 送信履歴用データ
 */
becky.Socket.stack.addDeferred = function(aStack, aDeferred)
{
	const postHist = {
		isFailed   : null,
		deferred   : aDeferred,
		resultJson : null,
	};
	aStack.arrayPostHist.push(postHist);
	return postHist;
}

/*!
 * スタックのクリーンナップ関数
 * 結果待ちが存在する場合は処理をスキップする
 *
 * @param[in,out] array aStack スタック オブジェクト
 */
becky.Socket.stack.cleanup = function(aStack)
{
	if (0 < aStack.resultWaitCount) {
		return;
	}

	if (modelHelper.isNullOrEmpty(aStack.arrayPostHist)) {
		return;
	}

	// 成功呼び出し
	// 最後にコマンドが成功した Deferred.resolve を呼ぶ
	aStack.arrayPostHist.forEach(postHist => {
		becky.assertion.assert(!modelHelper.isNull(postHist.isFailed), "null postHist.isFailed");
		if (postHist.isFailed) {
			return;
		}
		postHist.deferred.resolve(postHist.resultJson);
	});
	// 失敗呼び出し
	// 新しいものから過去へ遡り Deferred.reject を呼ぶ
	// (ただしコマンドが失敗していなければ、そこで走査を打ち切る)
	aStack.arrayPostHist.reverse().some(postHist => {
		becky.assertion.assert(!modelHelper.isNull(postHist.isFailed), "null postHist.isFailed");
		if (!postHist.isFailed) {
			// 失敗していない場合はそこで止める
			return true;
		}
		postHist.deferred.reject(postHist.resultJson);
		return false;
	});

	aStack.arrayPostHist = [];
}

/*!
 * @brief スタックの開始/終了のスコープ
 * ヘルパー関数
 *
 * @param[in] function aFuncExecute スコープ内で実行したい事
 */
becky.Socket.stack.scope = function(aFuncExecute)
{
	const transaction = becky.Socket.stack.begin();
	aFuncExecute(transaction);
	becky.Socket.stack.end(transaction);
}

/*!
 * @brief becky のソケットにJSONデータをポストする
 * 非同期関数
 *
 * @param[in] array aStack スタック オブジェクト
 * @param[in] array aJson 送信したいJSONデータ
 * @return Promise
 */
becky.Socket.stack.post = async function(aStack, aJson)
{
	return new Promise((resolve, reject) => {
		// 呼び出し順通りに Deferred を登録していく
		const postHist = becky.Socket.stack.addDeferred(aStack, { resolve: resolve, reject: reject });

		++aStack.resultWaitCount;
		becky.Socket.post(aJson).then(aResultJson => {
			postHist.isFailed   = false;
			postHist.resultJson = aResultJson;
		}).catch(aResultJson => {
			postHist.isFailed   = true;
			postHist.resultJson = aResultJson;
		}).then(() => {
			becky.assertion.assert(0 < aStack.resultWaitCount, "Fault aStack.resultWaitCount");
			--aStack.resultWaitCount;
			becky.Socket.stack.cleanup(aStack);
		});
	});
}
