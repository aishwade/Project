/*! @file
 * @brief ログのバックアップ画面で使用するスクリプト
 */

// 即時関数を使って閉じ込める
(function(){
"use strict";

//! @brief (受信済み)標準出力のデータ長
let _latestStdoutLength = 0;

/*!
 * @brief サーバ側で実行するコマンド(Ajax)
 *
 * @param[in] string aCommand コマンド名
 * @param[in] string aOffset オフセット値
 */
async function _commandAjax(aCommand, aOffset)
{
	const datas = {
		command: aCommand,
	};
	if (!modelHelper.isUndefined(aOffset)) {
		datas.offset = aOffset;
	}
	const json = await becky.async.ajax({
		url: "../ls/_backupLog.php",
		data: datas,
		type: "POST",
		cache: false,
	});
	if (becky.LeanStartup.isFailedJson(json)) {
		throw json;
	}
	return json;
}

/*!
 * @brief 進捗を更新
 */
async function _updateProgress()
{
	const $textareaMain = $("#textareaMain");
	try
	{
		const json = await _commandAjax("progress", _latestStdoutLength);
		$("#running").attr("data-value", json.running);
		if (modelHelper.isNullOrEmpty(json.stdout)) {
			return;
		}
		_latestStdoutLength += json.stdout.length;
		$textareaMain.val($textareaMain.val() + json.stdout);
		// 最下部へスクロール
		$textareaMain.scrollTop($textareaMain[0].scrollHeight);
	} catch (resultJson) {
		try {
			becky.assertion.failure(resultJson.error.message);
		} catch (ex) {
			modelHelper.catchExceptionByUndefined(ex);
		}
	}
}

/*!
 * @brief 定期的に進捗を更新
 */
function _intervalProgress()
{
	let bContacting = false;
	asyncHelper.interval(3000, async () => {
		if (bContacting) return;
		bContacting = true;
		await _updateProgress();
		bContacting = false;
	});
}

/*!
 * @brief バックアップを実行
 */
async function _doBackup()
{
	const $textareaMain = $("#textareaMain");
	let line = null;
	try
	{
		_latestStdoutLength = 0;
		$("#running").attr("data-value", true);
		await _commandAjax("backup");
	} catch (resultJson) {
		try {
			line = resultJson.error.message;
		} catch (ex) {
			modelHelper.catchExceptionByUndefined(ex);
		}
	}
	if (modelHelper.isNullOrEmpty(line)) {
		return;
	}
	$textareaMain.val($textareaMain.val() + line + "\n");
}

$(document).ready(function(){

	// data-text 属性を監視するオプション(MutationObserverInit)
	const optionsAttributeFilterDataValue = {
		attributes: true,
		attributeFilter: [ "data-value" ],
	};

	// バックアップ中にページを抜けた可能性もあるので、
	// バックアップが走っていないかを確認する
	_updateProgress();
	_intervalProgress();

	$("#btnBackup").click(function(){
		_doBackup();
	});

	becky.MutationObserver.byID("running",
		records => records.forEach(record_ => {
			const target = record_.target;
			const value = target.dataset.value;
			const bVal = modelHelper.toBoolean(value);
			$("#btnBackup").prop('disabled', bVal);
		}),
		optionsAttributeFilterDataValue);
	// 変更イベントを呼ぶ(初期化)
	becky.dataSync.callChangeEventAttr(document.getElementById("running"), "data-value");
});

}());//即時関数の終端
