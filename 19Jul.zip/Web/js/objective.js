/*! @file
 * @brief 他覚で使用するスクリプト
 *
 * 依存するもの
 * - viewHelper.js
 * - ajaxHelper.js
 * - beckyMutationObserver.js
 * - beckyDataSync.js
 * - beckyAsyncAjax.js
 * - beckyLeanStartupAjax.js
 * - beckyScopedStyle.js
 */

// 即時関数を使って閉じ込める
(function(){
"use strict";

//! 最後に計測した objective.refraction.json
let _latestObjectiveRefractionJson = null;

/*!
 * @brief 最後の計測値をクリアする
 *
 * @return void
 */
function _clearLatestObjectiveRefractionJson()
{
	_latestObjectiveRefractionJson = null;
}

/*!
 * @brief 最後の計測値(objective.refraction.json)を得る
 * 初回やクリア直後の場合、測定値が入っていないデータを返す
 *
 * @return object objective.refraction.json コピーではなく参照を返すので意識する
 */
function _getLatestObjectiveRefractionJson()
{
	if (modelHelper.isNull(_latestObjectiveRefractionJson)) {
		_latestObjectiveRefractionJson = _createObjectiveRefractionJson();
	}
	return _latestObjectiveRefractionJson;
}

/*!
 * @brief コマンド呼び出しイベントの排他制御オブジェクト
 * 開始:begin(), 終了:end()
 *
 * @return becky.scopedStyle.css
 */
function _getPointerEventsByCommand()
{
	const selectors = [
		"#btnSetting" , // 設定
		"#btnNaviNext", // 次へ
		"#btnStart", // 計測開始
		"#btnFixationLevel", // 固視
		"#imgHeadU", // ヘッド上移動
		"#imgHeadD", // ヘッド下移動
		"[id^=btnControllerEye]", // 計測対象の眼の選択
	];
	//becky.debug.scope(() => {
	//	selectors.forEach(selector_ => {
	//		becky.assertion.assert(!modelHelper.isNullOrEmpty($(selector_)));
	//	});
	//});
	const $target = $(selectors.join(","));
	return becky.scopedStyle.css($target, "pointer-events", "none", "auto");
}

/*!
 * @brief 配列の文字列をトグルした値を返す
 *
 * @param[in] string aVal 対象の値
 * @param[in] array aDefs 定義文字列郡
 * @return string 対象をトグルした値
 */
function _toggleVal_Base(aVal, aDefs)
{
	if (becky.assertion.isNullOrEmpty(aDefs)) {
		return;
	}
	becky.assertion.assert(2 === aDefs.length, "2 === aDefs.length");
	const index = aDefs.indexOf(aVal);
	becky.assertion.assert(0 <= index, "_toggleVal_Base");
	const toggledIndex = 0 !== index ? 0 : 1;
	return aDefs[toggledIndex];
}

/*!
 * @brief 論理型文字列をトグルした値を返す
 *
 * @param[in] string aVal 対象の値
 * @return string 対象をトグルした値
 */
function _toggleVal_Boolean(aVal)
{
	return _toggleVal_Base(aVal, ["false", "true"]);
}

/*!
 * @brief 文字を大きくするスタイルを適用
 *
 * @param[in,out] element $label 対象
 */
function _toTextLarge($label)
{
	$label.removeClass("txt-small").addClass("txt-large");
}

/*!
 * @brief 文字を小さくするスタイルを適用
 *
 * @param[in,out] element $label 対象
 */
function _toTextSmall($label)
{
	$label.removeClass("txt-large").addClass("txt-small");
}

/*!
 * @brief 選択されている眼を得る
 *
 * @retval "R" 右眼が選択されている
 * @retval "L" 左眼が選択されている
 * @retval "B" 両眼が選択されている
 */
function _getSelectEye()
{
	return $("#currentEye").attr("data-value");
}

/*!
 * @brief 右眼が選択されているか？
 *
 * @retval true  右眼が選択されている(両眼選択を含む)
 * @retval false 右眼は選択されていない
 */
function _isSelectEyeR()
{
	const eyeValue = _getSelectEye();
	switch (eyeValue) {
		case "R":
			return true;
		case "L":
			return false;
		case "B":
			return true;
		default:
			becky.assertion.failure("unknown eye");
			return false;
	}
}

/*!
 * @brief 左眼が選択されているか？
 *
 * @retval true  左眼が選択されている(両眼選択を含む)
 * @retval false 左眼は選択されていない
 */
function _isSelectEyeL()
{
	const eyeValue = _getSelectEye();
	switch (eyeValue) {
		case "R":
			return false;
		case "L":
			return true;
		case "B":
			return true;
		default:
			becky.assertion.failure("unknown eye");
			return false;
	}
}

/*!
 * @brief 両眼が選択されているか？
 *
 * @retval true  両眼が選択されている
 * @retval false 両眼は選択されていない
 */
function _isSelectEyeB()
{
	const eyeValue = _getSelectEye();
	switch (eyeValue) {
		case "R":
			return false;
		case "L":
			return false;
		case "B":
			return true;
		default:
			becky.assertion.failure("unknown eye");
			return false;
	}
}

/*!
 * @brief 左右両眼を選択状態にする
 * Model を更新
 *
 * @param[in] string aVal 選択対象
 */
function _setSelectEye(aVal)
{
	switch (aVal) {
		case "B":
		case "R":
		case "L":
			break;
		default:
			becky.assertion.failure("unknown eye");
			return;
	}
	$("#currentEye").attr("data-value", aVal);
}

/*!
 * @brief CataractMode をトグルした値を返す
 *
 * @param[in] string aVal 対象の値
 * @return string 対象をトグルした値
 */
function _toggleVal_CataractMode(aVal)
{
	return _toggleVal_Boolean(aVal);
}

/*!
 * @brief CataractMode のラベルを更新する
 *
 * @param[in] Node aRecordTarget 対象のレコード
 */
function _updateLblCataractMode(aRecordTarget)
{
	const valBool = modelHelper.toBoolean(aRecordTarget.value);
	if (valBool) {
		aRecordTarget.classList.add("active");
	} else {
		aRecordTarget.classList.remove("active");
	}
}

/*!
 * @brief H/L をトグルした値を返す
 *
 * @param[in] string aVal 対象の値
 * @return string 対象をトグルした値
 */
function _toggleVal_FixationLevel(aVal)
{
	return _toggleVal_Base(aVal, ["Low", "High"]);
}

/*!
 * @brief H/L のラベルを更新する
 *
 * @param[in] Node aRecordTarget 対象のレコード
 */
function _updateLblFixationLevel(aRecordTarget)
{
	const val = aRecordTarget.value;
	const toggleVal = _toggleVal_FixationLevel(val);
	_toTextLarge($("#labelFixationLevel" + val      ));
	_toTextSmall($("#labelFixationLevel" + toggleVal));
}

/*!
 * @brief A/M をトグルした値を返す
 *
 * @param[in] string aVal 対象の値
 * @return string 対象をトグルした値
 */
function _toggleVal_AM(aVal)
{
	return _toggleVal_Base(aVal, ["A", "M"]);
}

/*!
 * @brief A/M のラベルを更新する
 *
 * @param[in] Node aRecordTarget 対象のレコード
 */
function _updateLblAlignmentMode(aRecordTarget)
{
	const val = aRecordTarget.value;
	const toggleVal = _toggleVal_AM(val);
	_toTextLarge($("#label" + val      ));
	_toTextSmall($("#label" + toggleVal));
}

/*!
 * @brief FogTiming をトグルした値を返す
 *
 * @param[in] string aVal 対象の値
 * @return string 対象をトグルした値
 */
function _toggleVal_FogTiming(aVal)
{
	return _toggleVal_Base(aVal, ["once", "everyTime"]);
}

/*!
 * @brief FogTiming のラベルを更新する
 *
 * @param[in] Node aRecordTarget 対象のレコード
 */
function _updateLblFogTiming(aRecordTarget)
{
	const val = aRecordTarget.value;
	let html = "";
	switch (val) {
		case "once":
			html = '<span class="icon icon-03"></span>x1';
			break;
		case "everyTime":
			// 素直に画像を用意した方が良いのかも
			html += '<span class="icon icon-03" style="filter: drop-shadow(-2px 2px 4px black); left: 12px;"></span>';
			html += '<span class="icon icon-03" style="filter: drop-shadow(-2px 2px 4px black);"></span>';
			html += '<span class="icon icon-03" style="filter: drop-shadow(-2px 2px 4px black); left: -12px;"></span>';
			break;
		default:
			becky.assertion.failure("_updateLblFogTiming switch(aVal)");
			break;
	}
	$("#labelFogTiming").html(html);
}

/*!
 * @brief 撮影の結果JSONのメッセージハンドラ
 * データ受信のたびに呼び出される
 *
 * @param[in] array aResultJson 結果JSON
 */
function _onMessageResultJsonByCapture(aResultJson)
{
}

/*!
 * @brief 計測の一連のコマンドを送信する
 *
 * @param[in] bool aIsModelEyeAlignmentMode 模型眼アライメントモード
 * @return Promise
 */
async function _postMeasurementCommand(aIsModelEyeAlignmentMode)
{
	let postPos/* = ""*/;
	if (!_isSelectEyeB()) {
		// 両眼以外なら、コマンド送信は片眼のみ
		postPos = _getSelectEye();
	}

	const resetOptParamCleanupLR = {};
	const operatorLogMeasurementNode = becky.operatorLog.createObjectiveMeasurementNode();

	try {
		const resetOptParamStartLR = {
			LED: {
				Fixation: becky.WebStorage.objectiveLEDfixation.getValue(),
			},
			Rotary: true,
		};
		await becky.LeanStartup.post("ResetOpt", {
			L: resetOptParamStartLR,
			R: resetOptParamStartLR,
		}, postPos);
		resetOptParamCleanupLR.TF     = true; // 最初の ResetOpt が成功したら、クリーンナップ時に TF を true にする
		resetOptParamCleanupLR.Rotary = false;

		const alignmentJson = {
			RangeXY: 0.2,
			RangeZ : 0.375,
		};

		const objectiveAlignmentMethod = becky.settingJson.factory.objectiveAlignmentMethod;
		if (!modelHelper.isUndefined(objectiveAlignmentMethod)) {
			// 時期によって存在しない事がある
			alignmentJson.CorneaDetection = "cornea" === objectiveAlignmentMethod;
		}

		const commandAlignment = aIsModelEyeAlignmentMode ?
			"ChronosAlignment2ModelEye" : "ChronosAlignment2";
		let resultAlignmentJson = null;
		{
			const dateNow = new Date();
			alignmentJson.infoForLog = becky.log.createCommandParamInfoForLog(dateNow);
			resultAlignmentJson = await becky.LeanStartup.postWithOperatorLog(commandAlignment,
				alignmentJson, postPos, dateNow, operatorLogMeasurementNode.children);
		}

		const resetOptParamOpticalPathLR = {
			OpticalPath: true,
		};
		await becky.LeanStartup.post("ResetOpt", {
			L: resetOptParamOpticalPathLR,
			R: resetOptParamOpticalPathLR,
		}, postPos);
		resetOptParamCleanupLR.OpticalPath = false;

		{
			const dateNow = new Date();
			await becky.LeanStartup.postWithOperatorLog("ChronosRef2", {
				RoughMeasure: true,
				infoForLog: becky.log.createCommandParamInfoForLog(dateNow),
			}, postPos, dateNow, operatorLogMeasurementNode.children);
		}

		{
			const dateNow = new Date();
			alignmentJson.infoForLog = becky.log.createCommandParamInfoForLog(dateNow);
			await becky.LeanStartup.postWithOperatorLog(commandAlignment,
				alignmentJson, postPos, dateNow, operatorLogMeasurementNode.children);
		}

		let resultRefJson = null;
		{
			const dateNow = new Date();
			resultRefJson = await becky.LeanStartup.postWithOperatorLog("ChronosRef2", {
				RoughMeasure: false,
				DiopterShift: parseFloat(becky.settingJson.factory.diopterShift),
				infoForLog: becky.log.createCommandParamInfoForLog(dateNow),
			}, postPos, dateNow, operatorLogMeasurementNode.children);
		}

		// 自覚で使用する他覚データを保存
		await _updateObjectiveRefractionJsonTempFile(resultAlignmentJson, resultRefJson);

		const func_getValue = item_ => {
			if (    modelHelper.isUndefined(item_.error) ||
			    becky.assertion.isUndefined(item_.error.message)) {
				return item_.value;
			} else {
				return item_.error.message;
			}
		};
		let pdValue/* = 0*/;
		try {
			pdValue = resultAlignmentJson.L.HPD.value + resultAlignmentJson.R.HPD.value;
		} catch (ex) {
			// HPD が上手く処理できない
			modelHelper.catchExceptionByUndefined(ex);
			pdValue = "ERR";
		}
		const newJson = {
			PD: pdValue,
		};
		["L", "R"].forEach(pos => {
			if (modelHelper.isUndefined(resultRefJson[pos])) {
				// 片眼計測ではありえる
				return;
			}
			if (!becky.assertion.isUndefined(resultRefJson[pos].Median)) {
				// 代表値
				newJson["Sph" + pos] = func_getValue(resultRefJson[pos].Median.Sphere  );
				newJson["Cyl" + pos] = func_getValue(resultRefJson[pos].Median.Cylinder);
				newJson["Axs" + pos] = func_getValue(resultRefJson[pos].Median.Axis    );
			}
			if (!becky.assertion.isUndefined(resultRefJson[pos].Records)) {
				// n回目
				resultRefJson[pos].Records.forEach((record, index) => {
					const no = index + 1;
					newJson["Sph" + pos + no] = func_getValue(record.Sphere  );
					newJson["Cyl" + pos + no] = func_getValue(record.Cylinder);
					newJson["Axs" + pos + no] = func_getValue(record.Axis    );
				});
			}
		});
		_updateDataMeasurementValue(newJson);
	} finally {
		// 操作ログ
		becky.operatorLog.pushObjectiveMeasurementNode(operatorLogMeasurementNode);
		// クリーンナップ
		if (!modelHelper.isNullOrEmpty(resetOptParamCleanupLR)) {
			await becky.LeanStartup.post("ResetOpt", {
				L: resetOptParamCleanupLR,
				R: resetOptParamCleanupLR,
			}, postPos);
		}
	}
}

/*!
 * @brief 計測値が含まれていない objective.refraction.json を生成する
 *
 * @return object
 */
function _createObjectiveRefractionJson()
{
	return {
		refraction: {
			VD: {
				unit: "mm",
				value: 0,
			},
			R: {
				List: {
					1: {},
					2: {},
					3: {},
				},
				Median: {},
			},
			L: {
				List: {
					1: {},
					2: {},
					3: {},
				},
				Median: {},
			},
		},
		PD: {
			Distance: {},
		},
	};
}

/*!
 * @brief ChronosRef2 の結果を元に objective.refraction.json ファイルの更新を行う
 * 最後の計測値と合成する
 *
 * @param[in] array aResultAlignment2Json ChronosAlignment2の結果JSON
 * @param[in] array aResultRef2Json ChronosRef2の結果JSON
 */
async function _updateObjectiveRefractionJsonTempFile(aResultAlignment2Json, aResultRef2Json)
{
	const fileName = "objective.refraction.json";
	const latestObjectiveRefractionJson = _getLatestObjectiveRefractionJson();

	let targetEye = "";
	const eyeValue = _getSelectEye();
	switch (eyeValue) {
		case "R":
		case "L":
			targetEye = eyeValue;
			break;
		case "B":
			targetEye = "Bino";
			break;
		default:
			becky.assertion.failure("unknown eye");
			break;
	}

	["L", "R"].forEach(pos => {
		if (modelHelper.isUndefined(aResultRef2Json[pos])) {
			// 片眼計測ではありえる
			return;
		}
		if (!becky.assertion.isUndefined(aResultRef2Json[pos].Median)) {
			// 代表値
			latestObjectiveRefractionJson.refraction[pos].Median = aResultRef2Json[pos].Median;
		}
		if (!becky.assertion.isUndefined(aResultRef2Json[pos].Records)) {
			// n回目
			aResultRef2Json[pos].Records.forEach((record, index) => {
				latestObjectiveRefractionJson.refraction[pos].List[index + 1] = record;
			});
		}
		// 計測時に対象となった眼
		latestObjectiveRefractionJson.refraction[pos].TargetEye = targetEye;
	});

	latestObjectiveRefractionJson.refraction.VD.value = becky.settingJson.objective.vd;

	try {
		becky.assertion.assert("mm" === aResultAlignment2Json.L.HPD.unit, '"mm" !== L.HPD.unit');
		becky.assertion.assert(aResultAlignment2Json.L.HPD.unit === aResultAlignment2Json.R.HPD.unit, "L.HPD.unit !== R.HPD.unit");
		latestObjectiveRefractionJson.PD.Distance.value = aResultAlignment2Json.L.HPD.value + aResultAlignment2Json.R.HPD.value;
		latestObjectiveRefractionJson.PD.Distance.unit  = aResultAlignment2Json.L.HPD.unit;
	} catch (ex) {
		// HPD が上手く処理できない
		modelHelper.catchExceptionByUndefined(ex);
		latestObjectiveRefractionJson.PD.Distance.value = 0;
		latestObjectiveRefractionJson.PD.Distance.unit  = "";
	}

	// データの正規化
	becky.jsonHelper.normalization(latestObjectiveRefractionJson);

	{
		const requestJson = {
			fileName: fileName,
			json: latestObjectiveRefractionJson,
			backupSuffix: ".His", // 同名のファイルが存在する場合、末尾に時分秒を付加する
		};
		await becky.async.ajax({
			url     : "../ls/writeJsonTemp.php",
			type    : "post",
			dataType: "json",
			data    : JSON.stringify(requestJson),
		});
	}
}

/*!
 * @brief ボタンクリック時に背景を変更する
 *
 * @param[in] element $btn 対象のボタン
 */
function _buttonClickBackGroundOverlay($btn)
{
	if (becky.assertion.isNullOrEmpty($btn)) {
		return;
	}

	viewHelper.eventRegistrationTouchDownUp($btn,
		function(){ $(this).addClass   ("active"); },
		function(){ $(this).removeClass("active"); });
}

/*!
 * @brief 計測データをクリアする(UI)
 *
 * @param[in] string aEye クリア対象の眼(無指定の場合、左右両方)
 * @return void
 */
function _updateDataMeasurementValueClear(aEye)
{
	if (modelHelper.isUndefined(aEye)) {
		aEye = "B";
	}

	let targets = null;
	switch (aEye) {
		case "R":
		case "L":
			targets = [aEye];
			break;
		case "B":
			targets = ["L", "R"];
			break;
		default:
			becky.assertion.failure("unknown eye");
			return false;
	}

	const newVal = {
		PD: 65,
	};
	targets.forEach(pos => {
		newVal["Sph" + pos] = "";
		newVal["Cyl" + pos] = "";
		newVal["Axs" + pos] = "";
		[1, 2, 3].forEach(no => {
			newVal["Sph" + pos + no] = "";
			newVal["Cyl" + pos + no] = "";
			newVal["Axs" + pos + no] = "";
		});
	});
	// UI に反映
	_updateDataMeasurementValue(newVal);
}

/*!
 * @brief 計測データ・画面状態を WebStorage(Web browser) に保存
 * リロード対策
 *
 * @return void
 */
function _saveDataToWebStorage()
{
	becky.WebStorage.local.setJson("objective.update.data", _updateData());
}

/*!
 * @brief 更新(計測データ)
 *
 * @param[in] object aModel 引数が未指定:View→Model, 引数有り:Model→View
 * @return object 戻り値が存在するのは View→Model のみ
 */
function _updateDataMeasurementValue(aModel)
{
	// 属性の入出力
	const jQattrIO = (id_, key_, val_) => {
		if (modelHelper.isUndefined(val_)) {
			// get
			return $(id_).attr(key_);
		} else {
			// set
			$(id_).attr(key_, val_);
		}
	};
	const jQattrDataText  = (id_, val_) => jQattrIO(id_, "data-text" , val_);

	const update = {
		PD   : val_ => jQattrDataText("#labelPD"   , val_),
		VD   : val_ => jQattrDataText("#labelVD"   , val_),
		// 代表値
		SphL : val_ => jQattrDataText("#labelSphL" , val_),
		SphR : val_ => jQattrDataText("#labelSphR" , val_),
		CylL : val_ => jQattrDataText("#labelCylL" , val_),
		CylR : val_ => jQattrDataText("#labelCylR" , val_),
		AxsL : val_ => jQattrDataText("#labelAxsL" , val_),
		AxsR : val_ => jQattrDataText("#labelAxsR" , val_),
		// n回目
		SphL1: val_ => jQattrDataText("#labelSphL1", val_),
		SphL2: val_ => jQattrDataText("#labelSphL2", val_),
		SphL3: val_ => jQattrDataText("#labelSphL3", val_),
		SphR1: val_ => jQattrDataText("#labelSphR1", val_),
		SphR2: val_ => jQattrDataText("#labelSphR2", val_),
		SphR3: val_ => jQattrDataText("#labelSphR3", val_),
		CylL1: val_ => jQattrDataText("#labelCylL1", val_),
		CylL2: val_ => jQattrDataText("#labelCylL2", val_),
		CylL3: val_ => jQattrDataText("#labelCylL3", val_),
		CylR1: val_ => jQattrDataText("#labelCylR1", val_),
		CylR2: val_ => jQattrDataText("#labelCylR2", val_),
		CylR3: val_ => jQattrDataText("#labelCylR3", val_),
		AxsL1: val_ => jQattrDataText("#labelAxsL1", val_),
		AxsL2: val_ => jQattrDataText("#labelAxsL2", val_),
		AxsL3: val_ => jQattrDataText("#labelAxsL3", val_),
		AxsR1: val_ => jQattrDataText("#labelAxsR1", val_),
		AxsR2: val_ => jQattrDataText("#labelAxsR2", val_),
		AxsR3: val_ => jQattrDataText("#labelAxsR3", val_),
	};
	if (modelHelper.isUndefined(aModel)) {
		// View -> Model
		const json = {};
		Object.getOwnPropertyNames(update).forEach(name_ => {
			json[name_] = update[name_]();
		});
		// データの正規化
		becky.jsonHelper.normalization(json);
		return json;
	} else {
		// Model -> View
		Object.getOwnPropertyNames(update).forEach(name_ => {
			update[name_](aModel[name_]);
		});
	}
}

/*!
 * @brief 更新(画面の状態)
 *
 * @param[in] object aModel 引数が未指定:View→Model, 引数有り:Model→View
 * @return object 戻り値が存在するのは View→Model のみ
 */
function _updateDataScreenState(aModel)
{
	const jQval = (id_, val_) => {
		if (modelHelper.isUndefined(val_)) {
			// get
			return $(id_).val();
		} else {
			// set
			$(id_).val(val_);
		}
	};
	// 属性の入出力
	const jQattrIO = (id_, key_, val_) => {
		if (modelHelper.isUndefined(val_)) {
			// get
			return $(id_).attr(key_);
		} else {
			// set
			$(id_).attr(key_, val_);
		}
	};
	const jQattrDataValue = (id_, val_) => jQattrIO(id_, "data-value", val_);
	const update = {
		FixationLevel: val_ => jQval("#btnFixationLevel", val_),
		FogTiming    : val_ => jQval("#btnFogTiming"    , val_),
		CataractModeL: val_ => jQval("#btnCataractModeL", val_),
		CataractModeR: val_ => jQval("#btnCataractModeR", val_),
		currentEye   : val_ => jQattrDataValue("#currentEye", val_),
	};
	if (modelHelper.isUndefined(aModel)) {
		// View -> Model
		const json = {};
		Object.getOwnPropertyNames(update).forEach(name_ => {
			json[name_] = update[name_]();
		});
		return json;
	} else {
		// Model -> View
		Object.getOwnPropertyNames(update).forEach(name_ => {
			update[name_](aModel[name_]);
		});
	}
}

/*!
 * @brief 更新(全て)
 *
 * @param[in] object aModel 引数が未指定:View→Model, 引数有り:Model→View
 * @return object 戻り値が存在するのは View→Model のみ
 */
function _updateData(aModel)
{
	if (modelHelper.isUndefined(aModel)) {
		// View -> Model
		return {
			sessionPatientID: becky.session.sessionPatientID,
		    measurementValue: _updateDataMeasurementValue(),
		    screenState     : _updateDataScreenState     (),
		};
	} else {
		// Model -> View
		_updateDataMeasurementValue(aModel.measurementValue);
		_updateDataScreenState     (aModel.screenState     );
	}
}

$(document).ready(function(){

	// 端末に一時保存されているものがあれば復元
	{
		const updateDataJson = becky.WebStorage.local.getJson("objective.update.data");
		if (!modelHelper.isNullOrEmpty(updateDataJson) &&
		    becky.session.sessionPatientID === updateDataJson.sessionPatientID) {
			_updateData(updateDataJson);
		}
	}

	// data-text 属性を監視するオプション(MutationObserverInit)
	const optionsAttributeFilterDataValue = {
		attributes: true,
		attributeFilter: [ "data-value" ],
	};

	// 次へ遷移可能
	becky.navi.showNext();

	// value 属性を監視するオプション(MutationObserverInit)
	const optionsAttributeFilterValue = {
		attributes: true,
		attributeFilter: [ "value" ],
	};

	// クリック時にカレントの切り替えを行う
	// TODO. 必要になったタイミングで以下を有効化する
	//$(".current").parent().children().click(function(){
	//	viewHelper.selectClassSingle("current", $(this));
	//});

	// 模型眼アライメントモード
	const isModelEyeAlignmentMode = becky.WebStorage.modelEyeAlignmentMode.getValue();
	if (isModelEyeAlignmentMode) {
		const title = viewHelper.getDefMessage("factoryConfig/modelEyeAlignmentMode");
		const $txtEyeTitle = $("[class=txt-eye-title]");
		$txtEyeTitle.text(title);
		asyncHelper.interval(1500, () => {
			$txtEyeTitle.toggle();
		});
	}

	// Live像の領域
	$(".eye-box").click(function(e){
		// 座標をコンソールに出力
		console.log("offset=" + e.offsetX + "," + e.offsetY);
	});
	// CATモード
	const selectorCataractMode = "[id^=btnCataractMode]";
	const $selectorCataractMode = $(selectorCataractMode);
	//becky.MutationObserver.bySelectorAll(
	//	selectorCataractMode,
	//	records => records.forEach(record_ => _updateLblCataractMode(record_.target)),
	//	optionsAttributeFilterValue);
	//$selectorCataractMode.click(function(){
	//	const $btn = $(this);
	//	const val = $btn.val();
	//	const newVal = _toggleVal_CataractMode(val);
	//	const strRL = $btn.attr("id").slice(-1);
	//	const param = {
	//		left : false,
	//		right: false,
	//	}
	//	switch (strRL) {
	//		case "L":
	//			param.left  = newVal;
	//			param.right = $("#btnCataractModeR").val();
	//			break;
	//		case "R":
	//			param.left  = $("#btnCataractModeL").val();
	//			param.right = newVal;
	//			break;
	//		default:
	//			becky.assertion.failure(strRL);
	//			break;
	//	}
	//	const requestJson = {
	//		class: "objective",
	//		function: {
	//			name: "setCataractMode",
	//			param: param,
	//		},
	//	};
	//	// ボタンを無効化
	//	viewHelper.setAttDisabled($btn);
	//	// 新しい値を反映
	//	$btn.val(newVal);
	//	becky.WebSocket.post(requestJson).catch(() => {
	//		// 失敗したら値を戻す
	//		$btn.val(val);
	//	}).then(() => {
	//		// 完了時にボタンを有効化
	//		viewHelper.setAttDisabled($btn, false);
	//	});
	//});
	$selectorCataractMode.hide(); // 今は消す
	// 角膜直径(R/L)
	const $btnCornealDiameter = $("[id^=btnCornealDiameter]");
	//$btnCornealDiameter.click(function(){
	//	const $btn = $(this);
	//	const strRL = $btn.attr("id").slice(-1);
	//	$("<form/>", { action: "./objective-single.php", method: "post" })
	//		.append($("<input/>", { type: "hidden", name: "eye", value: strRL }))
	//		.appendTo(document.body)
	//		.submit();
	//});
	$btnCornealDiameter.hide(); // 今は消す
	// 固視標
	{
		const idFixationLevel = "#btnFixationLevel";
		becky.MutationObserver.byID(
			idFixationLevel,
			records => records.forEach(record_ => _updateLblFixationLevel(record_.target)),
			optionsAttributeFilterValue);
		const $btnFixationLevel = $(idFixationLevel);
		// 端末(WebStorage)から固視の状態を取得する
		const ledFixation = becky.WebStorage.objectiveLEDfixation.getValue();
		$btnFixationLevel.val(ledFixation); // 更新イベントを発生させる
		$btnFixationLevel.click(function(){
			const $btn = $(this);
			const val = $btn.val();
			const newVal = _toggleVal_FixationLevel(val);
			// 新しい値を反映
			$btn.val(newVal);
			(async function(){
				// ボタンを無効化
				const pointerEvents = _getPointerEventsByCommand();
				pointerEvents.begin();
				try {
					await becky.LeanStartup.post("ResetOpt", {
						L: {
							LED: {
								Fixation: _isSelectEyeL() ? newVal : "Off",
							},
						},
						R: {
							LED: {
								Fixation: _isSelectEyeR() ? newVal : "Off",
							},
						},
					});
					// 端末(WebStorage)に固視の状態を記録する
					becky.WebStorage.objectiveLEDfixation.setValue(newVal);
				} catch (resultJson) {
					// 失敗したら値を戻す
					$btn.val(val);
					// エラーメッセージ表示
					becky.LeanStartup.alertErrorMessage(resultJson);
				} finally {
					// 完了時にボタンを有効化
					pointerEvents.end();
				}
			}());
		});
	}
	// アライメントモード
	const idAlignmentMode = "#btnAlignmentMode";
	//becky.MutationObserver.byID(
	//	idAlignmentMode,
	//	records => records.forEach(record_ => _updateLblAlignmentMode(record_.target)),
	//	optionsAttributeFilterValue);
	const $btnAlignmentMode = $(idAlignmentMode);
	//$btnAlignmentMode.val($btnAlignmentMode.val()); // 更新イベントを発生させる
	//$btnAlignmentMode.click(function(){
	//	const $btn = $(this);
	//	const val = $btn.val();
	//	const newVal = _toggleVal_AM(val);
	//	const requestJson = {
	//		class: "objective",
	//		function: {
	//			name: "setAlignmentMode",
	//			param: {
	//				value: newVal,
	//			},
	//		},
	//	};
	//	// ボタンを無効化
	//	viewHelper.setAttDisabled($btn);
	//	// 新しい値を反映
	//	$btn.val(newVal);
	//	becky.WebSocket.post(requestJson).catch(() => {
	//		// 失敗したら値を戻す
	//		$btn.val(val);
	//	}).then(() => {
	//		// 完了時にボタンを有効化
	//		viewHelper.setAttDisabled($btn, false);
	//	});
	//});
	//$btnAlignmentMode.hide(); // 今は消す
	// 雲霧
	const idFogTiming = "#btnFogTiming";
	//becky.MutationObserver.byID(
	//	idFogTiming,
	//	records => records.forEach(record_ => _updateLblFogTiming(record_.target)),
	//	optionsAttributeFilterValue);
	const $btnFogTiming = $(idFogTiming);
	//$btnFogTiming.val($btnFogTiming.val()); // 更新イベントを発生させる
	//$btnFogTiming.click(function(){
	//	const $btn = $(this);
	//	const val = $btn.val();
	//	const newVal = _toggleVal_FogTiming(val);
	//	const requestJson = {
	//		class: "objective",
	//		function: {
	//			name: "setFogTiming",
	//			param: {
	//				value: newVal,
	//			},
	//		},
	//	};
	//	// ボタンを無効化
	//	viewHelper.setAttDisabled($btn);
	//	// 新しい値を反映
	//	$btn.val(newVal);
	//	becky.WebSocket.post(requestJson).catch(() => {
	//		// 失敗したら値を戻す
	//		$btn.val(val);
	//	}).then(() => {
	//		// 完了時にボタンを有効化
	//		viewHelper.setAttDisabled($btn, false);
	//	});
	//});
	$btnFogTiming.hide(); // 今は消す
	// クリア
	$("#btnClear").click(function(){
		_updateDataMeasurementValueClear();
		// 最後の計測値をクリア
		_clearLatestObjectiveRefractionJson();
	});
	// 計測開始
	$("#btnStart").click(function(){
		_updateDataMeasurementValueClear(_getSelectEye()); // 計測前にクリア
		(async function(){
			// ボタンを無効化
			const pointerEvents = _getPointerEventsByCommand();
			pointerEvents.begin();
			// 再び、ボタンが押せるようになるまで暗くする
			const $btnIcon = $("#btnStart > div > span");
			$btnIcon.attr("style", "filter: brightness(33%);");
			const $btnLabel = $("#btnStart > div");
			$btnLabel.attr("style", "color: #1a1a1a; text-shadow: 1px 1px #F2F2F240");
			try {
				await _postMeasurementCommand(isModelEyeAlignmentMode);
				// 端末に一時保存(リロード対策)
				_saveDataToWebStorage();
			} catch (resultJson) {
				// 失敗
				// エラーメッセージ表示
				becky.LeanStartup.alertErrorMessage(resultJson);
			} finally {
				// 暗くしたものを戻す
				$btnLabel.removeAttr("style");
				$btnIcon.removeAttr("style");
				// 完了時にボタンを有効化
				pointerEvents.end();
			}
		}());
	});

	{
		let isLock = false;
		let isTouch = false;
		// 反転する関数
		const funcInvert = ($target_, val_) => {
			$target_.attr("style", "filter: Invert(" + val_ + ")");
		};
		// ヘッドの上下ボタンクリック時の処理
		viewHelper.eventRegistrationTouchDownUp($("#imgHeadU, #imgHeadD"),
			async function(e) {
				// 押した
				e.preventDefault();
				if (isLock) return;
				const $btns = $(this);
				funcInvert($btns, 1); // 画像の色を反転

				becky.assertion.assert(1 === $btns.length, "1 !== $btns.length");
				let headUpDownJson = null;
				const $btn = $btns.first();
				const strUD = $btn.attr("id").slice(-1);
				switch (strUD) {
					case "U":
						headUpDownJson = { HeadUpDown:  2500 };
						break;
					case "D":
						headUpDownJson = { HeadUpDown: -2500 };
						break;
					default:
						becky.assertion.failure("unkown Head type.");
						return;
				}

				isLock = true; // ロック
				isTouch = true;
				try {
					console.log("head move - call");
					await becky.LeanStartup.post("ResetBase", headUpDownJson);
					console.log("head move - return");
					//console.log("interval - start");
					const intervalObj = asyncHelper.interval(33, async () => {
						if (isTouch) {
							// 待機
							return;
						}
						intervalObj.stop();
						try {
							console.log("head stop - call");
							await becky.LeanStartup.post("ResetBase", { HeadUpDown: 0 });
							console.log("head stop - return");
						} catch (resultJson) {
							// 失敗
							// エラーメッセージ表示
							becky.LeanStartup.alertErrorMessage(resultJson);
						} finally {
							// ロック解除
							isLock = false;
							// 画像の色を(反転から)戻す
							funcInvert($btns, 0);
						}
					});
					intervalObj.catch(() => {
						//console.log("interval - stop");
					});
				} catch (resultJson) {
					// 失敗
					// エラーメッセージ表示
					becky.LeanStartup.alertErrorMessage(resultJson);
					// ロック解除
					isLock = false;
					// 画像の色を(反転から)戻す
					funcInvert($btns, 0);
				}
			},
			function(e) {
				// 離した
				e.preventDefault();
				isTouch = false;
			}
		);
	}

	// コントローラーの左右(両)眼
	$("[id^=btnControllerEye]").click(function(){
		const backupSS = _updateDataScreenState(); // 戻せるように記憶しておく
		const strRLB = $(this).attr("id").slice(-1);
		_setSelectEye(strRLB);

		(async function(){
			// ボタンを無効化
			const pointerEvents = _getPointerEventsByCommand();
			pointerEvents.begin();
			try {
				const ledFixation = becky.WebStorage.objectiveLEDfixation.getValue();
				await becky.LeanStartup.post("ResetOpt", {
					L: {
						LED: {
							Fixation: _isSelectEyeL() ? ledFixation : "Off",
						},
					},
					R: {
						LED: {
							Fixation: _isSelectEyeR() ? ledFixation : "Off",
						},
					},
				});
				// 端末に一時保存(リロード対策)
				_saveDataToWebStorage();
			} catch (resultJson) {
				// 失敗したら値を戻す
				_updateDataScreenState(backupSS);
				// エラーメッセージ表示
				becky.LeanStartup.alertErrorMessage(resultJson);
			} finally {
				// 完了時にボタンを有効化
				pointerEvents.end();
			}
		}());
	});
	// 左右両眼の監視
	becky.MutationObserver.byID(
		"#currentEye",
		records => records.forEach(record_ => {
			const target = record_.target;
			const value = target.dataset.value;
			switch (value) {
				case "R":
					break;
				case "L":
					break;
				case "B":
					break;
				default:
					becky.assertion.failure("unknown eye");
					break;
			}
			const $btnControllerEye = $("#btnControllerEye" + value);
			if (!$btnControllerEye.hasClass("current")) {
				viewHelper.selectClassSingle("current", $btnControllerEye);
			}
		}),
		optionsAttributeFilterDataValue);
	// 左右両眼の変更イベントを呼ぶ(初期化)
	becky.dataSync.callChangeEventAttr(document.getElementById("currentEye"), "data-value");

	// ページ遷移時
	const $btnNaviNext = $("#btnNaviNext");
	$btnNaviNext.click(function(){
		// 次へのタッチイベントを無効化
		becky.navi.disableNext();
	});

	// data-* の変更イベントを作成する
	becky.dataSync.createChangeEvent();

	// ボタンの背景処理を変更する
	_buttonClickBackGroundOverlay($("[id^=btnCornealDiameter], .btn-menu"));
});

$(window).on('load', function(){
	// ライブ像のURLを設定する
	["L", "R"].forEach(pos => {
		document.getElementById("imgEye" + pos).setAttribute("src", becky.liveHttpUri[pos]);
	});
});

}());//即時関数の終端
