/*! @file
 * @brief ajax のヘルパー関数郡
 */
"use strict";

// 名前空間
var ajaxHelper = ajaxHelper || {};

/*!
 * @brief ajax 通信失敗時のエラー表示に使えそうな情報をまとめる
 * エラー表示の共通化に使う予定
 * 
 * @param[in] XMLHttpRequest aXMLHttpRequest 通信に失敗した際に呼び出される Ajax Event の引数1を渡す
 * @param[in] string aTextStatus 通信に失敗した際に呼び出される Ajax Event の引数2を渡す
 * @param[in] string aErrorThrown 通信に失敗した際に呼び出される Ajax Event の引数3を渡す
 * @param[in] array aRequestJson リクエストに使用したJSON
 * @return array[0] ステータス文字列
 * @return array[1] ステータスコード
 * @return array[2] 詳細情報
 * @return array[3] 文字列化したJSON
 */
ajaxHelper.getFailedArray = function(aXMLHttpRequest, aTextStatus, aErrorThrown, aRequestJson)
{
	const xmlHttpRequestStatus =
		(becky.assertion.isNullOrEmpty(aXMLHttpRequest) ||
		 becky.assertion.isUndefined(aXMLHttpRequest.status)) ?
			0 : aXMLHttpRequest.status;
	const enableRequestJson = !modelHelper.isNullOrEmpty(aRequestJson);
	const requestJsonString = enableRequestJson ? JSON.stringify(aRequestJson) : "";
	return [
		aTextStatus,
		xmlHttpRequestStatus,
		aErrorThrown,
		requestJsonString,
	];
}
