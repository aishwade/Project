/*! @file
 * @brief becky の操作ログ
 */
"use strict";

// 名前空間
var becky = becky || {};
becky.operatorLog = becky.operatorLog || {};

/*!
 * @brief 基本となるノードを生成する
 * 
 * @return object
 */
becky.operatorLog.createBaseNode = function()
{
	return {
		date: {
			first: "",
			last : "",
		},
		name: "",
		private: {},
		children: [],
	};
}

/*!
 * @brief 文字列の日付を Date 型に変換
 * JS は引数の参照渡しができないので配列で渡して中身を加工する
 * 
 * @param[in,out] array aValues 変換対象の配列
 * @return void
 */
becky.operatorLog.convertDateTypeStringIntoDate = function(aValues)
{
	if (Array.isArray(aValues)) {
		aValues.forEach((value_, i_, array_) => {
			if (!modelHelper.isString(value_)) {
				return;
			}
			array_[i_] = modelHelper.isNullOrEmpty(value_) ?
				null : new Date(value_);
		});
	} else {
		Object.getOwnPropertyNames(aValues).forEach(key_ => {
			if (!modelHelper.isString(aValues[key_])) {
				return;
			}
			aValues[key_] = modelHelper.isNullOrEmpty(aValues[key_]) ?
				null : new Date(aValues[key_]);
		});
	}
}

/*!
 * @brief 再帰的に date の内容を更新する
 * 
 * @param[in,out] object aNodeJson 更新対象のノード
 * @return object 対象の date
 */
becky.operatorLog.buildDateRecursively = function(aNodeJson)
{
	if (!modelHelper.isNullOrEmpty(aNodeJson.children)) {
		const dates = aNodeJson.children.map(child_ => becky.operatorLog.buildDateRecursively(child_));
		const firstDates = dates.map(date_ => date_.first);
		const  lastDates = dates.map(date_ => date_.last );
		becky.operatorLog.convertDateTypeStringIntoDate(firstDates); // Date 型に変換
		becky.operatorLog.convertDateTypeStringIntoDate( lastDates);
		becky.operatorLog.convertDateTypeStringIntoDate(aNodeJson.date);
		const firstDateOlder = new Date(Math.min(...firstDates)); // Math オブジェクトは数値に変換される
		const  lastDateNewer = new Date(Math.max(...lastDates )); // よって再度、new Date() する
		if (modelHelper.isNull(aNodeJson.date.first) ||
		    aNodeJson.date.first > firstDateOlder) {
				aNodeJson.date.first = firstDateOlder;
		}
		if (modelHelper.isNull(aNodeJson.date.last) ||
		    aNodeJson.date.last < lastDateNewer) {
				aNodeJson.date.last = lastDateNewer;
		}
	}
	return aNodeJson.date;
}

/*!
 * @brief 操作ログの正規化
 * JSON.stringify などで文字列に変換する前までには呼んでおく
 *
 * @param[in,out] object aJson 正規化の対象となるJson
 * @return void
 */
becky.operatorLog.normalization = function(aNodeJson)
{
	// 再帰的に処理する
	if (!modelHelper.isNullOrEmpty(aNodeJson.children)) {
		aNodeJson.children.forEach(child_ => becky.operatorLog.normalization(child_));
	}
	// 日付を文字列に変換
	if (aNodeJson.date.first instanceof Date) {
		aNodeJson.date.first = becky.log.toISO8601ExtString(aNodeJson.date.first);
	}
	if (aNodeJson.date.last instanceof Date) {
		aNodeJson.date.last = becky.log.toISO8601ExtString(aNodeJson.date.last);
	}
}

/*!
 * @brief 空の要素を削除する
 *
 * @param[in,out] object aJson 正規化の対象となるJson
 * @return void
 */
becky.operatorLog.removeEmptyField = function(aNodeJson)
{
	// 再帰的に処理する
	if (!modelHelper.isNullOrEmpty(aNodeJson.children)) {
		aNodeJson.children.forEach(child_ => becky.operatorLog.removeEmptyField(child_));
	}
	// 要素が空なら削除する
	["name", "private", "children"].forEach(key_ => {
		if (modelHelper.isNullOrEmpty(aNodeJson[key_])) {
			delete aNodeJson[key_];
		}
	});
}