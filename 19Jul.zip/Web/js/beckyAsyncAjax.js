/*! @file
 * @brief becky のソケットI/F関数郡
 *
 * 依存するもの
 * - ajaxHelper.js
 */
"use strict";

// 名前空間
var becky = becky || {};
becky.async = becky.async || {};

becky.async.ajax = async function(aSettings)
{
	return new Promise((resolve, reject) => {
		$.ajax(aSettings).done(aResult => {
			resolve(aResult);
		}).fail((jqXHR, textStatus, errorThrown) => {
			reject([ jqXHR, textStatus, errorThrown ]);
			const lines = ajaxHelper.getFailedArray(jqXHR, textStatus, errorThrown);
			becky.assertion.failure(lines.join(" "));
		});
	});
}

becky.async.getJSON = async function(aUrl)
{
	return new Promise((resolve, reject) => {
		$.getJSON(aUrl).done(aResult => {
			resolve(aResult);
		}).fail((jqXHR, textStatus, errorThrown) => {
			reject([ jqXHR, textStatus, errorThrown ]);
			const lines = ajaxHelper.getFailedArray(jqXHR, textStatus, errorThrown);
			becky.assertion.failure(lines.join(" "));
		});
	});
}
