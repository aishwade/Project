/*! @file
 * @brief ネットワーク設定で使用するスクリプト
 */

// 即時関数を使って閉じ込める
(function(){
"use strict";

/*!
 * @brief IPアドレスのフォーマットとして正しいか？
 * XXX.XXX.XXX.XXX
 *
 * @param[in] string aIP 対象
 * @retval true 正しい
 * @retval false 正しくない
 */
function _isIPAddressFormat(aIP)
{
	if (becky.assertion.isNullOrEmpty(aIP)) {
		return false;
	}
	const trimdIP = aIP.trim();
	const pattern = /^(\d{1,3})\s*\.\s*(\d{1,3})\s*\.\s*(\d{1,3})\s*\.\s*(\d{1,3})$/;
	const matches = trimdIP.match(pattern);
	if (modelHelper.isNullOrEmpty(matches)) {
		return false;
	}
	const ips = matches.filter(val => 0 <= val && val <= 255);
	return 4 === ips.length;
}

$(document).ready(function(){
	// スタイル適用前の画面を見せたくない
	$("body").fadeIn();

	//$("select").selectmenu(); 標準のコントロールを使用する
	$("button").button();
	$("input[type='radio']").checkboxradio({
		icon: false
	});
	$("input[type='tel']").spinner();

	$("input[name='date']").datepicker();

	$("input[name='packingMode']").click(function(){
		// おそらく実行前に確認ダイアログなどで確認する
	});

	// 戻る
	$("#goBack").click(function(){
		location.href = "../index.php";
	});

	const $networkConfig_form = $("#networkConfig_form");
	if (becky.assertion.isNullOrEmpty($networkConfig_form)) {
		return;
	}
	// 送信前の処理
	$("#register").click(function(){
		// 不正フィールド変更イベント定義する。
		const funcRegistEventInvalidField = () => {
			const funcRemoveClass = target => {
				const $invalid_field = $(target);
				$invalid_field.removeClass("invalidField");
			};
			$("input.invalidField").keypress(event => {
				funcRemoveClass(event.target);
			}).keyup(event => {
				// BackSpace, Delete
				if ( 8 !== event.keyCode &&
				    46 !== event.keyCode) {
					return;
				}
				funcRemoveClass(event.target);
			});
		};
		let isCancel = false;
		{	// 必須項目のチェック
			const $required_fields = $("[name=ip_Address], [name=subnetMask]");
			if (!modelHelper.isNullOrEmpty($required_fields)) {
				$required_fields.each((i, element) => {
					const $required_field = $(element);
					if (modelHelper.isNullOrEmpty($required_field.val())) {
						$required_field.addClass("invalidField");
						isCancel = true;
					}
				});
				// 不正フィールド変更イベントを登録する。
				funcRegistEventInvalidField();
			}
		}
		{	// IPアドレスのフォーマットチェック
			const $ip_fields = $("[name=ip_Address], [name=subnetMask], [name=defaultGateway]");
			if (!modelHelper.isNullOrEmpty($ip_fields)) {
				$ip_fields.each((i, element) => {
					const $ip_field = $(element);
					const val = $ip_field.val();
					if (modelHelper.isNullOrEmpty(val)) {
						return;
					}
					if (!_isIPAddressFormat(val)) {
						$ip_field.addClass("invalidField");
						isCancel = true;
					}
				});
				// 不正フィールド変更イベントを登録する。
				funcRegistEventInvalidField();
			}
		}
		if (isCancel) {
			// 送信をキャンセルする
			return;
		}
		{	// 続行確認
			const changeConfirmMessage = viewHelper.getDefMessage("networkConfig/changeConfirmMessage");
			const resultConfirm = confirm(changeConfirmMessage);
			if (!resultConfirm) {
				// キャンセル
				return;
			}
		}
		// 登録という事を識別する為の情報
		$("<input/>").attr({
			type : "hidden",
			name : "networkConfig_register",
			value: "Register"
		}).appendTo($networkConfig_form);
		$networkConfig_form.submit();
	});
});

}());//即時関数の終端
