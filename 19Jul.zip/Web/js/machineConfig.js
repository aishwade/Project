/*! @file
 * @brief 機器設定で使用するスクリプト
 */

// 即時関数を使って閉じ込める
(function(){
"use strict";

/*!
 * @brief 再確認ボタンの識別IDを生成する
 *
 * @param[in] string aCommandName コマンド名
 * @return string
 */
function _createRecheckButtonID(aCommandName)
{
	return 'btnRecheckCommandVersion' + aCommandName;
}

/*!
 * @brief 再確認ボタンのHTMLを生成する
 *
 * @param[in] string aID ボタンのID
 * @return string
 */
function _createRecheckButtonHTML(aID)
{
	return '<button type="button" id="' + aID + '">Recheck</button>';
}

/*!
 * @brief 警告領域に HTML を設定する
 *
 * @param[in] string aBaseName 左右の基本となる名前
 * @param[in] string aHtml 設定するHTML
 * @return void
 */
function _showWarn(aBaseName, aHtml)
{
	$(aBaseName + "Warn").html(aHtml);
}

/*!
 * @brief 左右の"checking"を表示する
 *
 * @param[in] string aBaseName 左右の基本となる名前
 * @return void
 */
function _showChecking(aBaseName)
{
	const strLoadingImg = '<img src="../img/loader_16x11.gif" width="16" height="11" alt="...">';
	const strChecking = "Checking" + strLoadingImg;
	const ids = [aBaseName + "L", aBaseName + "R"].join(",");
	$(ids).html(strChecking);
}

/*!
 * @brief エラーを表示する
 *
 * @param[in] string aBaseName 左右の基本となる名前
 * @param[in] string aPos 左/右(未指定の場合、左右両方)
 * @return void
 */
function _showError(aBaseName, aPos)
{
	let target = null;
	if (modelHelper.isUndefined(aPos)) {
		target = [ aBaseName + "L", aBaseName + "R" ].join(",");
	} else {
		target = aBaseName + aPos;
	}
	$(target).text("Error");
}

/*!
 * @brief バージョンを表示する
 *
 * @param[in] string aBaseName 左右の基本となる名前
 * @param[in] string aPos 左/右
 * @param[in] string aResultJsonByEye 結果 JSON (眼ごと)
 * @return void
 */
function _showVersion(aBaseName, aPos, aResultJsonByEye)
{
	try {
		const v = aResultJsonByEye.Version; // 短く表現したいだけのエイリアス
		const arrayVer = [v.Major, v.Minor, v.Build, v.Revision];
		$(aBaseName + aPos).text(arrayVer.join("."));
	} catch (ex) {
		_showError(aBaseName, aPos);
		modelHelper.catchExceptionByUndefined(ex);
	}
}

/*!
 * @brief 再確認ボタンを表示する
 *
 * @param[in] string aBaseName 左右の基本となる名前
 * @param[in] string aIdRecheckButton 再確認ボタンのID
 * @param[in] function aFuncRecheckClick 再確認クリック時に呼び出す関数
 * @return void
 */
function _showRecheckButton(aBaseName, aIdRecheckButton, aFuncRecheckClick)
{
	_showWarn(aBaseName, _createRecheckButtonHTML(aIdRecheckButton));
	$('#' + aIdRecheckButton).click(aFuncRecheckClick);
}

/*!
 * @brief 差分を表示する
 *
 * @param[in] string aBaseName 左右の基本となる名前
 * @return void
 */
function _showDiffer(aBaseName)
{
	const textL = $(aBaseName + "L").text();
	const textR = $(aBaseName + "R").text();
	const isDiffer = textL !== textR;
	_showWarn(aBaseName, isDiffer ? "differ!" : "");
}

/*!
 * @brief コマンドのバージョンを更新する
 * 非同期
 *
 * @param[in] string aCommandName コマンド名
 * @return Promise
 */
async function _updateCommandVersion(aCommandName)
{
	const baseName = "#labelCommandVersion" + aCommandName;
	_showChecking(baseName);
	_showWarn    (baseName, "");

	let json = null;
	try {
		json = await becky.LeanStartup.post(aCommandName, { GetVersion: true });
	} catch (resultJson) {
		json = resultJson;
	}
	if (modelHelper.isNullOrEmpty(json) ||
	    modelHelper.isUndefined(json.return)) {
		// 端末～制御ボックス間の通信エラーの可能性が高い
		_showError(baseName);
		// 再確認ボタンを配置
		const idRecheckButton = _createRecheckButtonID(aCommandName);
		_showRecheckButton(baseName, idRecheckButton, function(){ _updateCommandVersion(aCommandName); });
		return;
	}
	let someError = false;
	["L", "R"].forEach(pos_ => {
		const jsonByEye = json[pos_];
		if (modelHelper.isUndefined(jsonByEye.return) ||
		   !modelHelper.toBoolean  (jsonByEye.return) ||
		    modelHelper.isUndefined(jsonByEye.Version)) {
			// 制御ボックス～ヘッド間の通信エラーの可能性が高い
			_showError(baseName, pos_);
			someError = true;
			return;
		}
		// バージョン表示
		_showVersion(baseName, pos_, jsonByEye);
	});
	if (someError) {
		// 再確認ボタンを配置
		const idRecheckButton = _createRecheckButtonID(aCommandName);
		_showRecheckButton(baseName, idRecheckButton, function(){ _updateCommandVersion(aCommandName); });
		return;
	}
	// 差分表示
	_showDiffer(baseName);
}

/*!
 * @brief LiveStreamServer のバージョンを得る
 * 非同期
 *
 * @param[in] string aUri 接続先のURI
 * @return Promise
 */
async function _postLiveStreamServerVersion(aUri)
{
	return new Promise((resolve, reject) => {
		becky.async.ajax({
			url: aUri,
			cache: false,
		}).then(resultJson => {
			resolve(resultJson);
		}).catch(ex => {
			reject(ex);
		});
	});
}

/*!
 * @brief LiveStreamServer のバージョンを更新する
 *
 * @return void
 */
function _updateLiveStreamServerVersion()
{
	const baseName = "#labelLiveStreamServerVersion";
	_showChecking(baseName);
	_showWarn    (baseName, "");

	const promises = {};
	Object.keys(becky.liveHttpUri).forEach(function (pos_) {
		const liveUri = this[pos_];
		const uri = liveUri.replace('live.avi', 'getVersion.json');
		promises[pos_] = _postLiveStreamServerVersion(uri);
	}, becky.liveHttpUri);

	["L", "R"].forEach(pos_ => {
		const promise = promises[pos_];
		promise.then(resultJson => {
			const jsonByEye = resultJson;
			if (modelHelper.isUndefined(jsonByEye.return) ||
			   !modelHelper.toBoolean  (jsonByEye.return) ||
			    modelHelper.isUndefined(jsonByEye.Version)) {
				// 制御ボックス～ヘッド間の通信エラーの可能性が高い
				_showError(baseName, pos_);
				return;
			}
			// バージョン表示
			_showVersion(baseName, pos_, jsonByEye);
		}).catch(() => {
			// 端末～制御ボックス間の通信エラーの可能性が高い
			_showError(baseName, pos_);
		});
	});

	Promise.all([ promises.L, promises.R ]).then(() => {
		// 差分表示
		_showDiffer(baseName);
	}).catch(() => {
		// 再確認ボタンを配置
		const commandName = "LiveStreamServer";
		const idRecheckButton = "btnRecheckCommandVersion" + commandName;
		_showRecheckButton(baseName, idRecheckButton, _updateLiveStreamServerVersion);
	});
}

$(document).ready(function(){
	// スタイル適用前の画面を見せたくない
	$("body").fadeIn();

	const tabIDs = [
		"#tabs",
		"#tabs-generalSettings",
		"#tabs-objective",
		"#tabs-subjective",
		"#tabs-versions",
	];
	const $tabs = $(tabIDs.join(", "));
	$tabs.tabs();

	//$("select").selectmenu(); 標準のコントロールを使用する
	$("input[type='button']").button();
	$("input[type='radio']").checkboxradio({
		icon: false
	});
	$("input[type='tel']").spinner();

	$("input[name='date']").datepicker();

	$("input[name='packingMode']").click(function(){
		// おそらく実行前に確認ダイアログなどで確認する
	});

	// 戻る
	$("#goBack").click(function(){
		location.href = "../index.php";
	});

	// 各コマンドのバージョンを得る(並列)
	becky.commandNames.forEach(commandName_ => {
		_updateCommandVersion(commandName_);
	});
	// LiveStreamServer のバージョンを得る
	_updateLiveStreamServerVersion();
	// 各ファームウェアのバージョンを得る(直列)
	(async function(){
		for (let i = 0; i < becky.firmwareNames.length; ++i) {
			const firmwareName = becky.firmwareNames[i];
			await _updateCommandVersion(firmwareName);
		}
	}());

	const $machineConfig_form = $("#machineConfig_form");
	if (becky.assertion.isNullOrEmpty($machineConfig_form)) {
		return;
	}
	// 送信前の処理
	$("#register").click(function(){
		// 登録という事を識別する為の情報
		$("<input/>").attr({
			type : "hidden",
			name : "machineConfig_register",
			value: "Register"
		}).appendTo($machineConfig_form);
		$machineConfig_form.submit();
	});
});

}());//即時関数の終端
