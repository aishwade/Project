/*! @file
 * @brief becky の Web Storage 入出力
 *
 * 依存するもの
 * - beckyWebStorageHelper.js
 */
"use strict";

// 名前空間
var becky = becky || {};
becky.WebStorage = becky.WebStorage || {};

// ローカルストレージ(端末毎に永続化される)
becky.WebStorage.local = becky.WebStorage.local || {};

/*!
 * @brief ローカルストレージの入出力
 *
 * @param[in] string aKeyName キー
 * @return object 入出力オブジェクト
 */
becky.WebStorage.local.IO = function(aKeyName)
{
	return {
		getString: () => becky.WebStorage.local.getString(aKeyName),
		setString: aKeyValue => becky.WebStorage.local.setString(aKeyName, aKeyValue),
		getJson: () => becky.WebStorage.local.getJson(aKeyName),
		setJson: aJson => becky.WebStorage.local.setJson(aKeyName, aJson),
		removeItem: () => becky.WebStorage.local.removeItem(aKeyName),
	};
}
