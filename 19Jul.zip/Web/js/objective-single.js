/*! @file
 * @brief 他覚-角膜直径で使用するスクリプト
 */

// 即時関数を使って閉じ込める
(function(){
"use strict";

$(document).ready(function(){
	becky.WebSocket.build(event => {
		becky.liveImage.keepConnection(event);
		switch (event.type) {
			case "message":
				// ブロードキャストで受信
				const resultJsonString = event.data;
				console.log(resultJsonString);
				break;
			default:
				break;
		}
	});

	const $btnEye = $("[id^=btnEye]");
	$btnEye.click(function(){
		const strRL = $(this).attr("id").slice(-1);
		{
			let add    = "current-";
			let remove = "current-";
			       if ("R" == strRL) {
				add    += "a";
				remove += "b";
			} else if ("L" == strRL) {
				add    += "b";
				remove += "a";
			}

			$("#areaAB").removeClass(remove).addClass(add);
		}
		{
			const $imgLiveImage = $("#imgLiveImage");
			const imgSrc = liveHttpUri[strRL]; // liveHttpUri は view-single.php 内で定義

			$imgLiveImage.attr("src", imgSrc);
		}
	});
});

}());//即時関数の終端
