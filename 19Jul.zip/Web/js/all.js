/*! @file
 * @brief すべての画面で適用されるスクリプト
 */

// 即時関数を使って閉じ込める
(function(){
"use strict";

$(function(){
//	// コンテキストメニューを禁止
//	$(document).on('contextmenu',function(){
//		return false;
//	});
	// ページ内リンクのクリックを無効
	$("a[href^='#']").click(function(){
		return false;
	});
});

}());//即時関数の終端
