/*! @file
 * @brief 被検者情報 で使用するスクリプト
 */

// 即時関数を使って閉じ込める
(function(){
"use strict";

/*!
 * @brief ボタンクリック時に背景を変更する
 *
 * @param[in] element $btn 対象のボタン
 */
function _buttonClickBackGroundOverlay($btn)
{
	if (becky.assertion.isNullOrEmpty($btn)) {
		return;
	}

	viewHelper.eventRegistrationTouchDownUp($btn,
		function(){ $(this).addClass   ("active"); },
		function(){ $(this).removeClass("active"); });
}

$(document).ready(function(){

	becky.debug.scope(() => {
		const webStorageDebugCommandLog = becky.WebStorage.local.IO("debug.log.command");
		webStorageDebugCommandLog.removeItem(); // ログを削除
		webStorageDebugCommandLog.setJson({values:[]});
	});

	(async function(){
		try {
			becky.operatorLog.serialize();

			const resetOptParamLR = {
				LED: {
					Fixation: becky.WebStorage.objectiveLEDfixation.getValue(),
				},
				OpticalPath: false,
				TF: true,
				VCC1: true,
				VCC2: true,
			}
			await becky.LeanStartup.post("ResetOpt", {
				L: resetOptParamLR,
				R: resetOptParamLR,
			});

			await becky.LeanStartup.post("ResetBase", {
				X: true,
				Y: true,
				Z: true,
				Theta: true,
			});

			// 次へ遷移可能
			becky.navi.showNext();
		} catch (resultJson) {
			// 失敗
			// エラーメッセージ表示
			becky.LeanStartup.alertErrorMessage(resultJson);
		}
	}());

	const $patient_form = $("#patient_form");
	if (becky.assertion.isNullOrEmpty($patient_form)) {
		return;
	}
	// 送信前の処理
	const $btnNaviNext = $("#btnNaviNext");
	$btnNaviNext.attr("href", "#"); // href によるリンクを無効化
	$btnNaviNext.click(function(){
		// 不正フィールド変更イベント定義する。
		const funcRegistEventInvalidField = () => {
			const funcRemoveClass = target => {
				const $invalid_field = $(target);
				$invalid_field.removeClass("invalidField");
			};
			$("input.invalidField").keypress(event => {
				funcRemoveClass(event.target);
			}).keyup(event => {
				// BackSpace, Delete
				if ( 8 !== event.keyCode &&
				    46 !== event.keyCode) {
					return;
				}
				funcRemoveClass(event.target);
			});
		};
		let isCancel = false;
		{	// 必須項目のチェック
			const $required_fields = $("input[required='required']");
			if (!modelHelper.isNullOrEmpty($required_fields)) {
				$required_fields.each((i, element) => {
					const $required_field = $(element);
					if (modelHelper.isNullOrEmpty($required_field.val())) {
						$required_field.addClass("invalidField");
						isCancel = true;
					}
				});
				// 不正フィールド変更イベントを登録する。
				funcRegistEventInvalidField();
			}
		}
		if (isCancel) {
			// 送信をキャンセルする
			return;
		}
		// 端末のローカルタイムを設定する
		const dateNow = new Date();
		const patientID = $("[name=patientID]").val().trim();
		// 操作ログの1サイクル分の記録を開始
		becky.operatorLog.createOneCycleNode(patientID, dateNow);
		$("<input/>").attr({
			type : "hidden",
			name : "sessionDate",
			value: viewHelper.getStrDate(dateNow, ""),
		}).appendTo($patient_form);
		$("<input/>").attr({
			type : "hidden",
			name : "sessionTime",
			value: viewHelper.getStrTime(dateNow, ""),
		}).appendTo($patient_form);
		// 登録という事を識別する為の情報
		$("<input/>").attr({
			type : "hidden",
			name : "patient_register",
			value: "Register"
		}).appendTo($patient_form);
		$patient_form.submit();
		// 次へのタッチイベントを無効化
		becky.navi.disableNext();
	});
	// リセット処理
	$("#text_3-1_12-1").click(function(){
		$("input").val("");
	});

	// ボタンの背景処理を変更する
	_buttonClickBackGroundOverlay($("#text_3-1_12-1"));
});

}());//即時関数の終端
