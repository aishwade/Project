/*! @file
 * @brief 自覚で使用するスクリプト
 *
 * 依存するもの
 * - viewHelper.js
 * - ajaxHelper.js
 * - beckyMutationObserver.js
 * - beckyDataSync.js
 * - beckyWebStorageHelper.js
 * - beckyWebStorageIO.js
 * - beckyAsyncAjax.js
 * - beckyLeanStartupAjax.js
 * - beckyScopedStyle.js
 */

const newLocal = "far";
// 即時関数を使って閉じ込める
(function () {
    "use strict";

    //! @brief chartPage.parameter.json の chartPageN のカレント
    let _currentChart = null;
    //! @brief 遠見/近見 切り替え時にセットするSCA
    const _changeFarNearSetSCA = {
        far: "Sph",
        // near: "ADD",
        near: "PrismHor",
    }
    //! @brief 例外:クロスシリンダーの計算に使用する基準値
    const _crossCylinderBase = {};

    /*!
     * @brief カレントの視標を更新
     *
     * @param[in] array chartTable chartPage.parameter.json の chartPageN の単一要素
     */
    function _setCurrentChart(chartTable) {
        _currentChart = chartTable;
        // 例外:クロスシリンダー対応
        const mv = _updateDataMeasurementValue();
        ["Sph", "Cyl"].forEach(sc_ => {
            ["L", "R"].forEach(pos_ => {
                const key = sc_ + pos_;
                _crossCylinderBase[key] = mv[key];
            });
        });
        // 端末に一時保存(リロード対策)
        const webStorageIO = becky.WebStorage.local.IO("subjective.update.data");
        const updateDataJson = webStorageIO.getJson();
        if (!modelHelper.isNull(updateDataJson)) {
            updateDataJson.screenState.currentAutoID = chartTable.autoID;
            //old process
            webStorageIO.setJson(updateDataJson);
        }
    }

    /*!
     * @brief コマンド呼び出しイベントの排他制御オブジェクト
     * 開始:begin(), 終了:end()
     *
     * @return becky.scopedStyle.css
     */
    function _getPointerEventsByCommand() {
        const selectors = [
            "#btnSetting", // 設定
            "#btnNaviNext", // 次へ
            ".confirm-box .btn-group-va", // 視標の隣のボタン
            ".area-center", // メインデータのエリア
            ".controller-a", // コントローラーの左右(両)眼
            ".controller-b", // コントローラーの調整ボタン
            ".controller-c", // クロスシリンダー回転
            ".controller-d", // 乱視/軸の切り替え Astigmatic / axis switching
            ".controller-prism", //Prism controller switching
            "[data-auto-id]", // タブ内の視力表(サムネイル)
            "#btnMenuFarNear", // 遠見/近見
            "#btnMenuBinoMono", // 両眼開放/片眼遮蔽
            "#btnAutoAlignment", // オートアライメント
            "#btnResetBaseXYZ", // 駆動リセット
            "#btnMenuCC_Power", // クロスシリンダー power
            "[id^=inputExaminationDistancePoint_]", // 検査距離

        ];
        //becky.debug.scope(() => {
        //	selectors.forEach(selector_ => {
        //		becky.assertion.assert(!modelHelper.isNullOrEmpty($(selector_)));
        //	});
        //});
        const $target = $(selectors.join(","));
        return becky.scopedStyle.css($target, "pointer-events", "none", "auto");
    }

    /*!
     * @brief 配列の文字列をトグルした値を返す
     *
     * @param[in] string aVal 対象の値
     * @param[in] array aDefs 定義文字列郡
     * @return string 対象をトグルした値
     */
    function _toggleVal_Base(aVal, aDefs) {
        if (becky.assertion.isNullOrEmpty(aDefs)) {
            return;
        }
        becky.assertion.assert(2 === aDefs.length, "2 === aDefs.length");
        const index = aDefs.indexOf(aVal);
        becky.assertion.assert(0 <= index, "_toggleVal_Base");
        const toggledIndex = 0 !== index ? 0 : 1;
        return aDefs[toggledIndex];
    }

    /*!
     * @brief 文字を大きくするスタイルを適用
     *
     * @param[in,out] element $label 対象
     */
    function _toTextLarge($label) {
        $label.removeClass("txt-small").addClass("txt-large");
    }

    /*!
     * @brief 文字を小さくするスタイルを適用
     *
     * @param[in,out] element $label 対象
     */
    function _toTextSmall($label) {
        $label.removeClass("txt-large").addClass("txt-small");
    }

    /*!
     * @brief (自覚)メッセージの定義リストから文字列を得る
     *
     * @param[in] string aKeyBySubjective (自覚)メッセージの定義名
     * @return string メッセージ文字列
     */
    function _getDefMessageBySubjective(aKeyBySubjective) {
        if (becky.assertion.isNullOrEmpty(aKeyBySubjective)) {
            return "";
        }
        return viewHelper.getDefMessage("subjective/" + aKeyBySubjective);
    }

    /*!
     * @brief 要素が表示状態か？
     *
     * @param[in] element $element 調査対象
     * @retval true  表示状態
     * @retval false 非表示状態
     */
    function _isShow($element) {
        return $element.is(":visible");
    }

    /*!
     * @brief 要素が非表示状態か？
     *
     * @param[in] element $element 調査対象
     * @retval true  非表示状態
     * @retval false 表示状態
     */
    function _isHide($element) {
        return !_isShow($element);
    }

    /*!
     * @brief 選択されている眼を得る
     *
     * @retval "R" 右眼が選択されている
     * @retval "L" 左眼が選択されている
     * @retval "B" 両眼が選択されている
     */
    function _getSelectEye() {
        return $("#currentEye").attr("data-value");
    }

    /*!
     * @brief 右眼が選択されているか？
     *
     * @retval true  右眼が選択されている(両眼選択を含む)
     * @retval false 右眼は選択されていない
     */
    function _isSelectEyeR() {
        const eyeValue = _getSelectEye();
        switch (eyeValue) {
            case "R":
                return true;
            case "L":
                return false;
            case "B":
                return true;
            default:
                becky.assertion.failure("unknown eye");
                return false;
        }
    }

    /*!
     * @brief 左眼が選択されているか？
     *
     * @retval true  左眼が選択されている(両眼選択を含む)
     * @retval false 左眼は選択されていない
     */
    function _isSelectEyeL() {
        const eyeValue = _getSelectEye();
        switch (eyeValue) {
            case "R":
                return false;
            case "L":
                return true;
            case "B":
                return true;
            default:
                becky.assertion.failure("unknown eye");
                return false;
        }
    }

    /*!
     * @brief 両眼が選択されているか？
     *
     * @retval true  両眼が選択されている
     * @retval false 両眼は選択されていない
     */
    function _isSelectEyeB() {
        const eyeValue = _getSelectEye();
        switch (eyeValue) {
            case "R":
                return false;
            case "L":
                return false;
            case "B":
                return true;
            default:
                becky.assertion.failure("unknown eye");
                return false;
        }
    }

    /*!
     * @brief 左右両眼を選択状態にする
     * Model を更新
     *
     * @param[in] string aVal 選択対象
     */
    function _setSelectEye(aVal) {
        switch (aVal) {
            case "B":
            case "R":
            case "L":
                break;
            default:
                becky.assertion.failure("unknown eye");
                return;
        }
        $("#currentEye").attr("data-value", aVal);
    }

    /*!
     * @brief 右眼を選択状態にする
     * 変更イベントから呼ばれる事を想定
     * 左眼の選択状態は解除される
     */
    function _setSelectEyeR_FromEvent() {
        const $btnControllerEyeR = $("#btnControllerEyeR");
        if (!$btnControllerEyeR.hasClass("current")) {
            viewHelper.selectClassSingle("current", $btnControllerEyeR);
        }
        $(".data-table").addClass("current-a").removeClass("current-b");

        const isSelectEyes = {
            R: true,
            L: false,
        };
        _updateMainClasses(isSelectEyes, null);
    }

    /*!
     * @brief 左眼を選択状態にする
     * 変更イベントから呼ばれる事を想定
     * 右眼の選択状態は解除される
     */
    function _setSelectEyeL_FromEvent() {
        const $btnControllerEyeL = $("#btnControllerEyeL");
        if (!$btnControllerEyeL.hasClass("current")) {
            viewHelper.selectClassSingle("current", $btnControllerEyeL);
        }
        $(".data-table").addClass("current-b").removeClass("current-a");

        const isSelectEyes = {
            R: false,
            L: true,
        };
        _updateMainClasses(isSelectEyes, null);
    }

    /*!
     * @brief 両眼を選択状態にする
     * 変更イベントから呼ばれる事を想定
     */
    function _setSelectEyeB_FromEvent() {
        const $btnControllerEyeB = $("#btnControllerEyeB");
        if (!$btnControllerEyeB.hasClass("current")) {
            viewHelper.selectClassSingle("current", $btnControllerEyeB);
        }
        $(".data-table").addClass("current-a current-b");

        // 両眼のクロスシリンダーなし

        const isSelectEyes = {
            R: true,
            L: true,
        };
        _updateMainClasses(isSelectEyes, null);
    }

    /*!
     * @brief Sph, Cyl, Axs, ADD のどれが選択されているか？
     *
     * @retval "Sph" Sph が選択されている
     * @retval "Cyl" Cyl が選択されている
     * @retval "Axs" Axs が選択されている
     * @retval "ADD" ADD が選択されている
     */
    function _getSelectSCA() {
        return $("#currentSCA").attr("data-value");
    }

    /*!
     * @brief Sph が選択されているか？
     *
     * @retval true  Sph が選択されている
     * @retval false Sph は選択されていない
     */
    function _isSelectSph() {
        return "Sph" === _getSelectSCA();
    }

    /*!
     * @brief Cyl が選択されているか？
     *
     * @retval true  Cyl が選択されている
     * @retval false Cyl は選択されていない
     */
    function _isSelectCyl() {
        return "Cyl" === _getSelectSCA();
    }

    /*!
     * @brief Axs が選択されているか？
     *
     * @retval true  Axs が選択されている
     * @retval false Axs は選択されていない
     */
    function _isSelectAxs() {
        return "Axs" === _getSelectSCA();
    }

    /*!
     * @brief ADD が選択されているか？
     *
     * @retval true  ADD が選択されている
     * @retval false ADD は選択されていない
     */
    function _isSelectADD() {
        return "ADD" === _getSelectSCA();
    }

    function _isSelectHor() {
        return "HOR" === _getSelectSCA();
    }

    function _isSelectVer() {
        return "VER" === _getSelectSCA();
    }
    /*!
     * @brief Sph, Cyl, Axs, ADD を選択する
     * Model を更新
     *
     * @param[in] string aVal 選択対象
     */
    function _setSelectSCA(aVal) {

        switch (aVal) {
            case "Sph":
            case "Cyl":
            case "Axs":
            case "ADD":
                //case "Prism":
            case "PrismHor":
            case "PrismVer":
                break;
            default:
                becky.assertion.failure("unknown SCA");
                return;
        }
        $("#currentSCA").attr("data-value", aVal);
        // 遠見/近見 切り替え時にセットするSCAを更新
        const selectFarNear = _getSelectFarNear();
        _changeFarNearSetSCA[selectFarNear] = aVal;
    }

    /*!
     * @brief Sph を選択する
     * 変更イベントから呼ばれる事を想定
     */
    function _setSelectSph_FromEvent() {
        const $btnMenuS = $("#btnMenuS");
        const $btnMenuC = $("#btnMenuC");
        const $btnMenuA = $("#btnMenuA");
        const $menuItemS = $btnMenuS.parent(".menu-item");
        const $menuItemC = $btnMenuC.parent(".menu-item");
        const $menuItemA = $btnMenuA.parent(".menu-item");

        $menuItemS.show();
        $menuItemC.hide();
        $menuItemA.hide();

        const isSelectSCAs = {
            Sph: true,
            Cyl: false,
            Axs: false,
            ADD: false,
            PrismHor: false,
            PrismVer: false,
        };
        _updateMainClasses(null, isSelectSCAs);
    }

    /*!
     * @brief Cyl を選択する
     * 変更イベントから呼ばれる事を想定
     */
    function _setSelectCyl_FromEvent() {
        const $btnMenuS = $("#btnMenuS");
        const $btnMenuC = $("#btnMenuC");
        const $btnMenuA = $("#btnMenuA");
        const $menuItemS = $btnMenuS.parent(".menu-item");
        const $menuItemC = $btnMenuC.parent(".menu-item");
        const $menuItemA = $btnMenuA.parent(".menu-item");

        $menuItemS.hide();
        $menuItemC.show();
        $menuItemA.hide();

        const isSelectSCAs = {
            Sph: false,
            Cyl: true,
            Axs: false,
            ADD: false,
            PrismHor: false,
            PrismVer: false,
        };
        _updateMainClasses(null, isSelectSCAs);
    }

    /*!
     * @brief Axs を選択する
     * 変更イベントから呼ばれる事を想定
     */
    function _setSelectAxs_FromEvent() {
        const $btnMenuS = $("#btnMenuS");
        const $btnMenuC = $("#btnMenuC");
        const $btnMenuA = $("#btnMenuA");
        const $menuItemS = $btnMenuS.parent(".menu-item");
        const $menuItemC = $btnMenuC.parent(".menu-item");
        const $menuItemA = $btnMenuA.parent(".menu-item");

        $menuItemS.hide();
        $menuItemC.hide();
        $menuItemA.show();

        const isSelectSCAs = {
            Sph: false,
            Cyl: false,
            Axs: true,
            ADD: false,
            PrismHor: false,
            PrismVer: false,
        };
        _updateMainClasses(null, isSelectSCAs);
    }

    /*!
     * @brief ADD を選択する
     * 変更イベントから呼ばれる事を想定
     */
    function _setSelectADD_FromEvent() {
        const $btnMenuS = $("#btnMenuS");
        const $btnMenuC = $("#btnMenuC");
        const $btnMenuA = $("#btnMenuA");
        const $menuItemS = $btnMenuS.parent(".menu-item");
        const $menuItemC = $btnMenuC.parent(".menu-item");
        const $menuItemA = $btnMenuA.parent(".menu-item");

        $menuItemS.show(); // 加入(ADD)は Sph のステップを使用する
        $menuItemC.hide();
        $menuItemA.hide();

        const isSelectSCAs = {
            Sph: false,
            Cyl: false,
            Axs: false,
            ADD: true,
            PrismHor: false,
            PrismVer: false,
        };
        _updateMainClasses(null, isSelectSCAs);
    }

    /*!
     * @brief Cyl/Axs の選択状態をトグルする
     */
    function _toggleSelectCylAxs() {
        const currentSCA = _getSelectSCA();
        switch (currentSCA) {
            case "Cyl":
                _setSelectSCA("Axs");
                break;
            case "Axs":
                _setSelectSCA("Cyl");
                break;
            default:
                break;
        }
    }

    function _setSelectPrismHor_FromEvent() {
        const $btnMenuS = $("#btnMenuS");
        const $btnMenuC = $("#btnMenuC");
        const $btnMenuA = $("#btnMenuA");
        const $menuItemS = $btnMenuS.parent(".menu-item");
        const $menuItemC = $btnMenuC.parent(".menu-item");
        const $menuItemA = $btnMenuA.parent(".menu-item");

        $menuItemS.hide();
        $menuItemC.hide();
        $menuItemA.hide();

        const isSelectSCAs = {
            Sph: false,
            Cyl: false,
            Axs: false,
            ADD: false,
            PrismHor: true,
            PrismVer: false,
        };
        _updateMainClasses(null, isSelectSCAs);

        $(".labelMenu_V").removeClass("txt-large");
        $(".labelMenu_V").addClass("txt-small");
    }

    function _setSelectPrismVer_FromEvent() {
        const $btnMenuS = $("#btnMenuS");
        const $btnMenuC = $("#btnMenuC");
        const $btnMenuA = $("#btnMenuA");
        const $menuItemS = $btnMenuS.parent(".menu-item");
        const $menuItemC = $btnMenuC.parent(".menu-item");
        const $menuItemA = $btnMenuA.parent(".menu-item");

        $menuItemS.hide();
        $menuItemC.hide();
        $menuItemA.hide();

        const isSelectSCAs = {
            Sph: false,
            Cyl: false,
            Axs: false,
            ADD: false,
            PrismHor: false,
            PrismVer: true,
        };
        _updateMainClasses(null, isSelectSCAs);

        $(".labelMenu_V").addClass("txt-large");
        $(".labelMenu_V").removeClass("txt-small");
    }

    /*!
     * @brief 遠見/近見 の値を得る
     *
     * @retval string "far"  遠見
     * @return string "near" 近見
     */
    function _getSelectFarNear() {
        return $("#btnMenuFarNear").val();
    }

    /*!
     * @brief 遠見 が選択されているか？
     *
     * @retval bool true  遠見
     * @retval bool false 遠見ではない
     */
    function _isSelectFar() {
        return "far" === _getSelectFarNear();
    }

    /*!
     * @brief 近見 が選択されているか？
     *
     * @retval bool true  近見
     * @retval bool false 近見ではない
     */
    function _isSelectNear() {
        return "near" === _getSelectFarNear();
    }

    /*!
     * @brief 両眼開放/片眼遮蔽 の値を得る
     *
     * @retval string "bino" 両眼開放
     * @return string "mono" 片眼遮蔽
     */
    function _getSelectBinoMono() {
        return $("#btnMenuBinoMono").val();
    }

    /*!
     * @brief 片眼遮蔽 が選択されているか？
     *
     * @retval bool true  片眼遮蔽
     * @retval bool false 片眼遮蔽ではない
     */
    function _isSelectMono() {
        return "mono" === _getSelectBinoMono();
    }

    /*!
     * @brief クロスシリンダーの status を得る
     *
     * @param[in] array chartTable chartPage.parameter.json の chartPageN の単一要素
     * @return int クロスシリンダーの status
     */
    function _getCrossCylinderStatus(chartTable) {
  // if (becky.assertion.isUndefined(chartTable)) {
        //     return 0;
        // }
        switch (chartTable.examID) {
            case 1021: // [遠]ジャクソンクロスシリンダー
                break;
            case 2030: // [近]加入度測定
                return 3;
            default:
                return 0;
        }
        const currentSCA = _getSelectSCA();
        switch (currentSCA) {
            case "Cyl":
                // 度数検査
                return 2;
            case "Axs":
                // 軸検査
                return 1;
            default:
                becky.assertion.failure("unknown select type");
                return 0;
        }
    }

    /*!
     * @brief クロスシリンダーの power を得る
     *
     * @return int クロスシリンダーの power
     */
    function _getCrossCylinderPower() {
        const strDataValue = $("#btnMenuCC_Power").attr("data-value");
        const fDataValue = parseFloat(strDataValue);
        return fDataValue;
    }

    /*!
     * @brief クロスシリンダーのRG値を得る
     *
     * @param[in] array chartTable chartPage.parameter.json の chartPageN の単一要素
     * @return int クロスシリンダーのRG値
     */
    function _getCrossCylinderRG(chartTable) {
        // chartTable が指定されなかった場合は UI に設定されている状態のみで値を返す。
        // 指定されている場合は、検査の種類も考慮した値を返す。
        if (!modelHelper.isUndefined(chartTable)) {
            switch (chartTable.examID) {
                case 1021: // [遠]ジャクソンクロスシリンダー
                    break;
                default:
                    return 0;
            }
        }
        const strSelectIndex = $("#groupCrossCylinder").attr("data-select-index");
        const nSelectIndex = parseInt(strSelectIndex, 10);
        return nSelectIndex + 1;
    }

    /*!
     * @brief クロスシリンダーを得る(Phoropter 向け)
     *
     * @param[in] array chartTable chartPage.parameter.json の chartPageN の単一要素
     * @return int クロスシリンダーの値
     */
    function _getCrossCylinderByPhoropter(chartTable) {
        return {
            status: _getCrossCylinderStatus(chartTable),
            power: _getCrossCylinderPower(),
            RG: _getCrossCylinderRG(chartTable),
        };
    }

    /*!
     * @brief RGFilter 値を得る
     *
     * @param[in] array chartTable chartPage.parameter.json の chartPageN の単一要素
     * @return int RGFilter 値
     */
    function _getRGFilter(chartTable) {
        switch (chartTable.examID) {
            case 1010: // [遠]R/Gテスト
                return 1;
            default:
                return 0;
        }
    }

    /*!
     * @brief select-title クラスを持つ要素に対して更新を行う
     *
     * @param[in,out] element $selectTitle 対象のセレクタ
     */
    function _updateSelectTitle($selectTitle) {
        if (becky.assertion.isNullOrEmpty($selectTitle)) {
            return;
        }

        const val = $selectTitle.parents(".select-box").find(".select-selector").val();
        $selectTitle.find(".txt-select-title").text(val);
    }

    /*!
     * @brief メニューのステップの更新処理
     * MutationObserver 経由で呼ばれる
     * 
     * @param[in] Node aRecordTarget 対象のレコード
     * @param[in] string aMenuID 対象のメニューID
     */
    function _onUpdateHtmlMenuStep(aRecordTarget, aMenuID) {
        const value = aRecordTarget.dataset.value;
        const $currentItem = $("[data-for=" + aMenuID + "] [data-value='" + value + "']");
        $currentItem.addClass("current").siblings().removeClass("current");
        const itemText = $currentItem.text();
        $("#" + aMenuID + " > div").attr("data-text", itemText);
    }

    /*!
     * @brief 遠見/近見 をトグルした値を返す
     *
     * @param[in] string aVal 対象の値
     * @return string 対象をトグルした値
     */
    function _toggleVal_FarNear(aVal) {
        return _toggleVal_Base(aVal, ["far", "near"]);
    }

    /*!
     * @brief 遠見/近見 のラベルを更新する
     *
     * @param[in] Node aRecordTarget 対象のレコード
     */
    function _updateLblFarNear(aRecordTarget) {
        const val = aRecordTarget.value;
        const toggleVal = _toggleVal_FarNear(val);
        _toTextLarge($("#labelMenu_" + val));
        _toTextSmall($("#labelMenu_" + toggleVal));
        const text = viewHelper.getDefMessage("global/" + val);
        $("#labelHeaderCenter").text(text);
    }

    /*!
     * @brief 両眼開放/片眼遮蔽 をトグルした値を返す
     *
     * @param[in] string aVal 対象の値
     * @return string 対象をトグルした値
     */
    function _toggleVal_BinoMono(aVal) {
        return _toggleVal_Base(aVal, ["bino", "mono"]);
    }

    /*!
     * @brief 両眼開放/片眼遮蔽 のラベルを更新する
     *
     * @param[in] Node aRecordTarget 対象のレコード
     */
    function _updateLblBinoMono(aRecordTarget) {
        const val = aRecordTarget.value;
        const toggleVal = _toggleVal_BinoMono(val);
        _toTextLarge($("#labelMenu_" + val));
        _toTextSmall($("#labelMenu_" + toggleVal));
    }

    /*!
     * @brief 視力表の反転を解除
     */
    function _resetChartInvert() {
        $(".chart-table .image img").attr("style", "filter: Invert(0)");
        $(".chart-table .hitarea").attr("style", "filter: Invert(0)");
        $(".chart-table .top").attr("style", "filter: Invert(0)");
        $(".chart-table .side").attr("style", "filter: Invert(0)");
        $(".chart-table .bg").removeClass("bg-invert");
        //$(".chart-table .bg").removeClass("bg-rg");


    }

    /*!
     * @brief 視力表の RG を解除
     */
    function _resetChartRG() {
        $(".chart-table .bg").removeClass("bg-rg");
    }

    /*!
     * @brief 視力表の反転/RG ボタンの更新
     *
     * @param[in] array chartTable chartPage.parameter.json の chartPageN の単一要素
     */
    function _updateChartInvertAndRG(chartTable) {
        const chartParameterItem = becky.subjective.arrayChartParameter.chartParameter.filter(
            chartParameterItem_ => chartParameterItem_.chartID === chartTable.chartID)[0];
        if (becky.assertion.isUndefined(chartParameterItem)) {
            return;
        }

        let bInvert = false;
        let bRG = chartParameterItem.filterRG;


        const $btnInvert = $("#btnChartInvert");
        if (bInvert) {
            $btnInvert.show();
        } else {
            $btnInvert.hide();
            // 画像の背景スタイルも更新
            _resetChartInvert();
        }

        const $btnRG = $("#btnChartRG");
        if (bRG) {
            $btnRG.show();
        } else {
            $btnRG.hide();
            // 画像の背景スタイルも更新
            _resetChartRG();
        }
    }

    /*!
     * @brief 視力表テーブルのレイアウト更新
     *
     * @param[in] int totalColumnCount 列数
     * @param[in] int totalRowCount 行数
     */
    function _selectCurrentChart(chartTable) {
        _updateChartTableLayout(chartTable);
        _updateChartTable(chartTable);
        _updateControllerLayout(chartTable);
        _updateMenuInit(chartTable);
        _updateSelectSCA_FromChart(chartTable);
        // カレント更新
        _setCurrentChart(chartTable);
        const $tabContent = $("[data-auto-id=" + chartTable.autoID + "]");
        if (!modelHelper.isNull($tabContent)) {
            if (!$tabContent.hasClass("current")) {
                $("[data-auto-id]").removeClass("current");
                $tabContent.addClass("current");
                const $tabContentParent = $tabContent.parent();
                const tabIndex = $tabContentParent.parent().children().index($tabContentParent);
                if (tabIndex != $("#tabChart").attr("data-tab-index")) {
                    // 差がある場合のみ反映
                    $("#tabChart").attr("data-tab-index", tabIndex);
                }
            }
        }


    }

    function binoTestCalculation(examBinoResultID, Rvalue) {
        const updateDataJson = becky.WebStorage.local.getJson("subjective.update.data");
        var newBlurVal = 0;
        var BlurVarUnit = 0;
        const strSelectValL = $("#labelMainPrismHorL").attr("data-text");
        const strSelectValR = $("#labelMainPrismHorR").attr("data-text");
        const strSelectVerL = $("#labelMainPrismVerL").attr("data-text");
        const strSelectVerR = $("#labelMainPrismVerR").attr("data-text");
        const nSelectValL = parseFloat(strSelectValL);
        const nSelectValR = parseFloat(strSelectValR);
        const nSelectVerL = parseFloat(strSelectVerL);
        const nSelectVerR = parseFloat(strSelectVerR);
        var selectBI = " ";
        var selectBO = " ";
        var selectBU = " ";
        var selectBD = " ";
        selectBI = $(".prism-heading-inner-hor-R-BI").attr("data-text");
        selectBO = $(".prism-heading-inner-hor-L-BI").attr("data-text");
        selectBU = $(".prism-heading-inner-ver-R-BD").attr("data-text");
        selectBD = $(".prism-heading-inner-ver-L-BD").attr("data-text");
       
        /*For Horizontal */
        if ((selectBI == "BO " && selectBO == "BI ") || (selectBI == "BI " && selectBO == "BO ")) {
            
            if (nSelectValL > nSelectValR) {
                newBlurVal = (nSelectValL - nSelectValR);
                BlurVarUnit = selectBO;
                parseFloat(newBlurVal).toFixed(2);
            } else {
                newBlurVal = (nSelectValR - nSelectValL);
                parseFloat(newBlurVal).toFixed(2);
                BlurVarUnit = selectBI;
            }
        } else if ((selectBI == "BO " && selectBO == "BO ") || (selectBI == "BI " && selectBO == "BI ")) {
            newBlurVal = (nSelectValR + nSelectValL);
            parseFloat(newBlurVal).toFixed(2);
            BlurVarUnit = selectBI;
        }
        /*For Vertical */
        if ((selectBD == "BD " && selectBU == "BU ") || (selectBD == "BU " && selectBU == "BD ")) {
            {
                newBlurVal = (nSelectVerR + nSelectVerL);
                parseFloat(newBlurVal).toFixed(2);
                BlurVarUnit = selectBU;
                
            }

        } else if ((selectBD == "BD " && selectBU == "BD ") || (selectBD == "BU " && selectBU == "BU ")) {
            
            if (nSelectVerL > nSelectVerR) {
                newBlurVal = (nSelectVerL - nSelectVerR);
                parseFloat(newBlurVal).toFixed(2);
                BlurVarUnit = selectBU;
            } else {
                newBlurVal = (nSelectVerR - nSelectVerL);
                parseFloat(newBlurVal).toFixed(2);
                BlurVarUnit = selectBU;
            }
        }else if((selectBU == "BD " && selectBD == undefined)||(selectBU == "BD " && selectBD == " ")){
            newBlurVal = strSelectVerR;
            parseFloat(newBlurVal).toFixed(2);
                BlurVarUnit = "BD";
        }else if((selectBU == "BU " && selectBD == undefined)||(selectBU == "BU " && selectBD == " ")){
            newBlurVal = strSelectVerR;
            parseFloat(newBlurVal).toFixed(2);
                BlurVarUnit = "BU";
        }else if((selectBD == "BD " && selectBU == undefined)||(selectBD == "BD " && selectBU == " ")){
            
            newBlurVal = strSelectVerL;
            parseFloat(newBlurVal).toFixed(2);
                BlurVarUnit = "BU";
        }else if((selectBD == "BU " && selectBU == undefined)||(selectBD == "BU " && selectBU == " ")){
            
            newBlurVal = strSelectVerL;
            parseFloat(newBlurVal).toFixed(2);
                BlurVarUnit = "BD";
        }
      
           

        var testName = "bino" + examBinoResultID + "FHRR" + Rvalue;
        var testValueName = "bino" + examBinoResultID + "FHRR" + Rvalue + "unit";

        if (!modelHelper.isNullOrEmpty(updateDataJson)) {
            updateDataJson.binostate[testName] = newBlurVal;
            updateDataJson.binostate[testValueName] = BlurVarUnit;
            const webStorageIO = becky.WebStorage.local.IO("subjective.update.data");
            webStorageIO.setJson(updateDataJson);

        }

        var R1ButtonValues = {
            'newBlurVal': parseFloat(newBlurVal).toFixed(2),
            'BlurVarUnit': BlurVarUnit
        };


        return R1ButtonValues;
    };

    function _updateChartTableLayout(chartTable, totalColumnCount, totalRowCount) {
        const chartParameterItem = becky.subjective.arrayChartParameter.chartParameter.filter(
            chartParameterItem_ => chartParameterItem_.chartID === chartTable.chartID)[0];
        if (becky.assertion.isUndefined(chartParameterItem)) {
            return;
        }
        let one_letter = chartParameterItem.letter;
        let updown_nomask = chartParameterItem.noMaskOper.updown;
        let down_nomask = chartParameterItem.noMaskOper.down;
        let up_nomask = chartParameterItem.noMaskOper.up;
        let leftright_nomask = chartParameterItem.noMaskOper.leftright;
        let left_nomask = chartParameterItem.noMaskOper.left;
        let right_nomask = chartParameterItem.noMaskOper.right;
        let transnextChartID = chartParameterItem.transition.nextChartID;
        let transprevChartID = chartParameterItem.transition.prevChartID;


        // イベントの解除
        const top_side_div = ".chart-table .top div, .chart-table .side div";
        $(top_side_div).unbind();
        const hitarea_div = ".chart-table .hitarea div";
        $(hitarea_div).unbind();

        const $top = $(".chart-table .top"); { // 三角(下向き)
            const val = viewHelper.repeatString("<div>&#x25BC;</div>", totalColumnCount);
            $top.html(val);
        }

        const $up = $(".chart-shift .up"); { // 三角(下向き)
            const val = viewHelper.repeatString("<div>&#9650;</div>", 1);
            $up.html(val);
        }
        const $updummy = $(".chart-shift .updummy"); { // 三角(下向き)
            const val = viewHelper.repeatString("<div>&#9650;</div>", 1);
            $updummy.html(val);
        }
        const $down = $(".chart-shift .cursor-btn .down"); { // 三角(下向き)
            const val = viewHelper.repeatString("<div>&#9660;</div>", 1);
            $down.html(val);
        }
        const $downdummy = $(".chart-shift .cursor-btn .downdummy"); { // 三角(下向き)
            const val = viewHelper.repeatString("<div>&#9660;</div>", 1);
            $downdummy.html(val);
        }
        const $left = $(".chart-buttons .left"); { // 三角(下向き)
            const val = viewHelper.repeatString("<div>&#9664;</div>", 1);
            $left.html(val);
        }
        const $leftdummy = $(".chart-buttons .leftdummy"); { // 三角(下向き)
            const val = viewHelper.repeatString("<div>&#9664;</div>", 1);
            $leftdummy.html(val);
        }
        const $right = $(".chart-buttons .right"); { // 三角(下向き)
            const val = viewHelper.repeatString("<div>&#9654;</div>", 1);
            $right.html(val);
        }
        const $rightdummy = $(".chart-buttons .rightdummy"); { // 三角(下向き)
            const val = viewHelper.repeatString("<div>&#9654;</div>", 1);
            $rightdummy.html(val);
        }
        const $side = $(".chart-table .side"); { // 三角(右向き)
            const val = viewHelper.repeatString("<div>&#x25C0;</div>", totalRowCount);
            $side.html(val);
        }
        const $hitarea = $(".chart-table .hitarea"); {
            const val = viewHelper.repeatString('<div class="active"></div>', totalColumnCount * totalRowCount);
            $hitarea.html(val);
        }


        const singleWidth = $top.width() / totalColumnCount;
        const singleHeight = $side.height() / totalRowCount;

        $top.children().width(singleWidth);
        $side.children().height(singleHeight);
        $hitarea.children().width(singleWidth).height(singleHeight);

        // イベントの(再)登録
        /*Chart footer button functionalities for Coincidence H/V Test */
        //test
        
        // function defaultLabel(){
        //     $("#labelRLL").attr("data-text", " L>R 1.0");
        // };

        // $("#btnRLL").hover(function(){
        //     defaultLabel();
        //     } );
        //endtest
        function btnDLUDefault() {
            $("#labelDLUHalf").attr("data-text", " U>D 0.5");
            $("#labelUisD").attr("data-text", "U=D");
            $("#labelULDHalf").attr("data-text", "U < D 0.5");
            $("#labelULD").attr("data-text", "U < D 1.0");
            $("#btnDLUHalf").removeClass("activeButton");
            $("#btnUisD").removeClass("activeButton");
            $("#btnULDHalf").removeClass("activeButton");
            $("#btnULD").removeClass("activeButton");
        }

        function btnDLUHalfDefault() {
            $("#labelDLU").attr("data-text", " U>D 1.0");
            $("#labelUisD").attr("data-text", "U=D");
            $("#labelULDHalf").attr("data-text", "U < D 0.5");
            $("#labelULD").attr("data-text", "U < D 1.0");
            $("#btnDLU").removeClass("activeButton");
            $("#btnUisD").removeClass("activeButton");
            $("#btnULDHalf").removeClass("activeButton");
            $("#btnULD").removeClass("activeButton");
        }

        function btnUisDDefault() {
            $("#labelDLU").attr("data-text", " U>D 1.0");
            $("#labelDLUHalf").attr("data-text", " U>D 0.5");
            $("#labelULDHalf").attr("data-text", "U < D 0.5");
            $("#labelULD").attr("data-text", "U < D 1.0");
            $("#btnDLUHalf").removeClass("activeButton");
            $("#btnDLU").removeClass("activeButton");
            $("#btnULDHalf").removeClass("activeButton");
            $("#btnULD").removeClass("activeButton");
        }

        function btnULDHalfDefault() {
            $("#labelDLU").attr("data-text", " U>D 1.0");
            $("#labelDLUHalf").attr("data-text", " U>D 0.5");
            $("#labelUisD").attr("data-text", "U=D");
            $("#labelULD").attr("data-text", "U < D 1.0");
            $("#btnDLUHalf").removeClass("activeButton");
            $("#btnUisD").removeClass("activeButton");
            $("#btnDLU").removeClass("activeButton");
            $("#btnULD").removeClass("activeButton");
        }

        function btnULDDefault() {
            $("#labelDLU").attr("data-text", " U>D 1.0");
            $("#labelDLUHalf").attr("data-text", " U>D 0.5");
            $("#labelUisD").attr("data-text", "U=D");
            $("#labelULDHalf").attr("data-text", "U < D 0.5");
            $("#btnDLUHalf").removeClass("activeButton");
            $("#btnUisD").removeClass("activeButton");
            $("#btnULDHalf").removeClass("activeButton");
            $("#btnDLU").removeClass("activeButton");
        }

        function btnRLLDefault() {
            $("#labelRLLHalf").attr("data-text", " L>R 0.5");
            $("#labelLisR").attr("data-text", "L=R");
            $("#labelLLRHalf").attr("data-text", "L < R 0.5");
            $("#labelLLR").attr("data-text", "L < R 1.0");
            $("#btnRLLhalf").removeClass("activeButton");
            $("#btnLisR").removeClass("activeButton");
            $("#btnLLRHalf").removeClass("activeButton");
            $("#btnLLR").removeClass("activeButton");
        }

        function btnRLLhalfDefault() {
            $("#labelRLL").attr("data-text", " L>R 1.0");
            $("#labelLisR").attr("data-text", "L=R");
            $("#labelLLRHalf").attr("data-text", "L < R 0.5");
            $("#labelLLR").attr("data-text", "L < R 1.0");
            $("#btnRLL").removeClass("activeButton");
            $("#btnLisR").removeClass("activeButton");
            $("#btnLLRHalf").removeClass("activeButton");
            $("#btnLLR").removeClass("activeButton");
        }

        function btnLisRDefault() {
            $("#labelRLL").attr("data-text", " L>R 1.0");
            $("#labelRLLHalf").attr("data-text", " L>R 0.5");
            $("#labelLLRHalf").attr("data-text", "L < R 0.5");
            $("#labelLLR").attr("data-text", "L < R 1.0");
            $("#btnRLL").removeClass("activeButton");
            $("#btnRLLhalf").removeClass("activeButton");
            $("#btnLLRHalf").removeClass("activeButton");
            $("#btnLLR").removeClass("activeButton");
        }

        function btnLLRHalfDefault() {
            $("#labelRLL").attr("data-text", " L>R 1.0");
            $("#labelRLLHalf").attr("data-text", " L>R 0.5");
            $("#labelLisR").attr("data-text", "L=R");
            $("#labelLLR").attr("data-text", "L < R 1.0");
            $("#btnRLL").removeClass("activeButton");
            $("#btnRLLhalf").removeClass("activeButton");
            $("#btnLisR").removeClass("activeButton");
            $("#btnLLR").removeClass("activeButton");
        }

        function btnLLRDefault() {
            $("#labelRLL").attr("data-text", " L>R 1.0");
            $("#labelRLLHalf").attr("data-text", " L>R 0.5");
            $("#labelLisR").attr("data-text", "L=R");
            $("#labelLLRHalf").attr("data-text", "L < R 0.5");
            $("#btnRLL").removeClass("activeButton");
            $("#btnRLLhalf").removeClass("activeButton");
            $("#btnLisR").removeClass("activeButton");
            $("#btnLLRHalf").removeClass("activeButton");
        }

        $("#btnRLL").unbind().click(function () {
            $("#btnRLL").addClass("activeButton");
            const chartindex = Number(localStorage['chartindex']);
            const chartParameterItem = becky.subjective.arrayChartParameter.chartParameter.filter(
                chartParameterItem_ => chartParameterItem_.chartID === chartindex)[0];
            if (becky.assertion.isUndefined(chartParameterItem)) {
                return;
            }
            const newBlurVal = "R<L 7";
            const BlurVarUnit = "%";
            const farNearId = chartParameterItem.IsNearFar;
            const examBinoResultID = chartParameterItem.examBinoResultID;
            const updateDataJson = becky.WebStorage.local.getJson("subjective.update.data");
            if (farNearId == 'F' || farNearId == 'FN') {
                var testName = "bino" + examBinoResultID + "FHRR1";
                var testValueName = "bino" + examBinoResultID + "FHRR1" + "unit";
            }
            if (farNearId == 'N') {
                var testName = "bino" + examBinoResultID + "NHRR1";
                var testValueName = "bino" + examBinoResultID + "NHRR1" + "unit";
            }
          //  const btnBlurredBI = binoTestCalculation(examBinoResultID, Rvalue);
            if (!modelHelper.isNullOrEmpty(updateDataJson)) {
                updateDataJson.binostate[testName] = newBlurVal;
                updateDataJson.binostate[testValueName] = BlurVarUnit;
                const webStorageIO = becky.WebStorage.local.IO("subjective.update.data");
                webStorageIO.setJson(updateDataJson);

            }

            //$("#labelRLL").attr("data-text", newBlurVal + " " + BlurVarUnit);
            btnRLLDefault();
        });
        $("#btnRLLhalf").unbind().click(function () {
            $("#btnRLLhalf").addClass("activeButton");
            const chartindex = Number(localStorage['chartindex']);
            const chartParameterItem = becky.subjective.arrayChartParameter.chartParameter.filter(
                chartParameterItem_ => chartParameterItem_.chartID === chartindex)[0];
            if (becky.assertion.isUndefined(chartParameterItem)) {
                return;
            }
            const newBlurVal = "R<L 3.5";
            const BlurVarUnit = "%";
            const examBinoResultID = chartParameterItem.examBinoResultID;
            const updateDataJson = becky.WebStorage.local.getJson("subjective.update.data");
            const farNearId = chartParameterItem.IsNearFar;
            if (farNearId == 'F' || farNearId == 'FN') {
                var testName = "bino" + examBinoResultID + "FHRR1";
                var testValueName = "bino" + examBinoResultID + "FHRR1" + "unit";
            }
            if (farNearId == 'N') {
                var testName = "bino" + examBinoResultID + "NHRR1";
                var testValueName = "bino" + examBinoResultID + "NHRR1" + "unit";
            }
            if (!modelHelper.isNullOrEmpty(updateDataJson)) {
                updateDataJson.binostate[testName] = newBlurVal;
                updateDataJson.binostate[testValueName] = BlurVarUnit;
                const webStorageIO = becky.WebStorage.local.IO("subjective.update.data");
                webStorageIO.setJson(updateDataJson);

            }

            // $("#labelRLLHalf").attr("data-text", newBlurVal + " " + BlurVarUnit);
            btnRLLhalfDefault();
        });
        $("#btnLisR").unbind().click(function () {
            $("#btnLisR").addClass("activeButton");
            const chartindex = Number(localStorage['chartindex']);
            const chartParameterItem = becky.subjective.arrayChartParameter.chartParameter.filter(
                chartParameterItem_ => chartParameterItem_.chartID === chartindex)[0];
            if (becky.assertion.isUndefined(chartParameterItem)) {
                return;
            }
            const newBlurVal = "R=L";
            const BlurVarUnit = "%";
            const examBinoResultID = chartParameterItem.examBinoResultID;
            const updateDataJson = becky.WebStorage.local.getJson("subjective.update.data");
            const farNearId = chartParameterItem.IsNearFar;
            if (farNearId == 'F' || farNearId == 'FN') {
                var testName = "bino" + examBinoResultID + "FHRR1";
                var testValueName = "bino" + examBinoResultID + "FHRR1" + "unit";
            }
            if (farNearId == 'N') {
                var testName = "bino" + examBinoResultID + "NHRR1";
                var testValueName = "bino" + examBinoResultID + "NHRR1" + "unit";
            }
                      
            if (!modelHelper.isNullOrEmpty(updateDataJson)) {
                updateDataJson.binostate[testName] = newBlurVal;
                updateDataJson.binostate[testValueName] = BlurVarUnit;
                const webStorageIO = becky.WebStorage.local.IO("subjective.update.data");
                webStorageIO.setJson(updateDataJson);

            }

            // $("#labelLisR").attr("data-text", newBlurVal + " " + BlurVarUnit);
            btnLisRDefault();
        });
        $("#btnLLRHalf").unbind().click(function () {
            $("#btnLLRHalf").addClass("activeButton");
            const chartindex = Number(localStorage['chartindex']);
            const chartParameterItem = becky.subjective.arrayChartParameter.chartParameter.filter(
                chartParameterItem_ => chartParameterItem_.chartID === chartindex)[0];
            if (becky.assertion.isUndefined(chartParameterItem)) {
                return;
            }
            const newBlurVal = "R>L 3.5";
            const BlurVarUnit = "%";
            const examBinoResultID = chartParameterItem.examBinoResultID;
            const updateDataJson = becky.WebStorage.local.getJson("subjective.update.data");
            const farNearId = chartParameterItem.IsNearFar;
            if (farNearId == 'F' || farNearId == 'FN') {
                var testName = "bino" + examBinoResultID + "FHRR1";
                var testValueName = "bino" + examBinoResultID + "FHRR1" + "unit";
            }
            if (farNearId == 'N') {
                var testName = "bino" + examBinoResultID + "NHRR1";
                var testValueName = "bino" + examBinoResultID + "NHRR1" + "unit";
            }
            //const btnBlurredBI = binoTestCalculation(examBinoResultID, Rvalue);
            if (!modelHelper.isNullOrEmpty(updateDataJson)) {
                updateDataJson.binostate[testName] = newBlurVal;
                updateDataJson.binostate[testValueName] = BlurVarUnit;
                const webStorageIO = becky.WebStorage.local.IO("subjective.update.data");
                webStorageIO.setJson(updateDataJson);

            }

            // $("#labelLLRHalf").attr("data-text", newBlurVal + " " + BlurVarUnit);
            btnLLRHalfDefault();
        });
        $("#btnLLR").unbind().click(function () {
            $("#btnLLR").addClass("activeButton");
            const chartindex = Number(localStorage['chartindex']);
            const chartParameterItem = becky.subjective.arrayChartParameter.chartParameter.filter(
                chartParameterItem_ => chartParameterItem_.chartID === chartindex)[0];
            if (becky.assertion.isUndefined(chartParameterItem)) {
                return;
            }
            const newBlurVal = "R>L 7";
            const BlurVarUnit = "%";
            const examBinoResultID = chartParameterItem.examBinoResultID;
            const updateDataJson = becky.WebStorage.local.getJson("subjective.update.data");
            const farNearId = chartParameterItem.IsNearFar;
            if (farNearId == 'F' || farNearId == 'FN') {
                var testName = "bino" + examBinoResultID + "FHRR1";
                var testValueName = "bino" + examBinoResultID + "FHRR1" + "unit";
            }
            if (farNearId == 'N') {
                var testName = "bino" + examBinoResultID + "NHRR1";
                var testValueName = "bino" + examBinoResultID + "NHRR1" + "unit";
            }
            //const btnBlurredBI = binoTestCalculation(examBinoResultID, Rvalue);
            if (!modelHelper.isNullOrEmpty(updateDataJson)) {
                updateDataJson.binostate[testName] = newBlurVal;
                updateDataJson.binostate[testValueName] = BlurVarUnit;
                const webStorageIO = becky.WebStorage.local.IO("subjective.update.data");
                webStorageIO.setJson(updateDataJson);

            }

            // $("#labelLLR").attr("data-text", newBlurVal + " " + BlurVarUnit);
            btnLLRDefault();
        });
        $("#btnDLU").unbind().click(function () {
            $("#btnDLU").addClass("activeButton");
            const chartindex = Number(localStorage['chartindex']);
            const chartParameterItem = becky.subjective.arrayChartParameter.chartParameter.filter(
                chartParameterItem_ => chartParameterItem_.chartID === chartindex)[0];
            if (becky.assertion.isUndefined(chartParameterItem)) {
                return;
            }
            const newBlurVal = "R>L 7";
            const BlurVarUnit = "%";
            const examBinoResultID = chartParameterItem.examBinoResultID;
            const updateDataJson = becky.WebStorage.local.getJson("subjective.update.data");
            const farNearId = chartParameterItem.IsNearFar;
            if (farNearId == 'F' || farNearId == 'FN') {
                var testName = "bino" + examBinoResultID + "FHRR1";
                var testValueName = "bino" + examBinoResultID + "FHRR1" + "unit";
            }
            if (farNearId == 'N') {
                var testName = "bino" + examBinoResultID + "NHRR1";
                var testValueName = "bino" + examBinoResultID + "NHRR1" + "unit";
            }
            //const btnBlurredBI = binoTestCalculation(examBinoResultID, Rvalue);
            if (!modelHelper.isNullOrEmpty(updateDataJson)) {
                updateDataJson.binostate[testName] = newBlurVal;
                updateDataJson.binostate[testValueName] = BlurVarUnit;
                const webStorageIO = becky.WebStorage.local.IO("subjective.update.data");
                webStorageIO.setJson(updateDataJson);

            }

            // $("#labelDLU").attr("data-text", newBlurVal + " " + BlurVarUnit);
            btnDLUDefault();
        });
        $("#btnDLUHalf").unbind().click(function () {
            $("#btnDLUHalf").addClass("activeButton");
            const chartindex = Number(localStorage['chartindex']);
            const chartParameterItem = becky.subjective.arrayChartParameter.chartParameter.filter(
                chartParameterItem_ => chartParameterItem_.chartID === chartindex)[0];
            if (becky.assertion.isUndefined(chartParameterItem)) {
                return;
            }
            const newBlurVal = "R>L 3.5";
            const BlurVarUnit = "%";
            const examBinoResultID = chartParameterItem.examBinoResultID;
            const updateDataJson = becky.WebStorage.local.getJson("subjective.update.data");
            const farNearId = chartParameterItem.IsNearFar;
            if (farNearId == 'F' || farNearId == 'FN') {
                var testName = "bino" + examBinoResultID + "FHRR1";
                var testValueName = "bino" + examBinoResultID + "FHRR1" + "unit";
            }
            if (farNearId == 'N') {
                var testName = "bino" + examBinoResultID + "NHRR1";
                var testValueName = "bino" + examBinoResultID + "NHRR1" + "unit";
            }
            if (!modelHelper.isNullOrEmpty(updateDataJson)) {
                updateDataJson.binostate[testName] = newBlurVal;
                updateDataJson.binostate[testValueName] = BlurVarUnit;
                const webStorageIO = becky.WebStorage.local.IO("subjective.update.data");
                webStorageIO.setJson(updateDataJson);

            }
            // $("#labelDLUHalf").attr("data-text", newBlurVal + " " + BlurVarUnit);
            btnDLUHalfDefault();
        });
        $("#btnUisD").unbind().click(function () {
            $("#btnUisD").addClass("activeButton");
            const chartindex = Number(localStorage['chartindex']);
            const chartParameterItem = becky.subjective.arrayChartParameter.chartParameter.filter(
                chartParameterItem_ => chartParameterItem_.chartID === chartindex)[0];
            if (becky.assertion.isUndefined(chartParameterItem)) {
                return;
            }
            const newBlurVal = "R=L";
            const BlurVarUnit = "";
            const examBinoResultID = chartParameterItem.examBinoResultID;
            const updateDataJson = becky.WebStorage.local.getJson("subjective.update.data");
            const farNearId = chartParameterItem.IsNearFar;
            if (farNearId == 'F' || farNearId == 'FN') {
                var testName = "bino" + examBinoResultID + "FHRR1";
                var testValueName = "bino" + examBinoResultID + "FHRR1" + "unit";
            }
            if (farNearId == 'N') {
                var testName = "bino" + examBinoResultID + "NHRR1";
                var testValueName = "bino" + examBinoResultID + "NHRR1" + "unit";
            }
            if (!modelHelper.isNullOrEmpty(updateDataJson)) {
                updateDataJson.binostate[testName] = newBlurVal;
                updateDataJson.binostate[testValueName] = BlurVarUnit;
                const webStorageIO = becky.WebStorage.local.IO("subjective.update.data");
                webStorageIO.setJson(updateDataJson);

            }
            // $("#labelUisD").attr("data-text", newBlurVal + " " + BlurVarUnit);
            btnUisDDefault();
        });
        $("#btnULDHalf").unbind().click(function () {
            $("#btnULDHalf").addClass("activeButton");
            const chartindex = Number(localStorage['chartindex']);
            const chartParameterItem = becky.subjective.arrayChartParameter.chartParameter.filter(
                chartParameterItem_ => chartParameterItem_.chartID === chartindex)[0];
            if (becky.assertion.isUndefined(chartParameterItem)) {
                return;
            }
            const newBlurVal = "R<L 3.5";
            const BlurVarUnit = "%";
            const examBinoResultID = chartParameterItem.examBinoResultID;
            const updateDataJson = becky.WebStorage.local.getJson("subjective.update.data");
            const farNearId = chartParameterItem.IsNearFar;
            if (farNearId == 'F' || farNearId == 'FN') {
                var testName = "bino" + examBinoResultID + "FHRR1";
                var testValueName = "bino" + examBinoResultID + "FHRR1" + "unit";
            }
            if (farNearId == 'N') {
                var testName = "bino" + examBinoResultID + "NHRR1";
                var testValueName = "bino" + examBinoResultID + "NHRR1" + "unit";
            }
            if (!modelHelper.isNullOrEmpty(updateDataJson)) {
                updateDataJson.binostate[testName] = newBlurVal;
                updateDataJson.binostate[testValueName] = BlurVarUnit;
                const webStorageIO = becky.WebStorage.local.IO("subjective.update.data");
                webStorageIO.setJson(updateDataJson);

            }
            // $("#labelULDHalf").attr("data-text", newBlurVal + " " + BlurVarUnit);
            btnULDHalfDefault();


        });
        $("#btnULD").unbind().click(function () {
            $("#btnULD").addClass("activeButton");
            const chartindex = Number(localStorage['chartindex']);
            const chartParameterItem = becky.subjective.arrayChartParameter.chartParameter.filter(
                chartParameterItem_ => chartParameterItem_.chartID === chartindex)[0];
            if (becky.assertion.isUndefined(chartParameterItem)) {
                return;
            }
            const newBlurVal = "R<L 7";
            const BlurVarUnit = "%";
            const examBinoResultID = chartParameterItem.examBinoResultID;
            const updateDataJson = becky.WebStorage.local.getJson("subjective.update.data");
            const farNearId = chartParameterItem.IsNearFar;
            if (farNearId == 'F' || farNearId == 'FN') {
                var testName = "bino" + examBinoResultID + "FHRR1";
                var testValueName = "bino" + examBinoResultID + "FHRR1" + "unit";
            }
            if (farNearId == 'N') {
                var testName = "bino" + examBinoResultID + "NHRR1";
                var testValueName = "bino" + examBinoResultID + "NHRR1" + "unit";
            }
            if (!modelHelper.isNullOrEmpty(updateDataJson)) {
                updateDataJson.binostate[testName] = newBlurVal;
                updateDataJson.binostate[testValueName] = BlurVarUnit;
                const webStorageIO = becky.WebStorage.local.IO("subjective.update.data");
                webStorageIO.setJson(updateDataJson);

            }
          // $("#labelULD").attr("data-text", newBlurVal + " " + BlurVarUnit);
            btnULDDefault();

        });
        $("#btnBlurredBI").unbind().click(function () {
            const chartindex = Number(localStorage['chartindex']);
            const chartParameterItem = becky.subjective.arrayChartParameter.chartParameter.filter(
                chartParameterItem_ => chartParameterItem_.chartID === chartindex)[0];
            // if (becky.assertion.isUndefined(chartParameterItem)) {
            //     return;
            // }
            const examBinoResultID = chartParameterItem.examBinoResultID;
            const Rvalue = "4";
            const btnBlurredBI = binoTestCalculation(examBinoResultID, Rvalue);

            $("#labelABI").attr("data-text", btnBlurredBI.newBlurVal + " " + btnBlurredBI.BlurVarUnit);
                

        });
        $("#btnBreakBI").unbind().click(function () {
            // $("#btnBreakBI").css({"background-color": "#F2A60D","color": "black","border":"1px solid black"})
            const chartindex = Number(localStorage['chartindex']);
            const chartParameterItem = becky.subjective.arrayChartParameter.chartParameter.filter(
                chartParameterItem_ => chartParameterItem_.chartID === chartindex)[0];
            if (becky.assertion.isUndefined(chartParameterItem)) {
                return;
            }
            const examBinoResultID = chartParameterItem.examBinoResultID;
            const Rvalue = "5";
            const btnBreakBI = binoTestCalculation(examBinoResultID, Rvalue);
            $("#labelABR").attr("data-text", btnBreakBI.newBlurVal + " " + btnBreakBI.BlurVarUnit);
            $("#dummyShiftImageR").hide();
            $("#dummyShiftImageL").show();

        });
        $("#btnBreakBI2").unbind().click(function () {
            // $("#btnBreakBI").css({"background-color": "#F2A60D","color": "black","border":"1px solid black"})
            const chartindex = Number(localStorage['chartindex']);
            const chartParameterItem = becky.subjective.arrayChartParameter.chartParameter.filter(
                chartParameterItem_ => chartParameterItem_.chartID === chartindex)[0];
            if (becky.assertion.isUndefined(chartParameterItem)) {
                return;
            }
            const examBinoResultID = chartParameterItem.examBinoResultID;
            const Rvalue = "5";
            const btnBreakBI = binoTestCalculation(examBinoResultID, Rvalue);
            $("#labelABR2").attr("data-text", btnBreakBI.newBlurVal + " " + btnBreakBI.BlurVarUnit);
            $("#dummyShiftImageR").hide();
            $("#dummyShiftImageL").show();

        });
        $("#btnRecoveryBI").unbind().click(function () {
            // $("#btnRecoveryBI").css({"background-color": "#F2A60D","color": "black","border":"1px solid black"})
            const chartindex = Number(localStorage['chartindex']);
            const chartParameterItem = becky.subjective.arrayChartParameter.chartParameter.filter(
                chartParameterItem_ => chartParameterItem_.chartID === chartindex)[0];
            if (becky.assertion.isUndefined(chartParameterItem)) {
                return;
            }
            const examBinoResultID = chartParameterItem.examBinoResultID;
            const Rvalue = "6";
            const btnBlurredBI = binoTestCalculation(examBinoResultID, Rvalue);
            $("#labelAR").attr("data-text", btnBlurredBI.newBlurVal + " " + btnBlurredBI.BlurVarUnit);
            $("#dummyShiftImageR").hide();
            $("#dummyShiftImageL").show();

        });
        $("#btnRecoveryBI2").unbind().click(function () {
            // $("#btnRecoveryBI").css({"background-color": "#F2A60D","color": "black","border":"1px solid black"})
            const chartindex = Number(localStorage['chartindex']);
            const chartParameterItem = becky.subjective.arrayChartParameter.chartParameter.filter(
                chartParameterItem_ => chartParameterItem_.chartID === chartindex)[0];
            if (becky.assertion.isUndefined(chartParameterItem)) {
                return;
            }
            const examBinoResultID = chartParameterItem.examBinoResultID;
            const Rvalue = "6";
            const btnBlurredBI = binoTestCalculation(examBinoResultID, Rvalue);
            $("#labelAR2").attr("data-text", btnBlurredBI.newBlurVal + " " + btnBlurredBI.BlurVarUnit);
            $("#dummyShiftImageR").hide();
            $("#dummyShiftImageL").show();

        });
        $("#btnBlurredBO").unbind().click(function () {
            //  $("#btnBlurredBO").css({"background-color": "#F2A60D","color": "black","border":"1px solid black"})
            const chartindex = Number(localStorage['chartindex']);
            const chartParameterItem = becky.subjective.arrayChartParameter.chartParameter.filter(
                chartParameterItem_ => chartParameterItem_.chartID === chartindex)[0];
            if (becky.assertion.isUndefined(chartParameterItem)) {
                return;
            }
            const examBinoResultID = chartParameterItem.examBinoResultID;
            const Rvalue = "1";
            const btnBlurredBI = binoTestCalculation(examBinoResultID, Rvalue);
            $("#labelABO").attr("data-text", btnBlurredBI.newBlurVal + " " + btnBlurredBI.BlurVarUnit);
           

        });
        $("#btnBlurredBO2").unbind().click(function () {
            //  $("#btnBlurredBO").css({"background-color": "#F2A60D","color": "black","border":"1px solid black"})
            const chartindex = Number(localStorage['chartindex']);
            const chartParameterItem = becky.subjective.arrayChartParameter.chartParameter.filter(
                chartParameterItem_ => chartParameterItem_.chartID === chartindex)[0];
            if (becky.assertion.isUndefined(chartParameterItem)) {
                return;
            }
            const examBinoResultID = chartParameterItem.examBinoResultID;
            const Rvalue = "1";
            const btnBlurredBI = binoTestCalculation(examBinoResultID, Rvalue);
            $("#labelABO2").attr("data-text", btnBlurredBI.newBlurVal + " " + btnBlurredBI.BlurVarUnit);


        });
        
        
        
        $("#prismClear").unbind().click(function () {
            const chartindex = Number(localStorage['chartindex']);
            const chartParameterItem = becky.subjective.arrayChartParameter.chartParameter.filter(
            chartParameterItem_ => chartParameterItem_.chartID === chartindex)[0];
            const updateDataJson = becky.WebStorage.local.getJson("subjective.update.data");
            var farNearId = chartParameterItem.IsNearFar;
            var valBinoType = chartParameterItem.examBinoResultID;
            $("#labelMainPrismHorR").attr("data-text", "0.00");
            $("#labelMainPrismHorL").attr("data-text", "0.00");
            $("#labelMainPrismVerR").attr("data-text", "0.00");
            $("#labelMainPrismVerL").attr("data-text", "0.00");
            $(".prism-heading-inner-hor-R-BI").attr("data-text", " ");
                $(".prism-heading-inner-hor-L-BI").attr("data-text", " ");
                $(".prism-heading-inner-ver-R-BD").attr("data-text", " ");
                $(".prism-heading-inner-ver-L-BD").attr("data-text", " ");
                var testName1 = "bino" + valBinoType + farNearId + "HR";
                var testName2 = "bino" + valBinoType + farNearId + "HL";
                var testName3 = "bino" + valBinoType + farNearId + "VR";
                var testName4 = "bino" + valBinoType + farNearId + "VL";
                if (!modelHelper.isNullOrEmpty(updateDataJson)) {
                    updateDataJson.binostate[testName1] = "0.0";
                    updateDataJson.binostate[testName2] = "0.0";
                    updateDataJson.binostate[testName3] = "0.0";
                    updateDataJson.binostate[testName4] = "0.0";
                    const webStorageIO = becky.WebStorage.local.IO("subjective.update.data");
                    webStorageIO.setJson(updateDataJson);
                }
           
            
           
        });
        $("#btnDataClear").unbind().click(function () {
            const chartindex = Number(localStorage['chartindex']);
            const chartParameterItem = becky.subjective.arrayChartParameter.chartParameter.filter(
            chartParameterItem_ => chartParameterItem_.chartID === chartindex)[0];
            const updateDataJson = becky.WebStorage.local.getJson("subjective.update.data");
            var farNearId = chartParameterItem.IsNearFar;
            var valBinoType = chartParameterItem.examBinoResultID;
            $("#labelMainPrismHorR").attr("data-text", "0.00");
            $("#labelMainPrismHorL").attr("data-text", "0.00");
            $("#labelMainPrismVerR").attr("data-text", "0.00");
            $("#labelMainPrismVerL").attr("data-text", "0.00");
            $(".prism-heading-inner-hor-R-BI").attr("data-text", " ");
            $(".prism-heading-inner-hor-L-BI").attr("data-text", " ");
            $(".prism-heading-inner-ver-R-BD").attr("data-text", " ");
            $(".prism-heading-inner-ver-L-BD").attr("data-text", " ");
           
            var testName1 = "bino" + valBinoType + farNearId + "HR";
            var testName2 = "bino" + valBinoType + farNearId + "HL";
            var testName3 = "bino" + valBinoType + farNearId + "VR";
            var testName4 = "bino" + valBinoType + farNearId + "VL";
           
            $("#labelABI2").attr("data-text", "Blurred (BI)");
            $("#labelABR2").attr("data-text", "Break (BI)");
            $("#labelAR2").attr("data-text", "Recovery (BI)");
            $("#labelABO2").attr("data-text", "Blurred (BO)");
            $("#labelABRO2").attr("data-text", "Break (BO)");
            $("#labelARO2").attr("data-text", "Recovery (BO)");

            if (!modelHelper.isNullOrEmpty(updateDataJson)) {
                updateDataJson.binostate[testName1] = "0.0";
                updateDataJson.binostate[testName2] = "0.0";
                updateDataJson.binostate[testName3] = "0.0";
                updateDataJson.binostate[testName4] = "0.0";
                
                
                const webStorageIO = becky.WebStorage.local.IO("subjective.update.data");
                webStorageIO.setJson(updateDataJson);
            }
           
            
           
        });
        $("#btnDataClear1").unbind().click(function () {
         
           
            const chartindex = Number(localStorage['chartindex']);
            const chartParameterItem = becky.subjective.arrayChartParameter.chartParameter.filter(
                chartParameterItem_ => chartParameterItem_.chartID === chartindex)[0];
            if (becky.assertion.isUndefined(chartParameterItem)) {
                return;
            }
           
            const examBinoResultID = chartParameterItem.examBinoResultID;
            const updateDataJson = becky.WebStorage.local.getJson("subjective.update.data");
            const farNearId = chartParameterItem.IsNearFar;
            if (farNearId == 'F' || farNearId == 'FN') {
                var testName = "bino" + examBinoResultID + "FHRR1";
                
            }
            if (farNearId == 'N') {
                var testName = "bino" + examBinoResultID + "NHRR1";
                
            }
            if (!modelHelper.isNullOrEmpty(updateDataJson)) {
                updateDataJson.binostate[testName] = "0.0";
                
                const webStorageIO = becky.WebStorage.local.IO("subjective.update.data");
                webStorageIO.setJson(updateDataJson);

            }
           
            $("#btnDLU").removeClass("activeButton");
            $("#btnDLUHalf").removeClass("activeButton");
	        $("#btnUisD").removeClass("activeButton");
            $("#btnULDHalf").removeClass("activeButton");
            $("#btnULD").removeClass("activeButton");
        });
        $("#btnDataClear2").unbind().click(function () {
            const chartindex = Number(localStorage['chartindex']);
            const chartParameterItem = becky.subjective.arrayChartParameter.chartParameter.filter(
                chartParameterItem_ => chartParameterItem_.chartID === chartindex)[0];
            if (becky.assertion.isUndefined(chartParameterItem)) {
                return;
            }
           
            const examBinoResultID = chartParameterItem.examBinoResultID;
            const updateDataJson = becky.WebStorage.local.getJson("subjective.update.data");
            const farNearId = chartParameterItem.IsNearFar;
            if (farNearId == 'F' || farNearId == 'FN') {
                var testName = "bino" + examBinoResultID + "FHRR1";
                
            }
            if (farNearId == 'N') {
                var testName = "bino" + examBinoResultID + "NHRR1";
                
            }
            if (!modelHelper.isNullOrEmpty(updateDataJson)) {
                updateDataJson.binostate[testName] = "0.0";
                
                const webStorageIO = becky.WebStorage.local.IO("subjective.update.data");
                webStorageIO.setJson(updateDataJson);

            }


            $("#btnRLL").removeClass("activeButton");
            $("#btnRLLhalf").removeClass("activeButton");
            $("#btnLisR").removeClass("activeButton");
            $("#btnLLRHalf").removeClass("activeButton");
            $("#btnLLR").removeClass("activeButton");
        });
        
       
        $("#btnDataClear4").unbind().click(function () {
            const chartindex = Number(localStorage['chartindex']);
            const chartParameterItem = becky.subjective.arrayChartParameter.chartParameter.filter(
                chartParameterItem_ => chartParameterItem_.chartID === chartindex)[0];
                var farNearId = chartParameterItem.IsNearFar;
                var valBinoType = chartParameterItem.examBinoResultID;
               
                    $("#labelMainPrismHorR").attr("data-text", "0.00");
                    $("#labelMainPrismHorL").attr("data-text", "0.00");
                    $("#labelMainPrismVerR").attr("data-text", "0.00");
                    $("#labelMainPrismVerL").attr("data-text", "0.00");
                    $(".prism-heading-inner-hor-R-BI").attr("data-text", " ");
                    $(".prism-heading-inner-hor-L-BI").attr("data-text", " ");
                    $(".prism-heading-inner-ver-R-BD").attr("data-text", " ");
                    $(".prism-heading-inner-ver-L-BD").attr("data-text", " ");
    
                
            $("#labelABI").attr("data-text", "Blurred (BI)");
            $("#labelABR").attr("data-text", "Break (BI)");
            $("#labelAR").attr("data-text", "Recovery (BI)");
            $("#labelABO").attr("data-text", "Blurred (BO)");
            $("#labelABRO").attr("data-text", "Break (BO)");
            $("#labelARO").attr("data-text", "Recovery (BO)");
            var testName1 = "bino" + valBinoType + farNearId + "HR";
            var testName2 = "bino" + valBinoType + farNearId + "HL";
            var testName3 = "bino" + valBinoType + farNearId + "VR";
            var testName4 = "bino" + valBinoType + farNearId + "VL";
            
            if (!modelHelper.isNullOrEmpty(updateDataJson)) {
                updateDataJson.binostate[testName1] = "0.0";
                updateDataJson.binostate[testName2] = "0.0";
                updateDataJson.binostate[testName3] = "0.0";
                updateDataJson.binostate[testName4] = "0.0";
                
                const webStorageIO = becky.WebStorage.local.IO("subjective.update.data");
                webStorageIO.setJson(updateDataJson);
            }
         
           
        });
        $("#btnDataClear5").unbind().click(function () {
            const chartindex = Number(localStorage['chartindex']);
            const chartParameterItem = becky.subjective.arrayChartParameter.chartParameter.filter(
                chartParameterItem_ => chartParameterItem_.chartID === chartindex)[0];
                var farNearId = chartParameterItem.IsNearFar;
                var valBinoType = chartParameterItem.examBinoResultID;
               
                    $(".prism-heading-inner-hor-R-BI").attr("data-text", " ");
                    $(".prism-heading-inner-hor-L-BI").attr("data-text", " ");
                    $(".prism-heading-inner-ver-R-BD").attr("data-text", " ");
                    $(".prism-heading-inner-ver-L-BD").attr("data-text", " ");
                    $("#labelMainPrismHorR").attr("data-text", "0.00");
                    $("#labelMainPrismHorL").attr("data-text", "0.00");
                    $("#labelMainPrismVerR").attr("data-text", "0.00");
                    $("#labelMainPrismVerL").attr("data-text", "0.00");
    
               
            $("#labelBreakBU").attr("data-text", "Break (BU)");
            $("#labelRecoveryBU").attr("data-text", "Recovery (BU)");
            $("#labelBreakBD").attr("data-text", "Break (BD)");
            $("#labelRecoveryBD").attr("data-text", "Recovery (BD)");
            var testName1 = "bino" + valBinoType + farNearId + "HR";
            var testName2 = "bino" + valBinoType + farNearId + "HL";
            var testName3 = "bino" + valBinoType + farNearId + "VR";
            var testName4 = "bino" + valBinoType + farNearId + "VL";
            
            if (!modelHelper.isNullOrEmpty(updateDataJson)) {
                updateDataJson.binostate[testName1] = "0.0";
                updateDataJson.binostate[testName2] = "0.0";
                updateDataJson.binostate[testName3] = "0.0";
                updateDataJson.binostate[testName4] = "0.0";
                
                const webStorageIO = becky.WebStorage.local.IO("subjective.update.data");
                webStorageIO.setJson(updateDataJson);
            }
         
           
           
           
        });
        $("#btnDataClear6").unbind().click(function () {
            const chartindex = Number(localStorage['chartindex']);
            const chartParameterItem = becky.subjective.arrayChartParameter.chartParameter.filter(
                chartParameterItem_ => chartParameterItem_.chartID === chartindex)[0];
                var farNearId = chartParameterItem.IsNearFar;
                var valBinoType = chartParameterItem.examBinoResultID;
               
                    $(".prism-heading-inner-hor-R-BI").attr("data-text", " ");
                    $(".prism-heading-inner-hor-L-BI").attr("data-text", " ");
                    $(".prism-heading-inner-ver-R-BD").attr("data-text", " ");
                    $(".prism-heading-inner-ver-L-BD").attr("data-text", " ");
                    $("#labelMainPrismHorR").attr("data-text", "0.00");
                    $("#labelMainPrismHorL").attr("data-text", "0.00");
                    $("#labelMainPrismVerR").attr("data-text", "0.00");
                    $("#labelMainPrismVerL").attr("data-text", "0.00");
    
            $("#labelBreakBU2").attr("data-text", "Break (BU)");
            $("#labelRecoveryBU2").attr("data-text", "Recovery (BU)");
            $("#labelBreakBD2").attr("data-text", "Break (BD)");
            $("#labelRecoveryBD2").attr("data-text", "Recovery (BD)");
            var testName1 = "bino" + valBinoType + farNearId + "HR";
            var testName2 = "bino" + valBinoType + farNearId + "HL";
            var testName3 = "bino" + valBinoType + farNearId + "VR";
            var testName4 = "bino" + valBinoType + farNearId + "VL";
            
            if (!modelHelper.isNullOrEmpty(updateDataJson)) {
                updateDataJson.binostate[testName1] = "0.0";
                updateDataJson.binostate[testName2] = "0.0";
                updateDataJson.binostate[testName3] = "0.0";
                updateDataJson.binostate[testName4] = "0.0";
                
                const webStorageIO = becky.WebStorage.local.IO("subjective.update.data");
                webStorageIO.setJson(updateDataJson);
            }
        });

        $("#btnBreakBO").unbind().click(function () {
            // $("#btnBreakBO").css({"background-color": "#F2A60D","color": "black","border":"1px solid black"})
            const chartindex = Number(localStorage['chartindex']);
            const chartParameterItem = becky.subjective.arrayChartParameter.chartParameter.filter(
                chartParameterItem_ => chartParameterItem_.chartID === chartindex)[0];
            if (becky.assertion.isUndefined(chartParameterItem)) {
                return;
            }
            const examBinoResultID = chartParameterItem.examBinoResultID;
            const Rvalue = "2";
            const btnBlurredBI = binoTestCalculation(examBinoResultID, Rvalue);
            $("#labelABRO").attr("data-text", btnBlurredBI.newBlurVal + " " + btnBlurredBI.BlurVarUnit);

            $("#dummyShiftImageR").show();
            $("#dummyShiftImageL").hide();
        });
        $("#btnBreakBO2").unbind().click(function () {
            // $("#btnBreakBO").css({"background-color": "#F2A60D","color": "black","border":"1px solid black"})
            const chartindex = Number(localStorage['chartindex']);
            const chartParameterItem = becky.subjective.arrayChartParameter.chartParameter.filter(
                chartParameterItem_ => chartParameterItem_.chartID === chartindex)[0];
            if (becky.assertion.isUndefined(chartParameterItem)) {
                return;
            }
            const examBinoResultID = chartParameterItem.examBinoResultID;
            const Rvalue = "2";
            const btnBlurredBI = binoTestCalculation(examBinoResultID, Rvalue);
            $("#labelABRO2").attr("data-text", btnBlurredBI.newBlurVal + " " + btnBlurredBI.BlurVarUnit);
            $("#dummyShiftImageR").show();
            $("#dummyShiftImageL").hide();

        });
        $("#btnRecoveryBO").unbind().click(function () {
            // $("#btnRecoveryBO").css({"background-color": "#F2A60D","color": "black","border":"1px solid black"})
            const chartindex = Number(localStorage['chartindex']);
            const chartParameterItem = becky.subjective.arrayChartParameter.chartParameter.filter(
                chartParameterItem_ => chartParameterItem_.chartID === chartindex)[0];
            if (becky.assertion.isUndefined(chartParameterItem)) {
                return;
            }
            const examBinoResultID = chartParameterItem.examBinoResultID;
            const Rvalue = "3";
            const btnBlurredBI = binoTestCalculation(examBinoResultID, Rvalue);
            $("#labelARO").attr("data-text", btnBlurredBI.newBlurVal + " " + btnBlurredBI.BlurVarUnit);
            $("#dummyShiftImageR").show();
            $("#dummyShiftImageL").hide();

        });
        $("#btnRecoveryBO2").unbind().click(function () {
            // $("#btnRecoveryBO").css({"background-color": "#F2A60D","color": "black","border":"1px solid black"})
            const chartindex = Number(localStorage['chartindex']);
            const chartParameterItem = becky.subjective.arrayChartParameter.chartParameter.filter(
                chartParameterItem_ => chartParameterItem_.chartID === chartindex)[0];
            if (becky.assertion.isUndefined(chartParameterItem)) {
                return;
            }
            const examBinoResultID = chartParameterItem.examBinoResultID;
            const Rvalue = "3";
            const btnBlurredBI = binoTestCalculation(examBinoResultID, Rvalue);
            $("#labelARO2").attr("data-text", btnBlurredBI.newBlurVal + " " + btnBlurredBI.BlurVarUnit);
            $("#dummyShiftImageR").show();
            $("#dummyShiftImageL").hide();

        });
        $("#btnBreakBU").unbind().click(function () {
            //  $("#btnBreakBU").css({"background-color": "#F2A60D","color": "black","border":"1px solid black"})
            
            const chartindex = Number(localStorage['chartindex']);
            const chartParameterItem = becky.subjective.arrayChartParameter.chartParameter.filter(
                chartParameterItem_ => chartParameterItem_.chartID === chartindex)[0];
            if (becky.assertion.isUndefined(chartParameterItem)) {
                return;
            }
            
            const examBinoResultID = chartParameterItem.examBinoResultID;
            console.log(examBinoResultID);
            const Rvalue = "3";
           
            const btnBlurredBI = binoTestCalculation(examBinoResultID, Rvalue);
            $("#labelBreakBU").attr("data-text", btnBlurredBI.newBlurVal + " " + btnBlurredBI.BlurVarUnit);
            $("#vdummyShiftImageR").show();
            $("#vdummyShiftImageL").hide();

        });
        $("#btnRecoveryBU").unbind().click(function () {
            //$("#btnRecoveryBU").css({"background-color": "#F2A60D","color": "black","border":"1px solid black"})
            const chartindex = Number(localStorage['chartindex']);
            const chartParameterItem = becky.subjective.arrayChartParameter.chartParameter.filter(
                chartParameterItem_ => chartParameterItem_.chartID === chartindex)[0];
            if (becky.assertion.isUndefined(chartParameterItem)) {
                return;
            }
            const examBinoResultID = chartParameterItem.examBinoResultID;
            const Rvalue = "4";
            const btnBlurredBI = binoTestCalculation(examBinoResultID, Rvalue);
            $("#labelRecoveryBU").attr("data-text", btnBlurredBI.newBlurVal + " " + btnBlurredBI.BlurVarUnit);
            $("#vdummyShiftImageR").show();
            $("#vdummyShiftImageL").hide();

        });
        $("#btnBreakBD").unbind().click(function () {
            //  $("#btnBreakBD").css({"background-color": "#F2A60D","color": "black","border":"1px solid black"})
            const chartindex = Number(localStorage['chartindex']);
            const chartParameterItem = becky.subjective.arrayChartParameter.chartParameter.filter(
                chartParameterItem_ => chartParameterItem_.chartID === chartindex)[0];
            if (becky.assertion.isUndefined(chartParameterItem)) {
                return;
            }
            const examBinoResultID = chartParameterItem.examBinoResultID;
            const Rvalue = "1";
            const btnBlurredBI = binoTestCalculation(examBinoResultID, Rvalue);
            $("#labelBreakBD").attr("data-text", btnBlurredBI.newBlurVal + " " + btnBlurredBI.BlurVarUnit);
            $("#vdummyShiftImageR").hide();
            $("#vdummyShiftImageL").show();

        });
        $("#btnRecoveryBD").unbind().click(function () {
            //$("#btnRecoveryBD").css({"background-color": "#F2A60D","color": "black","border":"1px solid black"})
            const chartindex = Number(localStorage['chartindex']);
            const chartParameterItem = becky.subjective.arrayChartParameter.chartParameter.filter(
                chartParameterItem_ => chartParameterItem_.chartID === chartindex)[0];
            if (becky.assertion.isUndefined(chartParameterItem)) {
                return;
            }
            const examBinoResultID = chartParameterItem.examBinoResultID;
            const Rvalue = "2";
            const btnBlurredBI = binoTestCalculation(examBinoResultID, Rvalue);
            $("#labelRecoveryBD").attr("data-text", btnBlurredBI.newBlurVal + " " + btnBlurredBI.BlurVarUnit);
            $("#vdummyShiftImageR").hide();
            $("#vdummyShiftImageL").show();

        });
        $("#btnBreakBU2").unbind().click(function () {
            //  $("#btnBreakBU").css({"background-color": "#F2A60D","color": "black","border":"1px solid black"})
            const chartindex = Number(localStorage['chartindex']);
            const chartParameterItem = becky.subjective.arrayChartParameter.chartParameter.filter(
                chartParameterItem_ => chartParameterItem_.chartID === chartindex)[0];
            if (becky.assertion.isUndefined(chartParameterItem)) {
                return;
            }
            const examBinoResultID = chartParameterItem.examBinoResultID;
            const Rvalue = "3";
            const btnBlurredBI = binoTestCalculation(examBinoResultID, Rvalue);
            $("#labelBreakBU2").attr("data-text", btnBlurredBI.newBlurVal + " " + btnBlurredBI.BlurVarUnit);
            $("#vdummyShiftImageR").show();
            $("#vdummyShiftImageL").hide();

        });
        $("#btnRecoveryBU2").unbind().click(function () {
            //$("#btnRecoveryBU").css({"background-color": "#F2A60D","color": "black","border":"1px solid black"})
            const chartindex = Number(localStorage['chartindex']);
            const chartParameterItem = becky.subjective.arrayChartParameter.chartParameter.filter(
                chartParameterItem_ => chartParameterItem_.chartID === chartindex)[0];
            if (becky.assertion.isUndefined(chartParameterItem)) {
                return;
            }
            const examBinoResultID = chartParameterItem.examBinoResultID;
            const Rvalue = "4";
            const btnBlurredBI = binoTestCalculation(examBinoResultID, Rvalue);
            $("#labelRecoveryBU2").attr("data-text", btnBlurredBI.newBlurVal + " " + btnBlurredBI.BlurVarUnit);
            $("#vdummyShiftImageR").show();
            $("#vdummyShiftImageL").hide();

        });
        $("#btnBreakBD2").unbind().click(function () {
            //  $("#btnBreakBD").css({"background-color": "#F2A60D","color": "black","border":"1px solid black"})
            const chartindex = Number(localStorage['chartindex']);
            const chartParameterItem = becky.subjective.arrayChartParameter.chartParameter.filter(
                chartParameterItem_ => chartParameterItem_.chartID === chartindex)[0];
            if (becky.assertion.isUndefined(chartParameterItem)) {
                return;
            }
            const examBinoResultID = chartParameterItem.examBinoResultID;
            const Rvalue = "1";
            const btnBlurredBI = binoTestCalculation(examBinoResultID, Rvalue);
            $("#labelBreakBD2").attr("data-text", btnBlurredBI.newBlurVal + " " + btnBlurredBI.BlurVarUnit);
            $("#vdummyShiftImageR").hide();
            $("#vdummyShiftImageL").show();

        });
        $("#btnRecoveryBD2").unbind().click(function () {
            //$("#btnRecoveryBD").css({"background-color": "#F2A60D","color": "black","border":"1px solid black"})
            const chartindex = Number(localStorage['chartindex']);
            const chartParameterItem = becky.subjective.arrayChartParameter.chartParameter.filter(
                chartParameterItem_ => chartParameterItem_.chartID === chartindex)[0];
            if (becky.assertion.isUndefined(chartParameterItem)) {
                return;
            }
            const examBinoResultID = chartParameterItem.examBinoResultID;
            const Rvalue = "2";
            const btnBlurredBI = binoTestCalculation(examBinoResultID, Rvalue);
            $("#labelRecoveryBD2").attr("data-text", btnBlurredBI.newBlurVal + " " + btnBlurredBI.BlurVarUnit);
            $("#vdummyShiftImageR").hide();
            $("#vdummyShiftImageL").show();

        });

        // 行・列の選択s
        //masking row/column
        $(top_side_div).click(function () {
            const $this = $(this);
            const isTop = $this.parent().hasClass("top");
            const isSide = $this.parent().hasClass("side");
            const isThisActive = $this.hasClass("active");
            const $hitarea_div = $(".chart-table .hitarea div");
            const index = $this.index();
            //const index_top = $(isTop).index;

            if (isThisActive) {
                $this.removeClass("active");
                $hitarea_div.addClass("active");
            } else {
                $(".chart-table div").removeClass("active");
                $this.addClass("active");
                //const index = $this.index();

                $hitarea_div.removeClass("active");
                if (isTop) {
                    for (let i = 0; i < totalColumnCount * totalRowCount; i += totalColumnCount) {
                        $hitarea_div.eq(index + i).addClass("active");
                    }
                }
                if (isSide) {
                    for (let i = 0; i < totalColumnCount; ++i) {
                        $hitarea_div.eq(index * totalColumnCount + i).addClass("active");
                    }
                }

            }

            if (isThisActive) {
                $(".right").hide();
                $(".left").hide();
                $(".up").show();
                $(".down").show();

                if (transprevChartID == 0) {
                    $(".up").hide();
                }
                if (transnextChartID == 0) {
                    $(".down").hide();
                }
            } else {
                _visibleChartButtonsOnMaskSelection(totalRowCount, totalColumnCount, transnextChartID, transprevChartID, index, isTop);
            }

            // RG は排他なので無効化
            _resetChartRG();

        });
        //right click event
        /*Chart Transition*/
        function selectCurrentChart(chartTable) {
            _updateChartTableLayout(chartTable);
            _updateChartTable(chartTable);
            _updateControllerLayout(chartTable);
            _updateMenuInit(chartTable);
            _updateSelectSCA_FromChart(chartTable);
            // カレント更新
            _setCurrentChart(chartTable);
            const $tabContent = $("[data-auto-id=" + chartTable.autoID + "]");
            if (!modelHelper.isNull($tabContent)) {
                if (!$tabContent.hasClass("current")) {
                    $("[data-auto-id]").removeClass("current");
                    $tabContent.addClass("current");
                    const $tabContentParent = $tabContent.parent();
                    const tabIndex = $tabContentParent.parent().children().index($tabContentParent);
                    if (tabIndex != $("#tabChart").attr("data-tab-index")) {
                        // 差がある場合のみ反映
                        $("#tabChart").attr("data-tab-index", tabIndex);
                    }
                }
            }


        }
        /*Cell Selection during Previous Chart Transition on Left Button Click */
        function selectLastCell(chartTable) {
            selectCurrentChart(chartTable);
            //var index = localStorage['index'];
            $(hitarea_div).last().trigger("click");
        }
        /*Cell Selection during Next Chart Transition on Right Button Click */
        function selectFirstCell(chartTable) {
            //var index = localStorage['index'];
            selectCurrentChart(chartTable);
            $(hitarea_div).first().trigger("click");
        }

        /*Cell Selection during Next Chart Transition on Down Button Click */
        function selectNextChartCellOnDown(chartTable) {

            var index = localStorage['index'];
            selectCurrentChart(chartTable);
            var currentCol = localStorage['currentCol'];
            var currentRow = localStorage['currentRow'];
            var intIndex = 0;

            if (totalColumnCount == currentCol) {
                if (totalRowCount == currentRow) {
                    intIndex = index - (currentCol * (currentRow - 1));
                } else if (totalRowCount > currentRow) {
                    intIndex = index - (totalColumnCount * (totalRowCount - 1));
                } else
                    intIndex = index - currentCol
            } else if (totalColumnCount > currentCol) {
                if (index == totalColumnCount * (totalRowCount - 1)) {
                    intIndex = 0
                } else if (index == totalColumnCount * (totalRowCount - 1) + 2) {
                    intIndex = 1
                } else if (index > totalColumnCount * (totalRowCount - 1) + 2) {
                    intIndex = currentCol - 1
                }
            } else if (totalColumnCount < currentCol) {
                if (index == totalColumnCount) {
                    intIndex = 0
                } else if (index == totalColumnCount + 1) {
                    intIndex = totalRowCount
                } else if (index == totalColumnCount * totalRowCount - 1) {
                    intIndex = currentCol - 1
                }
            }
            $(hitarea_div).eq(intIndex).trigger("click");
        }

        /*Cell Selection during Previous Chart Transition on Up Button Click */
        function selectNextChartCellOnUp(chartTable) {

            var index = parseInt(localStorage['index']);
            selectCurrentChart(chartTable);
            var currentCol = parseInt(localStorage['currentCol']);
            var currentRow = parseInt(localStorage['currentRow']);
            var intIndex1 = parseInt(0);

            if (totalColumnCount == currentCol) {
                intIndex1 = index + (currentCol * (currentRow - 1));
            } else if (totalColumnCount > currentCol) {
                if (index > 2) {
                    intIndex1 = currentRow * currentCol - 1
                } else if (index <= 1) {
                    intIndex1 = currentCol
                } else if (index == 2) {
                    intIndex1 = currentCol + 1
                }
            } else if (totalColumnCount < currentCol) {
                if (index > 1) {
                    intIndex1 = currentRow * currentCol - 1
                } else if (index == 1) {
                    intIndex1 = currentCol * (currentRow - 1) + 2
                } else if (index < 1) {
                    intIndex1 = currentCol * (currentRow - 1)
                }
            }

            $(hitarea_div).eq(intIndex1).trigger("click");
        }

        /*On chart transition, select first row of next chart */
        function selectFirstDown(chartTable) {

            selectCurrentChart(chartTable);
            $(".chart-table .side div").first().trigger("click");
        }

        function selectFirstCol(chartTable) {

            selectCurrentChart(chartTable);
            $(".chart-table .top div").first().trigger("click");
        }

        function selectLastCol(chartTable) {

            selectCurrentChart(chartTable);
            $(".chart-table .top div").last().trigger("click");
        }
        /*On chart transition, select last column of previous chart */
        function selectLast(chartTable) {
            var index_top = localStorage['index_top']; //Current chart selected column index

            if (index_top == null) {
                selectCurrentChart(chartTable);
            } else {
                selectCurrentChart(chartTable)
                var currentCol = localStorage['currentCol'];
                if ((currentCol > 3) && totalColumnCount > 3) {
                    $(".chart-table .top div").eq(index_top).trigger("click");
                } else {
                    if (currentCol > 3) {
                        if (index_top < 1) {
                            $(".chart-table .top div").first().trigger("click");
                        }
                        if (index_top > 1) {
                            $(".chart-table .top div").last().trigger("click");
                        }
                        if (index_top == 1) {
                            $(".chart-table .top div").eq(2).trigger("click");
                        }
                    }
                    if (currentCol <= 3) {
                        if (index_top > 2) {
                            $(".chart-table .top div").last().trigger("click");
                        }
                        if (index_top == 2) {
                            $(".chart-table .top div").eq(1).trigger("click");
                        }
                        if (index_top <= 1) {
                            $(".chart-table .top div").first().trigger("click");
                        }
                    }
                }
            }
        }

        /*On chart transition, select last row of previous chart */
        function selectLastDown(chartTable) {
            selectCurrentChart(chartTable);
            $(".chart-table .side div").last().trigger("click");
        }
        /*prism h/v click */
        $(".prism-hv-control").unbind().click(function () {

            const chartindex = Number(localStorage['chartindex']);
            const chartParameterItem = becky.subjective.arrayChartParameter.chartParameter.filter(
                chartParameterItem_ => chartParameterItem_.chartID === chartindex)[0];
            if (becky.assertion.isUndefined(chartParameterItem)) {
                return;
            }

            let horizontalprismId = chartParameterItem.PrismtRuleChartIDH.toString();
            let verticalprismId = chartParameterItem.PrismtRuleChartIDV.toString();


            if ((horizontalprismId >= 1) || (verticalprismId >= 1)) {

                if (horizontalprismId >= 1) {
                    const charts = becky.subjective.arrayFlatChartPageParameter.filter(chart_ => horizontalprismId == chart_.chartID);
                    chartTable = charts[0];
                    selectCurrentChart(chartTable);
                    const $btn = $(this);
                    const autoID = $btn.attr("data-auto-id");
                    //const chart = _getChartByAutoID(becky.subjective.arrayFlatChartPageParameter, autoID);
                    const nExamID = chartTable.examID;
                    // get chart value of exam chart json

                    const examParameterItem = becky.subjective.arrayExamParameter.examParameter.filter(
                        examParameterItem_ => examParameterItem_.examID === nExamID)[0];
                    const strTitle = examParameterItem.titleExam;
                    $("#labelExamTitle").attr("data-text", strTitle);
                    _setSelectPrismHor_FromEvent();
                    _setSelectSCA("PrismHor");
                    $("#btnControllerEyeL").trigger("click");
                    $(".vertical-icons").hide();
                    $(".horizontal-icons").show();
                    localStorage['chartindex'] = chartTable.chartID;
                }
                if (verticalprismId >= 1) {
                    const charts = becky.subjective.arrayFlatChartPageParameter.filter(chart_ => verticalprismId == chart_.chartID);
                    chartTable = charts[0];
                    selectCurrentChart(chartTable);
                    const $btn = $(this);
                    const autoID = $btn.attr("data-auto-id");
                    //const chart = _getChartByAutoID(becky.subjective.arrayFlatChartPageParameter, autoID);
                    const nExamID = chartTable.examID;
                    // get chart value of exam chart json

                    const examParameterItem = becky.subjective.arrayExamParameter.examParameter.filter(
                        examParameterItem_ => examParameterItem_.examID === nExamID)[0];
                    const strTitle = examParameterItem.titleExam;
                    $("#labelExamTitle").attr("data-text", strTitle);
                    _setSelectPrismVer_FromEvent();
                    _setSelectSCA("PrismVer");
                    $("#btnControllerEyeR").trigger("click");
                    $(".horizontal-icons").hide();
                   // $(".vertical-icons").show();
                    localStorage['chartindex'] = chartTable.chartID;

                }
            } else {
                if ($(".horizontal-icons").is(':visible')) {
                    _setSelectPrismVer_FromEvent();
                    _setSelectSCA("PrismVer");
                    $("#btnControllerEyeR").trigger("click");
                    $(".vertical-icons").show();
                $(".horizontal-icons").hide();
                } else
                if ($(".vertical-icons").is(':visible')) {
                    _setSelectPrismHor_FromEvent();
                    _setSelectSCA("PrismHor");
                    $("#btnControllerEyeL").trigger("click");
                    $(".vertical-icons").hide();
                    $(".horizontal-icons").show();
                }


            }
        });
        /*Masking and chart transition on click of right button */
        $(".right").unbind().click(function () {
            const $this = $(".chart-table .top .active");
            const isTop = $this.parent().hasClass("top");
            const isThisActive = $this.hasClass("active");
            const $hitarea_div = $(".chart-table .hitarea div");
            const hitAreaActive = $hitarea_div.hasClass("active");
            const index = $this.index();
            const index2 = $(".chart-table .hitarea .active").index();
            const $chartTableActive = $(".chart-table .active");
            let nActiveCount = 0;
            if (leftright_nomask == 0 || right_nomask == 0) {
                $(".right").hide();
            } else
                /*If column is masked */
                if (isThisActive) {
                    if (isTop) {
                        if (totalRowCount * totalColumnCount >= 10) {
                            if (index == 3 && (transnextChartID == 0)) {
                                $(".right").hide();
                            }
                        }
                    }
                    $this.removeClass("active");
                    $hitarea_div.removeClass("active");
                    if (isTop) {

                        if (index == (totalColumnCount - 1)) {
                            for (let i = 1; i < totalColumnCount * totalRowCount; i += totalColumnCount) {
                                $hitarea_div.eq(index + i - 1).addClass("active");
                                (async function () {
                                    const pointerEvents = _getPointerEventsByCommand();
                                    chartTable.maskCell = 'NULL';
                                    chartTable.Row = totalRowCount;
                                    chartTable.Col = totalColumnCount;
                                    await _postMaskCommand(chartTable);
                                }());

                            }
                            $this.addClass("active");
                        } else
                            for (let i = 1; i < totalColumnCount * totalRowCount; i += totalColumnCount) {

                                $hitarea_div.eq(index + i).addClass("active");

                            }
                        if ((index) == (totalColumnCount - 1)) {
                            //chartTable.chartID=transnextChartID;
                            if ((transnextChartID == 0) || (transnextChartID == null)) {
                                $(".right").hide();
                            } else {
                                const charts = becky.subjective.arrayFlatChartPageParameter.filter(chart_ => transnextChartID == chart_.chartID);
                                chartTable = charts[0];
                                selectFirstCol(chartTable);
                                (async function () {
                                    const pointerEvents = _getPointerEventsByCommand();
                                    chartTable.maskCell = 'NULL';
                                    chartTable.Row = totalRowCount;
                                    chartTable.Col = totalColumnCount;
                                    await _postMaskCommand(chartTable);
                                }());
                            }

                        }
                        _visibleChartButtonsOnMaskSelection(totalRowCount, totalColumnCount, transnextChartID, transprevChartID, index + 1, isTop)
                    }
                    $this.next().addClass("active");
                    if (index == -1) {
                        const charts = becky.subjective.arrayFlatChartPageParameter.filter(chart_ => transnextChartID == chart_.chartID);
                        chartTable = charts[0];
                        selectCurrentChart(chartTable);
                        //Change long chart without selecting mask
                        (async function () {
                            const pointerEvents = _getPointerEventsByCommand();
                            await _postChartCommand(chartTable);
                        }());
                    }
                }
            else
                /*If single cell is masked */
                if (!modelHelper.isNullOrEmpty($chartTableActive)) {
                    nActiveCount = $chartTableActive.length;
                    const isSingleActive = 1 == nActiveCount;
                    if (hitAreaActive && isSingleActive) {
                        $hitarea_div.removeClass("active");
                        for (let i = 1; i <= totalColumnCount * totalRowCount; i += totalColumnCount * totalRowCount) {
                            $hitarea_div.eq(i + index2).addClass("active");
                        }
                        if (transnextChartID == 0 || transnextChartID == null) {
                            if ((index2 + 1) == (totalRowCount * totalColumnCount - 1)) {
                                $(".right").hide();
                            }
                            if (index2 + 1 >= totalColumnCount * (totalRowCount - 1)) {

                                $(".down").hide();
                            } else $(".right").show();
                        }
                        if ((index2 + 1) == (totalRowCount * totalColumnCount)) {

                            {
                                const charts = becky.subjective.arrayFlatChartPageParameter.filter(chart_ => transnextChartID == chart_.chartID);
                                chartTable = charts[0];
                                selectFirstCell(chartTable);
                            }

                        } else
                        if (index2 > totalRowCount - 1) {
                            $(".up").show();
                        }
                        $(".left").show();

                        ;
                        (async function () {
                            const pointerEvents = _getPointerEventsByCommand();
                            chartTable.Row = totalRowCount;
                            chartTable.Col = totalColumnCount;
                            await _postMaskCommand(chartTable);
                        }());


                    } else {
                        $hitarea_div.addClass("active");
                    }
                }
            else
                // RG は排他なので無効化
                _resetChartRG();
        });
        //left click event
        $(".left").unbind().click(function () {
            const $this = $(".chart-table .top .active");
            const isTop = $this.parent().hasClass("top");
            const isThisActive = $this.hasClass("active");
            const $hitarea_div = $(".chart-table .hitarea div");
            const hitAreaActive = $hitarea_div.hasClass("active");
            const $chartTableActive = $(".chart-table .active");
            const index = $this.index();
            const index2 = $(".chart-table .hitarea .active").index();
            let nActiveCount = 0;
            if (leftright_nomask == 0 || left_nomask == 0) {
                $(".left").hide();
            }

            if (index2 == 1 && isTop) {
                {
                    $this.removeClass("active");
                    $hitarea_div.removeClass("active");
                    for (let i = 1; i < totalColumnCount * totalRowCount; i += totalColumnCount) {
                        $hitarea_div.eq(index - i).addClass("active");
                    }
                    $this.prev().addClass("active");
                }
                if ((transprevChartID == 0) || (transprevChartID == null)) {
                    $(".left").hide();
                }

            } else
                /* If column is masked*/
                if (isThisActive) {
                    if (isTop) {
                        if (index == 0) {
                            {
                                const charts = becky.subjective.arrayFlatChartPageParameter.filter(chart_ => transprevChartID == chart_.chartID);
                                chartTable = charts[0];
                                selectLastCol(chartTable);
                                (async function () {
                                    const pointerEvents = _getPointerEventsByCommand();
                                    chartTable.maskCell = index;
                                    chartTable.Row = totalRowCount;
                                    chartTable.Col = totalColumnCount;
                                    await _postMaskCommand(chartTable);
                                }());
                            }
                        } else
                        if (index > 0) {
                            $this.removeClass("active");
                            $hitarea_div.removeClass("active");
                            for (let i = 1; i < totalColumnCount * totalRowCount; i += totalColumnCount) {
                                $hitarea_div.eq(index - i).addClass("active");
                            }
                            $this.prev().addClass("active");
                            _visibleChartButtonsOnMaskSelection(totalRowCount, totalColumnCount, transnextChartID, transprevChartID, index - 1, isTop)
                        }
                    }
                }
            else
                /*If single cell is masked */
                if (!modelHelper.isNullOrEmpty($chartTableActive)) {
                    nActiveCount = $chartTableActive.length;
                    const isSingleActive = 1 == nActiveCount;
                    if (hitAreaActive && isSingleActive) {
                        $hitarea_div.removeClass("active");
                        for (let i = 1; i < totalColumnCount * totalRowCount; i += totalColumnCount * totalRowCount) {
                            $hitarea_div.eq(index2 - i).addClass("active");
                        }
                        if (index2 <= totalColumnCount * (totalRowCount - 1)) {
                            $(".down").show();
                        }
                        if ((transprevChartID == 0) || (transprevChartID == null)) {
                            if (index2 == 1) {
                                $(".left").hide();
                            } else {
                                if (index2 <= totalColumnCount)
                                    $(".up").hide();
                            }
                        }
                        if (index2 < 1) {
                            //chartTable.chartID=transprevChartID;
                            const charts = becky.subjective.arrayFlatChartPageParameter.filter(chart_ => transprevChartID == chart_.chartID);
                            chartTable = charts[0];
                            selectLastCell(chartTable);
                            (async function () {
                                const pointerEvents = _getPointerEventsByCommand();
                                chartTable.maskCell = index;
                                chartTable.Row = totalRowCount;
                                chartTable.Col = totalColumnCount;
                                await _postMaskCommand(chartTable);
                            }());

                        } else $(".right").show();
                    } else {
                        $hitarea_div.addClass("active");

                    }
                }
            // RG は排他なので無効化
            _resetChartRG();

        });
        /*Up Button Click event */
        $(".up").unbind().click(function () {
            const $this = $(".chart-table .side .active");
            const $this_top = $(".chart-table .top .active");
            const index = $this.index();
            const index_top = $this_top.index();
            localStorage['index_top'] = index_top;
            const isSide = $this.parent().hasClass("side");
            const isTop = $this_top.parent().hasClass("top");
            const isThisActive = $this.hasClass("active");
            const isTopActive = $this_top.hasClass("active");
            const $hitarea_div = $(".chart-table .hitarea div");
            const $chartTableActive = $(".chart-table .active");
            const index2 = $(".chart-table .hitarea .active").index();
            localStorage['index'] = index2;
            const hitAreaActive = $hitarea_div.hasClass("active");
            let nActiveCount = 0;


            if (updown_nomask == 0 || up_nomask == 0) {
                $(".up").hide();
            } else
                /*If row is selected */
                if (isThisActive) {
                    $this.removeClass("active");
                    $hitarea_div.addClass("active");
                    $(".chart-table div").removeClass("active");
                    $hitarea_div.removeClass("active");
                    if (isSide) {
                        const index3 = $this.prev().index();
                        const firstindex = $this.eq(0).index();
                        for (let i = 0; i < totalColumnCount; ++i) {
                            $hitarea_div.eq(index3 * totalColumnCount + i).addClass("active");
                        }
                        if (index == 0 || index == -1) {
                            //chartTable.chartID=transnextChartID;
                            const charts = becky.subjective.arrayFlatChartPageParameter.filter(chart_ => transprevChartID == chart_.chartID);
                            chartTable = charts[0];
                            selectLastDown(chartTable);
                            (async function () {
                                const pointerEvents = _getPointerEventsByCommand();
                                chartTable.maskCell = index;
                                chartTable.Row = totalRowCount;
                                chartTable.Col = totalColumnCount;
                                await _postMaskCommand(chartTable);
                            }());
                        }
                        $this.prev().addClass("active");

                    }

                    _visibleChartButtonsOnMaskSelection(totalRowCount, totalColumnCount, transnextChartID, transprevChartID, index - 1, isTop);
                }
            else
            if (isTopActive) {
                if (isTop) {

                    //chartTable.chartID=transnextChartID;
                    const charts = becky.subjective.arrayFlatChartPageParameter.filter(chart_ => transprevChartID == chart_.chartID);
                    chartTable = charts[0];
                    selectLast(chartTable);

                }
            } else
                /*If single cell is selected */
                if (!modelHelper.isNullOrEmpty($chartTableActive)) {
                    nActiveCount = $chartTableActive.length;
                    const isSingleActive = 1 == nActiveCount;
                    if (hitAreaActive && isSingleActive) {
                        $hitarea_div.removeClass("active");
                        for (let i = 0; i < totalColumnCount * totalRowCount; i += (totalColumnCount - 1)) {
                            $hitarea_div.eq(index2 - totalColumnCount).addClass("active");
                        }
                        if (totalRowCount <= 2) {
                            if (index2 <= totalColumnCount * totalRowCount) {
                                if ((transprevChartID == 0) || (transprevChartID == null)) {
                                    if (index2 == totalColumnCount) {
                                        $(".left").hide();
                                    }
                                    $(".up").hide();
                                }
                                $(".down").show();
                                $(".right").show();
                            }
                        } else if (totalRowCount > 2) {
                            if (index2 <= totalColumnCount * totalRowCount) {
                                if ((transprevChartID == 0) || (transprevChartID == null)) {
                                    if (index2 == totalColumnCount) {
                                        $(".left").hide();
                                    }
                                    if (index2 <= totalColumnCount + totalRowCount + 1) {
                                        $(".up").hide();
                                    }
                                }
                                $(".down").show();
                                $(".right").show();
                            }
                        } else {
                            if (index2 < totalColumnCount * (totalRowCount - 1)) {
                                if ((transprevChartID == 0) || (transprevChartID == null)) {
                                    if (index2 == totalColumnCount) {
                                        $(".left").hide();
                                    }
                                    $(".up").hide();

                                }
                            }
                        }
                        if (index2 < totalColumnCount) {
                            const charts = becky.subjective.arrayFlatChartPageParameter.filter(chart_ => transprevChartID == chart_.chartID);
                            chartTable = charts[0];
                            //Select current selected index
                            //selectLastCell(chartTable);
                            selectNextChartCellOnUp(chartTable);
                            (async function () {
                                const pointerEvents = _getPointerEventsByCommand();
                                chartTable.maskCell = index;
                                chartTable.Row = totalRowCount;
                                chartTable.Col = totalColumnCount;
                                await _postMaskCommand(chartTable);
                            }());
                        }
                    } else /*If no mask */
                        if (index == -1) {
                            if ((transprevChartID == 0) || (transprevChartID == null)) {
                                _visibleChartButtonsOnLoad(transnextChartID, transprevChartID);
                            } else {
                                const charts = becky.subjective.arrayFlatChartPageParameter.filter(chart_ => transprevChartID == chart_.chartID);
                                chartTable = charts[0];
                                selectCurrentChart(chartTable);

                                const chartParameterItem = becky.subjective.arrayChartParameter.chartParameter.filter(
                                    chartParameterItem_ => chartParameterItem_.chartID === transprevChartID)[0];
                                // if (becky.assertion.isUndefined(chartParameterItem)) {
                                //     return;
                                // }
                                _visibleChartButtonsOnLoad(chartParameterItem.transition.nextChartID, chartParameterItem.transition.prevChartID);

                                (async function () {
                                    const pointerEvents = _getPointerEventsByCommand();
                                    await _postChartCommand(chartTable);
                                }());
                            }
                        }
                    else {
                        $hitarea_div.addClass("active");
                    }
                }
            // RG は排他なので無効化
            else _resetChartRG();
        });
        //down button masking
        $(".down").unbind().click(function () {
            const $this = $(".chart-table .side .active");
            const $this_top = $(".chart-table .top .active");
            const index = $this.index();
            const index_top = $this_top.index();
            localStorage['index_top'] = index_top;
            const isSide = $this.parent().hasClass("side");
            const isTop = $this_top.parent().hasClass("top");
            const isThisActive = $this.hasClass("active");
            const isTopActive = $this_top.hasClass("active");
            const $hitarea_div = $(".chart-table .hitarea div");
            const $chartTableActive = $(".chart-table .active");
            const index2 = $(".chart-table .hitarea .active").index();
            localStorage['index'] = index2;
            const hitAreaActive = $hitarea_div.hasClass("active");
            let nActiveCount = 0;

            if (updown_nomask == 0 || down_nomask == 0) {
                $(".down").hide();
            } else
                /*Mask Movement when row is selected */
                if (isThisActive) {
                    $this.removeClass("active");
                    $hitarea_div.addClass("active");
                    $(".chart-table div").removeClass("active");
                    $this.next().addClass("active");
                    const index3 = $this.next().index();
                    $hitarea_div.removeClass("active");
                    if (isSide) {

                        for (let i = 0; i < totalColumnCount; ++i) {
                            $hitarea_div.eq(index3 * totalColumnCount + i).addClass("active");
                            $this.next().addClass("active")
                        }

                        if ((index + 1) == (totalRowCount)) {
                            //chartTable.chartID=transnextChartID;
                            const charts = becky.subjective.arrayFlatChartPageParameter.filter(chart_ => transnextChartID == chart_.chartID);
                            chartTable = charts[0];
                            selectFirstDown(chartTable);
                            (async function () {
                                const pointerEvents = _getPointerEventsByCommand();
                                chartTable.maskCell = index;
                                chartTable.Row = totalRowCount;
                                chartTable.Col = totalColumnCount;
                                await _postMaskCommand(chartTable);
                            }());

                        }

                        $this.next().addClass("active")
                        _visibleChartButtonsOnMaskSelection(totalRowCount, totalColumnCount, transnextChartID, transprevChartID, index + 1, isTop)

                    }
                }
            if (isTopActive) {
                if (isTop) {

                    //chartTable.chartID=transnextChartID;
                    const charts = becky.subjective.arrayFlatChartPageParameter.filter(chart_ => transnextChartID == chart_.chartID);
                    chartTable = charts[0];
                    selectLast(chartTable);

                }
            } else
                /*Mask movement when single cell is selected */
                if (!modelHelper.isNullOrEmpty($chartTableActive)) {

                    nActiveCount = $chartTableActive.length;
                    const isSingleActive = 1 == nActiveCount;
                    if (hitAreaActive && isSingleActive) {
                        $hitarea_div.removeClass("active");
                        for (let i = 0; i < totalRowCount * totalColumnCount; i += totalColumnCount * totalRowCount) {
                            $hitarea_div.eq(i + index2 + totalColumnCount).addClass("active");
                        }
                        if (totalRowCount <= 2) {
                            if (index2 >= 0) {
                                if ((transnextChartID == 0) || (transnextChartID == null)) {
                                    if (index2 + 1 == totalColumnCount * (totalRowCount - 1)) {
                                        $(".right").hide();
                                    }
                                    $(".down").hide();
                                }
                            }
                        } else
                        if (index2 > totalColumnCount - 1) {
                            if ((transnextChartID == 0) || (transnextChartID == null)) {
                                if (index2 + 1 == totalColumnCount * (totalRowCount - 1)) {
                                    $(".right").hide();
                                }
                                $(".down").hide();
                            }
                        }

                        if ((index2 + totalColumnCount) >= (totalRowCount * totalColumnCount)) {
                            //chartTable.chartID=transprevChartID;
                            const charts = becky.subjective.arrayFlatChartPageParameter.filter(chart_ => transnextChartID == chart_.chartID);
                            chartTable = charts[0];
                            selectNextChartCellOnDown(chartTable);

                        } else {
                            $(".up").show();
                            $(".left").show()
                        };
                    } else if (index == -1) {
                        /*When no mask is selected - chart transition */

                        if ((transnextChartID == 0) || (transnextChartID == null)) {
                            _visibleChartButtonsOnLoad(transnextChartID, transprevChartID);
                        } else {
                            const charts = becky.subjective.arrayFlatChartPageParameter.filter(chart_ => transnextChartID == chart_.chartID);
                            chartTable = charts[0];
                            selectCurrentChart(chartTable);

                            const chartParameterItem = becky.subjective.arrayChartParameter.chartParameter.filter(
                                chartParameterItem_ => chartParameterItem_.chartID === transnextChartID)[0];
                            // if (becky.assertion.isUndefined(chartParameterItem)) {
                            //     return;
                            // }
                            _visibleChartButtonsOnLoad(chartParameterItem.transition.nextChartID, chartParameterItem.transition.prevChartID);

                            (async function () {
                                const pointerEvents = _getPointerEventsByCommand();
                                await _postChartCommand(chartTable);
                            }());
                        }

                    }

                }

            else
                _resetChartRG();
        });

        // 単一の選択
        //masking single element
        $(hitarea_div).click(function () {
            const $this = $(this);
            const index = $this.index();
            const isThisActive = $this.hasClass("active");
            const $chartTableActive = $(".chart-table .active");
            localStorage['index'] = index;
            let nActiveCount = 0;
            if (!modelHelper.isNullOrEmpty($chartTableActive)) {
                nActiveCount = $chartTableActive.length;
            }
            (async function () {
                // ボタンを無効化
                const pointerEvents = _getPointerEventsByCommand();
                //await _postChartCommand(chartTable);
                chartTable.maskCell = index;
                chartTable.Row = totalRowCount;
                chartTable.Col = totalColumnCount;
                await _postMaskCommand(chartTable);

            }());

            $(".chart-table div").removeClass("active");
            if ((transnextChartID == 0) || (transnextChartID == null)) {
                $(".down").hide();
                $(".right").hide();
            }
            if ((transprevChartID == 0) || (transprevChartID == null)) {
                $(".up").hide();
                $(".right").hide();
            }
            const isSingleActive = one_letter == nActiveCount;
            if (one_letter == 1) {
                if (isThisActive && isSingleActive) {
                    $(".chart-table .hitarea div").addClass("active");
                    $(".left").hide();
                    $(".right").hide();

                } else {
                    $this.addClass("active");
                    _visibleChartButtonsOnCellSelection(totalRowCount, totalColumnCount, transnextChartID, transprevChartID);
                    //Left, right, up, down buttons on single cell selection

                }
            }

            // RG は排他なので無効化
            _resetChartRG();

        });

    }

    /*!
     * @brief 視力表テーブルのボタン更新
     *
     * @param[in] (array of (integer or string)) aBtnValues ボタンに表示する内容(数値または文字列)の配列
     * @param[in] bool aIsSingleLine ボタンが単一(列)か？
     */
    function _updateChartTableButtons(aBtnValues, aIsSingleLine) {
        // ボタンのイベント解除 & 削除
        //Cancel button event & delete
        {
            const group = ".confirm-box .btn-group-va";
            const button = group + " button";
            const $button = $(button);
            if (!modelHelper.isNullOrEmpty($button)) {
                $button.unbind();
            }
            $(group).text("");
        }
        // ボタン生成
        //Button generation
        {
            let group = null;
            if (aIsSingleLine) {
                group = ".confirm-box .btn-group-b";
            } else {
                group = ".confirm-box .btn-group-c";
            }
            if (!modelHelper.isNullOrEmpty(aBtnValues)) {
                const $buttons = aBtnValues.map(btnValue => {
                    const $div = $("<div/>").attr({
                        class: "btn-inner",
                    }).text(btnValue);
                    const $button = $("<button/>").attr({
                        type: "button",
                        class: "btn btn-confirm",
                        value: btnValue,
                    }).append($div);
                    return $button;
                });
                $(group).append($buttons);
            }
        }
        // 例外
        // ボタンが複数(列)という条件の場合「視力」ボタンを生成する
        //If the button has multiple (rows) conditions, generate the "eyesight" button
        if (!aIsSingleLine) {
            const captionVA = viewHelper.getDefMessage("global/va");
            const $div = $("<div/>").attr({
                class: "btn-inner",
            }).text(captionVA);
            const $button = $("<button/>").attr({
                type: "button",
                class: "btn btn-confirm",
                id: "btnShowVA",
            }).append($div);
            $(".confirm-box .btn-group-b").append($button);
        } {
            const group = ".confirm-box .btn-group-va";
            const button = group + " button";
            const $button = $(button); // すぐ上で生成したボタンを含めるため再代入
            if (!modelHelper.isNullOrEmpty($button)) {
                // ボタンの背景処理を変更する
                _buttonClickBackGroundOverlay($button);
            }
        }
    }

    /*!
     * @brief 視力表テーブルの更新
     *
     * @param[in] array chartTable chartPage.parameter.json の chartPageN の単一要素
     */
    function _updateChartTable(chartTable) {
        const chartParameterItem = becky.subjective.arrayChartParameter.chartParameter.filter(
            chartParameterItem_ => chartParameterItem_.chartID === chartTable.chartID)[0];
        // if (becky.assertion.isUndefined(chartParameterItem)) {
        //     return;
        // }

        let ChartAuto = chartTable.autoID;
        let stringChartAuto = ChartAuto.toString();
        let prismtabId = stringChartAuto.substring(0, 10);
        //alert(chartParameterItem.IsPrismChart);
        if (chartParameterItem.IsPrismChart == '1' && chartParameterItem.IsPrismHV == "HV") {
            $("#labelMainPrismHor").show();
            $("#labelMainPrismVer").show();
            //$(".prism-buttons").show();
            $(".horizontal-icons").show();
            $(".vertical-icons").hide();
            $("#labelMainPrismHor").trigger("click");
        } else if (chartParameterItem.IsPrismChart == '1' && chartParameterItem.IsPrismHV == "H") {
            $("#labelMainPrismHor").show();
            $("#labelMainPrismVer").show();
            $(".horizontal-icons").show();
            $(".vertical-icons").hide();
            _setSelectSCA("PrismHor");
            $("#btnControllerEyeL").trigger("click");

        } else if (chartParameterItem.IsPrismChart == '1' && chartParameterItem.IsPrismHV == "V") {
            $("#labelMainPrismHor").show();
            $("#labelMainPrismVer").show();
            $(".horizontal-icons").hide();
            $(".vertical-icons").show();
            _setSelectSCA("PrismVer");
            $("#btnControllerEyeR").trigger("click");

        } else if (chartParameterItem.IsPrismChart == '2' && chartParameterItem.IsPrismHV == "HV") {
            $("#labelMainPrismHor").show();
            $("#labelMainPrismVer").show();
           // $(".prism-buttons").show();
            $(".horizontal-icons").show();
            $(".vertical-icons").hide();
            $("#labelMainPrismHor").trigger("click");
        } else if (chartParameterItem.IsPrismChart == '2' && chartParameterItem.IsPrismHV == "H") {
            $("#labelMainPrismHor").show();
            $("#labelMainPrismVer").show();
            $(".horizontal-icons").show();
            $(".vertical-icons").hide();
            _setSelectSCA("PrismHor");
            $("#btnControllerEyeL").trigger("click");

        } else if (chartParameterItem.IsPrismChart == '2' && chartParameterItem.IsPrismHV == "V") {
            $("#labelMainPrismHor").show();
            $("#labelMainPrismVer").show();
            $(".horizontal-icons").hide();
            $(".vertical-icons").show();
            _setSelectSCA("PrismVer");
            $("#btnControllerEyeR").trigger("click");

        } else {
            $("#labelMainPrismHor").hide();
            $("#labelMainPrismVer").hide();
            $(".prism-buttons").hide();
        }

        // 反転/RG ボタンの更新
        _updateChartInvertAndRG(chartTable);

        // Todo. chart.parameter.json に定義すべき
        let col = chartParameterItem.col;
        let row = chartParameterItem.row;
        let one_letter = chartParameterItem.letter;
        let prevChart = chartParameterItem.transition.prevChartID;
        let nextChart = chartParameterItem.transition.nextChartID;
        _updateChartTableLayout(chartTable, col, row);
        localStorage['currentCol'] = col;
        localStorage['currentRow'] = row;

        /* show/hide mask navigation icons based on row/column count */

        const top_side_col = ".chart-table .top div";
        const top_side_row = ".chart-table .side div";

        if (col <= 1) {
            $(top_side_col).hide();
            $(".sidecursors").hide();
            $("#btnChartRG").hide();

        } else if (col >= 2) {
            $(top_side_col).show();
            $(".sidecursors").show();
            $("#btnChartRG").show();
        }

        if (row <= 1) {
            $(top_side_row).hide();
            $(".sidecursors").hide();
            $("#btnChartRG").hide();
        } else if (row >= 2) {
            $(top_side_row).show();
            $(".sidecursors").show();
            $("#btnChartRG").show();
        }

        $(".right").hide();
        $(".left").hide();


        // 視力表画像の切り替え
        let imgExt = "";
        switch (chartTable.chartID) {
            case 2004:
            case 2005:
            case 2006:
            case 2007:
            case 2104:
            case 2105:
            case 2106:
            case 2107:
            case 2204:
            case 2205:
            case 2206:
            case 2207:
            case 3156:
            case 3157:
                imgExt = ".svg";
                break;
            default:
                imgExt = ".png";
                break;

        }
        const imgSrc = "../img/large/large_" + chartTable.chartID + imgExt;
        $(".chart-table .image img").attr("src", imgSrc);

        let btnValues = null;
        switch (chartTable.examID) {
            case 1020: // [遠]乱視テスト
            case 1021: // [遠]ジャクソンクロスシリンダー
                btnValues = [0, 45, 90, 135, ];
                break;
            default:
                if (!becky.assertion.isUndefined(chartParameterItem.va) &&
                    !becky.assertion.isUndefined(chartParameterItem.va.string)) {
                    btnValues = chartParameterItem.va.string;
                }
                break;
        }

        const isSingleLine = modelHelper.isNullOrEmpty(btnValues) || 6 > btnValues.length;
        _updateChartTableButtons(btnValues, isSingleLine);

        // 「視力」ボタン関連のイベント
        {
            const $btnShowVA = $("#btnShowVA");
            const $chartTable = $(".chart-table");
            const $vaTable = $(".confirm-box .btn-group-c");
            const $vaTableButton = $(".confirm-box .btn-group-c button");
            const fncShowVA = function () {
                $chartTable.toggle();
                $vaTable.toggle();

            };
            const fncHideVA = function () {
                $chartTable.show();
                $vaTable.hide();
            };
            $btnShowVA.click(fncShowVA);

            $vaTableButton.click(fncHideVA);
            fncHideVA();
        }

        // 検査毎に異なるボタンイベントの登録を行う
        const $btnChartTable = $(".confirm-box .btn-group-va button");
        switch (chartTable.examID) {
            case 1000: // [遠]球面度テスト / 遠用視力測定
                $btnChartTable.click(function () {
                    const val = $(this).val();
                    if (modelHelper.isNullOrEmpty(val)) {
                        return;
                    }

                    let $labelMainVA = null;
                    let strFarNear = "";
                    const farNear = _getSelectFarNear();
                    switch (farNear) {
                        case "far":
                            strFarNear = "_Far";
                            break;
                        case "near":
                            strFarNear = "_Near";
                            break;
                        default:
                            becky.assertion.failure("unknown far near");
                            break;
                    }
                    const eyeValue = _getSelectEye();
                    switch (eyeValue) {
                        case "B":
                        case "R":
                        case "L":
                            $labelMainVA = $("#labelMainVA" + strFarNear + eyeValue);
                            break;
                        default:
                            becky.assertion.failure("unknown eye");
                            return;
                    }

                    $labelMainVA.attr("data-text", val);
                    $labelMainVA.attr("data-unit", chartParameterItem.va.format);
                });
                break;
            case 1020: // [遠]乱視テスト
            case 1021: // [遠]ジャクソンクロスシリンダー
                $btnChartTable.click(function () {
                    let val = $(this).val();
                    if (modelHelper.isNullOrEmpty(val)) {
                        return;
                    }

                    // 軸の 0 は 180 として扱う
                    if (0 == val) {
                        val = 180;
                    }

                    let $labelMainAxs = null;
                    const eyeValue = _getSelectEye();
                    switch (eyeValue) {
                        case "B":
                            $labelMainAxs = $("[id^=labelMainAxs]");
                            break;
                        case "R":
                        case "L":
                            $labelMainAxs = $("#labelMainAxs" + eyeValue);
                            break;
                        default:
                            becky.assertion.failure("unknown eye");
                            return;
                    }

                    // 値変更前
                    const orgJson = _updateDataMeasurementValue();

                    $labelMainAxs.each((i, element) => {
                        const $label = $(element);
                        const dValue = $label.attr("data-text");
                        if (modelHelper.isUndefined(dValue)) {
                            // おそらく、#labelMainAxsCaption
                            return;
                        }

                        $label.attr("data-text", val);
                    });

                    (async function () {
                        // ボタンを無効化
                        const pointerEvents = _getPointerEventsByCommand();
                        pointerEvents.begin();
                        try {
                            // フォロプター
                            await _postPhoropterCommand(_currentChart);
                            // 端末に一時保存(リロード対策)
                            _saveDataToWebStorage();
                        } catch (resultJson) {
                            // 失敗したら値を戻す
                            _updateDataMeasurementValue(orgJson);
                            // エラーメッセージ表示
                            becky.LeanStartup.alertErrorMessage(resultJson);
                        } finally {
                            // 完了時にボタンを有効化
                            pointerEvents.end();
                        }
                    }());

                });
                break;
            case 1010: // [遠]R/G テスト
            case 1092: // [遠]ウォース4点テスト
            case 2030: // [近]加入度測定
                break;
            case 1041:
            case 1042:
            case 1043:
            case 1044:
            case 1050:
                break;
            default:
                becky.assertion.failure("unknown chart examID");
                break;
        }

        switch (chartTable.examID) {
            case 1021: // [遠]ジャクソンクロスシリンダー
                $(".eye-mark").show();
                break;
            default:
                $(".eye-mark").hide();
                break;
        }

        _visibleChartButtonsOnLoad(nextChart, prevChart);
    }

    /*!
     * @brief 選択眼の更新
     *
     * @param[in] array chartTable chartPage.parameter.json の chartPageN の単一要素
     */
    function _updateSelectEyeFromChart(chartTable) {
        if (modelHelper.isUndefined(chartTable.testEyeID)) {
            return;
        }

        switch (chartTable.testEyeID) {
            case 0: // 検査対象眼の変更をせず、直前の状態を引き継ぐ
                break;
            case 1: // 片眼右眼検査
                _setSelectEye("R");
                break;
            case 2: // 片眼左眼検査
                _setSelectEye("L");
                break;
            case 3: // 直前の被検眼が片眼ならその状態を引き継ぎ、それ以外なら片眼(右)として扱う
                if (_isSelectEyeB()) {
                    _setSelectEye("R");
                }
                break;
            case 4: // 両眼検査で、データ変更対象が両眼
                _setSelectEye("B");
                break;
            case 5: // 両眼検査で、データ変更対象が右眼
                _setSelectEye("R");
                break;
            case 6: // 両眼検査で、データ変更対象が左眼
                _setSelectEye("L");
                break;
            default:
                becky.assertion.failure("unknown chart testEyeID");
                break;
        }
    }

    /*!
     * @brief 操作コントローラーのレイアウトの更新を行う
     *
     * @param[in] array chartTable chartPage.parameter.json の chartPageN の単一要素
     */
    function _updateControllerLayout(chartTable) {
        let htmls = null;
        let visibles = null;
        let disableEyeBino = false;
        switch (chartTable.examID) {
            case 1000: // [遠]球面度テスト / 遠用視力測定
            case 10031: {
                htmls = {
                    L: {
                        main: '<span id="imgAddPlus"></span>',
                        tips: "",
                    },
                    R: {
                        main: '<span id="imgAddMinus"></span>',
                        tips: "",
                    },
                };

            };
        case 2030: // [近]加入度測定
            htmls = {
                L: {
                    main: "( + )",
                    tips: "",
                },
                R: {
                    main: "( - )",
                    tips: "",
                },
            };
            visibles = {
                C: false,
                D: false,
                E: false,
                H: false,
                V: false,
            };
            break;
        case 1010: // [遠]R/G テスト
            htmls = {
                L: {
                    main: "G",
                    tips: "( + )",
                },
                R: {
                    main: "R",
                    tips: "( - )",
                },
            };
            visibles = {
                C: false,
                D: false,
                E: false,
                H: false,
                V: false,
            };
            break;

        case 1020: // [遠]乱視テスト
            htmls = {
                L: {
                    main: "( + )",
                    tips: "",
                },
                R: {
                    main: "( - )",
                    tips: "",
                },
                AreaD: _getDefMessageBySubjective("controllerPowerAxis"),
            };
            visibles = {
                C: false,
                D: true,
                E: false,
                H: false,
                V: false,
            };
            break;
        case 1021: // [遠]ジャクソンクロスシリンダー
            htmls = {
                L: {
                    main: "( + )",
                    tips: "",
                },
                R: {
                    main: "( - )",
                    tips: "",
                },
                AreaD: _getDefMessageBySubjective("controllerPowerAxis"),
            };
            visibles = {
                C: true,
                D: true,
                E: false,
                H: false,
                V: false,
            };
            disableEyeBino = true; // 両眼を無効化
            break;
        case 1092: // [遠]ウォース4点テスト
            // 原則、直前のものを使用する。ただし、controller-c のみ非表示にする
            visibles = {
                C: false,
            };
            break;
        default:
            becky.assertion.failure("unknown chart examID");
            htmls = {
                L: {
                    main: "",
                    tips: "",
                },
                R: {
                    main: "",
                    tips: "",
                },
            };
            visibles = {
                C: true,
                D: true,
                E: true,
                H: false,
                V: false,
            };
            break;
        }

        _updateSelectEyeFromChart(chartTable);

        if (modelHelper.isNull(htmls) &&
            modelHelper.isNull(visibles)) {
            return;
        }

        if (_isSelectFar() || _isSelectNear()) {

            // ADD が有効
            switch (chartTable.examID) {
                case 2030: // [近]加入度測定
                    htmls = {
                        L: {
                            main: '<span id="imgAddPlus"></span>',
                            tips: "",
                        },
                        R: {
                            main: '<span id="imgAddMinus"></span>',
                            tips: "",
                        },
                    };
                    visibles = {
                        C: false,
                        D: false,
                        E: false,
                        H: false,
                        V: false,
                    };
                    break;
                case 1041:
                    htmls = {
                        L: {
                            main: '<div class="vertical-icons"><div class="prism-heading-vertical">BD</div><span id="icon1041_BD_VER"></span></div><div class="horizontal-icons"><div class="prism-heading">BI</div><span id="icon1041_BI_HOR"></span></div>',
                            tips: "",
                        },
                        R: {
                            main: '<div class="vertical-icons"><div class="prism-heading-vertical">BU</div><span id="icon1041_BU_VER"></span></div><div class="horizontal-icons"><div class="prism-heading">BO</div><span id="icon1041_BO_HOR"></span></div>',
                            tips: "",
                        },
                    };
                    visibles = {
                        C: false,
                        D: false,
                        E: false,
                        H: true,
                        V: true,
                    };
                    break;
                case 1042:
                case 1051:
                case 2052:
                case 2062:
                case 2070:
                case 2072:

                    htmls = {
                        L: {
                            main: '<div class="vertical-icons"><div class="prism-heading-vertical">BD</div><span id="icon1051_BD_VER"></span></div><div class="horizontal-icons"><div class="prism-heading">BI</div><span id="icon1042_BI_HOR"></span></div>',
                            tips: "",
                        },
                        R: {
                            main: '<div class="vertical-icons"><div class="prism-heading-vertical">BU</div><span id="icon1051_BU_VER"></span></div><div class="horizontal-icons"><div class="prism-heading">BO</div><span id="icon1042_BO_HOR"></span></div>',
                            tips: "",
                        },
                    };
                    visibles = {
                        C: false,
                        D: false,
                        E: false,
                        H: true,
                        V: true,
                    };
                    break;
                case 1070:
                case 2090:
                    htmls = {
                        L: {
                            main: '<div class="horizontal-icons imageless"><div class="prism-heading">BI</div><div id="dummyShiftImageR"><span id="icon1070_BO_HOR"></span></div></div>',
                            tips: "",
                        },
                        R: {
                            main: '<div class="horizontal-icons imageless"><div class="prism-heading">BO</div><div id="dummyShiftImageL"><span id="icon1070_BO_HOR"></span></div></div>',
                            tips: "",
                        },
                    };
                    visibles = {
                        C: false,
                        D: false,
                        E: false,
                        H: true,
                        V: true,
                    };
                    break;
                case 1071:
                case 2091:
                    htmls = {
                        L: {
                            main: '<div class="vertical-icons imageless"><div class="prism-heading">BD</div><div id="vdummyShiftImageR"><span id="icon1070_BO_HOR"></span></div></div>',
                            tips: "",
                        },
                        R: {
                            main: '<div class="vertical-icons imageless"><div class="prism-heading">BU</div><div id="vdummyShiftImageL"><span id="icon1070_BO_HOR"></span></div></div>',
                            tips: "",
                        },
                    };
                    visibles = {
                        C: false,
                        D: false,
                        E: false,
                        H: true,
                        V: true,
                    };
                    break;
                case 1043:
                case 1053:
                    htmls = {
                        L: {
                            main: '<div class="vertical-icons"><div class="prism-heading-vertical">BD</div><span id="icon1043_BD_VER"></span></div><div class="horizontal-icons"><div class="prism-heading">BI</div><span id="icon1043_BI_HOR"></span></div>',
                            tips: "",
                        },
                        R: {
                            main: '<div class="vertical-icons"><div class="prism-heading-vertical">BU</div><span id="icon1043_BU_VER"></span></div><div class="horizontal-icons"><div class="prism-heading">BO</div><span id="icon1043_BO_HOR"></span></div>',
                            tips: "",
                        },
                    };
                    visibles = {
                        C: false,
                        D: false,
                        E: false,
                        H: true,
                        V: true,
                    };
                    break;
                case 1044:
                    htmls = {
                        L: {
                            main: '<div class="vertical-icons"><div class="prism-heading-vertical">BD</div><span id="icon1044_BD_VER"></span></div><div class="horizontal-icons"><div class="prism-heading">BI</div><span id="icon1044_BI_HOR"></span></div>',
                            tips: "",
                        },
                        R: {
                            main: '<div class="vertical-icons"><div class="prism-heading-vertical">BU</div><span id="icon1044_BU_VER"></span></div><div class="horizontal-icons"><div class="prism-heading">BO</div><span id="icon1044_BO_HOR"></span></div>',
                            tips: "",
                        },
                    };
                    visibles = {
                        C: false,
                        D: false,
                        E: false,
                        H: true,
                        V: true,
                    };
                    break;
                case 1050:
                case 2051:
                case 2061:
                case 2071:
                case 2076:
                    htmls = {
                        L: {
                            main: '<div class="vertical-icons"><div class="prism-heading-vertical">BD</div><span id="icon1041_BD_VER"></span></div><div class="horizontal-icons"><div class="prism-heading">BI</div><span id="icon1041_BI_HOR"></span></div>',
                            tips: "",
                        },
                        R: {
                            main: '<div class="vertical-icons"><div class="prism-heading-vertical">BU</div><span id="icon1041_BU_VER"></span></div><div class="horizontal-icons"><div class="prism-heading">BO</div><span id="icon1041_BO_HOR"></span></div>',
                            tips: "",
                        },
                    };
                    visibles = {
                        C: false,
                        D: false,
                        E: false,
                        H: true,
                        V: true,
                    };
                    break;



                case 2070:
                case 2072:
                    htmls = {
                        L: {
                            main: '<div class="vertical-icons"><div class="prism-heading-vertical">BD</div><span id="icon1051_BD_VER"></span></div>',
                            tips: "",
                        },
                        R: {
                            main: '<div class="vertical-icons"><div class="prism-heading-vertical">BU</div><span id="icon1051_BU_VER"></span></div>',
                            tips: "",
                        },
                    };
                    visibles = {
                        C: false,
                        D: false,
                        E: false,
                        H: true,
                        V: true,
                    };
                    break;
                    /*horizontal */

                case 2053:
                case 2064:
                case 2073:
                case 2077:
                    htmls = {
                        L: {
                            main: '<div class="vertical-icons"><div class="prism-heading-vertical">BD</div><span id="icon2052_BD_VER"></span></div><div class="horizontal-icons"><div class="prism-heading">BI</div><span id="icon2052_BI_HOR"></span></div>',
                            tips: "",
                        },
                        R: {
                            main: '<div class="vertical-icons"><div class="prism-heading-vertical">BU</div><span id="icon2052_BU_VER"></span></div><div class="horizontal-icons"><div class="prism-heading">BO</div><span id="icon2052_BO_HOR"></span></div>',
                            tips: "",
                        },
                    };
                    visibles = {
                        C: false,
                        D: false,
                        E: false,
                        H: true,
                        V: true,
                    };
                    break;
                case 1054:
                case 2054:
                case 2065:
                case 2074:
                case 2078:
                    htmls = {
                        L: {
                            main: '<div class="vertical-icons"><div class="prism-heading-vertical">BD</div><span id="icon1044_BD_VER"></span></div><div class="horizontal-icons"><div class="prism-heading">BI</div><span id="icon1044_BI_HOR"></span></div>',
                            tips: "",
                        },
                        R: {
                            main: '<div class="vertical-icons"><div class="prism-heading-vertical">BU</div><span id="icon1044_BU_VER"></span></div><div class="horizontal-icons"><div class="prism-heading">BO</div><span id="icon1044_BO_HOR"></span></div>',
                            tips: "",
                        },
                    };
                    visibles = {
                        C: false,
                        D: false,
                        E: false,
                        H: true,
                        V: true,
                    };
                    break;
                case 1061:
                    htmls = {
                        L: {
                            main: '<div class="vertical-icons"><div class="prism-heading-vertical">BD</div><span id="icon2051_BD_VER"></span></div><div class="horizontal-icons"><div class="prism-heading">BI</div><span id="icon2051_BI_HOR"></span></div>',
                            tips: "",
                        },
                        R: {
                            main: '<div class="vertical-icons"><div class="prism-heading-vertical">BU</div><span id="icon2051_BU_VER"></span></div><div class="horizontal-icons"><div class="prism-heading">BO</div><span id="icon2051_BO_HOR"></span></div>',
                            tips: "",
                        },
                    };
                    visibles = {
                        C: false,
                        D: false,
                        E: false,
                        H: true,
                        V: true,
                    };
                    break;
                case 1062:
                    htmls = {
                        L: {
                            main: '<div class="vertical-icons"><div class="prism-heading-vertical">BD</div><span id="icon1062_BD_VER"></span></div><div class="horizontal-icons"><div class="prism-heading">BI</div><span id="icon1062_BI_HOR"></span></div>',
                            tips: "",
                        },
                        R: {
                            main: '<div class="vertical-icons"><div class="prism-heading-vertical">BU</div><span id="icon1062_BU_VER"></span></div><div class="horizontal-icons"><div class="prism-heading">BO</div><span id="icon1062_BO_HOR"></span></div>',
                            tips: "",
                        },
                    };
                    visibles = {
                        C: false,
                        D: false,
                        E: false,
                        H: true,
                        V: true,
                    };
                    break;
                case 1090:
                case 2120:
                    htmls = {
                        L: {
                            main: '<div class="horizontal-icons imageless"><div class="prism-heading">BI</div></div>',
                            tips: "",
                        },
                        R: {
                            main: '<div class="horizontal-icons imageless"><div class="prism-heading">BO</div></div>',
                            tips: "",
                        },
                    };
                    visibles = {
                        C: false,
                        D: false,
                        E: false,
                        H: true,
                        V: true,
                    };
                    break;
                case 1091:
                case 2121:
                    htmls = {
                        L: {
                            main: '<div class="vertical-icons imageless"><div class="prism-heading-vertical">BD</div></div>',
                            tips: "",
                        },
                        R: {
                            main: '<div class="vertical-icons imageless"><div class="prism-heading-vertical">BU</div></div>',
                            tips: "",
                        },
                    };
                    visibles = {
                        C: false,
                        D: false,
                        E: false,
                        H: true,
                        V: true,
                    };
                    break;
                    // case 1092:
                    //     htmls = {
                    //         L: {
                    //             main: '<div class="vertical-icons"><div class="prism-heading-vertical">BD</div><span id="icon1041_BD_VER"></span></div><div class="horizontal-icons"><div class="prism-heading">BI</div><span id="icon1041_BI_HOR"></span></div>',
                    //             tips: "",
                    //         },
                    //         R: {
                    //             main: '<div class="vertical-icons"><div class="prism-heading-vertical">BU</div><span id="icon1041_BU_VER"></span></div><div class="horizontal-icons"><div class="prism-heading">BO</div><span id="icon1041_BO_HOR"></span></div>',
                    //             tips: "",
                    //         },
                    //     };
                    //     visibles = {
                    //         C: false,
                    //         D: false,
                    //         E: false,
                    //         H: true,
                    //         V: true,
                    //     };
                    //     break;
                case 1052:
                case 1071:
                case 2063:
                case 1049:
                case 2055:
                case 2080:
                case 2081:
                    htmls = {
                        L: {
                            main: '<div class="vertical-icons"><div class="prism-heading-vertical">BD</div><span id="icon1051_BD_VER"></span></div>',
                            tips: "",
                        },
                        R: {
                            main: '<div class="vertical-icons"><div class="prism-heading-vertical">BU</div><span id="icon1051_BU_VER"></span></div>',
                            tips: "",
                        },
                    };
                    visibles = {
                        C: false,
                        D: false,
                        E: false,
                        H: true,
                        V: true,
                    };
                    break;
                default:
                    htmls = {
                        L: {
                            main: "( + )",
                            tips: "",
                        },
                        R: {
                            main: "( - )",
                            tips: "",
                        },
                    };
                    visibles = {
                        C: false,
                        D: false,
                        E: false,
                        H: false,
                        V: false,
                    };
                    break;

            }
        }

        if (!modelHelper.isNull(htmls)) {
            $(".icon.icon-G").html(htmls.L.main);
            $(".icon.icon-R").html(htmls.R.main);
            $(".icon.icon-plus-brackets:eq(0)").html(htmls.L.tips);
            $(".icon.icon-plus-brackets:eq(1)").html(htmls.R.tips);
            if (!modelHelper.isNullOrEmpty(htmls.AreaD)) {
                $(".icon.icon-astigmat-axis").html(htmls.AreaD);
            }
        }
        if (!modelHelper.isUndefined(visibles.C)) {
            const $buttonC = $(".controller-c"); // 仮
            if (visibles.C) {
                $buttonC.show();
            } else {
                $buttonC.hide();
            }
        }
        if (!modelHelper.isUndefined(visibles.D)) {
            const $buttonD = $(".controller-d"); // 仮
            if (visibles.D) {
                $buttonD.show();
            } else {
                $buttonD.hide();
            }
        }
        if (!modelHelper.isUndefined(visibles.E)) {
            const $buttonE = $(".controller-e"); // 仮
            if (visibles.E) {
                $buttonE.show();
            } else {
                $buttonE.hide();
            }
        }
        if (!modelHelper.isUndefined(visibles.H)) {
            const $buttonH = $(".controller-prism"); // 仮
            if (visibles.H) {
                $buttonH.show();
            } else {
                $buttonH.hide();
            }
        }
        if (!modelHelper.isUndefined(visibles.V)) {
            const $buttonH = $(".controller-prism"); // 仮
            if (visibles.V) {
                $buttonH.show();
            } else {
                $buttonH.hide();
            }
        }

        if (disableEyeBino) {
            $("#btnControllerEyeB").addClass("disabled");
        } else {
            $("#btnControllerEyeB").removeClass("disabled");
        }
    }

    /*!
     * @brief メニューの初期化
     * 検査の切り替えタイミングで呼び出す
     *
     * @param[in] array chartTable chartPage.parameter.json の chartPageN の単一要素
     */
    function _updateMenuInit(chartTable) {

        let btnMenuEnables = null;
        switch (chartTable.examID) {
            case 1000: // [遠]球面度テスト / 遠用視力測定
            case 1010: // [遠]R/G テスト
            case 2030: // [近]加入度測定
                btnMenuEnables = "#btnMenuReferenceData, #btnMenuFarNear, #btnMenuBinoMono, #btnMenuS";
                $("#btnMenuS").hide();
                break;
            case 1020: // [遠]乱視テスト
                btnMenuEnables = "#btnMenuReferenceData, #btnMenuFarNear, #btnMenuBinoMono, #btnMenuC";
                break;
            case 1021: // [遠]ジャクソンクロスシリンダー
                btnMenuEnables = "#btnMenuReferenceData, #btnMenuFarNear, #btnMenuBinoMono, #btnMenuC, #btnMenuCC_Power";
                break;
            case 1092: // [遠]ウォース4点テスト
                btnMenuEnables = "#btnMenuChartID9, #btnMenuChartID9_ResultValue";
                break;
            case 1041:
                btnMenuEnables = "#btnMenuFarNear, #btnMenuPrism_Stap";
                $("#btnControllerEyeL").trigger("click");
                $("#btnMenuFarNear").val(newLocal);
                $("#btnMenuS").hide();
                $(".prism-hv-control").show();
                break;
            case 1042:
            case 1050:
            case 1051:
                btnMenuEnables = "#btnMenuFarNear, #btnMenuPrism_Stap";
                $("#btnControllerEyeL").trigger("click");
                $("#btnMenuFarNear").val(newLocal);
                $("#btnMenuS").hide();
                $(".prism-hv-control").show();
                break;
            case 1049:
                btnMenuEnables = "#btnMenuFarNear, #btnMenuPrism_Stap";
                $("#btnControllerEyeR").trigger("click");
                $("#btnMenuFarNear").val(newLocal);
                $("#btnMenuS").hide();
                $(".prism-hv-control").show();
                break;
            case 1053:
            case 1054:
            case 1043:
            case 1044:
                //btnMenuEnables = "#btnMenuReferenceData, #btnMenuPrism_Stap, #btnMenuFarNear, #btnOccludeFog, #btnFinalMemSet, #btnAuxLens, #btnSheard, #btnPrismStimulate, #btn15Pin";
                btnMenuEnables = "#btnMenuFarNear, #btnMenuPrism_Stap";
                $("#btnControllerEyeL").trigger("click");
                $("#btnMenuFarNear").val("far");
                $("#btnMenuS").hide();
                $(".prism-hv-control").show();
                break;
            case 1052:
                //btnMenuEnables = "#btnMenuReferenceData, #btnMenuPrism_Stap, #btnMenuFarNear, #btnOccludeFog, #btnFinalMemSet, #btnAuxLens, #btnSheard, #btn6Up, #btn10Up";
                btnMenuEnables = "#btnMenuFarNear, #btnMenuPrism_Stap";
                $("#btnControllerEyeL").trigger("click");
                $("#btnMenuFarNear").val("far");
                $("#btnMenuS").hide();
                $(".prism-hv-control").show();
                break;

            case 1061:
            case 1062:
                //btnMenuEnables = "#btnMenuReferenceData, #btnMenuPrism_Stap, #btnMenuFarNear, #btnOccludeFog, #btnFinalMemSet, #btnAuxLens";
                btnMenuEnables = "#btnMenuFarNear, #btnMenuPrism_Stap, #btnMenuReferenceData, #btnFinalMemSet ";
                $("#btnMenuFarNear").val("far");
                $("#btnControllerEyeL").trigger("click");
                $("#labelMenu_near").removeClass("txt-large").addClass("txt-small");
                $("#labelMenu_far").removeClass("txt-small").addClass("txt-large");
               // $(".labelMenu_H").addClass("txt-large");
                $(".labelMenu_V").addClass("txt-small");
                $("#btnMenuS").hide();
                $(".prism-hv-control").show();
                break;
            case 1090:
                    btnMenuEnables = " #btnMenuFarNear, #btnMenuPrism_Stap, #btnDLU, #btnDLUHalf, #btnUisD, #btnULDHalf, #btnULD, #btnDataClear1";
                    //btnMenuEnables = "#btnMenuFarNear, #btnMenuPrism_Stap";
                    $("#btnControllerEyeL").trigger("click");
                    $("#btnMenuFarNear").val("far");
                    $("#labelMenu_far").removeClass("txt-large").addClass("txt-small");
                    $("#labelMenu_near").removeClass("txt-small").addClass("txt-large");
                    $("#btnMenuS").hide();
                    $(".prism-hv-control").hide();
                    break;
            case 2120:
                btnMenuEnables = "#btnMenuFarNear, #btnMenuPrism_Stap, #btnDLU, #btnDLUHalf, #btnUisD, #btnULDHalf, #btnULD, #btnDataClear1";
                //btnMenuEnables = "#btnMenuFarNear, #btnMenuPrism_Stap";
                $("#btnControllerEyeL").trigger("click");
                $("#btnMenuFarNear").val("near");
                $("#labelMenu_near").removeClass("txt-large").addClass("txt-small");
                $("#labelMenu_far").removeClass("txt-small").addClass("txt-large");
                $("#btnMenuS").hide();
                $(".prism-hv-control").hide();
                break;
            case 1091:
                btnMenuEnables = "#btnMenuFarNear,  #btnMenuPrism_Stap, #btnRLL, #btnRLLhalf, #btnLisR, #btnLLRHalf, #btnLLR, #btnScaleStimulate, #btnDataClear2 ";
                // btnMenuEnables = "#btnMenuFarNear, #btnMenuPrism_Stap";
                $("#btnControllerEyeL").trigger("click");
                $("#btnMenuFarNear").val("far");
                $("#labelMenu_near").removeClass("txt-large").addClass("txt-small");
                $("#labelMenu_far").removeClass("txt-small").addClass("txt-large");
                $("#btnMenuS").hide();
                $(".prism-hv-control").hide();
                break;
            case 2121:
                btnMenuEnables = "#btnMenuFarNear,  #btnMenuPrism_Stap, #btnRLL, #btnRLLhalf, #btnLisR, #btnLLRHalf, #btnLLR, #btnDataClear2";
                $("#btnControllerEyeL").trigger("click");
                $("#btnMenuFarNear").val("near");
                $("#labelMenu_near").removeClass("txt-large").addClass("txt-small");
                $("#labelMenu_far").removeClass("txt-small").addClass("txt-large");
                $("#btnMenuS").hide();
                $(".prism-hv-control").hide();
                break;
            case 1092:
                btnMenuEnables = "#btnMenuFarNear, #btnMenuPrism_Stap, #btnBreakBU";
                $("#btnControllerEyeL").trigger("click");
                $("#btnMenuFarNear").val("far");
                $("#labelMenu_near").removeClass("txt-large").addClass("txt-small");
                $("#labelMenu_far").removeClass("txt-small").addClass("txt-large");
                $("#btnMenuS").hide();
                $(".prism-hv-control").hide();
                break;
            case 2090:
                btnMenuEnables = "#btnMenuFarNear, #btnBlurredBI, #btnBreakBI, #btnRecoveryBI, #prismClear, #btnBlurredBO, #btnBreakBO, #btnRecoveryBO, #btnDataClear4 ";
                $("#btnControllerEyeB").trigger("click");
                $("#btnMenuFarNear").val("near");
                $("#labelMenu_near").removeClass("txt-large").addClass("txt-small");
                $("#labelMenu_far").removeClass("txt-small").addClass("txt-large");
                $("#btnMenuS").hide();
                $(".prism-hv-control").hide();
                break;
            case 1070:
                btnMenuEnables = "#btnMenuFarNear, #btnBlurredBI2, #btnBreakBI2, #btnRecoveryBI2, #prismClear, #btnBlurredBO2, #btnBreakBO2, #btnRecoveryBO2, #btnDataClear ";
                $("#btnControllerEyeB").trigger("click");
                $("#btnMenuFarNear").val("far");
                $("#labelMenu_near").removeClass("txt-large").addClass("txt-small");
                $("#labelMenu_far").removeClass("txt-small").addClass("txt-large");
                $("#btnMenuS").hide();
                $(".prism-hv-control").hide();
                break;
            case 1071:
                btnMenuEnables = "#btnMenuFarNear, #btnMenuPrism_Stap, #btnBreakBU, #btnRecoveryBU, #prismClear, #btnBreakBD, #btnRecoveryBD, #btnDataClear5 "
                $("#btnControllerEyeB").trigger("click");
                $("#btnMenuFarNear").val("far");
                $("#labelMenu_near").removeClass("txt-large").addClass("txt-small");
                $("#labelMenu_far").removeClass("txt-small").addClass("txt-large");
                $("#btnMenuS").hide();
                $(".prism-hv-control").hide();
                break;
            case 2091:
                btnMenuEnables = "#btnMenuFarNear, #btnMenuPrism_Stap, #btnBreakBU2, #btnRecoveryBU2, #prismClear, #btnBreakBD2, #btnRecoveryBD2, #btnDataClear6 "
                $("#btnControllerEyeB").trigger("click");
                $("#btnMenuFarNear").val("near");
                $("#labelMenu_near").removeClass("txt-large").addClass("txt-small");
                $("#labelMenu_far").removeClass("txt-small").addClass("txt-large");
                $("#btnMenuS").hide();
                $(".prism-hv-control").hide();
                break;
            case 2055:
            case 2078:
            case 2061:
            case 2062:
            case 2063:
                btnMenuEnables = "#btnMenuFarNear, #btnMenuPrism_Stap";
                $("#btnMenuFarNear").val("near");
                // $("#btnControllerEyeR").trigger("click");
                $("#labelMenu_far").removeClass("txt-large").addClass("txt-small");
                $("#labelMenu_near").removeClass("txt-small").addClass("txt-large");
                $("#btnMenuS").hide();
                $(".prism-hv-control").show();
                break;
            case 2080:
            case 2081:
            case 2054:
                btnMenuEnables = "#btnMenuFarNear, #btnMenuPrism_Stap";
                $("#btnMenuFarNear").val("near");
                // $("#btnControllerEyeR").trigger("click");
                $("#labelMenu_far").removeClass("txt-large").addClass("txt-small");
                $("#labelMenu_near").removeClass("txt-small").addClass("txt-large");
                $("#btnMenuS").hide();
                $(".prism-hv-control").show();
                break;
            case 2053:
                btnMenuEnables = "#btnMenuFarNear, #btnMenuPrism_Stap";
                $("#btnMenuFarNear").val("near");
                $("#btnControllerEyeL").trigger("click");
                $("#labelMenu_far").removeClass("txt-large").addClass("txt-small");
                $("#labelMenu_near").removeClass("txt-small").addClass("txt-large");
                $("#btnMenuS").hide();
                $(".prism-hv-control").show();
                break;
            case 2052:
            case 2051:
                // btnMenuEnables = "#btnMenuFarNear, #btnMenuPrism_Stap, #btnOccludeFog, #btnMenuReferenceData, #btnFinalMemSet, #btnAuxLens, #btnSheard, #btnAca, #btn15Pin ";
                btnMenuEnables = "#btnMenuFarNear, #btnMenuPrism_Stap";
                $("#btnMenuFarNear").val("near");
                $("#btnControllerEyeL").trigger("click");
                $("#labelMenu_far").removeClass("txt-large").addClass("txt-small");
                $("#labelMenu_near").removeClass("txt-small").addClass("txt-large");
                $("#btnMenuS").hide();
                $(".prism-hv-control").show();
                break;

                // case 2052:
                //         //btnMenuEnables = "#btnMenuFarNear, #btnMenuPrism_Stap, #btnOccludeFog, #btnMenuReferenceData, #btnFinalMemSet, #btnAuxLens, #btnSheard, #btnAca, #btn15Pin ";
                //         btnMenuEnables = "#btnMenuFarNear, #btnMenuPrism_Stap";
                //         $("#btnMenuFarNear").val("near");
                //         $("#btnControllerEyeL").trigger("click");
                //         $("#labelMenu_far").removeClass("txt-large").addClass("txt-small");
                //         $("#labelMenu_near").removeClass("txt-small").addClass("txt-large");
                //         break;
                // case 2053:
                // btnMenuEnables = "#btnMenuFarNear, #btnMenuPrism_Stap, #btnOccludeFog, #btnMenuReferenceData, #btnFinalMemSet, #btnAuxLens, #btnSheard, #btnAca ";
                // btnMenuEnables = "#btnMenuFarNear, #btnMenuPrism_Stap";
                // $("#btnControllerEyeL").trigger("click");
                // $("#labelMenu_far").removeClass("txt-large").addClass("txt-small");
                // $("#labelMenu_near").removeClass("txt-small").addClass("txt-large");
                // break;

                // case 2054:
                //         btnMenuEnables = "#btnMenuFarNear, #btnMenuPrism_Stap";
                //         $("#btnControllerEyeL").trigger("click");
                //         $("#labelMenu_far").removeClass("txt-large").addClass("txt-small");
                //         $("#labelMenu_near").removeClass("txt-small").addClass("txt-large");
                //         break;
                // case 2061:
                //         btnMenuEnables = "#btnMenuFarNear, #btnMenuPrism_Stap";
                //         $("#btnControllerEyeL").trigger("click");
                //         $("#labelMenu_far").removeClass("txt-large").addClass("txt-small");
                //         $("#labelMenu_near").removeClass("txt-small").addClass("txt-large");
                //         break;
            case 2062:
                btnMenuEnables = "#btnMenuFarNear, #btnMenuPrism_Stap";
                $("#btnMenuFarNear").val("near");
                $("#btnControllerEyeL").trigger("click");
                $("#labelMenu_far").removeClass("txt-large").addClass("txt-small");
                $("#labelMenu_near").removeClass("txt-small").addClass("txt-large");
                break;
            case 2063:
                btnMenuEnables = "#btnMenuFarNear, #btnMenuPrism_Stap";
                $("#btnMenuFarNear").val("near");
                $("#btnControllerEyeL").trigger("click");
                $("#labelMenu_far").removeClass("txt-large").addClass("txt-small");
                $("#labelMenu_near").removeClass("txt-small").addClass("txt-large");
                break;
            case 2064:
                btnMenuEnables = "#btnMenuFarNear, #btnMenuPrism_Stap";
                $("#btnMenuFarNear").val("near");
                $("#btnControllerEyeL").trigger("click");
                $("#labelMenu_far").removeClass("txt-large").addClass("txt-small");
                $("#labelMenu_near").removeClass("txt-small").addClass("txt-large");
                $("#btnMenuS").hide();
                break;
            case 2065:
                btnMenuEnables = "#btnMenuFarNear, #btnMenuPrism_Stap";
                $("#btnMenuFarNear").val("near");
                $("#btnControllerEyeL").trigger("click");
                $("#labelMenu_far").removeClass("txt-large").addClass("txt-small");
                $("#labelMenu_near").removeClass("txt-small").addClass("txt-large");
                $("#btnMenuS").hide();
                break;
            case 2070:
                btnMenuEnables = "#btnMenuFarNear, #btnMenuPrism_Stap";
                $("#btnMenuFarNear").val("near");
                $("#btnControllerEyeL").trigger("click");
                $("#labelMenu_far").removeClass("txt-large").addClass("txt-small");
                $("#labelMenu_near").removeClass("txt-small").addClass("txt-large");
                $("#btnMenuS").hide();
                break;
            case 2071:
                btnMenuEnables = "#btnMenuFarNear, #btnMenuPrism_Stap";
                $("#btnMenuFarNear").val("near");
                $("#btnControllerEyeL").trigger("click");
                $("#labelMenu_far").removeClass("txt-large").addClass("txt-small");
                $("#labelMenu_near").removeClass("txt-small").addClass("txt-large");
                $("#btnMenuS").hide();
                break;
            case 2072:
                btnMenuEnables = "#btnMenuFarNear, #btnMenuPrism_Stap";
                $("#btnMenuFarNear").val("near");
                $("#btnControllerEyeL").trigger("click");
                $("#labelMenu_far").removeClass("txt-large").addClass("txt-small");
                $("#labelMenu_near").removeClass("txt-small").addClass("txt-large");
                $("#btnMenuS").hide();
                break;
            case 2073:
                btnMenuEnables = "#btnMenuFarNear, #btnMenuPrism_Stap";
                $("#btnMenuFarNear").val("near");
                $("#btnControllerEyeL").trigger("click");
                $("#labelMenu_far").removeClass("txt-large").addClass("txt-small");
                $("#labelMenu_near").removeClass("txt-small").addClass("txt-large");
                $("#btnMenuS").hide();
                break;
            case 2074:
                btnMenuEnables = "#btnMenuFarNear, #btnMenuPrism_Stap";
                $("#btnMenuFarNear").val("near");
                $("#btnControllerEyeL").trigger("click");
                $("#labelMenu_far").removeClass("txt-large").addClass("txt-small");
                $("#labelMenu_near").removeClass("txt-small").addClass("txt-large");
                $("#btnMenuS").hide();
                break;
            case 2076:
                btnMenuEnables = "#btnMenuFarNear, #btnMenuPrism_Stap";
                $("#btnMenuFarNear").val("near");
                $("#btnControllerEyeL").trigger("click");
                $("#labelMenu_far").removeClass("txt-large").addClass("txt-small");
                $("#labelMenu_near").removeClass("txt-small").addClass("txt-large");
                $("#btnMenuS").hide();
                break;
            case 2077:
                btnMenuEnables = "#btnMenuFarNear, #btnMenuPrism_Stap";
                $("#btnMenuFarNear").val("near");
                $("#btnControllerEyeL").trigger("click");
                $("#labelMenu_far").removeClass("txt-large").addClass("txt-small");
                $("#labelMenu_near").removeClass("txt-small").addClass("txt-large");
                $("#btnMenuS").hide();
                break;
                // case 2078:
                //         btnMenuEnables = "#btnMenuFarNear, #btnMenuPrism_Stap";
                //         $("#btnMenuFarNear").val("near");
                //         $("#btnControllerEyeL").trigger("click");
                //         $("#labelMenu_far").removeClass("txt-large").addClass("txt-small");
                //         $("#labelMenu_near").removeClass("txt-small").addClass("txt-large");
                //         break;
            default:
                becky.assertion.failure("unknown chart examID");
                break;
        }
        if (modelHelper.isNullOrEmpty(btnMenuEnables)) {
            return;
        }

        // 全検査共通で必ず表示
        //btnMenuEnables += ", #btnMenu1";

        $(".menu-item").hide();
        $(btnMenuEnables).each((i, element) => {
            $(element).parent().show();
        });
    }
    /*!
     * @brief S/C/A 選択状態の更新を行う
     * 遠見/近見 の切り替えイベントから
     */
    function _updateSelectSCA_FromFarNear() {
        _setSelectSCA(_isSelectNear() ? _changeFarNearSetSCA.near : _changeFarNearSetSCA.far);
    }

    /*!
     * @brief S/C/A 選択状態の更新を行う
     * Chart 情報を元に更新する
     *
     * @param[in] array chartTable chartPage.parameter.json の chartPageN の単一要素
     */
    function _updateSelectSCA_FromChart(chartTable) {


        // if (becky.assertion.isUndefined(chartTable)) {
        //     return;
        // }

        const chartParameterItem = becky.subjective.arrayChartParameter.chartParameter.filter(
            chartParameterItem_ => chartParameterItem_.chartID === chartTable.chartID)[0];
        if (becky.assertion.isUndefined(chartParameterItem)) {
            return;
        }

        const bIsSelectNear = _isSelectNear();


        switch (chartTable.examID) {
            case 1000: // [遠]球面度テスト / 遠用視力測定
            case 1010: // [遠]R/G テスト
            case 2030: // [近]加入度測定
                if (bIsSelectNear) {
                    // ADD が有効
                    _setSelectSCA("ADD");
                } else {
                    // Sph が有効
                    _setSelectSCA("Sph");
                }
                break;
            case 1020: // [遠]乱視テスト
            case 1021: // [遠]ジャクソンクロスシリンダー
                if (bIsSelectNear) {
                    // ADD が有効
                    _setSelectSCA("ADD");
                } else {
                    // Axs が有効
                    _setSelectSCA("Axs");
                }
                break;
            case 1092: // [遠]ウォース4点テスト
                // 直前のものを使用
                break;
            case 1041:
            case 1043:
            case 1044:
            case 1050:
            case 1053:
            case 1042:
            case 1049:
            case 1051:
            case 1052:
            case 1070:
            case 1071:
            case 1090:
            case 1091:
            case 2120:
            case 2121:
            case 2090:
            case 2091:
            case 2063:
            case 2051:
            case 2053:
            case 2054:
            case 2076:
            case 2077:
            case 2074:
            case 1062:
            case 1061:
            case 2073:
            case 2071:
            case 2061:
            case 2065:
            case 2078:
                if (chartParameterItem.IsPrismHV == "V") {
                    _setSelectSCA("PrismVer");
                    $("#btnControllerEyeR").trigger("click");
                } else if ((chartParameterItem.IsPrismHV == "HV") || (chartParameterItem.IsPrismHV == "H")){
                    _setSelectSCA("PrismHor");
                    $("#btnControllerEyeL").trigger("click");
                }
                
                break;
            default:
                becky.assertion.failure("unknown chart examID");
                break;
        }
    }

    /*!
     * @brief メインのフォーカスの更新を行う
     *
     * @param[in] array aIsSelectEyes R/L   の選択状態の配列
     * @param[in] array aIsSelectSCAs S/C/A の選択状態の配列
     */
    function _updateMainFocus(aIsSelectEyes, aIsSelectSCAs) {

        // 選択状態が取得できない場合は画面から取得
        if (modelHelper.isNullOrEmpty(aIsSelectEyes)) {
            aIsSelectEyes = {
                R: _isSelectEyeR(),
                L: _isSelectEyeL(),
            };
        }
        if (modelHelper.isNullOrEmpty(aIsSelectSCAs)) {
            aIsSelectSCAs = {
                Sph: _isSelectSph(),
                Cyl: _isSelectCyl(),
                Axs: _isSelectAxs(),
                ADD: _isSelectADD(),
                PrismHor: _isSelectHor(),
                PrismVer: _isSelectVer(),
            };
        }

        const prefix = "labelMain";
        // いったん全て解除
        $("[id^=" + prefix + "]").parents(".td").removeClass("focus");

        Object.keys(aIsSelectSCAs).forEach(function (aSCA) {
            const bIsSelect = this[aSCA];
            if (!bIsSelect) return;
            let suffix = "";
            switch (aSCA) {
                case "ADD": // ADD は末尾に"_"が付く
                    suffix = "_";
                    break;
                default:
                    break;
            }

            const prefix_sca = prefix + aSCA + suffix;
            //  const prefix_sca = "labelMainPrism";
            // 項目部
            $("#" + prefix_sca + "Caption").parents(".td").addClass("focus");
            // 値(R/L)
            Object.keys(aIsSelectEyes).forEach(function (aEye) {
                const bIsSelect = this[aEye];
                if (!bIsSelect) return;
                $("#" + prefix_sca + aEye).parents(".td").addClass("focus");
            }, aIsSelectEyes);
        }, aIsSelectSCAs);
    }

    /*!
     * @brief メインの色の更新を行う(単体)
     *
     * @param[in,out] element $labelMain 対象のラベル
     */
    function _updateMainColor($labelMain) {
        if (becky.assertion.isNullOrEmpty($labelMain)) {
            return;
        }

        const dataText = $labelMain.attr("data-text");
        if (modelHelper.isUndefined(dataText)) {
            return;
        }

        // 値が +/- で使用するクラスを取得する
        const dataClassPlus = $labelMain.attr("data-class-plus");
        const dataClassMinus = $labelMain.attr("data-class-minus");
        if (modelHelper.isUndefined(dataClassPlus) ||
            modelHelper.isUndefined(dataClassMinus)) {
            return;
        }

        const $parents_td = $labelMain.parents(".td");
        if (becky.assertion.isNullOrEmpty($parents_td)) {
            return;
        }

        let dataTextFloat = parseFloat(dataText);
        if (isNaN(dataTextFloat)) {
            $parents_td.removeClass(dataClassPlus + " " + dataClassMinus);
        } else {
            const dataFround = $labelMain.attr("data-fround");
            const dataFbankersRound = $labelMain.attr("data-fbankers-round");
            if (!modelHelper.isUndefined(dataFround)) {
                dataTextFloat = modelHelper.fround(dataTextFloat, dataFround);
            } else if (!modelHelper.isUndefined(dataFbankersRound)) {
                dataTextFloat = modelHelper.fbankersRound(dataTextFloat, dataFbankersRound);
            }
            if (0.0 < dataTextFloat) {
                $parents_td.addClass(dataClassPlus).removeClass(dataClassMinus);
            } else if (0.0 > dataTextFloat) {
                $parents_td.addClass(dataClassMinus).removeClass(dataClassPlus);
            } else {
                $parents_td.removeClass(dataClassPlus + " " + dataClassMinus);
            }
        }

    }

    /*!
     * @brief メインの色の更新を行う(全体)
     */
    function _updateMainColors() {
        // 球面度数、乱視度数、加入度数
        $("[id^=labelMainSph], [id^=labelMainCyl], [id^=labelMainADD_]").each((i, element) => {
            _updateMainColor($(element));
        });
    }

    /*!
     * @brief メインのクラス郡の更新を行う
     *
     * @param[in] array aIsSelectEyes R/L   の選択状態の配列
     * @param[in] array aIsSelectSCAs S/C/A の選択状態の配列
     */
    function _updateMainClasses(aIsSelectEyes, aIsSelectSCAs) {
        _updateMainFocus(aIsSelectEyes, aIsSelectSCAs);
        _updateMainColors();
    }

    /*!
     * @brief クロスシリンダーのクラス郡の更新を行う
     */
    function _updateCrossCylinderClasses() {
        if (_isSelectEyeB() ||
            _isSelectSph()) {
            return;
        }

        let classIconEyemarkBC = null;
        switch (_getCrossCylinderRG()) {
            case 1:
                classIconEyemarkBC = "icon-eyemark-b";
                break;
            case 2:
                classIconEyemarkBC = "icon-eyemark-c";
                break;
            default:
                becky.assertion.failure("unknown type CrossCylinderRG");
                break;
        }
        if (_isSelectAxs()) {
            classIconEyemarkBC += "-axs";
        } else if (_isSelectCyl()) {
            classIconEyemarkBC += "-cyl";
        }

        const removeClasses = [
            "icon-eyemark-a",
            "icon-eyemark-b-axs",
            "icon-eyemark-c-axs",
            "icon-eyemark-b-cyl",
            "icon-eyemark-c-cyl",
        ];
        $("#iconEyeMarkR, #iconEyeMarkL").removeClass(removeClasses.join(" "));
        if (_isSelectEyeR()) {
            $("#iconEyeMarkR").addClass(classIconEyemarkBC)
            $("#iconEyeMarkL").addClass("icon-eyemark-a");
        } else if (_isSelectEyeL()) {
            $("#iconEyeMarkR").addClass("icon-eyemark-a");
            $("#iconEyeMarkL").addClass(classIconEyemarkBC);
        }
    }

    /*!
     * @brief autoID をキーに視力表のデータを得る
     *
     * @param[in] array aArrayFlatChartPageParameter chartPage.parameter.json をフラットな構造にしたもの
     * @param[in] int aAutoID 自動生成ID
     * @return array 視力表のデータ
     */
    function _getChartByAutoID(aArrayFlatChartPageParameter, aAutoID) {
        const charts = aArrayFlatChartPageParameter.filter(chart_ => aAutoID == chart_.autoID);

        // autoID は重複しないはずなので、最初の要素を得る
        if (becky.assertion.isFalse(1 === charts.length)) {
            // 複数要素は許さない
            return null;
        }

        return charts[0];
    }

    /*!
     * @brief ResetBase コマンドを送信する
     * X, Y, Z, θを指定
     *
     * @return Promise
     */
    async function _postResetBaseXYZCommand() {
        const resetBaseJson = {
            X: true,
            Y: true,
            Z: true,
            //	Theta: true, // 遠見に戻ってしまうため除外
        };
        await becky.LeanStartup.post("ResetBase", resetBaseJson);
    }

    /*!
     * @brief ChronosAlignment2 コマンドを送信する
     *
     * @return Promise
     */
    async function _postAlignmentCommand() {
        const alignmentJson = {
            RangeXY: 1.0,
            RangeZ: 1.0,
            infoForLog: becky.log.createCommandParamInfoForLog(new Date()),
        };
        let postPos /* = ""*/ ;
        if (_isSelectMono() && !_isSelectEyeB()) {
            // 片眼遮蔽かつ両眼以外なら、アライメントは片眼のみ
            postPos = _getSelectEye();
        }
        await becky.LeanStartup.post("ChronosAlignment2", alignmentJson, postPos);
    }

    /*!
     * @brief ChartID を生成する(片眼)
     *
     * @param[in] array chartTable chartPage.parameter.json の chartPageN の単一要素
     * @param[in] int aFlatFusionFrameID 融像枠のID
     * @param[in] bool aIsSelectEye 対象の眼が選択されているか？
     * @return int ChartID
     */
    function _createChartID_ByEye(chartTable, aFlatFusionFrameID, aIsSelectEye) {
        if (!aIsSelectEye) {
            const selectBinoMono = _getSelectBinoMono();
            switch (selectBinoMono) {
                case "bino":
                    // 両眼開放
                    return aFlatFusionFrameID; // 融像枠
                case "mono":
                    // 片眼遮蔽
                    return 0; // 黒画像
                default:
                    becky.assertion.failure("un-known value _getSelectBinoMono()");
                    break;
            }
        }

        return chartTable.chartID; // 視標ID
    }

    /*!
     * @brief ChartIDs を生成する
     *
     * @param[in] array chartTable chartPage.parameter.json の chartPageN の単一要素
     * @param[in] int aFlatFusionFrameID 融像枠のID
     * @return object ChartIDs
     */
    function _createChartIDs(chartTable, aFlatFusionFrameID) {
        return {
            R: _createChartID_ByEye(chartTable, aFlatFusionFrameID, _isSelectEyeR()),
            L: _createChartID_ByEye(chartTable, aFlatFusionFrameID, _isSelectEyeL()),
        };
    }

    /*!
     * @brief Chart コマンドに渡すパラメータを生成
     * 画面の状態に依存しているものが多いため呼び出し順はなるべく後が良い
     *
     * @param[in] array chartTable chartPage.parameter.json の chartPageN の単一要素
     * @return array Chart コマンドに渡すパラメータ
     */
    function _createChartParam(chartTable) {
        let chartIDs = null;
        const newJson = _updateDataMeasurementValue();
        switch (chartTable.chartID) {
            case 7000: // [遠]R/G テスト
                // RG視標専用融像枠(4)
                chartIDs = _createChartIDs(chartTable, 4);
                break;
            case 7030: // [遠]ウォース4点テスト
                // 融像枠の対応は不要
                chartIDs = {
                    R: 7031,
                    L: 7032,
                }
                break;
            default:
                // 汎用融像枠(1)
                chartIDs = _createChartIDs(chartTable, 1);
                break;
        }

        return {
            R: {
                chartID: chartIDs.R,
                effect: 0,
                Hpri: {
                    Direction: 1, //BO
                    Value: newJson.H_R
                },
                Vpri: {
                    Direction: 1, //BU
                    Value: newJson.V_R
                },

            },
            L: {
                chartID: chartIDs.L,
                effect: 0,
                Hpri: {
                    Direction: 0, //BI
                    Value: newJson.H_L
                },
                Vpri: {
                    Direction: 0, //BD
                    Value: newJson.V_L
                },

            },
        };
    }

    /*!
     * @brief Chart コマンドを送信する
     *
     * @param[in] array chartTable chartPage.parameter.json の chartPageN の単一要素
     * @return Promise
     */
    async function _postChartCommand(chartTable) {
        const operatorLogNodes = [];

        try {
            const requestJson = _createChartParam(chartTable);
            await becky.LeanStartup.postWithOperatorLog(
                "Chart", requestJson, "", new Date(), operatorLogNodes);
        } finally {
            // 操作ログ
            becky.operatorLog.pushSubjectiveCommandNodes(operatorLogNodes);
        }
    }

    /*!
     * @brief Create mask pattern
     *
     * @param[in] array chartTable chartPage.parameter.json の chartPageN の単一要素
     * @return Promise
     */

    function _createMaskParam(chartTable) {
        let chartIDs = null;
        switch (chartTable.chartID) {
            case 7000: // [遠]R/G テスト
                // RG視標専用融像枠(4)
                chartIDs = _createChartIDs(chartTable, 4);
                break;
            case 7030: // [遠]ウォース4点テスト
                // 融像枠の対応は不要
                chartIDs = {
                    R: 7031,
                    L: 7032,
                }
                break;
            default:
                // 汎用融像枠(1)
                chartIDs = _createChartIDs(chartTable, 1);
                break;
        }

        return {
            chartID: chartIDs.R,
            maskCellID: chartTable.maskCell,
            Row: chartTable.Row,
            Col: chartTable.Col

            /* L: { chartID: chartIDs.L, 
            	 maskCellID: chartTable.maskCell
            	}, */
        };
    }


    /*!
     * @brief Mask Send command
     *
     * @param[in] array chartTable chartPage.parameter.json の chartPageN の単一要素
     * @return Promise
     */
    async function _postMaskCommand(chartTable) {
        const operatorLogNodes = [];
        try {
            const requestJson = _createMaskParam(chartTable);
            await becky.LeanStartup.postWithOperatorLog(
                "Chart", requestJson, "", new Date(), operatorLogNodes);
        } finally {
            // 操作ログ
            becky.operatorLog.pushSubjectiveCommandNodes(operatorLogNodes);
        }
    }

    /*!
     * @brief _postLCOS_Command に渡すIDを生成
     * もし、null が返ってきた場合は渡す必要が無い
     * 
     * @param[in] aBackupPP 直前の _createPhoropterParam 関数の値
     * @param[in] aNewPP 新しい  _createPhoropterParam 関数の値
     * @return integer | null
     */
    function _createLCOS_CommandID(aBackupPP, aNewPP) {
        const statuses = [
            aBackupPP.crossCylinder.status,
            aNewPP.crossCylinder.status,
        ];
        statuses.sort();
        if (1 === statuses[0] && 2 === statuses[1]) {
            // クロスシリンダーの 乱視←→軸 へ切り替え時
            return 1; // 融像枠
        }

        const diffChecker = {
            isExamDistance: aBackupPP.distance !== aNewPP.distance,
            isCrossCylinderRG: aBackupPP.crossCylinder.RG !== aNewPP.crossCylinder.RG,
            //! 差があるか？
            someDiff: function () {
                return Object.keys(this).some(function (propertyName_) {
                    if (!modelHelper.isBoolean(this[propertyName_])) {
                        return false;
                    }
                    return this[propertyName_];
                }, this);
            },
        };

        if (!diffChecker.someDiff()) {
            // 変化が無いのでコマンド送信の必要が無い
            return null;
        }
        if (diffChecker.isExamDistance) {
            // 検査距離に変化あり
            return 0; // 消灯
        }
        if (diffChecker.isCrossCylinderRG) {
            // クロスシリンダーのRGに変化あり
            return 1; // 融像枠
        }

        // 実装ミス
        becky.assertion.failure("_getLCOS_CommandID add switch");
        return null;
    }

    /*!
     * @brief LCOS コマンドを送信する
     * といっても Chart コマンド
     *
     * @param[in] int aID 画像ID (0:黒, 1:融像枠)
     * @return Promise
     */
    async function _postLCOS_Command(aID) {
        const operatorLogNodes = [];
        try {
            await becky.LeanStartup.postWithOperatorLog(
                "Chart", {
                    R: {
                        chartID: aID
                    },
                    L: {
                        chartID: aID
                    },
                }, "", new Date(), operatorLogNodes);
        } finally {
            // 操作ログ
            becky.operatorLog.pushSubjectiveCommandNodes(operatorLogNodes);
        }
    }

    /*!
     * @brief Phoropter コマンドに渡すパラメータを生成
     * 画面の状態に依存しているものが多いため呼び出し順はなるべく後が良い
     *
     * @param[in] array chartTable chartPage.parameter.json の chartPageN の単一要素
     * @return array Phoropter コマンドに渡すパラメータ
     */
    function _createPhoropterParam(chartTable) {
        const newJson = _updateDataMeasurementValue();

        let nEye = 0;
        const eyeValue = _getSelectEye();
        switch (eyeValue) {
            case "B":
                nEye = 2;
                break;
            case "R":
                nEye = 0;
                break;
            case "L":
                nEye = 1;
                break;
            default:
                becky.assertion.failure("unknown eye");
                break;
        }

        let nDistance = 0;
        const strSelectFarNear = _getSelectFarNear();

        switch (strSelectFarNear) {
            case "far":
            case "near":
                nDistance = $("#inputExaminationDistancePoint_" + strSelectFarNear).val();
                break;
            default:
                becky.assertion.failure("un-known value _getSelectFarNear()");
                break;
        }

        const nVD = becky.settingJson.objective.vd;
        const nPD = $("#labelPD").attr("data-text");
        const nSphR = _isSelectFar() ? newJson.SphR : newJson.SphR + newJson.ADD_R;
        const nSphL = _isSelectFar() ? newJson.SphL : newJson.SphL + newJson.ADD_L;
        const nRGFilter = _getRGFilter(chartTable);
        const crossCylinderJson = _getCrossCylinderByPhoropter(chartTable);

        const requestJson = {
            eye: nEye,
            distance: nDistance,
            vd: nVD,
            pd: nPD,
            R: {
                sphere: nSphR,
                cylinder: newJson.CylR,
                axis: newJson.AxsR,
            },
            L: {
                sphere: nSphL,
                cylinder: newJson.CylL,
                axis: newJson.AxsL,
            },
            crossCylinder: crossCylinderJson,
            RGFilter: nRGFilter
            /*prism: {
                R: {
                    Hpri: {
                        Direction: 1, //BO
                        Value: newJson.H_R
                    },
                    Vpri: {
                        Direction: 1, //BU
                        Value: newJson.V_R
                    },

                },
                L: {
                    Hpri: {
                        Direction: 0, //BI
                        Value: newJson.H_L
                    },
                    Vpri: {
                        Direction: 0, //BD
                        Value: newJson.V_L
                    }
                },
            }*/
        };

        // データの正規化
        becky.jsonHelper.normalization(requestJson);

        return requestJson;
    }

    /*!
     * @brief Phoropter コマンドを送信する
     *
     * @param[in] array chartTable chartPage.parameter.json の chartPageN の単一要素
     * @return Promise
     */
    async function _postPhoropterCommand(chartTable) {
        const operatorLogNodes = [];

        try {
            const requestJson = _createPhoropterParam(chartTable);
            await becky.LeanStartup.postWithOperatorLog(
                "Phoropter", requestJson, "", new Date(), operatorLogNodes);
        } finally {
            // 操作ログ
            becky.operatorLog.pushSubjectiveCommandNodes(operatorLogNodes);
        }
    }

    /*!
     * @brief ボタンクリック時に背景を変更する
     *
     * @param[in] element $btn 対象のボタン
     */
    function _buttonClickBackGroundOverlay($btn) {

        if (becky.assertion.isNullOrEmpty($btn)) {
            return;
        }

        viewHelper.eventRegistrationTouchDownUp($btn,
            function () {
                $(this).addClass("active");
            },
            function () {
                $(this).removeClass("active");
            });
    }

    /*!
     * @brief 計測データ・画面状態を WebStorage(Web browser) に保存
     * リロード対策
     *
     * @return void
     */
    function _saveDataToWebStorage() {
        //console.log(_updateData());
        becky.WebStorage.local.setJson("subjective.update.data", _updateData());
    }

    /*!
     * @brief 更新(計測データ)
     *
     * @param[in] object aModel 引数が未指定:View→Model, 引数有り:Model→View
     * @return object 戻り値が存在するのは View→Model のみ
     */
    function _updateDataMeasurementValue(aModel) {
        // 属性の入出力
        const jQattrIO = (id_, key_, val_) => {
            if (modelHelper.isUndefined(val_)) {
                // get
                return $(id_).attr(key_);
            } else {
                // set
                $(id_).attr(key_, val_);
            }
        };
        const jQattrDataText = (id_, val_) => jQattrIO(id_, "data-text", val_);
        const jQattrDataValue = (id_, val_) => jQattrIO(id_, "data-value", val_);
        const jQattrDataUnit = (id_, val_) => jQattrIO(id_, "data-unit", val_);

        // value の入出力
        const jQvalIO = (id_, val_) => {
            if (modelHelper.isUndefined(val_)) {
                // get
                return $(id_).val();
            } else {
                // set
                $(id_).val(val_);
            }
        };

        const update = {
            SphL: val_ => jQattrDataText("#labelMainSphL", val_),
            CylL: val_ => jQattrDataText("#labelMainCylL", val_),
            AxsL: val_ => jQattrDataText("#labelMainAxsL", val_),
            ADD_L: val_ => jQattrDataText("#labelMainADD_L", val_),


            VA_FarL: val_ => jQattrDataText("#labelMainVA_FarL", val_),
            VA_UnitFarL: val_ => jQattrDataUnit("#labelMainVA_FarL", val_),
            VA_NearL: val_ => jQattrDataText("#labelMainVA_NearL", val_),
            VA_UnitNearL: val_ => jQattrDataUnit("#labelMainVA_NearL", val_),

            SphR: val_ => jQattrDataText("#labelMainSphR", val_),
            CylR: val_ => jQattrDataText("#labelMainCylR", val_),
            AxsR: val_ => jQattrDataText("#labelMainAxsR", val_),
            ADD_R: val_ => jQattrDataText("#labelMainADD_R", val_),

            VA_FarR: val_ => jQattrDataText("#labelMainVA_FarR", val_),
            VA_UnitFarR: val_ => jQattrDataUnit("#labelMainVA_FarR", val_),
            VA_NearR: val_ => jQattrDataText("#labelMainVA_NearR", val_),
            VA_UnitNearR: val_ => jQattrDataUnit("#labelMainVA_NearR", val_),

            VA_FarB: val_ => jQattrDataText("#labelMainVA_FarB", val_),
            VA_UnitFarB: val_ => jQattrDataUnit("#labelMainVA_FarB", val_),
            VA_NearB: val_ => jQattrDataText("#labelMainVA_NearB", val_),
            VA_UnitNearB: val_ => jQattrDataUnit("#labelMainVA_NearB", val_),

            PD: val_ => jQattrDataText("#labelPD", val_),

            // 検査距離
            ExamDistanceFar: val_ => jQvalIO("#inputExaminationDistancePoint_far", val_),
            ExamDistanceNear: val_ => jQvalIO("#inputExaminationDistancePoint_near", val_),

            // ウォース4点テスト
            Worth4DotsResult: val_ => jQattrDataValue("#btnMenuChartID9_ResultValue", val_),
            // クロスシリンダー power
            CC_Power: val_ => jQattrDataValue("#btnMenuCC_Power", val_),
            Prism_Power: val_ => jQattrDataValue("#btnMenuPrism_Stap", val_),
        };

        if (modelHelper.isUndefined(aModel)) {
            // View -> Model
            const json = {};
            Object.getOwnPropertyNames(update).forEach(name_ => {
                json[name_] = update[name_]();
            });
            // データの正規化
            becky.jsonHelper.normalization(json);
            return json;
        } else {
            // Model -> View
            Object.getOwnPropertyNames(update).forEach(name_ => {
                update[name_](aModel[name_]);
            });

            // UI の色を更新
            // (この処理を外に追い出す事はできないだろうか……)
            _updateMainColors();
        }
    }

    function _getPrismHVTestValue(chartParameterItem) {


        var valPrismType = chartParameterItem.PrismtRuleH;
        var farNear = chartParameterItem.IsNearFar;
        const updateDataJson = becky.WebStorage.local.getJson("subjective.update.data")
        if (!modelHelper.isNull(updateDataJson)) {
            const prismTestvalue = updateDataJson.prismstate;
            //console.log(farNear);
            //console.log(valPrismType);
            switch (valPrismType.toUpperCase()) {
                case "3":
                    switch (farNear.toUpperCase()) {
                        case "FN":
                        case "F":
                            $("#labelMainPrismHorR").attr("data-text", prismTestvalue.prism3FHR);
                            $("#labelMainPrismHorL").attr("data-text", prismTestvalue.prism3FHL);
                            $("#labelMainPrismVerR").attr("data-text", prismTestvalue.prism3FVR);
                            $("#labelMainPrismVerL").attr("data-text", prismTestvalue.prism3FVL);
                            $(".prism-heading-inner-hor-R-BI").attr("data-fixed", prismTestvalue.prism3FHRunit);
                            if (prismTestvalue.prism3FHRunit == '1') {

                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BI");
                            } else if (prismTestvalue.prism3FHRunit == '0' && prismTestvalue.prism3FHR >= "0.01") {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", " ");
                            }

                            $(".prism-heading-inner-hor-L-BI").attr("data-fixed", prismTestvalue.prism3FHLunit);
                            if (prismTestvalue.prism3FHLunit == '1') {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BI");
                            } else if (prismTestvalue.prism3FHLunit == '0' && prismTestvalue.prism3FHL >= "0.01") {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", " ");
                            }

                            $(".prism-heading-inner-ver-R-BD").attr("data-fixed", prismTestvalue.prism3FVRunit);
                            if (prismTestvalue.prism3FVRunit == '1') {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BD");
                            } else if (prismTestvalue.prism3FVRunit == '0' && prismTestvalue.prism3FVR >= "0.01") {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", " ");
                            }
                            $(".prism-heading-inner-ver-L-BD").attr("data-fixed", prismTestvalue.prism3FVLunit);
                            if (prismTestvalue.prism3FVLunit == '1') {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BU");
                            } else if (prismTestvalue.prism3FVLunit == '0' && prismTestvalue.prism3FVL >= "0.01") {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BD");
                            } else {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", " ");
                            }
                            break;
                        case "N":
                            $("#labelMainPrismHorR").attr("data-text", prismTestvalue.prism3NHR);
                            $("#labelMainPrismHorL").attr("data-text", prismTestvalue.prism3NHL);
                            $("#labelMainPrismVerR").attr("data-text", prismTestvalue.prism3NVR);
                            $("#labelMainPrismVerL").attr("data-text", prismTestvalue.prism3NVL);

                            $(".prism-heading-inner-hor-R-BI").attr("data-fixed", prismTestvalue.prism3NHRunit);
                            if (prismTestvalue.prism3NHRunit == '1') {

                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BI");
                            } else if (prismTestvalue.prism3NHRunit == '0' && prismTestvalue.prism3NHR >= "0.01") {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", " ");
                            }

                            $(".prism-heading-inner-hor-L-BI").attr("data-fixed", prismTestvalue.prism3NHLunit);
                            if (prismTestvalue.prism3NHLunit == '1') {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BI");
                            } else if (prismTestvalue.prism3NHLunit == '0' && prismTestvalue.prism3NHL >= "0.01") {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", " ");
                            }
                            $(".prism-heading-inner-ver-R-BD").attr("data-fixed", prismTestvalue.prism3NVRunit);
                            if (prismTestvalue.prism3NVRunit == '1') {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BD");
                            } else if (prismTestvalue.prism3NVRunit == '0' && prismTestvalue.prism3NVR >= "0.01") {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", " ");
                            }
                            $(".prism-heading-inner-ver-L-BD").attr("data-fixed", prismTestvalue.prism3NVLunit);
                            if (prismTestvalue.prism3NVLunit == '1') {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BU");
                            } else if (prismTestvalue.prism3NVLunit == '0' && prismTestvalue.prism3NVL >= "0.01") {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BD");
                            } else {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", " ");
                            }
                            break;
                        default:
                            // becky.assertion.failure("unknown SCA");
                            break;
                    }
                    break;
                case "8":
                    switch (farNear) {
                        case "FN":
                        case "F":
                            $("#labelMainPrismHorR").attr("data-text", prismTestvalue.prism8FHR);
                            $("#labelMainPrismHorL").attr("data-text", prismTestvalue.prism8FHL);
                            $("#labelMainPrismVerR").attr("data-text", prismTestvalue.prism8FVR);
                            $("#labelMainPrismVerL").attr("data-text", prismTestvalue.prism8FVL);
                            $(".prism-heading-inner-hor-R-BI").attr("data-fixed", prismTestvalue.prism8FHRunit);
                            if (prismTestvalue.prism8FHRunit == '1') {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BI");
                            } else if (prismTestvalue.prism8FHRunit == '0' && prismTestvalue.prism8FHR >= "0.01") {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", " ");
                            }
                            $(".prism-heading-inner-hor-L-BI").attr("data-fixed", prismTestvalue.prism8FHLunit);
                            if (prismTestvalue.prism8FHLunit == '1') {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BI");
                            } else if (prismTestvalue.prism8FHLunit == '0' && prismTestvalue.prism8FHL >= "0.01") {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", " ");
                            }
                            $(".prism-heading-inner-ver-R-BD").attr("data-fixed", prismTestvalue.prism8FVRunit);
                            if (prismTestvalue.prism8FVRunit == '1') {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BD");
                            } else if (prismTestvalue.prism8FVRunit == '0' && prismTestvalue.prism8FVR >= "0.01") {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", " ");
                            }
                            $(".prism-heading-inner-ver-L-BD").attr("data-fixed", prismTestvalue.prism8FVLunit);
                            if (prismTestvalue.prism8FVLunit == '1') {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BU");
                            } else if (prismTestvalue.prism8FVLunit == '0' && prismTestvalue.prism8FVL >= "0.01") {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BD");
                            } else {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", " ");
                            }
                            break;
                        case "N":
                            $("#labelMainPrismHorR").attr("data-text", prismTestvalue.prism8NHR);
                            $("#labelMainPrismHorL").attr("data-text", prismTestvalue.prism8NHL);
                            $("#labelMainPrismVerR").attr("data-text", prismTestvalue.prism8NVR);
                            $("#labelMainPrismVerL").attr("data-text", prismTestvalue.prism8NVL);

                            $(".prism-heading-inner-hor-R-BI").attr("data-fixed", prismTestvalue.prism8NHRunit);
                            if (prismTestvalue.prism8NHRunit == '1') {

                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BI");
                            } else if (prismTestvalue.prism8NHRunit == '0' && prismTestvalue.prism8NHR >= "0.01") {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", " ");
                            }
                            $(".prism-heading-inner-hor-L-BI").attr("data-fixed", prismTestvalue.prism8NHLunit);
                            if (prismTestvalue.prism8NHLunit == '1') {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BI");
                            } else if (prismTestvalue.prism8NHLunit == '0' && prismTestvalue.prism8NHL >= "0.01") {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", " ");
                            }
                            $(".prism-heading-inner-ver-R-BD").attr("data-fixed", prismTestvalue.prism8NVRunit);
                            if (prismTestvalue.prism8NVRunit == '1') {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BD");
                            } else if (prismTestvalue.prism8NVRunit == '0' && prismTestvalue.prism8NVR >= "0.01") {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", " ");
                            }
                            $(".prism-heading-inner-ver-L-BD").attr("data-fixed", prismTestvalue.prism8NVLunit);
                            if (prismTestvalue.prism8NVLunit == '1') {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BU");
                            } else if (prismTestvalue.prism8NVLunit == '0' && prismTestvalue.prism8NVL >= "0.01") {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BD");
                            } else {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", " ");
                            }
                            break;
                        default:
                            // becky.assertion.failure("unknown SCA");
                            break;
                    }
                    break;
                case "9":
                    switch (farNear) {
                        case "FN":
                        case "F":
                            $("#labelMainPrismHorR").attr("data-text", prismTestvalue.prism9FHR);
                            $("#labelMainPrismHorL").attr("data-text", prismTestvalue.prism9FHL);
                            $("#labelMainPrismVerR").attr("data-text", prismTestvalue.prism9FVR);
                            $("#labelMainPrismVerL").attr("data-text", prismTestvalue.prism9FVL);
                            $(".prism-heading-inner-hor-R-BI").attr("data-fixed", prismTestvalue.prism9FHRunit);
                            if (prismTestvalue.prism9FHRunit == '1') {

                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BI");
                            } else if (prismTestvalue.prism9FHRunit == '0' && prismTestvalue.prism9FHR >= "0.01") {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", " ");
                            }
                            $(".prism-heading-inner-hor-L-BI").attr("data-fixed", prismTestvalue.prism9FHLunit);
                            if (prismTestvalue.prism9FHLunit == '1') {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BI");
                            } else if (prismTestvalue.prism9FHLunit == '0' && prismTestvalue.prism9FHL >= "0.01") {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", " ");
                            }
                            $(".prism-heading-inner-ver-R-BD").attr("data-fixed", prismTestvalue.prism9FVRunit);
                            if (prismTestvalue.prism9FVRunit == '1') {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BD");
                            } else if (prismTestvalue.prism9FVRunit == '0' && prismTestvalue.prism9FVR >= "0.01") {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", " ");
                            }
                            $(".prism-heading-inner-ver-L-BD").attr("data-fixed", prismTestvalue.prism9FVLunit);
                            if (prismTestvalue.prism9FVLunit == '1') {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BU");
                            } else if (prismTestvalue.prism9FVLunit == '0' && prismTestvalue.prism9FVL >= "0.01") {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BD");
                            } else {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", " ");
                            }
                            break;
                        case "N":
                            $("#labelMainPrismHorR").attr("data-text", prismTestvalue.prism9NHR);
                            $("#labelMainPrismHorL").attr("data-text", prismTestvalue.prism9NHL);
                            $("#labelMainPrismVerR").attr("data-text", prismTestvalue.prism9NVR);
                            $("#labelMainPrismVerL").attr("data-text", prismTestvalue.prism9NVL);
                            $(".prism-heading-inner-hor-R-BI").attr("data-fixed", prismTestvalue.prism9NHRunit);
                            if (prismTestvalue.prism9NHRunit == '1') {

                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BI");
                            } else if (prismTestvalue.prism9NHRunit == '0' && prismTestvalue.prism9NHR >= "0.01") {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", " ");
                            }
                            $(".prism-heading-inner-hor-L-BI").attr("data-fixed", prismTestvalue.prism9NHLunit);
                            if (prismTestvalue.prism9NHLunit == '1') {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BI");
                            } else if (prismTestvalue.prism9NHLunit == '0' && prismTestvalue.prism9NHL >= "0.01") {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", " ");
                            }
                            $(".prism-heading-inner-ver-R-BD").attr("data-fixed", prismTestvalue.prism9NVRunit);
                            if (prismTestvalue.prism9NVRunit == '1') {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BD");
                            } else if (prismTestvalue.prism9NVRunit == '0' && prismTestvalue.prism9NVR >= "0.01") {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", " ");
                            }
                            $(".prism-heading-inner-ver-L-BD").attr("data-fixed", prismTestvalue.prism9NVLunit);
                            if (prismTestvalue.prism9NVLunit == '1') {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BU");
                            } else if (prismTestvalue.prism9NVLunit == '0' && prismTestvalue.prism9NVL >= "0.01") {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BD");
                            } else {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", " ");
                            }
                            break;
                        default:
                            // becky.assertion.failure("unknown SCA");
                            break;
                    }
                    break;
                case "10":
                    switch (farNear) {
                        case "FN":
                        case "F":
                            $("#labelMainPrismHorR").attr("data-text", prismTestvalue.prism10FHR);
                            $("#labelMainPrismHorL").attr("data-text", prismTestvalue.prism10FHL);
                            $("#labelMainPrismVerR").attr("data-text", prismTestvalue.prism10FVR);
                            $("#labelMainPrismVerL").attr("data-text", prismTestvalue.prism10FVL);
                            $(".prism-heading-inner-hor-R-BI").attr("data-fixed", prismTestvalue.prism10FHRunit);
                            $(".prism-heading-inner-hor-L-BI").attr("data-fixed", prismTestvalue.prism10FHLunit);
                            $(".prism-heading-inner-ver-R-BD").attr("data-fixed", prismTestvalue.prism10FVRunit);
                            $(".prism-heading-inner-ver-L-BD").attr("data-fixed", prismTestvalue.prism10FVLunit);
                            if (prismTestvalue.prism9NHRunit == '1') {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BI");
                            } else if (prismTestvalue.prism9NHRunit == '0' && prismTestvalue.prism9NHR >= "0.01") {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", " ");
                            }
                            if (prismTestvalue.prism10FHLunit == '1') {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BI");
                            } else if (prismTestvalue.prism10FHLunit == '0' && prismTestvalue.prism10FHL >= "0.01") {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", " ");
                            }
                            if (prismTestvalue.prism10FVRunit == '1') {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BD");
                            } else if (prismTestvalue.prism10FVRunit == '0' && prismTestvalue.prism10FVR >= "0.01") {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "");
                            }
                            if (prismTestvalue.prism10FVLunit == '1') {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BU");
                            } else if (prismTestvalue.prism10FVLunit == '0' && prismTestvalue.prism10FVL >= "0.01") {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BD");
                            } else {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", " ");
                            }
                            break;
                        case "N":
                            $("#labelMainPrismHorR").attr("data-text", prismTestvalue.prism10NHR);
                            $("#labelMainPrismHorL").attr("data-text", prismTestvalue.prism10NHL);
                            $("#labelMainPrismVerR").attr("data-text", prismTestvalue.prism10NVR);
                            $("#labelMainPrismVerL").attr("data-text", prismTestvalue.prism10NVL);
                            $(".prism-heading-inner-hor-R-BI").attr("data-fixed", prismTestvalue.prism10NHRunit);
                            $(".prism-heading-inner-hor-L-BI").attr("data-fixed", prismTestvalue.prism10NHLunit);
                            $(".prism-heading-inner-ver-R-BD").attr("data-fixed", prismTestvalue.prism10NVRunit);
                            $(".prism-heading-inner-ver-L-BD").attr("data-fixed", prismTestvalue.prism10NVLunit);
                            if (prismTestvalue.prism10NHRunit == '1') {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BI");
                            } else if (prismTestvalue.prism10NHRunit == '0' && prismTestvalue.prism10NHR >= "0.01") {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", " ");
                            }
                            if (prismTestvalue.prism10NHLunit == '1') {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BI");
                            } else if (prismTestvalue.prism10NHLunit == '0' && prismTestvalue.prism10NHL >= "0.01") {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "");
                            }
                            if (prismTestvalue.prism10NVRunit == '1') {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BD");
                            } else if (prismTestvalue.prism10NVRunit == '0' && prismTestvalue.prism10NVR >= "0.01") {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", " ");
                            }
                            if (prismTestvalue.prism10NVLunit == '1') {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BU");
                            } else if (prismTestvalue.prism10NVLunit == '0' && prismTestvalue.prism10NVL >= "0.01") {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BD");
                            } else {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", " ");
                            }
                            break;
                        default:
                            // becky.assertion.failure("unknown SCA");
                            break;
                    }
                    break;
                case "12A":
                    switch (farNear) {
                        case "FN":
                        case "F":
                            $("#labelMainPrismHorR").attr("data-text", prismTestvalue.prism12AFHR);
                            $("#labelMainPrismHorL").attr("data-text", prismTestvalue.prism12AFHL);
                            $("#labelMainPrismVerR").attr("data-text", prismTestvalue.prism12AFVR);
                            $("#labelMainPrismVerL").attr("data-text", prismTestvalue.prism12AFVL);
                            $(".prism-heading-inner-hor-R-BI").attr("data-fixed", prismTestvalue.prism12AFHRunit);
                            $(".prism-heading-inner-hor-L-BI").attr("data-fixed", prismTestvalue.prism12AFHLunit);
                            $(".prism-heading-inner-ver-R-BD").attr("data-fixed", prismTestvalue.prism12AFVRunit);
                            $(".prism-heading-inner-ver-L-BD").attr("data-fixed", prismTestvalue.prism12AFVLunit);
                            if (prismTestvalue.prism12AFHRunit == '1') {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BI");
                            } else if (prismTestvalue.prism12AFHRunit == '0' && prismTestvalue.prism12AFHR >= "0.01") {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", " ");
                            }
                            if (prismTestvalue.prism12AFHLunit == '1') {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BI");
                            } else if (prismTestvalue.prism12AFHLunit == '0' && prismTestvalue.prism12AFHL >= "0.01") {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", " ");
                            }
                            if (prismTestvalue.prism12AFVRunit == '1') {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BD");
                            } else if (prismTestvalue.prism12AFVRunit == '0' && prismTestvalue.prism12AFVR >= "0.01") {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", " ");
                            }
                            if (prismTestvalue.prism12AFVLunit == '1') {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BU");
                            } else if (prismTestvalue.prism12AFVLunit == '0' && prismTestvalue.prism12AFVL >= "0.01") {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BD");
                            } else {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", " ");
                            }
                            break;
                        case "N":
                            $("#labelMainPrismHorR").attr("data-text", prismTestvalue.prism12ANHR);
                            $("#labelMainPrismHorL").attr("data-text", prismTestvalue.prism12ANHL);
                            $("#labelMainPrismVerR").attr("data-text", prismTestvalue.prism12ANVR);
                            $("#labelMainPrismVerL").attr("data-text", prismTestvalue.prism12ANVL);
                            $(".prism-heading-inner-hor-R-BI").attr("data-fixed", prismTestvalue.prism12ANHRunit);
                            $(".prism-heading-inner-hor-L-BI").attr("data-fixed", prismTestvalue.prism12ANHLunit);
                            $(".prism-heading-inner-ver-R-BD").attr("data-fixed", prismTestvalue.prism12ANVRunit);
                            $(".prism-heading-inner-ver-L-BD").attr("data-fixed", prismTestvalue.prism12ANVLunit);
                            if (prismTestvalue.prism12ANHRunit == '1') {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BI");
                            } else if (prismTestvalue.prism12ANHRunit == '0' && prismTestvalue.prism12ANHR >= "0.01") {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", " ");
                            }
                            if (prismTestvalue.prism12ANHLunit == '1') {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BI");
                            } else if (prismTestvalue.prism12ANHLunit == '0' && prismTestvalue.prism12ANHL >= "0.01") {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", " ");
                            }
                            if (prismTestvalue.prism12ANVRunit == '1') {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BD");
                            } else if (prismTestvalue.prism12ANVRunit == '0' && prismTestvalue.prism12ANVR >= "0.01") {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", " ");
                            }
                            if (prismTestvalue.prism12ANVLunit == '1') {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BU");
                            } else if (prismTestvalue.prism12ANVLunit == '0' && prismTestvalue.prism12ANVL >= "0.01") {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BD");
                            } else {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", " ");
                            }
                            break;
                        default:
                            // becky.assertion.failure("unknown SCA");
                            break;
                    }
                    break;
                case "12B":
                    switch (farNear) {
                        case "FN":
                        case "F":
                            $("#labelMainPrismHorR").attr("data-text", prismTestvalue.prism12BFHR);
                            $("#labelMainPrismHorL").attr("data-text", prismTestvalue.prism12BFHL);
                            $("#labelMainPrismVerR").attr("data-text", prismTestvalue.prism12BFVR);
                            $("#labelMainPrismVerL").attr("data-text", prismTestvalue.prism12BFVL);
                            $(".prism-heading-inner-hor-R-BI").attr("data-fixed", prismTestvalue.prism12BFHRunit);
                            $(".prism-heading-inner-hor-L-BI").attr("data-fixed", prismTestvalue.prism12BFHLunit);
                            $(".prism-heading-inner-ver-R-BD").attr("data-fixed", prismTestvalue.prism12BFVRunit);
                            $(".prism-heading-inner-ver-L-BD").attr("data-fixed", prismTestvalue.prism12BFVLunit);
                            if (prismTestvalue.prism12BFHRunit == '1') {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BI");
                            } else if (prismTestvalue.prism12BFHRunit == '0' && prismTestvalue.prism12BFHR >= "0.01") {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", " ");
                            }
                            if (prismTestvalue.prism12BFHLunit == '1') {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BI");
                            } else if (prismTestvalue.prism12BFHLunit == '0' && prismTestvalue.prism12BFHL >= "0.01") {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", " ");
                            }
                            if (prismTestvalue.prism12BFVRunit == '1') {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BD");
                            } else if (prismTestvalue.prism12BFVRunit == '0' && prismTestvalue.prism12BFVR >= "0.01") {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", " ");
                            }
                            if (prismTestvalue.prism12BFVLunit == '1') {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BU");
                            } else if (prismTestvalue.prism12BFVLunit == '0' && prismTestvalue.prism12BFVL >= "0.01") {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BD");
                            } else {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", " ");
                            }
                            break;
                        case "N":
                            $("#labelMainPrismHorR").attr("data-text", prismTestvalue.prism12BNHR);
                            $("#labelMainPrismHorL").attr("data-text", prismTestvalue.prism12BNHL);
                            $("#labelMainPrismVerR").attr("data-text", prismTestvalue.prism12BNVR);
                            $("#labelMainPrismVerL").attr("data-text", prismTestvalue.prism12BNVL);
                            $(".prism-heading-inner-hor-R-BI").attr("data-fixed", prismTestvalue.prism12BNHRunit);
                            $(".prism-heading-inner-hor-L-BI").attr("data-fixed", prismTestvalue.prism12BNHLunit);
                            $(".prism-heading-inner-ver-R-BD").attr("data-fixed", prismTestvalue.prism12BNVRunit);
                            $(".prism-heading-inner-ver-L-BD").attr("data-fixed", prismTestvalue.prism12BNVLunit);
                            if (prismTestvalue.prism12BNHRunit == '1') {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BI");
                            } else if (prismTestvalue.prism12BNHRunit == '0' && prismTestvalue.prism12BNHR >= "0.01") {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", " ");
                            }
                            if (prismTestvalue.prism12BNHLunit == '1') {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BI");
                            } else if (prismTestvalue.prism12BNHLunit == '0' && prismTestvalue.prism12BNHL >= "0.01") {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "");
                            }
                            if (prismTestvalue.prism12BNVRunit == '1') {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BD");
                            } else if (prismTestvalue.prism12BNVRunit == '0' && prismTestvalue.prism12BNVR >= "0.01") {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", " ");
                            }
                            if (prismTestvalue.prism12BNVLunit == '1') {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BU");
                            } else if (prismTestvalue.prism12BNVLunit == '0' && prismTestvalue.prism12BNVL >= "0.01") {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BD");
                            } else {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", " ");
                            }
                            break;
                        default:
                            // becky.assertion.failure("unknown SCA");
                            break;
                    }

                    break;
                case "13A":
                    switch (farNear) {
                        case "FN":
                        case "F":
                            $("#labelMainPrismHorR").attr("data-text", prismTestvalue.prism13AFHR);
                            $("#labelMainPrismHorL").attr("data-text", prismTestvalue.prism13AFHL);
                            $("#labelMainPrismVerR").attr("data-text", prismTestvalue.prism13AFVR);
                            $("#labelMainPrismVerL").attr("data-text", prismTestvalue.prism13AFVL);
                            $(".prism-heading-inner-hor-R-BI").attr("data-fixed", prismTestvalue.prism13AFHRunit);
                            $(".prism-heading-inner-hor-L-BI").attr("data-fixed", prismTestvalue.prism13AFHLunit);
                            $(".prism-heading-inner-ver-R-BD").attr("data-fixed", prismTestvalue.prism13AFVRunit);
                            $(".prism-heading-inner-ver-L-BD").attr("data-fixed", prismTestvalue.prism13AFVLunit);
                            if (prismTestvalue.prism13AFHRunit == '1') {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BI");
                            } else if (prismTestvalue.prism13AFHRunit == '0' && prismTestvalue.prism13AFHR >= "0.01") {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", " ");
                            }
                            if (prismTestvalue.prism13AFHLunit == '1') {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BI");
                            } else if (prismTestvalue.prism13AFHLunit == '0' && prismTestvalue.prism13AFHL >= "0.01") {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", " ");
                            }
                            if (prismTestvalue.prism13AFVRunit == '1') {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BD");
                            } else if (prismTestvalue.prism13AFVRunit == '0' && prismTestvalue.prism13AFVR >= "0.01") {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", " ");
                            }
                            if (prismTestvalue.prism13AFVLunit == '1') {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BU");
                            } else if (prismTestvalue.prism13AFVLunit == '0' && prismTestvalue.prism13AFVL >= "0.01") {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BD");
                            } else {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", " ");
                            }
                            break;
                        case "N":
                            $("#labelMainPrismHorR").attr("data-text", prismTestvalue.prism13ANHR);
                            $("#labelMainPrismHorL").attr("data-text", prismTestvalue.prism13ANHL);
                            $("#labelMainPrismVerR").attr("data-text", prismTestvalue.prism13ANVR);
                            $("#labelMainPrismVerL").attr("data-text", prismTestvalue.prism13ANVL);
                            $(".prism-heading-inner-hor-R-BI").attr("data-fixed", prismTestvalue.prism13ANHRunit);
                            $(".prism-heading-inner-hor-L-BI").attr("data-fixed", prismTestvalue.prism13ANHLunit);
                            $(".prism-heading-inner-ver-R-BD").attr("data-fixed", prismTestvalue.prism13ANVRunit);
                            $(".prism-heading-inner-ver-L-BD").attr("data-fixed", prismTestvalue.prism13ANVLunit);
                            if (prismTestvalue.prism13ANHRunit == '1') {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BI");
                            } else if (prismTestvalue.prism13ANHRunit == '0' && prismTestvalue.prism13ANHR >= "0.01") {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", " ");
                            }
                            if (prismTestvalue.prism13ANHLunit == '1') {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BI");
                            } else if (prismTestvalue.prism13ANHLunit == '0' && prismTestvalue.prism13ANHL >= "0.01") {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", " ");
                            }
                            if (prismTestvalue.prism13ANVRunit == '1') {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BD");
                            } else if (prismTestvalue.prism13ANVRunit == '0' && prismTestvalue.prism13ANVR >= "0.01") {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", " ");
                            }
                            if (prismTestvalue.prism13ANVLunit == '1') {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BU");
                            } else if (prismTestvalue.prism13ANVLunit == '0' && prismTestvalue.prism13ANVL >= "0.01") {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BD");
                            } else {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", " ");
                            }
                            break;
                        default:
                            // becky.assertion.failure("unknown SCA");
                            break;
                    }

                    break;
                case "13B":
                    switch (farNear) {
                        case "FN":
                        case "F":
                            $("#labelMainPrismHorR").attr("data-text", prismTestvalue.prism13BFHR);
                            $("#labelMainPrismHorL").attr("data-text", prismTestvalue.prism13BFHL);
                            $("#labelMainPrismVerR").attr("data-text", prismTestvalue.prism13BFVR);
                            $("#labelMainPrismVerL").attr("data-text", prismTestvalue.prism13BFVL);
                            $(".prism-heading-inner-hor-R-BI").attr("data-fixed", prismTestvalue.prism13BFHRunit);
                            $(".prism-heading-inner-hor-L-BI").attr("data-fixed", prismTestvalue.prism13BFHLunit);
                            $(".prism-heading-inner-ver-R-BD").attr("data-fixed", prismTestvalue.prism13BFVRunit);
                            $(".prism-heading-inner-ver-L-BD").attr("data-fixed", prismTestvalue.prism13BFVLunit);
                            if (prismTestvalue.prism13BFHRunit == '1') {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BI");
                            } else if (prismTestvalue.prism13BFHRunit == '0' && prismTestvalue.prism13BFHR >= "0.01") {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", " ");
                            }
                            if (prismTestvalue.prism13BFHLunit == '1') {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BI");
                            } else if (prismTestvalue.prism13BFHLunit == '0' && prismTestvalue.prism13BFHL >= "0.01") {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", " ");
                            }
                            if (prismTestvalue.prism13BFVRunit == '1') {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BD");
                            } else if (prismTestvalue.prism13BFVRunit == '0' && prismTestvalue.prism13BFVR >= "0.01") {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", " ");
                            }
                            if (prismTestvalue.prism13BFVLunit == '1') {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BU");
                            } else if (prismTestvalue.prism13BFVLunit == '0' && prismTestvalue.prism13BFVL >= "0.01") {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BD");
                            } else {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", " ");
                            }

                            break;
                        case "N":
                            $("#labelMainPrismHorR").attr("data-text", prismTestvalue.prism13BNHR);
                            $("#labelMainPrismHorL").attr("data-text", prismTestvalue.prism13BNHL);
                            $("#labelMainPrismVerR").attr("data-text", prismTestvalue.prism13BNVR);
                            $("#labelMainPrismVerL").attr("data-text", prismTestvalue.prism13BNVL);
                            $(".prism-heading-inner-hor-R-BI").attr("data-fixed", prismTestvalue.prism13BNHRunit);
                            $(".prism-heading-inner-hor-L-BI").attr("data-fixed", prismTestvalue.prism13BNHLunit);
                            $(".prism-heading-inner-ver-R-BD").attr("data-fixed", prismTestvalue.prism13BNVRunit);
                            $(".prism-heading-inner-ver-L-BD").attr("data-fixed", prismTestvalue.prism13BNVLunit);
                            if (prismTestvalue.prism13BNHRunit == '1') {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BI");
                            } else if (prismTestvalue.prism13BNHRunit == '0' && prismTestvalue.prism13BNHR >= "0.01") {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", " ");
                            }
                            if (prismTestvalue.prism13BNHLunit == '1') {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BI");
                            } else if (prismTestvalue.prism13BNHLunit == '0' && prismTestvalue.prism13BNHL >= "0.01") {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", " ");
                            }
                            if (prismTestvalue.prism13BNVRunit == '1') {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BD");
                            } else if (prismTestvalue.prism13BNVRunit == '0' && prismTestvalue.prism13BNVR >= "0.01") {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", " ");
                            }
                            if (prismTestvalue.prism13BNVLunit == '1') {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BU");
                            } else if (prismTestvalue.prism13BNVLunit == '0' && prismTestvalue.prism13BNVL >= "0.01") {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BD");
                            } else {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", " ");
                            }
                            break;
                        default:
                            // becky.assertion.failure("unknown SCA");
                            break;
                    }
                    break;
                case "14A":
                    switch (farNear) {
                        case "FN":
                        case "F":
                            $("#labelMainPrismHorR").attr("data-text", prismTestvalue.prism14AFHR);
                            $("#labelMainPrismHorL").attr("data-text", prismTestvalue.prism14AFHL);
                            $("#labelMainPrismVerR").attr("data-text", prismTestvalue.prism14AFVR);
                            $("#labelMainPrismVerL").attr("data-text", prismTestvalue.prism14AFVL);
                            $(".prism-heading-inner-hor-R-BI").attr("data-fixed", prismTestvalue.prism14AFHRunit);
                            $(".prism-heading-inner-hor-L-BI").attr("data-fixed", prismTestvalue.prism14AFHLunit);
                            $(".prism-heading-inner-ver-R-BD").attr("data-fixed", prismTestvalue.prism14AFVRunit);
                            $(".prism-heading-inner-ver-L-BD").attr("data-fixed", prismTestvalue.prism14AFVLunit);
                            if (prismTestvalue.prism14AFHRunit == '1') {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BI");
                            } else if (prismTestvalue.prism14AFHRunit == '0' && prismTestvalue.prism14AFHR >= "0.01") {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", " ");
                            }
                            if (prismTestvalue.prism14AFHLunit == '1') {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BI");
                            } else if (prismTestvalue.prism14AFHLunit == '0' && prismTestvalue.prism14AFHL >= "0.01") {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", " ");
                            }
                            if (prismTestvalue.prism14AFVRunit == '1') {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BD");
                            } else if (prismTestvalue.prism14AFVRunit == '0' && prismTestvalue.prism14AFVR >= "0.01") {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", " ");
                            }
                            if (prismTestvalue.prism14AFVLunit == '1') {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BU");
                            } else if (prismTestvalue.prism14AFVLunit == '0' && prismTestvalue.prism14AFVL >= "0.01") {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BD");
                            } else {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", " ");
                            }
                            break;
                        case "N":
                            $("#labelMainPrismHorR").attr("data-text", prismTestvalue.prism14ANHR);
                            $("#labelMainPrismHorL").attr("data-text", prismTestvalue.prism14ANHL);
                            $("#labelMainPrismVerR").attr("data-text", prismTestvalue.prism14ANVR);
                            $("#labelMainPrismVerL").attr("data-text", prismTestvalue.prism14ANVL);
                            $(".prism-heading-inner-hor-R-BI").attr("data-fixed", prismTestvalue.prism14ANHRunit);
                            $(".prism-heading-inner-hor-L-BI").attr("data-fixed", prismTestvalue.prism14ANHLunit);
                            $(".prism-heading-inner-ver-R-BD").attr("data-fixed", prismTestvalue.prism14ANVRunit);
                            $(".prism-heading-inner-ver-L-BD").attr("data-fixed", prismTestvalue.prism14ANVLunit);
                            if (prismTestvalue.prism14ANHRunit == '1') {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BI");
                            } else if (prismTestvalue.prism14ANHRunit == '0' && prismTestvalue.prism14ANHR >= "0.01") {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", " ");
                            }
                            if (prismTestvalue.prism14ANHLunit == '1') {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BI");
                            } else if (prismTestvalue.prism14ANHLunit == '0' && prismTestvalue.prism14ANHL >= "0.01") {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", " ");
                            }
                            if (prismTestvalue.prism14ANVRunit == '1') {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BD");
                            } else if (prismTestvalue.prism14ANVRunit == '0' && prismTestvalue.prism14ANVR >= "0.01") {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", " ");
                            }
                            if (prismTestvalue.prism14ANVLunit == '1') {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BU");
                            } else if (prismTestvalue.prism14ANVLunit == '0' && prismTestvalue.prism14ANVL >= "0.01") {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BD");
                            } else {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", " ");
                            }
                            break;
                        default:
                            // becky.assertion.failure("unknown SCA");
                            break;
                    }
                    break;
                case "14B":
                    switch (farNear) {
                        case "FN":
                        case "F":
                            $("#labelMainPrismHorR").attr("data-text", prismTestvalue.prism14BFHR);
                            $("#labelMainPrismHorL").attr("data-text", prismTestvalue.prism14BFHL);
                            $("#labelMainPrismVerR").attr("data-text", prismTestvalue.prism14BFVR);
                            $("#labelMainPrismVerL").attr("data-text", prismTestvalue.prism14BFVL);
                            $(".prism-heading-inner-hor-R-BI").attr("data-fixed", prismTestvalue.prism14BFHRunit);
                            $(".prism-heading-inner-hor-L-BI").attr("data-fixed", prismTestvalue.prism14BFHLunit);
                            $(".prism-heading-inner-ver-R-BD").attr("data-fixed", prismTestvalue.prism14BFVRunit);
                            $(".prism-heading-inner-ver-L-BD").attr("data-fixed", prismTestvalue.prism14BFVLunit);
                            if (prismTestvalue.prism14BFHRunit == '1') {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BI");
                            } else if (prismTestvalue.prism14BFHRunit == '0' && prismTestvalue.prism14BFHR >= "0.01") {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", " ");
                            }
                            if (prismTestvalue.prism14BFHLunit == '1') {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BI");
                            } else if (prismTestvalue.prism14BFHLunit == '0' && prismTestvalue.prism14BFHL >= "0.01") {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", " ");
                            }
                            if (prismTestvalue.prism14BFVRunit == '1') {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BD");
                            } else if (prismTestvalue.prism14BFVRunit == '0' && prismTestvalue.prism14BFVR >= "0.01") {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", " ");
                            }
                            if (prismTestvalue.prism14BFVLunit == '1') {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BU");
                            } else if (prismTestvalue.prism14BFVLunit == '0' && prismTestvalue.prism14BFVL >= "0.01") {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BD");
                            } else {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", " ");
                            }
                            break;
                        case "N":
                            $("#labelMainPrismHorR").attr("data-text", prismTestvalue.prism14BNHR);
                            $("#labelMainPrismHorL").attr("data-text", prismTestvalue.prism14BNHL);
                            $("#labelMainPrismVerR").attr("data-text", prismTestvalue.prism14BNVR);
                            $("#labelMainPrismVerL").attr("data-text", prismTestvalue.prism14BNVL);
                            $(".prism-heading-inner-hor-R-BI").attr("data-fixed", prismTestvalue.prism14BNHRunit);
                            $(".prism-heading-inner-hor-L-BI").attr("data-fixed", prismTestvalue.prism14BNHLunit);
                            $(".prism-heading-inner-ver-R-BD").attr("data-fixed", prismTestvalue.prism14BNVRunit);
                            $(".prism-heading-inner-ver-L-BD").attr("data-fixed", prismTestvalue.prism14BNVLunit);
                            if (prismTestvalue.prism14BNHRunit == '1') {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BI");
                            } else if (prismTestvalue.prism14BNHRunit == '0' && prismTestvalue.prism14BNHR >= "0.01") {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", " ");
                            }
                            if (prismTestvalue.prism14BNHLunit == '1') {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BI");
                            } else if (prismTestvalue.prism14BNHLunit == '0' && prismTestvalue.prism14BNHL >= "0.01") {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", " ");
                            }
                            if (prismTestvalue.prism14BNVRunit == '1') {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BD");
                            } else if (prismTestvalue.prism14BNVRunit == '0' && prismTestvalue.prism14BNVR >= "0.01") {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", " ");
                            }
                            if (prismTestvalue.prism14BNVLunit == '1') {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BU");
                            } else if (prismTestvalue.prism14BNVLunit == '0' && prismTestvalue.prism14BNVL >= "0.01") {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BD");
                            } else {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", " ");
                            }
                            break;
                        default:
                            // becky.assertion.failure("unknown SCA");
                            break;
                    }
                    break;
                case "15A":
                    switch (farNear) {
                        case "FN":
                        case "F":
                            $("#labelMainPrismHorR").attr("data-text", prismTestvalue.prism15AFHR);
                            $("#labelMainPrismHorL").attr("data-text", prismTestvalue.prism15AFHL);
                            $("#labelMainPrismVerR").attr("data-text", prismTestvalue.prism15AFVR);
                            $("#labelMainPrismVerL").attr("data-text", prismTestvalue.prism15AFVL);
                            $(".prism-heading-inner-hor-R-BI").attr("data-fixed", prismTestvalue.prism15AFHRunit);
                            $(".prism-heading-inner-hor-L-BI").attr("data-fixed", prismTestvalue.prism15AFHLunit);
                            $(".prism-heading-inner-ver-R-BD").attr("data-fixed", prismTestvalue.prism15AFVRunit);
                            $(".prism-heading-inner-ver-L-BD").attr("data-fixed", prismTestvalue.prism15AFVLunit);
                            if (prismTestvalue.prism15AFHRunit == '1') {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BI");
                            } else if (prismTestvalue.prism15AFHRunit == '0' && prismTestvalue.prism15AFHR >= "0.01") {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", " ");
                            }
                            if (prismTestvalue.prism15AFHLunit == '1') {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BI");
                            } else if (prismTestvalue.prism15AFHLunit == '0' && prismTestvalue.prism15AFHL >= "0.01") {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", " ");
                            }
                            if (prismTestvalue.prism15AFVRunit == '1') {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BD");
                            } else if (prismTestvalue.prism15AFVRunit == '0' && prismTestvalue.prism15AFVR >= "0.01") {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", " ");
                            }
                            if (prismTestvalue.prism15AFVLunit == '1') {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BU");
                            } else if (prismTestvalue.prism15AFVLunit == '0' && prismTestvalue.prism15AFVL >= "0.01") {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BD");
                            } else {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", " ");
                            }
                            break;
                        case "N":
                            $("#labelMainPrismHorR").attr("data-text", prismTestvalue.prism15ANHR);
                            $("#labelMainPrismHorL").attr("data-text", prismTestvalue.prism15ANHL);
                            $("#labelMainPrismVerR").attr("data-text", prismTestvalue.prism15ANVR);
                            $("#labelMainPrismVerL").attr("data-text", prismTestvalue.prism15ANVL);
                            $(".prism-heading-inner-hor-R-BI").attr("data-fixed", prismTestvalue.prism15ANHRunit);
                            $(".prism-heading-inner-hor-L-BI").attr("data-fixed", prismTestvalue.prism15ANHLunit);
                            $(".prism-heading-inner-ver-R-BD").attr("data-fixed", prismTestvalue.prism15ANVRunit);
                            $(".prism-heading-inner-ver-L-BD").attr("data-fixed", prismTestvalue.prism15ANVLunit);
                            if (prismTestvalue.prism15ANHRunit == '1') {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BI");
                            } else if (prismTestvalue.prism15ANHRunit == '0' && prismTestvalue.prism15ANHR >= "0.01") {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", " ");
                            }
                            if (prismTestvalue.prism15AFHLunit == '1') {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BI");
                            } else if (prismTestvalue.prism15ANHLunit == '0' && prismTestvalue.prism15ANHL >= "0.01") {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", " ");
                            }
                            if (prismTestvalue.prism15ANVRunit == '1') {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BD");
                            } else if (prismTestvalue.prism15ANVRunit == '0' && prismTestvalue.prism15ANVR >= "0.01") {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", " ");
                            }
                            if (prismTestvalue.prism15ANVLunit == '1') {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BU");
                            } else if (prismTestvalue.prism15ANVLunit == '0' && prismTestvalue.prism15ANVL >= "0.01") {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BD");
                            } else {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", " ");
                            }
                            break;
                        default:
                            // becky.assertion.failure("unknown SCA");
                            break;
                    }
                    break;
                case "15B":
                    switch (farNear) {
                        case "FN":
                        case "F":
                            $("#labelMainPrismHorR").attr("data-text", prismTestvalue.prism15BFHR);
                            $("#labelMainPrismHorL").attr("data-text", prismTestvalue.prism15BFHL);
                            $("#labelMainPrismVerR").attr("data-text", prismTestvalue.prism15BFVR);
                            $("#labelMainPrismVerL").attr("data-text", prismTestvalue.prism15BFVL);
                            $(".prism-heading-inner-hor-R-BI").attr("data-fixed", prismTestvalue.prism15BFHRunit);
                            $(".prism-heading-inner-hor-L-BI").attr("data-fixed", prismTestvalue.prism15BFHLunit);
                            $(".prism-heading-inner-ver-R-BD").attr("data-fixed", prismTestvalue.prism15BFVRunit);
                            $(".prism-heading-inner-ver-L-BD").attr("data-fixed", prismTestvalue.prism15BFVLunit);
                            if (prismTestvalue.prism15BFHRunit == '1') {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BI");
                            } else if (prismTestvalue.prism15BFHRunit == '0' && prismTestvalue.prism15BFHR >= "0.01") {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", " ");
                            }
                            if (prismTestvalue.prism15BFHLunit == '1') {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BI");
                            } else if (prismTestvalue.prism15BFHLunit == '0' && prismTestvalue.prism15BFHL >= "0.01") {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", " ");
                            }
                            if (prismTestvalue.prism15BFVRunit == '1') {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BD");
                            } else if (prismTestvalue.prism15BFVRunit == '0' && prismTestvalue.prism15BFVR >= "0.01") {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", " ");
                            }
                            if (prismTestvalue.prism15BFVLunit == '1') {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BU");
                            } else if (prismTestvalue.prism15BFVLunit == '0' && prismTestvalue.prism15BFVL >= "0.01") {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BD");
                            } else {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", " ");
                            }
                            break;
                        case "N":
                            $("#labelMainPrismHorR").attr("data-text", prismTestvalue.prism15BNHR);
                            $("#labelMainPrismHorL").attr("data-text", prismTestvalue.prism15BNHL);
                            $("#labelMainPrismVerR").attr("data-text", prismTestvalue.prism15BNVR);
                            $("#labelMainPrismVerL").attr("data-text", prismTestvalue.prism15BNVL);
                            $(".prism-heading-inner-hor-R-BI").attr("data-fixed", prismTestvalue.prism15BNHRunit);
                            $(".prism-heading-inner-hor-L-BI").attr("data-fixed", prismTestvalue.prism15BNHLunit);
                            $(".prism-heading-inner-ver-R-BD").attr("data-fixed", prismTestvalue.prism15BNVRunit);
                            $(".prism-heading-inner-ver-L-BD").attr("data-fixed", prismTestvalue.prism15BNVLunit);
                            if (prismTestvalue.prism15BNHRunit == '1') {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BI");
                            } else if (prismTestvalue.prism15BNHRunit == '0' && prismTestvalue.prism15BNHR >= "0.01") {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", " ");
                            }
                            if (prismTestvalue.prism15BNHLunit == '1') {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BI");
                            } else if (prismTestvalue.prism15BNHLunit == '0' && prismTestvalue.prism15BNHL >= "0.01") {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", " ");
                            }
                            if (prismTestvalue.prism15BNVRunit == '1') {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BD");
                            } else if (prismTestvalue.prism15BNVRunit == '0' && prismTestvalue.prism15BNVR >= "0.01") {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", " ");
                            }
                            if (prismTestvalue.prism15BNVLunit == '1') {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BU");
                            } else if (prismTestvalue.prism15BNVLunit == '0' && prismTestvalue.prism15BNVL >= "0.01") {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BD");
                            } else {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", " ");
                            }
                            break;
                        default:
                            // becky.assertion.failure("unknown SCA");
                            break;
                    }
                    break;
                case "16":
                    switch (farNear) {
                        case "FN":
                        case "F":
                            $("#labelMainPrismHorR").attr("data-text", prismTestvalue.prism16FHR);
                            $("#labelMainPrismHorL").attr("data-text", prismTestvalue.prism16FHL);
                            $("#labelMainPrismVerR").attr("data-text", prismTestvalue.prism16FVR);
                            $("#labelMainPrismVerL").attr("data-text", prismTestvalue.prism16FVL);
                            $(".prism-heading-inner-hor-R-BI").attr("data-fixed", prismTestvalue.prism16FHRunit);
                            $(".prism-heading-inner-hor-L-BI").attr("data-fixed", prismTestvalue.prism16FHLunit);
                            $(".prism-heading-inner-ver-R-BD").attr("data-fixed", prismTestvalue.prism16FVRunit);
                            $(".prism-heading-inner-ver-L-BD").attr("data-fixed", prismTestvalue.prism16FVLunit);
                            if (prismTestvalue.prism16FHRunit == '1') {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BI");
                            } else if (prismTestvalue.prism16FHRunit == '0' && prismTestvalue.prism16FHRunit >= '0.01') {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "");
                            }
                            if (prismTestvalue.prism16FHLunit == '1') {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BI");
                            } else if (prismTestvalue.prism16FHLunit == '0' && prismTestvalue.prism16FHLunit >= '0.01') {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "");
                            }
                            if (prismTestvalue.prism16FVRunit == '1') {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BD");
                            } else if (prismTestvalue.prism16FVRunit == '0' && prismTestvalue.prism16FVRunit >= '0.01') {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "");
                            }
                            if (prismTestvalue.prism16FVLunit == '1') {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BU");
                            } else if (prismTestvalue.prism16FVLunit == '0' && prismTestvalue.prism16FVLunit >= '0.01') {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BD");
                            } else {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "");
                            }
                            break;
                        case "N":
                            $("#labelMainPrismHorR").attr("data-text", prismTestvalue.prism16NHR);
                            $("#labelMainPrismHorL").attr("data-text", prismTestvalue.prism16NHL);
                            $("#labelMainPrismVerR").attr("data-text", prismTestvalue.prism16NVR);
                            $("#labelMainPrismVerL").attr("data-text", prismTestvalue.prism16NVL);
                            $(".prism-heading-inner-hor-R-BI").attr("data-fixed", prismTestvalue.prism16NHRunit);
                            $(".prism-heading-inner-hor-L-BI").attr("data-fixed", prismTestvalue.prism16NHLunit);
                            $(".prism-heading-inner-ver-R-BD").attr("data-fixed", prismTestvalue.prism16NVRunit);
                            $(".prism-heading-inner-ver-L-BD").attr("data-fixed", prismTestvalue.prism16NVLunit);
                            if (prismTestvalue.prism16NHRunit == '1') {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BI");
                            } else if (prismTestvalue.prism16NHRunit == '' && prismTestvalue.prism16NHRunit >= '0.01') {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "");
                            }
                            if (prismTestvalue.prism16NHLunit == '1') {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BI");
                            } else if (prismTestvalue.prism16NHLunit == '0' && prismTestvalue.prism16NHLunit >= '0.01') {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "");
                            }
                            if (prismTestvalue.prism16NVRunit == '1') {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BD");
                            } else if (prismTestvalue.prism16NVRunit == '0' && prismTestvalue.prism16NVRunit >= '0.01') {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "");
                            }
                            if (prismTestvalue.prism16NVLunit == '1') {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BU");
                            } else if (prismTestvalue.prism16NVLunit == '0' && prismTestvalue.prism16NVLunit >= '0.01') {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BD");
                            } else {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "");
                            }
                            break;
                        default:
                            // becky.assertion.failure("unknown SCA");
                            break;
                    }
                    break;
                case "17":
                    switch (farNear) {
                        case "FN":
                        case "F":
                            $("#labelMainPrismHorR").attr("data-text", prismTestvalue.prism17FHR);
                            $("#labelMainPrismHorL").attr("data-text", prismTestvalue.prism17FHL);
                            $("#labelMainPrismVerR").attr("data-text", prismTestvalue.prism17FVR);
                            $("#labelMainPrismVerL").attr("data-text", prismTestvalue.prism17FVL);
                            $(".prism-heading-inner-hor-R-BI").attr("data-fixed", prismTestvalue.prism17FHRunit);
                            $(".prism-heading-inner-hor-L-BI").attr("data-fixed", prismTestvalue.prism17FHLunit);
                            $(".prism-heading-inner-ver-R-BD").attr("data-fixed", prismTestvalue.prism17FVRunit);
                            $(".prism-heading-inner-ver-L-BD").attr("data-fixed", prismTestvalue.prism17FVLunit);
                            if (prismTestvalue.prism17FHRunit == '1') {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BI");
                            } else if (prismTestvalue.prism17FHRunit == '0' && prismTestvalue.prism17FHRunit >= '0.01') {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "");
                            }
                            if (prismTestvalue.prism17FHLunit == '1') {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BI");
                            } else if (prismTestvalue.prism17FHLunit == '0' && prismTestvalue.prism17FHLunit >= '0.01') {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "");
                            }
                            if (prismTestvalue.prism17FVRunit == '1') {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BD");
                            } else if (prismTestvalue.prism17FVRunit == '0' && prismTestvalue.prism17FVRunit >= '0.01') {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "");
                            }
                            if (prismTestvalue.prism17FVLunit == '1') {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BU");
                            } else if (prismTestvalue.prism17FVLunit == '0' && prismTestvalue.prism17FVLunit >= '0.01') {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BD");
                            } else {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "");
                            }
                            break;
                        case "N":
                            $("#labelMainPrismHorR").attr("data-text", prismTestvalue.prism17NHR);
                            $("#labelMainPrismHorL").attr("data-text", prismTestvalue.prism17NHL);
                            $("#labelMainPrismVerR").attr("data-text", prismTestvalue.prism17NVR);
                            $("#labelMainPrismVerL").attr("data-text", prismTestvalue.prism17NVL);
                            $(".prism-heading-inner-hor-R-BI").attr("data-fixed", prismTestvalue.prism17NHRunit);
                            $(".prism-heading-inner-hor-L-BI").attr("data-fixed", prismTestvalue.prism17NHLunit);
                            $(".prism-heading-inner-ver-R-BD").attr("data-fixed", prismTestvalue.prism17NVRunit);
                            $(".prism-heading-inner-ver-L-BD").attr("data-fixed", prismTestvalue.prism17NVLunit);
                            if (prismTestvalue.prism17NVLunit == '1') {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BI");
                            } else if (prismTestvalue.prism17NVLunit == '0' && prismTestvalue.prism17NVLunit >= '0.01') {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "");
                            }
                            if (prismTestvalue.prism17NVLunit == '1') {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BI");
                            } else if (prismTestvalue.prism17NVLunit == '0' && prismTestvalue.prism17NVLunit >= '0.01') {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "");
                            }
                            if (prismTestvalue.prism17NVLunit == '1') {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BD");
                            } else if (prismTestvalue.prism17NVLunit == '0' && prismTestvalue.prism17NVLunit >= '0.01') {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "");
                            }
                            if (prismTestvalue.prism17NVLunit == '1') {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BU");
                            } else if (prismTestvalue.prism17NVLunit == '0' && prismTestvalue.prism17NVLunit >= '0.01') {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BD");
                            } else {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "");
                            }
                            break;
                        default:
                            // becky.assertion.failure("unknown SCA");
                            break;
                    }
                    break;
                    case "18A":
                    switch (farNear.toUpperCase()) {
                        case "FN":
                        case "F":
                            $("#labelMainPrismHorR").attr("data-text", prismTestvalue.prism18AFHR);
                            $("#labelMainPrismHorL").attr("data-text", prismTestvalue.prism18AFHL);
                            $("#labelMainPrismVerR").attr("data-text", prismTestvalue.prism18AFVR);
                            $("#labelMainPrismVerL").attr("data-text", prismTestvalue.prism18AFVL);
                            $(".prism-heading-inner-hor-R-BI").attr("data-fixed", prismTestvalue.prism18AFHRunit);
                            if (prismTestvalue.prism18AFHRunit == '1') {

                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BI");
                            } else if (prismTestvalue.prism18AFHRunit == '0' && prismTestvalue.prism18AFHR >= "0.01") {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", " ");
                            }

                            $(".prism-heading-inner-hor-L-BI").attr("data-fixed", prismTestvalue.prism18AFHLunit);
                            if (prismTestvalue.prism18AFHLunit == '1') {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BI");
                            } else if (prismTestvalue.prism18AFHLunit == '0' && prismTestvalue.prism18AFHL >= "0.01") {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", " ");
                            }

                            $(".prism-heading-inner-ver-R-BD").attr("data-fixed", prismTestvalue.prism18AFVRunit);
                            if (prismTestvalue.prism18AFVRunit == '1') {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BD");
                            } else if (prismTestvalue.prism18AFVRunit == '0' && prismTestvalue.prism18AFVR >= "0.01") {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", " ");
                            }
                            $(".prism-heading-inner-ver-L-BD").attr("data-fixed", prismTestvalue.prism18AFVLunit);
                            if (prismTestvalue.prism18AFVLunit == '1') {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BU");
                            } else if (prismTestvalue.prism18AFVLunit == '0' && prismTestvalue.prism18AFVL >= "0.01") {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BD");
                            } else {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", " ");
                            }
                            break;
                        case "N":
                            $("#labelMainPrismHorR").attr("data-text", prismTestvalue.prism18ANHR);
                            $("#labelMainPrismHorL").attr("data-text", prismTestvalue.prism18ANHL);
                            $("#labelMainPrismVerR").attr("data-text", prismTestvalue.prism18ANVR);
                            $("#labelMainPrismVerL").attr("data-text", prismTestvalue.prism18ANVL);

                            $(".prism-heading-inner-hor-R-BI").attr("data-fixed", prismTestvalue.prism18ANHRunit);
                            if (prismTestvalue.prism18ANHRunit == '1') {

                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BI");
                            } else if (prismTestvalue.prism18ANHRunit == '0' && prismTestvalue.prism18ANHR >= "0.01") {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", " ");
                            }

                            $(".prism-heading-inner-hor-L-BI").attr("data-fixed", prismTestvalue.prism18ANHLunit);
                            if (prismTestvalue.prism18ANHLunit == '1') {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BI");
                            } else if (prismTestvalue.prism18ANHLunit == '0' && prismTestvalue.prism18ANHL >= "0.01") {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", " ");
                            }
                            $(".prism-heading-inner-ver-R-BD").attr("data-fixed", prismTestvalue.prism18ANVRunit);
                            if (prismTestvalue.prism18ANVRunit == '1') {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BD");
                            } else if (prismTestvalue.prism18ANVRunit == '0' && prismTestvalue.prism18ANVR >= "0.01") {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", " ");
                            }
                            $(".prism-heading-inner-ver-L-BD").attr("data-fixed", prismTestvalue.prism18ANVLunit);
                            if (prismTestvalue.prism18ANVLunit == '1') {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BU");
                            } else if (prismTestvalue.prism18ANVLunit == '0' && prismTestvalue.prism18ANVL >= "0.01") {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BD");
                            } else {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", " ");
                            }
                            break;
                        default:
                            // becky.assertion.failure("unknown SCA");
                            break;
                    }
                    break;
                default:
                    //becky.assertion.failure("unknown eye");
                    break;
            }
        }
        console.log(chartParameterItem);

    }

    function getsamechartIDvalues(aModel) {
        const chartindex = Number(localStorage['chartindex']);

        //console.log(chartindex);
        const chartParameterItem = becky.subjective.arrayChartParameter.chartParameter.filter(
            chartParameterItem_ => chartParameterItem_.chartID === chartindex)[0];

        if (becky.assertion.isUndefined(chartParameterItem)) {
            return;
        }
        const PrismtRuleH = chartParameterItem.PrismtRuleH;
        const PrismtRuleV = chartParameterItem.PrismtRuleV;
        if (modelHelper.isUndefined(aModel)) {

            const updateDataJson = becky.WebStorage.local.getJson("subjective.update.data");
            var prism3FHR = 0;
            var prism3FHL = 0;
            var prism3FVR = 0;
            var prism3FVL = 0;

            // var prism3FHRunit = 0;
            // var prism3FHLunit = 0;
            // var prism3FVRunit = 0;
            // var prism3FVLunit = 0;

            var prism3NHR = 0;
            var prism3NHL = 0;
            var prism3NVR = 0;
            var prism3NVL = 0;

            // var prism3NHRunit = 0;
            // var prism3NHLunit = 0;
            // var prism3NVRunit = 0;
            // var prism3NVLunit = 0;

            var prism8FHR = 0;
            var prism8FHL = 0;
            var prism8FVR = 0;
            var prism8FVL = 0;

            // var prism8FHRunit = 0;
            // var prism8FHLunit = 0;
            // var prism8FVRunit = 0;
            // var prism8FVLunit = 0;


            var prism8NHR = 0;
            var prism8NHL = 0;
            var prism8NVR = 0;
            var prism8NVL = 0;

            // var prism8NHRunit = 0;
            // var prism8NHLunit = 0;
            // var prism8NVRunit = 0;
            // var prism8NVLunit = 0;

            var prism9FHR = 0;
            var prism9FHL = 0;
            var prism9FVR = 0;
            var prism9FVL = 0;

            // var prism9FHRunit = 0;
            // var prism9FHLunit = 0;
            // var prism9FVRunit = 0;
            // var prism9FVLunit = 0;

            var prism9NHR = 0;
            var prism9NHL = 0;
            var prism9NVR = 0;
            var prism9NVL = 0;

            // var prism9NHRunit = 0;
            // var prism9NHLunit = 0;
            // var prism9NVRunit = 0;
            // var prism9NVLunit = 0;

            var prism10FHR = 0;
            var prism10FHL = 0;
            var prism10FVR = 0;
            var prism10FVL = 0;

            // var prism10FHRunit = 0;
            // var prism10FHLunit = 0;
            // var prism10FVRunit = 0;
            // var prism10FVLunit = 0;

            var prism10NHR = 0;
            var prism10NHL = 0;
            var prism10NVR = 0;
            var prism10NVL = 0;

            // var prism10NHRunit = 0;
            // var prism10NHLunit = 0;
            // var prism10NVRunit = 0;
            // var prism10NVLunit = 0;

            var prism12AFHR = 0;
            var prism12AFHL = 0;
            var prism12AFVR = 0;
            var prism12AFVL = 0;

            // var prism12AFHRunit = 0;
            // var prism12AFHLunit = 0;
            // var prism12AFVRunit = 0;
            // var prism12AFVLunit = 0;

            var prism12ANHR = 0;
            var prism12ANHL = 0;
            var prism12ANVR = 0;
            var prism12ANVL = 0;

            // var prism12ANHRunit = 0;
            // var prism12ANHLunit = 0;
            // var prism12ANVRunit = 0;
            // var prism12ANVLunit = 0;

            var prism12BFHR = 0;
            var prism12BFHL = 0;
            var prism12BFVR = 0;
            var prism12BFVL = 0;

            // var prism12BFHRunit = 0;
            // var prism12BFHLunit = 0;
            // var prism12BFVRunit = 0;
            // var prism12BFVLunit = 0;

            var prism12BNHR = 0;
            var prism12BNHL = 0;
            var prism12BNVR = 0;
            var prism12BNVL = 0;

            // var prism12BNHRunit = 0;
            // var prism12BNHLunit = 0;
            // var prism12BNVRunit = 0;
            // var prism12BNVLunit = 0;

            var prism13AFHR = 0;
            var prism13AFHL = 0;
            var prism13AFVR = 0;
            var prism13AFVL = 0;

            // var prism13AFHRunit = 0;
            // var prism13AFHLunit = 0;
            // var prism13AFVRunit = 0;
            // var prism13AFVLunit = 0;

            var prism13ANHR = 0;
            var prism13ANHL = 0;
            var prism13ANVR = 0;
            var prism13ANVL = 0;

            // var prism13ANHRunit = 0;
            // var prism13ANHLunit = 0;
            // var prism13ANVRunit = 0;
            // var prism13ANVLunit = 0;


            var prism13BFHR = 0;
            var prism13BFHL = 0;
            var prism13BFVR = 0;
            var prism13BFVL = 0;

            // var prism13BFHRunit = 0;
            // var prism13BFHLunit = 0;
            // var prism13BFVRunit = 0;
            // var prism13BFVLunit = 0;

            var prism13BNHR = 0;
            var prism13BNHL = 0;
            var prism13BNVR = 0;
            var prism13BNVL = 0;

            // var prism13BNHRunit = 0;
            // var prism13BNHLunit = 0;
            // var prism13BNVRunit = 0;
            // var prism13BNVLunit = 0;

            var prism14AFHR = 0;
            var prism14AFHL = 0;
            var prism14AFVR = 0;
            var prism14AFVL = 0;

            // var prism14AFHRunit = 0;
            // var prism14AFHLunit = 0;
            // var prism14AFVRunit = 0;
            // var prism14AFVLunit = 0;

            var prism14ANHR = 0;
            var prism14ANHL = 0;
            var prism14ANVR = 0;
            var prism14ANVL = 0;

            // var prism14ANHRunit = 0;
            // var prism14ANHLunit = 0;
            // var prism14ANVRunit = 0;
            // var prism14ANVLunit = 0;

            var prism14BFHR = 0;
            var prism14BFHL = 0;
            var prism14BFVR = 0;
            var prism14BFVL = 0;

            // var prism14BFHRunit = 0;
            // var prism14BFHLunit = 0;
            // var prism14BFVRunit = 0;
            // var prism14BFVLunit = 0;

            var prism14BNHR = 0;
            var prism14BNHL = 0;
            var prism14BNVR = 0;
            var prism14BNVL = 0;

            // var prism14BNHRunit = 0;
            // var prism14BNHLunit = 0;
            // var prism14BNVRunit = 0;
            // var prism14BNVLunit = 0;

            var prism15AFHR = 0;
            var prism15AFHL = 0;
            var prism15AFVR = 0;
            var prism15AFVL = 0;

            // var prism15AFHRunit = 0;
            // var prism15AFHLunit = 0;
            // var prism15AFVRunit = 0;
            // var prism15AFVLunit = 0;

            var prism15ANHR = 0;
            var prism15ANHL = 0;
            var prism15ANVR = 0;
            var prism15ANVL = 0;

            // var prism15ANHRunit = 0;
            // var prism15ANHLunit = 0;
            // var prism15ANVRunit = 0;
            // var prism15ANVLunit = 0;

            var prism15BFHR = 0;
            var prism15BFHL = 0;
            var prism15BFVR = 0;
            var prism15BFVL = 0;

            // var prism15BFHRunit = 0;
            // var prism15BFHLunit = 0;
            // var prism15BFVRunit = 0;
            // var prism15BFVLunit = 0;

            var prism15BNHR = 0;
            var prism15BNHL = 0;
            var prism15BNVR = 0;
            var prism15BNVL = 0;

            // var prism15BNHRunit = 0;
            // var prism15BNHLunit = 0;
            // var prism15BNVRunit = 0;
            // var prism15BNVLunit = 0;

            var prism16FHR = 0;
            var prism16FHL = 0;
            var prism16FVR = 0;
            var prism16FVL = 0;

            // var prism16FHRunit = 0;
            // var prism16FHLunit = 0;
            // var prism16FVRunit = 0;
            // var prism16FVLunit = 0;

            var prism16NHR = 0;
            var prism16NHL = 0;
            var prism16NVR = 0;
            var prism16NVL = 0;

            // var prism16NHRunit = 0;
            // var prism16NHLunit = 0;
            // var prism16NVRunit = 0;
            // var prism16NVLunit = 0;

            var prism17FHR = 0;
            var prism17FHL = 0;
            var prism17FVR = 0;
            var prism17FVL = 0;

            // var prism17FHRunit = 0;
            // var prism17FHLunit = 0;
            // var prism17FVRunit = 0;
            // var prism17FVLunit = 0;

            var prism17NHR = 0;
            var prism17NHL = 0;
            var prism17NVR = 0;
            var prism17NVL = 0;

            var prism18AFHR = 0;
            var prism18AFHL = 0;
            var prism18AFVR = 0;
            var prism18AFVL = 0;
			var prism18ANHR = 0;
            var prism18ANHL = 0;
            var prism18ANVR = 0;
            var prism18ANVL = 0;

            // var prism17NHRunit = 0;
            // var prism17NHLunit = 0;
            // var prism17NVRunit = 0;
            // var prism17NVLunit = 0;
            if (!modelHelper.isNull(updateDataJson)) {
                const prismvalues = updateDataJson.prismstate;
                var prism3FHR = prismvalues.prism3FHR;
                var prism3FHL = prismvalues.prism3FHL;
                var prism3FVR = prismvalues.prism3FVR;
                var prism3FVL = prismvalues.prism3FVL;

                var prism3FHRunit = prismvalues.prism3FHRunit;
                var prism3FHLunit = prismvalues.prism3FHLunit;
                var prism3FVRunit = prismvalues.prism3FVRunit;
                var prism3FVLunit = prismvalues.prism3FVLunit;

                var prism3NHR = prismvalues.prism3NHR;
                var prism3NHL = prismvalues.prism3NHL;
                var prism3NVR = prismvalues.prism3NVR;
                var prism3NVL = prismvalues.prism3NVL;

                var prism3NHRunit = prismvalues.prism3NHRunit;
                var prism3NHLunit = prismvalues.prism3NHLunit;
                var prism3NVRunit = prismvalues.prism3NVRunit;
                var prism3NVLunit = prismvalues.prism3NVLunit;

                var prism8FHR = prismvalues.prism8FHR;
                var prism8FHL = prismvalues.prism8FHL;
                var prism8FVR = prismvalues.prism8FVR;
                var prism8FVL = prismvalues.prism8FVL;

                var prism8FHRunit = prismvalues.prism8FHRunit;
                var prism8FHLunit = prismvalues.prism8FHLunit;
                var prism8FVRunit = prismvalues.prism8FVRunit;
                var prism8FVLunit = prismvalues.prism8FVLunit;

                var prism8NHR = prismvalues.prism8NHR;
                var prism8NHL = prismvalues.prism8NHL;
                var prism8NVR = prismvalues.prism8NVR;
                var prism8NVL = prismvalues.prism8NVL;

                var prism8NHRunit = prismvalues.prism8NHRunit;
                var prism8NHLunit = prismvalues.prism8NHLunit;
                var prism8NVRunit = prismvalues.prism8NVRunit;
                var prism8NVLunit = prismvalues.prism8NVLunit;

                var prism9FHR = prismvalues.prism9FHR;
                var prism9FHL = prismvalues.prism9FHL;
                var prism9FVR = prismvalues.prism9FVR;
                var prism9FVL = prismvalues.prism9FVL;

                var prism9FHRunit = prismvalues.prism9FHRunit;
                var prism9FHLunit = prismvalues.prism9FHLunit;
                var prism9FVRunit = prismvalues.prism9FVRunit;
                var prism9FVLunit = prismvalues.prism9FVLunit;

                var prism9NHR = prismvalues.prism9NHR;
                var prism9NHL = prismvalues.prism9NHL;
                var prism9NVR = prismvalues.prism9NVR;
                var prism9NVL = prismvalues.prism9NVL;

                var prism9NHRunit = prismvalues.prism9NHRunit;
                var prism9NHLunit = prismvalues.prism9NHLunit;
                var prism9NVRunit = prismvalues.prism9NVRunit;
                var prism9NVLunit = prismvalues.prism9NVLunit;

                var prism10FHR = prismvalues.prism10FHR;
                var prism10FHL = prismvalues.prism10FHL;
                var prism10FVR = prismvalues.prism10FVR;
                var prism10FVL = prismvalues.prism10FVL;

                var prism10FHRunit = prismvalues.prism10FHRunit;
                var prism10FHLunit = prismvalues.prism10FHLunit;
                var prism10FVRunit = prismvalues.prism10FVRunit;
                var prism10FVLunit = prismvalues.prism10FVLunit;

                var prism10NHR = prismvalues.prism10NHR;
                var prism10NHL = prismvalues.prism10NHL;
                var prism10NVR = prismvalues.prism10NVR;
                var prism10NVL = prismvalues.prism10NVR;

                var prism10NHRunit = prismvalues.prism10NHRunit;
                var prism10NHLunit = prismvalues.prism10NHLunit;
                var prism10NVRunit = prismvalues.prism10NVRunit;
                var prism10NVLunit = prismvalues.prism10NVRunit;

                var prism12AFHR = prismvalues.prism12AFHR;
                var prism12AFHL = prismvalues.prism12AFHL;
                var prism12AFVR = prismvalues.prism12AFVR;
                var prism12AFVL = prismvalues.prism12AFVL;

                var prism12AFHRunit = prismvalues.prism12AFHRunit;
                var prism12AFHLunit = prismvalues.prism12AFHLunit;
                var prism12AFVRunit = prismvalues.prism12AFVRunit;
                var prism12AFVLunit = prismvalues.prism12AFVLunit;

                var prism12ANHR = prismvalues.prism12ANHR;
                var prism12ANHL = prismvalues.prism12ANHL;
                var prism12ANVR = prismvalues.prism12ANVR;
                var prism12ANVL = prismvalues.prism12ANVL;

                var prism12ANHRunit = prismvalues.prism12ANHRunit;
                var prism12ANHLunit = prismvalues.prism12ANHLunit;
                var prism12ANVRunit = prismvalues.prism12ANVRunit;
                var prism12ANVLunit = prismvalues.prism12ANVLunit;


                var prism12BFHR = prismvalues.prism12BFHR;
                var prism12BFHL = prismvalues.prism12BFHL;
                var prism12BFVR = prismvalues.prism12BFVR;
                var prism12BFVL = prismvalues.prism12BFVL;

                var prism12BFHRunit = prismvalues.prism12BFHRunit;
                var prism12BFHLunit = prismvalues.prism12BFHLunit;
                var prism12BFVRunit = prismvalues.prism12BFVRunit;
                var prism12BFVLunit = prismvalues.prism12BFVLunit;

                var prism12BNHR = prismvalues.prism12BNHR;
                var prism12BNHL = prismvalues.prism12BNHL;
                var prism12BNVR = prismvalues.prism12BNVR;
                var prism12BNVL = prismvalues.prism12BNVL;

                var prism12BNHRunit = prismvalues.prism12BNHRunit;
                var prism12BNHLunit = prismvalues.prism12BNHLunit;
                var prism12BNVRunit = prismvalues.prism12BNVRunit;
                var prism12BNVLunit = prismvalues.prism12BNVLunit;

                var prism13AFHR = prismvalues.prism13AFHR;
                var prism13AFHL = prismvalues.prism13AFHL;
                var prism13AFVR = prismvalues.prism13AFVR;
                var prism13AFVL = prismvalues.prism13AFVL;

                var prism13AFHRunit = prismvalues.prism13AFHRunit;
                var prism13AFHLunit = prismvalues.prism13AFHLunit;
                var prism13AFVRunit = prismvalues.prism13AFVRunit;
                var prism13AFVLunit = prismvalues.prism13AFVLunit;

                var prism13ANHR = prismvalues.prism13ANHR;
                var prism13ANHL = prismvalues.prism13ANHL;
                var prism13ANVR = prismvalues.prism13ANVR;
                var prism13ANVL = prismvalues.prism13ANVL;

                var prism13ANHRunit = prismvalues.prism13ANHRunit;
                var prism13ANHLunit = prismvalues.prism13ANHLunit;
                var prism13ANVRunit = prismvalues.prism13ANVRunit;
                var prism13ANVLunit = prismvalues.prism13ANVLunit;

                var prism13BFHR = prismvalues.prism13BFHR;
                var prism13BFHL = prismvalues.prism13BFHL;
                var prism13BFVR = prismvalues.prism13BFVR;
                var prism13BFVL = prismvalues.prism13BFVL;

                var prism13BFHRunit = prismvalues.prism13BFHRunit;
                var prism13BFHLunit = prismvalues.prism13BFHLunit;
                var prism13BFVRunit = prismvalues.prism13BFVRunit;
                var prism13BFVLunit = prismvalues.prism13BFVLunit;

                var prism13BNHR = prismvalues.prism13BNHR;
                var prism13BNHL = prismvalues.prism13BNHL;
                var prism13BNVR = prismvalues.prism13BNVR;
                var prism13BNVL = prismvalues.prism13BNVL;

                var prism13BNHRunit = prismvalues.prism13BNHRunit;
                var prism13BNHLunit = prismvalues.prism13BNHLunit;
                var prism13BNVRunit = prismvalues.prism13BNVRunit;
                var prism13BNVLunit = prismvalues.prism13BNVLunit;

                var prism14AFHR = prismvalues.prism14AFHR;
                var prism14AFHL = prismvalues.prism14AFHL;
                var prism14AFVR = prismvalues.prism14AFVR;
                var prism14AFVL = prismvalues.prism14AFVL;

                var prism14AFHRunit = prismvalues.prism14AFHRunit;
                var prism14AFHLunit = prismvalues.prism14AFHLunit;
                var prism14AFVRunit = prismvalues.prism14AFVRunit;
                var prism14AFVLunit = prismvalues.prism14AFVLunit;

                var prism14ANHR = prismvalues.prism14ANHR;
                var prism14ANHL = prismvalues.prism14ANHL;
                var prism14ANVR = prismvalues.prism14ANVR;
                var prism14ANVL = prismvalues.prism14ANVL;

                var prism14ANHRunit = prismvalues.prism14ANHRunit;
                var prism14ANHLunit = prismvalues.prism14ANHLunit;
                var prism14ANVRunit = prismvalues.prism14ANVRunit;
                var prism14ANVLunit = prismvalues.prism14ANVLunit;

                var prism14BFHR = prismvalues.prism14BFHR;
                var prism14BFHL = prismvalues.prism14BFHL;
                var prism14BFVR = prismvalues.prism14BFVR;
                var prism14BFVL = prismvalues.prism14BFVL;

                var prism14BFHRunit = prismvalues.prism14BFHRunit;
                var prism14BFHLunit = prismvalues.prism14BFHLunit;
                var prism14BFVRunit = prismvalues.prism14BFVRunit;
                var prism14BFVLunit = prismvalues.prism14BFVLunit;

                var prism14BNHR = prismvalues.prism14BNHR;
                var prism14BNHL = prismvalues.prism14BNHL;
                var prism14BNVR = prismvalues.prism14BNVR;
                var prism14BNVL = prismvalues.prism14BNVL;

                var prism14BNHRunit = prismvalues.prism14BNHRunit;
                var prism14BNHLunit = prismvalues.prism14BNHLunit;
                var prism14BNVRunit = prismvalues.prism14BNVRunit;
                var prism14BNVLunit = prismvalues.prism14BNVLunit;

                var prism15AFHR = prismvalues.prism15AFHR;
                var prism15AFHL = prismvalues.prism15AFHL;
                var prism15AFVR = prismvalues.prism15AFVR;
                var prism15AFVL = prismvalues.prism15AFVL;

                var prism15AFHRunit = prismvalues.prism15AFHRunit;
                var prism15AFHLunit = prismvalues.prism15AFHLunit;
                var prism15AFVRunit = prismvalues.prism15AFVRunit;
                var prism15AFVLunit = prismvalues.prism15AFVLunit;

                var prism15ANHR = prismvalues.prism15ANHR;
                var prism15ANHL = prismvalues.prism15ANHL;
                var prism15ANVR = prismvalues.prism15ANVR;
                var prism15ANVL = prismvalues.prism15ANVL;

                var prism15ANHRunit = prismvalues.prism15ANHRunit;
                var prism15ANHLunit = prismvalues.prism15ANHLunit;
                var prism15ANVRunit = prismvalues.prism15ANVRunit;
                var prism15ANVLunit = prismvalues.prism15ANVLunit;

                var prism15BFHR = prismvalues.prism15BFHR;
                var prism15BFHL = prismvalues.prism15BFHL;
                var prism15BFVR = prismvalues.prism15BFVR;
                var prism15BFVL = prismvalues.prism15BFVL;

                var prism15BFHRunit = prismvalues.prism15BFHRunit;
                var prism15BFHLunit = prismvalues.prism15BFHLunit;
                var prism15BFVRunit = prismvalues.prism15BFVRunit;
                var prism15BFVLunit = prismvalues.prism15BFVLunit;

                var prism15BNHR = prismvalues.prism15BNHR;
                var prism15BNHL = prismvalues.prism15BNHL;
                var prism15BNVR = prismvalues.prism15BNVR;
                var prism15BNVL = prismvalues.prism15BNVL;

                var prism15BNHRunit = prismvalues.prism15BNHRunit;
                var prism15BNHLunit = prismvalues.prism15BNHLunit;
                var prism15BNVRunit = prismvalues.prism15BNVRunit;
                var prism15BNVLunit = prismvalues.prism15BNVLunit;

                var prism16FHR = prismvalues.prism16FHR;
                var prism16FHL = prismvalues.prism16FHL;
                var prism16FVR = prismvalues.prism16FVR;
                var prism16FVL = prismvalues.prism16FVL;

                var prism16FHRunit = prismvalues.prism16FHRunit;
                var prism16FHLunit = prismvalues.prism16FHLunit;
                var prism16FVRunit = prismvalues.prism16FVRunit;
                var prism16FVLunit = prismvalues.prism16FVLunit;

                var prism16NHR = prismvalues.prism16NHR;
                var prism16NHL = prismvalues.prism16NHL;
                var prism16NVR = prismvalues.prism16NVR;
                var prism16NVL = prismvalues.prism16NVL;

                var prism16NHRunit = prismvalues.prism16NHRunit;
                var prism16NHLunit = prismvalues.prism16NHLunit;
                var prism16NVRunit = prismvalues.prism16NVRunit;
                var prism16NVLunit = prismvalues.prism16NVLunit;

                var prism17FHR = prismvalues.prism17FHR;
                var prism17FHL = prismvalues.prism17FHL;
                var prism17FVR = prismvalues.prism17FVR;
                var prism17FVL = prismvalues.prism17FVL;

                var prism17FHRunit = prismvalues.prism17FHRunit;
                var prism17FHLunit = prismvalues.prism17FHLunit;
                var prism17FVRunit = prismvalues.prism17FVRunit;
                var prism17FVLunit = prismvalues.prism17FVLunit;

                var prism17NHR = prismvalues.prism17NHR;
                var prism17NHL = prismvalues.prism17NHL;
                var prism17NVR = prismvalues.prism17NVR;
                var prism17NVL = prismvalues.prism17NVL;

                var prism17NHRunit = prismvalues.prism17NHRunit;
                var prism17NHLunit = prismvalues.prism17NHLunit;
                var prism17NVRunit = prismvalues.prism17NVRunit;
                var prism17NVLunit = prismvalues.prism17NVLunit;

                var prism18AFHR = prismvalues.prism18AFHR;
                var prism18AFHL = prismvalues.prism18AFHL;
                var prism18AFVR = prismvalues.prism18AFVR;
                var prism18AFVL = prismvalues.prism18AFVL;

                var prism18AFHRunit = prismvalues.prism18AFHRunit;
                var prism18AFHLunit = prismvalues.prism18AFHLunit;
                var prism18AFVRunit = prismvalues.prism18AFVRunit;
                var prism18AFVLunit = prismvalues.prism18AFVLunit;

                var prism18ANHR = prismvalues.prism18ANHR;
                var prism18ANHL = prismvalues.prism18ANHL;
                var prism18ANVR = prismvalues.prism18ANVR;
                var prism18ANVL = prismvalues.prism18ANVL;

                var prism18ANHRunit = prismvalues.prism18ANHRunit;
                var prism18ANHLunit = prismvalues.prism18ANHLunit;
                var prism18ANVRunit = prismvalues.prism18ANVRunit;
                var prism18ANVLunit = prismvalues.prism18ANVLunit;



                console.log(prismvalues);
            }



            //const BO = $("#labelMainPrismHorR").attr("data-text");
            //const BU = $("#labelMainPrismVerR").attr("data-text");
            //const BI = $("#labelMainPrismHorL").attr("data-text");
            //const BD = $("#labelMainPrismVerL").attr("data-text");



        } else {
            //console.log(aModel);
            var prism3FHR = aModel.prism3FHR;
            var prism3FHL = aModel.prism3FHL;
            var prism3FVR = aModel.prism3FVR;
            var prism3FVL = aModel.prism3FVL;

            var prism3FHRunit = aModel.prism3FHRunit;
            var prism3FHLunit = aModel.prism3FHLunit;
            var prism3FVRunit = aModel.prism3FVRunit;
            var prism3FVLunit = aModel.prism3FVLunit;

            var prism3NHR = aModel.prism3NHR;
            var prism3NHL = aModel.prism3NHL;
            var prism3NVR = aModel.prism3NVR;
            var prism3NVL = aModel.prism3NVL;

            var prism3NHRunit = aModel.prism3NHRunit;
            var prism3NHLunit = aModel.prism3NHLunit;
            var prism3NVRunit = aModel.prism3NVRunit;
            var prism3NVLunit = aModel.prism3NVLunit;

            var prism8FHR = aModel.prism8FHR;
            var prism8FHL = aModel.prism8FHL;
            var prism8FVR = aModel.prism8FVR;
            var prism8FVL = aModel.prism8FVL;

            var prism8FHRunit = aModel.prism8FHRunit;
            var prism8FHLunit = aModel.prism8FHLunit;
            var prism8FVRunit = aModel.prism8FVRunit;
            var prism8FVLunit = aModel.prism8FVLunit;

            var prism8NHR = aModel.prism8NHR;
            var prism8NHL = aModel.prism8NHL;
            var prism8NVR = aModel.prism8NVR;
            var prism8NVL = aModel.prism8NVL;

            var prism8NHRunit = aModel.prism8NHRunit;
            var prism8NHLunit = aModel.prism8NHLunit;
            var prism8NVRunit = aModel.prism8NVRunit;
            var prism8NVLunit = aModel.prism8NVLunit;

            var prism9FHR = aModel.prism9FHR;
            var prism9FHL = aModel.prism9FHL;
            var prism9FVR = aModel.prism9FVR;
            var prism9FVL = aModel.prism9FVL;

            var prism9FHRunit = aModel.prism9FHRunit;
            var prism9FHLunit = aModel.prism9FHLunit;
            var prism9FVRunit = aModel.prism9FVRunit;
            var prism9FVLunit = aModel.prism9FVLunit;

            var prism9NHR = aModel.prism9NHR;
            var prism9NHL = aModel.prism9NHL;
            var prism9NVR = aModel.prism9NVR;
            var prism9NVL = aModel.prism9NVL;

            var prism9NHRunit = aModel.prism9NHRunit;
            var prism9NHLunit = aModel.prism9NHLunit;
            var prism9NVRunit = aModel.prism9NVRunit;
            var prism9NVLunit = aModel.prism9NVLunit;

            var prism10FHR = aModel.prism10FHR;
            var prism10FHL = aModel.prism10FHL;
            var prism10FVR = aModel.prism10FVR;
            var prism10FVL = aModel.prism10FVL;

            var prism10FHRunit = aModel.prism10FHRunit;
            var prism10FHLunit = aModel.prism10FHLunit;
            var prism10FVRunit = aModel.prism10FVRunit;
            var prism10FVLunit = aModel.prism10FVLunit;

            var prism10NHR = aModel.prism10NHR;
            var prism10NHL = aModel.prism10NHL;
            var prism10NVR = aModel.prism10NVR;
            var prism10NVL = aModel.prism10NVR;

            var prism10NHRunit = aModel.prism10NHRunit;
            var prism10NHLunit = aModel.prism10NHLunit;
            var prism10NVRunit = aModel.prism10NVRunit;
            var prism10NVLunit = aModel.prism10NVRunit;

            var prism12AFHR = aModel.prism12AFHR;
            var prism12AFHL = aModel.prism12AFHL;
            var prism12AFVR = aModel.prism12AFVR;
            var prism12AFVL = aModel.prism12AFVL;

            var prism12AFHRunit = aModel.prism12AFHRunit;
            var prism12AFHLunit = aModel.prism12AFHLunit;
            var prism12AFVRunit = aModel.prism12AFVRunit;
            var prism12AFVLunit = aModel.prism12AFVLunit;

            var prism12ANHR = aModel.prism12ANHR;
            var prism12ANHL = aModel.prism12ANHL;
            var prism12ANVR = aModel.prism12ANVR;
            var prism12ANVL = aModel.prism12ANVL;

            var prism12ANHRunit = aModel.prism12ANHRunit;
            var prism12ANHLunit = aModel.prism12ANHLunit;
            var prism12ANVRunit = aModel.prism12ANVRunit;
            var prism12ANVLunit = aModel.prism12ANVLunit;


            var prism12BFHR = aModel.prism12BFHR;
            var prism12BFHL = aModel.prism12BFHL;
            var prism12BFVR = aModel.prism12BFVR;
            var prism12BFVL = aModel.prism12BFVL;

            var prism12BFHRunit = aModel.prism12BFHRunit;
            var prism12BFHLunit = aModel.prism12BFHLunit;
            var prism12BFVRunit = aModel.prism12BFVRunit;
            var prism12BFVLunit = aModel.prism12BFVLunit;

            var prism12BNHR = aModel.prism12BNHR;
            var prism12BNHL = aModel.prism12BNHL;
            var prism12BNVR = aModel.prism12BNVR;
            var prism12BNVL = aModel.prism12BNVL;

            var prism12BNHRunit = aModel.prism12BNHRunit;
            var prism12BNHLunit = aModel.prism12BNHLunit;
            var prism12BNVRunit = aModel.prism12BNVRunit;
            var prism12BNVLunit = aModel.prism12BNVLunit;

            var prism13AFHR = aModel.prism13AFHR;
            var prism13AFHL = aModel.prism13AFHL;
            var prism13AFVR = aModel.prism13AFVR;
            var prism13AFVL = aModel.prism13AFVL;

            var prism13AFHRunit = aModel.prism13AFHRunit;
            var prism13AFHLunit = aModel.prism13AFHLunit;
            var prism13AFVRunit = aModel.prism13AFVRunit;
            var prism13AFVLunit = aModel.prism13AFVLunit;

            var prism13ANHR = aModel.prism13ANHR;
            var prism13ANHL = aModel.prism13ANHL;
            var prism13ANVR = aModel.prism13ANVR;
            var prism13ANVL = aModel.prism13ANVL;

            var prism13ANHRunit = aModel.prism13ANHRunit;
            var prism13ANHLunit = aModel.prism13ANHLunit;
            var prism13ANVRunit = aModel.prism13ANVRunit;
            var prism13ANVLunit = aModel.prism13ANVLunit;

            var prism13BFHR = aModel.prism13BFHR;
            var prism13BFHL = aModel.prism13BFHL;
            var prism13BFVR = aModel.prism13BFVR;
            var prism13BFVL = aModel.prism13BFVL;

            var prism13BFHRunit = aModel.prism13BFHRunit;
            var prism13BFHLunit = aModel.prism13BFHLunit;
            var prism13BFVRunit = aModel.prism13BFVRunit;
            var prism13BFVLunit = aModel.prism13BFVLunit;

            var prism13BNHR = aModel.prism13BNHR;
            var prism13BNHL = aModel.prism13BNHL;
            var prism13BNVR = aModel.prism13BNVR;
            var prism13BNVL = aModel.prism13BNVL;

            var prism13BNHRunit = aModel.prism13BNHRunit;
            var prism13BNHLunit = aModel.prism13BNHLunit;
            var prism13BNVRunit = aModel.prism13BNVRunit;
            var prism13BNVLunit = aModel.prism13BNVLunit;

            var prism14AFHR = aModel.prism14AFHR;
            var prism14AFHL = aModel.prism14AFHL;
            var prism14AFVR = aModel.prism14AFVR;
            var prism14AFVL = aModel.prism14AFVL;

            var prism14AFHRunit = aModel.prism14AFHRunit;
            var prism14AFHLunit = aModel.prism14AFHLunit;
            var prism14AFVRunit = aModel.prism14AFVRunit;
            var prism14AFVLunit = aModel.prism14AFVLunit;

            var prism14ANHR = aModel.prism14ANHR;
            var prism14ANHL = aModel.prism14ANHL;
            var prism14ANVR = aModel.prism14ANVR;
            var prism14ANVL = aModel.prism14ANVL;

            var prism14ANHRunit = aModel.prism14ANHRunit;
            var prism14ANHLunit = aModel.prism14ANHLunit;
            var prism14ANVRunit = aModel.prism14ANVRunit;
            var prism14ANVLunit = aModel.prism14ANVLunit;

            var prism14BFHR = aModel.prism14BFHR;
            var prism14BFHL = aModel.prism14BFHL;
            var prism14BFVR = aModel.prism14BFVR;
            var prism14BFVL = aModel.prism14BFVL;

            var prism14BFHRunit = aModel.prism14BFHRunit;
            var prism14BFHLunit = aModel.prism14BFHLunit;
            var prism14BFVRunit = aModel.prism14BFVRunit;
            var prism14BFVLunit = aModel.prism14BFVLunit;

            var prism14BNHR = aModel.prism14BNHR;
            var prism14BNHL = aModel.prism14BNHL;
            var prism14BNVR = aModel.prism14BNVR;
            var prism14BNVL = aModel.prism14BNVL;

            var prism14BNHRunit = aModel.prism14BNHRunit;
            var prism14BNHLunit = aModel.prism14BNHLunit;
            var prism14BNVRunit = aModel.prism14BNVRunit;
            var prism14BNVLunit = aModel.prism14BNVLunit;

            var prism15AFHR = aModel.prism15AFHR;
            var prism15AFHL = aModel.prism15AFHL;
            var prism15AFVR = aModel.prism15AFVR;
            var prism15AFVL = aModel.prism15AFVL;

            var prism15AFHRunit = aModel.prism15AFHRunit;
            var prism15AFHLunit = aModel.prism15AFHLunit;
            var prism15AFVRunit = aModel.prism15AFVRunit;
            var prism15AFVLunit = aModel.prism15AFVLunit;

            var prism15ANHR = aModel.prism15ANHR;
            var prism15ANHL = aModel.prism15ANHL;
            var prism15ANVR = aModel.prism15ANVR;
            var prism15ANVL = aModel.prism15ANVL;

            var prism15ANHRunit = aModel.prism15ANHRunit;
            var prism15ANHLunit = aModel.prism15ANHLunit;
            var prism15ANVRunit = aModel.prism15ANVRunit;
            var prism15ANVLunit = aModel.prism15ANVLunit;

            var prism15BFHR = aModel.prism15BFHR;
            var prism15BFHL = aModel.prism15BFHL;
            var prism15BFVR = aModel.prism15BFVR;
            var prism15BFVL = aModel.prism15BFVL;

            var prism15BFHRunit = aModel.prism15BFHRunit;
            var prism15BFHLunit = aModel.prism15BFHLunit;
            var prism15BFVRunit = aModel.prism15BFVRunit;
            var prism15BFVLunit = aModel.prism15BFVLunit;

            var prism15BNHR = aModel.prism15BNHR;
            var prism15BNHL = aModel.prism15BNHL;
            var prism15BNVR = aModel.prism15BNVR;
            var prism15BNVL = aModel.prism15BNVL;

            var prism15BNHRunit = aModel.prism15BNHRunit;
            var prism15BNHLunit = aModel.prism15BNHLunit;
            var prism15BNVRunit = aModel.prism15BNVRunit;
            var prism15BNVLunit = aModel.prism15BNVLunit;

            var prism16FHR = aModel.prism16FHR;
            var prism16FHL = aModel.prism16FHL;
            var prism16FVR = aModel.prism16FVR;
            var prism16FVL = aModel.prism16FVL;

            var prism16FHRunit = aModel.prism16FHRunit;
            var prism16FHLunit = aModel.prism16FHLunit;
            var prism16FVRunit = aModel.prism16FVRunit;
            var prism16FVLunit = aModel.prism16FVLunit;

            var prism16NHR = aModel.prism16NHR;
            var prism16NHL = aModel.prism16NHL;
            var prism16NVR = aModel.prism16NVR;
            var prism16NVL = aModel.prism16NVL;

            var prism16NHRunit = aModel.prism16NHRunit;
            var prism16NHLunit = aModel.prism16NHLunit;
            var prism16NVRunit = aModel.prism16NVRunit;
            var prism16NVLunit = aModel.prism16NVLunit;

            var prism17FHR = aModel.prism17FHR;
            var prism17FHL = aModel.prism17FHL;
            var prism17FVR = aModel.prism17FVR;
            var prism17FVL = aModel.prism17FVL;

            var prism17FHRunit = aModel.prism17FHRunit;
            var prism17FHLunit = aModel.prism17FHLunit;
            var prism17FVRunit = aModel.prism17FVRunit;
            var prism17FVLunit = aModel.prism17FVLunit;

            var prism17NHR = aModel.prism17NHR;
            var prism17NHL = aModel.prism17NHL;
            var prism17NVR = aModel.prism17NVR;
            var prism17NVL = aModel.prism17NVL;

            var prism17NHRunit = aModel.prism17NHRunit;
            var prism17NHLunit = aModel.prism17NHLunit;
            var prism17NVRunit = aModel.prism17NVRunit;
            var prism17NVLunit = aModel.prism17NVLunit;

            var prism18AFHR = aModel.prism18AFHR;
            var prism18AFHL = aModel.prism18AFHL;
            var prism18AFVR = aModel.prism18AFVR;
            var prism18AFVL = aModel.prism18AFVL;

            var prism18AFHRunit = aModel.prism18AFHRunit;
            var prism18AFHLunit = aModel.prism18AFHLunit;
            var prism18AFVRunit = aModel.prism18AFVRunit;
            var prism18AFVLunit = aModel.prism18AFVLunit;

            var prism18ANHR = aModel.prism18ANHR;
            var prism18ANHL = aModel.prism18ANHL;
            var prism18ANVR = aModel.prism18ANVR;
            var prism18ANVL = aModel.prism18ANVL;

            var prism18ANHRunit = aModel.prism18ANHRunit;
            var prism18ANHLunit = aModel.prism18ANHLunit;
            var prism18ANVRunit = aModel.prism18ANVRunit;
            var prism18ANVLunit = aModel.prism18ANVLunit;


        }

        var valPrismType = chartParameterItem.PrismtRuleH;
        var farNear = chartParameterItem.IsNearFar;

        switch (valPrismType.toUpperCase()) {
            case "3":
                switch (farNear.toUpperCase()) {
                    case "FN":
                    case "F":
                        prism3FHR = $("#labelMainPrismHorR").attr("data-text");
                        prism3FHL = $("#labelMainPrismHorL").attr("data-text");
                        prism3FVR = $("#labelMainPrismVerR").attr("data-text");
                        prism3FVL = $("#labelMainPrismVerL").attr("data-text");

                        prism3FHRunit = $(".prism-heading-inner-hor-R-BI").attr("data-fixed");
                        prism3FHLunit = $(".prism-heading-inner-hor-L-BI").attr("data-fixed");
                        prism3FVRunit = $(".prism-heading-inner-ver-R-BD").attr("data-fixed");
                        prism3FVLunit = $(".prism-heading-inner-ver-L-BD").attr("data-fixed");
                        break;
                    case "N":
                        prism3NHR = $("#labelMainPrismHorR").attr("data-text");
                        prism3NHL = $("#labelMainPrismHorL").attr("data-text");
                        prism3NVR = $("#labelMainPrismVerR").attr("data-text");
                        prism3NVL = $("#labelMainPrismVerL").attr("data-text");

                        prism3NHRunit = $(".prism-heading-inner-hor-R-BI").attr("data-fixed");
                        prism3NHLunit = $(".prism-heading-inner-hor-L-BI").attr("data-fixed");
                        prism3NVRunit = $(".prism-heading-inner-ver-R-BD").attr("data-fixed");
                        prism3NVLunit = $(".prism-heading-inner-ver-L-BD").attr("data-fixed");
                        break;
                    default:
                        // becky.assertion.failure("unknown SCA");
                        break;
                }
                break;
            case "8":
                switch (farNear) {
                    case "FN":
                    case "F":
                        prism8FHR = $("#labelMainPrismHorR").attr("data-text");
                        prism8FHL = $("#labelMainPrismHorL").attr("data-text");
                        prism8FVR = $("#labelMainPrismVerR").attr("data-text");
                        prism8FVL = $("#labelMainPrismVerL").attr("data-text");

                        prism8FHRunit = $(".prism-heading-inner-hor-R-BI").attr("data-fixed");
                        prism8FHLunit = $(".prism-heading-inner-hor-L-BI").attr("data-fixed");
                        prism8FVRunit = $(".prism-heading-inner-ver-R-BD").attr("data-fixed");
                        prism8FVLunit = $(".prism-heading-inner-ver-L-BD").attr("data-fixed");
                        break;
                    case "N":
                        prism8NHR = $("#labelMainPrismHorR").attr("data-text");
                        prism8NHL = $("#labelMainPrismHorL").attr("data-text");
                        prism8NVR = $("#labelMainPrismVerR").attr("data-text");
                        prism8NVL = $("#labelMainPrismVerL").attr("data-text");

                        prism8NHRunit = $(".prism-heading-inner-hor-R-BI").attr("data-fixed");
                        prism8NHLunit = $(".prism-heading-inner-hor-L-BI").attr("data-fixed");
                        prism8NVRunit = $(".prism-heading-inner-ver-R-BD").attr("data-fixed");
                        prism8NVLunit = $(".prism-heading-inner-ver-L-BD").attr("data-fixed");
                        break;
                    default:
                        // becky.assertion.failure("unknown SCA");
                        break;
                }
                break;
            case "9":
                switch (farNear) {
                    case "FN":
                    case "F":
                        prism9FHR = $("#labelMainPrismHorR").attr("data-text");
                        prism9FHL = $("#labelMainPrismHorL").attr("data-text");
                        prism9FVR = $("#labelMainPrismVerR").attr("data-text");
                        prism9FVL = $("#labelMainPrismVerL").attr("data-text");

                        prism9FHRunit = $(".prism-heading-inner-hor-R-BI").attr("data-fixed");
                        prism9FHLunit = $(".prism-heading-inner-hor-L-BI").attr("data-fixed");
                        prism9FVRunit = $(".prism-heading-inner-ver-R-BD").attr("data-fixed");
                        prism9FVLunit = $(".prism-heading-inner-ver-L-BD").attr("data-fixed");
                        break;
                    case "N":
                        prism9NHR = $("#labelMainPrismHorR").attr("data-text");
                        prism9NHL = $("#labelMainPrismHorL").attr("data-text");
                        prism9NVR = $("#labelMainPrismVerR").attr("data-text");
                        prism9NVL = $("#labelMainPrismVerL").attr("data-text");

                        prism9NHRunit = $(".prism-heading-inner-hor-R-BI").attr("data-fixed");
                        prism9NHLunit = $(".prism-heading-inner-hor-L-BI").attr("data-fixed");
                        prism9NVRunit = $(".prism-heading-inner-ver-R-BD").attr("data-fixed");
                        prism9NVLunit = $(".prism-heading-inner-ver-L-BD").attr("data-fixed");
                        break;
                    default:
                        // becky.assertion.failure("unknown SCA");
                        break;
                }
                break;
            case "10":
                switch (farNear) {
                    case "FN":
                    case "F":
                        prism10FHR = $("#labelMainPrismHorR").attr("data-text");
                        prism10FHL = $("#labelMainPrismHorL").attr("data-text");
                        prism10FVR = $("#labelMainPrismVerR").attr("data-text");
                        prism10FVL = $("#labelMainPrismVerL").attr("data-text");

                        prism10FHRunit = $(".prism-heading-inner-hor-R-BI").attr("data-fixed");
                        prism10FHLunit = $(".prism-heading-inner-hor-L-BI").attr("data-fixed");
                        prism10FVRunit = $(".prism-heading-inner-ver-R-BD").attr("data-fixed");
                        prism10FVLunit = $(".prism-heading-inner-ver-L-BD").attr("data-fixed");
                        break;
                    case "N":
                        prism10NHR = $("#labelMainPrismHorR").attr("data-text");
                        prism10NHL = $("#labelMainPrismHorL").attr("data-text");
                        prism10NVR = $("#labelMainPrismVerR").attr("data-text");
                        prism10NVL = $("#labelMainPrismVerL").attr("data-text");

                        prism10NHRunit = $(".prism-heading-inner-hor-R-BI").attr("data-fixed");
                        prism10NHLunit = $(".prism-heading-inner-hor-L-BI").attr("data-fixed");
                        prism10NVRunit = $(".prism-heading-inner-ver-R-BD").attr("data-fixed");
                        prism10NVLunit = $(".prism-heading-inner-ver-L-BD").attr("data-fixed");
                        break;
                    default:
                        // becky.assertion.failure("unknown SCA");
                        break;
                }
                break;
            case "12A":
                switch (farNear) {
                    case "FN":
                    case "F":
                        prism12AFHR = $("#labelMainPrismHorR").attr("data-text");
                        prism12AFHL = $("#labelMainPrismHorL").attr("data-text");
                        prism12AFVR = $("#labelMainPrismVerR").attr("data-text");
                        prism12AFVL = $("#labelMainPrismVerL").attr("data-text");

                        prism12AFHRunit = $(".prism-heading-inner-hor-R-BI").attr("data-fixed");
                        prism12AFHLunit = $(".prism-heading-inner-hor-L-BI").attr("data-fixed");
                        prism12AFVRunit = $(".prism-heading-inner-ver-R-BD").attr("data-fixed");
                        prism12AFVLunit = $(".prism-heading-inner-ver-L-BD").attr("data-fixed");
                        break;
                    case "N":
                        prism12ANHR = $("#labelMainPrismHorR").attr("data-text");
                        prism12ANHL = $("#labelMainPrismHorL").attr("data-text");
                        prism12ANVR = $("#labelMainPrismVerR").attr("data-text");
                        prism12ANVL = $("#labelMainPrismVerL").attr("data-text");

                        prism12ANHRunit = $(".prism-heading-inner-hor-R-BI").attr("data-fixed");
                        prism12ANHLunit = $(".prism-heading-inner-hor-L-BI").attr("data-fixed");
                        prism12ANVRunit = $(".prism-heading-inner-ver-R-BD").attr("data-fixed");
                        prism12ANVLunit = $(".prism-heading-inner-ver-L-BD").attr("data-fixed");
                        break;
                    default:
                        // becky.assertion.failure("unknown SCA");
                        break;
                }
                break;
            case "12B":
                switch (farNear) {
                    case "FN":
                    case "F":
                        prism12BFHR = $("#labelMainPrismHorR").attr("data-text");
                        prism12BFHL = $("#labelMainPrismHorL").attr("data-text");
                        prism12BFVR = $("#labelMainPrismVerR").attr("data-text");
                        prism12BFVL = $("#labelMainPrismVerL").attr("data-text");

                        prism12BFHRunit = $(".prism-heading-inner-hor-R-BI").attr("data-fixed");
                        prism12BFHLunit = $(".prism-heading-inner-hor-L-BI").attr("data-fixed");
                        prism12BFVRunit = $(".prism-heading-inner-ver-R-BD").attr("data-fixed");
                        prism12BFVLunit = $(".prism-heading-inner-ver-L-BD").attr("data-fixed");
                        break;
                    case "N":
                        prism12BNHR = $("#labelMainPrismHorR").attr("data-text");
                        prism12BNHL = $("#labelMainPrismHorL").attr("data-text");
                        prism12BNVR = $("#labelMainPrismVerR").attr("data-text");
                        prism12BNVL = $("#labelMainPrismVerL").attr("data-text");

                        prism12BNHRunit = $(".prism-heading-inner-hor-R-BI").attr("data-fixed");
                        prism12BNHLunit = $(".prism-heading-inner-hor-L-BI").attr("data-fixed");
                        prism12BNVRunit = $(".prism-heading-inner-ver-R-BD").attr("data-fixed");
                        prism12BNVLunit = $(".prism-heading-inner-ver-L-BD").attr("data-fixed");
                        break;
                    default:
                        // becky.assertion.failure("unknown SCA");
                        break;
                }

                break;
            case "13A":
                switch (farNear) {
                    case "FN":
                    case "F":
                        prism13AFHR = $("#labelMainPrismHorR").attr("data-text");
                        prism13AFHL = $("#labelMainPrismHorL").attr("data-text");
                        prism13AFVR = $("#labelMainPrismVerR").attr("data-text");
                        prism13AFVL = $("#labelMainPrismVerL").attr("data-text");

                        prism13AFHRunit = $(".prism-heading-inner-hor-R-BI").attr("data-fixed");
                        prism13AFHLunit = $(".prism-heading-inner-hor-L-BI").attr("data-fixed");
                        prism13AFVRunit = $(".prism-heading-inner-ver-R-BD").attr("data-fixed");
                        prism13AFVLunit = $(".prism-heading-inner-ver-L-BD").attr("data-fixed");
                        break;
                    case "N":
                        prism13ANHR = $("#labelMainPrismHorR").attr("data-text");
                        prism13ANHL = $("#labelMainPrismHorL").attr("data-text");
                        prism13ANVR = $("#labelMainPrismVerR").attr("data-text");
                        prism13ANVL = $("#labelMainPrismVerL").attr("data-text");


                        prism13ANHRunit = $(".prism-heading-inner-hor-R-BI").attr("data-fixed");
                        prism13ANHLunit = $(".prism-heading-inner-hor-L-BI").attr("data-fixed");
                        prism13ANVRunit = $(".prism-heading-inner-ver-R-BD").attr("data-fixed");
                        prism13ANVLunit = $(".prism-heading-inner-ver-L-BD").attr("data-fixed");
                        break;
                    default:
                        // becky.assertion.failure("unknown SCA");
                        break;
                }

                break;
            case "13B":
                switch (farNear) {
                    case "FN":
                    case "F":
                        prism13BFHR = $("#labelMainPrismHorR").attr("data-text");
                        prism13BFHL = $("#labelMainPrismHorL").attr("data-text");
                        prism13BFVR = $("#labelMainPrismVerR").attr("data-text");
                        prism13BFVL = $("#labelMainPrismVerL").attr("data-text");

                        prism13BFHRunit = $(".prism-heading-inner-hor-R-BI").attr("data-fixed");
                        prism13BFHLunit = $(".prism-heading-inner-hor-L-BI").attr("data-fixed");
                        prism13BFVRunit = $(".prism-heading-inner-ver-R-BD").attr("data-fixed");
                        prism13BFVLunit = $(".prism-heading-inner-ver-L-BD").attr("data-fixed");
                        break;
                    case "N":
                        prism13BNHR = $("#labelMainPrismHorR").attr("data-text");
                        prism13BNHL = $("#labelMainPrismHorL").attr("data-text");
                        prism13BNVR = $("#labelMainPrismVerR").attr("data-text");
                        prism13BNVL = $("#labelMainPrismVerL").attr("data-text");

                        prism13BNHRunit = $(".prism-heading-inner-hor-R-BI").attr("data-fixed");
                        prism13BNHLunit = $(".prism-heading-inner-hor-L-BI").attr("data-fixed");
                        prism13BNVRunit = $(".prism-heading-inner-ver-R-BD").attr("data-fixed");
                        prism13BNVLunit = $(".prism-heading-inner-ver-L-BD").attr("data-fixed");
                        break;
                    default:
                        // becky.assertion.failure("unknown SCA");
                        break;
                }
                break;
            case "14A":
                switch (farNear) {
                    case "FN":
                    case "F":
                        prism14AFHR = $("#labelMainPrismHorR").attr("data-text");
                        prism14AFHL = $("#labelMainPrismHorL").attr("data-text");
                        prism14AFVR = $("#labelMainPrismVerR").attr("data-text");
                        prism14AFVL = $("#labelMainPrismVerL").attr("data-text");

                        prism14AFHRunit = $(".prism-heading-inner-hor-R-BI").attr("data-fixed");
                        prism14AFHLunit = $(".prism-heading-inner-hor-L-BI").attr("data-fixed");
                        prism14AFVRunit = $(".prism-heading-inner-ver-R-BD").attr("data-fixed");
                        prism14AFVLunit = $(".prism-heading-inner-ver-L-BD").attr("data-fixed");
                        break;
                    case "N":
                        prism14ANHR = $("#labelMainPrismHorR").attr("data-text");
                        prism14ANHL = $("#labelMainPrismHorL").attr("data-text");
                        prism14ANVR = $("#labelMainPrismVerR").attr("data-text");
                        prism14ANVL = $("#labelMainPrismVerL").attr("data-text");

                        prism14ANHRunit = $(".prism-heading-inner-hor-R-BI").attr("data-fixed");
                        prism14ANHLunit = $(".prism-heading-inner-hor-L-BI").attr("data-fixed");
                        prism14ANVRunit = $(".prism-heading-inner-ver-R-BD").attr("data-fixed");
                        prism14ANVLunit = $(".prism-heading-inner-ver-L-BD").attr("data-fixed");
                        break;
                    default:
                        // becky.assertion.failure("unknown SCA");
                        break;
                }
                break;
            case "14B":
                switch (farNear) {
                    case "FN":
                    case "F":
                        prism14BFHR = $("#labelMainPrismHorR").attr("data-text");
                        prism14BFHL = $("#labelMainPrismHorL").attr("data-text");
                        prism14BFVR = $("#labelMainPrismVerR").attr("data-text");
                        prism14BFVL = $("#labelMainPrismVerL").attr("data-text");

                        prism14BFHRunit = $(".prism-heading-inner-hor-R-BI").attr("data-fixed");
                        prism14BFHLunit = $(".prism-heading-inner-hor-L-BI").attr("data-fixed");
                        prism14BFVRunit = $(".prism-heading-inner-ver-R-BD").attr("data-fixed");
                        prism14BFVLunit = $(".prism-heading-inner-ver-L-BD").attr("data-fixed");
                        break;
                    case "N":
                        prism14BNHR = $("#labelMainPrismHorR").attr("data-text");
                        prism14BNHL = $("#labelMainPrismHorL").attr("data-text");
                        prism14BNVR = $("#labelMainPrismVerR").attr("data-text");
                        prism14BNVL = $("#labelMainPrismVerL").attr("data-text");

                        prism14BNHRunit = $(".prism-heading-inner-hor-R-BI").attr("data-fixed");
                        prism14BNHLunit = $(".prism-heading-inner-hor-L-BI").attr("data-fixed");
                        prism14BNVRunit = $(".prism-heading-inner-ver-R-BD").attr("data-fixed");
                        prism14BNVLunit = $(".prism-heading-inner-ver-L-BD").attr("data-fixed");
                        break;
                    default:
                        // becky.assertion.failure("unknown SCA");
                        break;
                }
                break;
            case "15A":
                switch (farNear) {
                    case "FN":
                    case "F":
                        prism15AFHR = $("#labelMainPrismHorR").attr("data-text");
                        prism15AFHL = $("#labelMainPrismHorL").attr("data-text");
                        prism15AFVR = $("#labelMainPrismVerR").attr("data-text");
                        prism15AFVL = $("#labelMainPrismVerL").attr("data-text");

                        prism15AFHRunit = $(".prism-heading-inner-hor-R-BI").attr("data-fixed");
                        prism15AFHLunit = $(".prism-heading-inner-hor-L-BI").attr("data-fixed");
                        prism15AFVRunit = $(".prism-heading-inner-ver-R-BD").attr("data-fixed");
                        prism15AFVLunit = $(".prism-heading-inner-ver-L-BD").attr("data-fixed");
                        break;
                    case "N":
                        prism15ANHR = $("#labelMainPrismHorR").attr("data-text");
                        prism15ANHL = $("#labelMainPrismHorL").attr("data-text");
                        prism15ANVR = $("#labelMainPrismVerR").attr("data-text");
                        prism15ANVL = $("#labelMainPrismVerL").attr("data-text");

                        prism15ANHRunit = $(".prism-heading-inner-hor-R-BI").attr("data-fixed");
                        prism15ANHLunit = $(".prism-heading-inner-hor-L-BI").attr("data-fixed");
                        prism15ANVRunit = $(".prism-heading-inner-ver-R-BD").attr("data-fixed");
                        prism15ANVLunit = $(".prism-heading-inner-ver-L-BD").attr("data-fixed");
                        break;
                    default:
                        // becky.assertion.failure("unknown SCA");
                        break;
                }
                break;
            case "15B":
                switch (farNear) {
                    case "FN":
                    case "F":
                        prism15BFHR = $("#labelMainPrismHorR").attr("data-text");
                        prism15BFHL = $("#labelMainPrismHorL").attr("data-text");
                        prism15BFVR = $("#labelMainPrismVerR").attr("data-text");
                        prism15BFVL = $("#labelMainPrismVerL").attr("data-text");

                        prism15BFHRunit = $(".prism-heading-inner-hor-R-BI").attr("data-fixed");
                        prism15BFHLunit = $(".prism-heading-inner-hor-L-BI").attr("data-fixed");
                        prism15BFVRunit = $(".prism-heading-inner-ver-R-BD").attr("data-fixed");
                        prism15BFVLunit = $(".prism-heading-inner-ver-L-BD").attr("data-fixed");
                        break;
                    case "N":
                        prism15BNHR = $("#labelMainPrismHorR").attr("data-text");
                        prism15BNHL = $("#labelMainPrismHorL").attr("data-text");
                        prism15BNVR = $("#labelMainPrismVerR").attr("data-text");
                        prism15BNVL = $("#labelMainPrismVerL").attr("data-text");

                        prism15BNHRunit = $(".prism-heading-inner-hor-R-BI").attr("data-fixed");
                        prism15BNHLunit = $(".prism-heading-inner-hor-L-BI").attr("data-fixed");
                        prism15BNVRunit = $(".prism-heading-inner-ver-R-BD").attr("data-fixed");
                        prism15BNVLunit = $(".prism-heading-inner-ver-L-BD").attr("data-fixed");
                        break;
                    default:
                        // becky.assertion.failure("unknown SCA");
                        break;
                }
                break;
            case "16":
                switch (farNear) {
                    case "FN":
                    case "F":
                        prism16FHR = $("#labelMainPrismHorR").attr("data-text");
                        prism16FHL = $("#labelMainPrismHorL").attr("data-text");
                        prism16FVR = $("#labelMainPrismVerR").attr("data-text");
                        prism16FVL = $("#labelMainPrismVerL").attr("data-text");

                        prism16FHRunit = $(".prism-heading-inner-hor-R-BI").attr("data-fixed");
                        prism16FHLunit = $(".prism-heading-inner-hor-L-BI").attr("data-fixed");
                        prism16FVRunit = $(".prism-heading-inner-ver-R-BD").attr("data-fixed");
                        prism16FVLunit = $(".prism-heading-inner-ver-L-BD").attr("data-fixed");
                        break;
                    case "N":
                        prism16NHR = $("#labelMainPrismHorR").attr("data-text");
                        prism16NHL = $("#labelMainPrismHorL").attr("data-text");
                        prism16NVR = $("#labelMainPrismVerR").attr("data-text");
                        prism16NVL = $("#labelMainPrismVerL").attr("data-text");

                        prism16NHRunit = $(".prism-heading-inner-hor-R-BI").attr("data-fixed");
                        prism16NHLunit = $(".prism-heading-inner-hor-L-BI").attr("data-fixed");
                        prism16NVRunit = $(".prism-heading-inner-ver-R-BD").attr("data-fixed");
                        prism16NVLunit = $(".prism-heading-inner-ver-L-BD").attr("data-fixed");
                        break;
                    default:
                        // becky.assertion.failure("unknown SCA");
                        break;
                }
                break;
            case "17":
                switch (farNear) {
                    case "FN":
                    case "F":
                        prism17FHR = $("#labelMainPrismHorR").attr("data-text");
                        prism17FHL = $("#labelMainPrismHorL").attr("data-text");
                        prism17FVR = $("#labelMainPrismVerR").attr("data-text");
                        prism17FVL = $("#labelMainPrismVerL").attr("data-text");

                        prism17FHRunit = $(".prism-heading-inner-hor-R-BI").attr("data-fixed");
                        prism17FHLunit = $(".prism-heading-inner-hor-L-BI").attr("data-fixed");
                        prism17FVRunit = $(".prism-heading-inner-ver-R-BD").attr("data-fixed");
                        prism17FVLunit = $(".prism-heading-inner-ver-L-BD").attr("data-fixed");
                        break;
                    case "N":
                        prism17NHR = $("#labelMainPrismHorR").attr("data-text");
                        prism17NHL = $("#labelMainPrismHorL").attr("data-text");
                        prism17NVR = $("#labelMainPrismVerR").attr("data-text");
                        prism17NVL = $("#labelMainPrismVerL").attr("data-text");

                        prism17NHRunit = $(".prism-heading-inner-hor-R-BI").attr("data-fixed");
                        prism17NHLunit = $(".prism-heading-inner-hor-L-BI").attr("data-fixed");
                        prism17NVRunit = $(".prism-heading-inner-ver-R-BD").attr("data-fixed");
                        prism17NVLunit = $(".prism-heading-inner-ver-L-BD").attr("data-fixed");
                        break;
                    default:
                        // becky.assertion.failure("unknown SCA");
                        break;
                }
                break;
                case "18A":
                switch (farNear) {
                    case "FN":
                    case "F":
                        prism18AFHR = $("#labelMainPrismHorR").attr("data-text");
                        prism18AFHL = $("#labelMainPrismHorL").attr("data-text");
                        prism18AFVR = $("#labelMainPrismVerR").attr("data-text");
                        prism18AFVL = $("#labelMainPrismVerL").attr("data-text");

                        prism18AFHRunit = $(".prism-heading-inner-hor-R-BI").attr("data-fixed");
                        prism18AFHLunit = $(".prism-heading-inner-hor-L-BI").attr("data-fixed");
                        prism18AFVRunit = $(".prism-heading-inner-ver-R-BD").attr("data-fixed");
                        prism18AFVLunit = $(".prism-heading-inner-ver-L-BD").attr("data-fixed");
                        break;
                    case "N":
                        prism18ANHR = $("#labelMainPrismHorR").attr("data-text");
                        prism18ANHL = $("#labelMainPrismHorL").attr("data-text");
                        prism18ANVR = $("#labelMainPrismVerR").attr("data-text");
                        prism18ANVL = $("#labelMainPrismVerL").attr("data-text");

                        prism18ANHRunit = $(".prism-heading-inner-hor-R-BI").attr("data-fixed");
                        prism18ANHLunit = $(".prism-heading-inner-hor-L-BI").attr("data-fixed");
                        prism18ANVRunit = $(".prism-heading-inner-ver-R-BD").attr("data-fixed");
                        prism18ANVLunit = $(".prism-heading-inner-ver-L-BD").attr("data-fixed");
                        break;
                    default:
                        // becky.assertion.failure("unknown SCA");
                        break;
                }
                break;
            default:
                //becky.assertion.failure("unknown eye");
                break;
        }

        const json = {
            "PrismtRuleH": PrismtRuleH,
            "PrismtRuleV": PrismtRuleV,
            "prism3FHR": prism3FHR,
            "prism3FHL": prism3FHL,
            "prism3FVR": prism3FVR,
            "prism3FVL": prism3FVL,
            "prism3FHRunit": prism3FHRunit,
            "prism3FHLunit": prism3FHLunit,
            "prism3FVRunit": prism3FVRunit,
            "prism3FVLunit": prism3FVLunit,
            "prism3NHR": prism3NHR,
            "prism3NHL": prism3NHL,
            "prism3NVR": prism3NVR,
            "prism3NVL": prism3NVL,
            "prism3NHRunit": prism3NHRunit,
            "prism3NHLunit": prism3NHLunit,
            "prism3NVRunit": prism3NVRunit,
            "prism3NVLunit": prism3NVLunit,
            "prism8FHR": prism8FHR,
            "prism8FHL": prism8FHL,
            "prism8FVR": prism8FVR,
            "prism8FVL": prism8FVL,
            "prism8FHRunit": prism8FHRunit,
            "prism8FHLunit": prism8FHLunit,
            "prism8FVRunit": prism8FVRunit,
            "prism8FVLunit": prism8FVLunit,
            "prism8NHR": prism8NHR,
            "prism8NHL": prism8NHL,
            "prism8NVR": prism8NVR,
            "prism8NVL": prism8NVL,
            "prism8NHRunit": prism8NHRunit,
            "prism8NHLunit": prism8NHLunit,
            "prism8NVRunit": prism8NVRunit,
            "prism8NVLunit": prism8NVLunit,
            "prism9FHR": prism9FHR,
            "prism9FHL": prism9FHL,
            "prism9FVR": prism9FVR,
            "prism9FVL": prism9FVL,
            "prism9FHRunit": prism9FHRunit,
            "prism9FHLunit": prism9FHLunit,
            "prism9FVRunit": prism9FVRunit,
            "prism9FVLunit": prism9FVLunit,
            "prism9NHR": prism9NHR,
            "prism9NHL": prism9NHL,
            "prism9NVR": prism9NVR,
            "prism9NVL": prism9NVL,
            "prism9NHRunit": prism9NHRunit,
            "prism9NHLunit": prism9NHLunit,
            "prism9NVRunit": prism9NVRunit,
            "prism9NVLunit": prism9NVLunit,
            "prism10FHR": prism10FHR,
            "prism10FHL": prism10FHL,
            "prism10FVR": prism10FVR,
            "prism10FVL": prism10FVL,
            "prism10FHRunit": prism10FHRunit,
            "prism10FHLunit": prism10FHLunit,
            "prism10FVRunit": prism10FVRunit,
            "prism10FVLunit": prism10FVLunit,
            "prism10NHR": prism10NHR,
            "prism10NHL": prism10NHL,
            "prism10NVR": prism10NVR,
            "prism10NVL": prism10NVL,
            "prism10NHRunit": prism10NHRunit,
            "prism10NHLunit": prism10NHLunit,
            "prism10NVRunit": prism10NVRunit,
            "prism10NVLunit": prism10NVLunit,
            "prism12AFHR": prism12AFHR,
            "prism12AFHL": prism12AFHL,
            "prism12AFVR": prism12AFVR,
            "prism12AFVL": prism12AFVL,
            "prism12AFHRunit": prism12AFHRunit,
            "prism12AFHLunit": prism12AFHLunit,
            "prism12AFVRunit": prism12AFVRunit,
            "prism12AFVLunit": prism12AFVLunit,
            "prism12ANHR": prism12ANHR,
            "prism12ANHL": prism12ANHL,
            "prism12ANVR": prism12ANVR,
            "prism12ANVL": prism12ANVL,
            "prism12ANHRunit": prism12ANHRunit,
            "prism12ANHLunit": prism12ANHLunit,
            "prism12ANVRunit": prism12ANVRunit,
            "prism12ANVLunit": prism12ANVLunit,
            "prism12BFHR": prism12BFHR,
            "prism12BFHL": prism12BFHL,
            "prism12BFVR": prism12BFVR,
            "prism12BFVL": prism12BFVL,
            "prism12BFHRunit": prism12BFHRunit,
            "prism12BFHLunit": prism12BFHLunit,
            "prism12BFVRunit": prism12BFVRunit,
            "prism12BFVLunit": prism12BFVLunit,
            "prism12BNHR": prism12BNHR,
            "prism12BNHL": prism12BNHL,
            "prism12BNVR": prism12BNVR,
            "prism12BNVL": prism12BNVL,
            "prism12BNHRunit": prism12BNHRunit,
            "prism12BNHLunit": prism12BNHLunit,
            "prism12BNVRunit": prism12BNVRunit,
            "prism12BNVLunit": prism12BNVLunit,
            "prism13AFHR": prism13AFHR,
            "prism13AFHL": prism13AFHL,
            "prism13AFVR": prism13AFVR,
            "prism13AFVL": prism13AFVL,
            "prism13AFHRunit": prism13AFHRunit,
            "prism13AFHLunit": prism13AFHLunit,
            "prism13AFVRunit": prism13AFVRunit,
            "prism13AFVLunit": prism13AFVLunit,
            "prism13ANHR": prism13ANHR,
            "prism13ANHL": prism13ANHL,
            "prism13ANVR": prism13ANVR,
            "prism13ANVL": prism13ANVL,
            "prism13ANHRunit": prism13ANHRunit,
            "prism13ANHLunit": prism13ANHLunit,
            "prism13ANVRunit": prism13ANVRunit,
            "prism13ANVLunit": prism13ANVLunit,
            "prism13BFHR": prism13BFHR,
            "prism13BFHL": prism13BFHL,
            "prism13BFVR": prism13BFVR,
            "prism13BFVL": prism13BFVL,
            "prism13BFHRunit": prism13BFHRunit,
            "prism13BFHLunit": prism13BFHLunit,
            "prism13BFVRunit": prism13BFVRunit,
            "prism13BFVLunit": prism13BFVLunit,
            "prism13BNHR": prism13BNHR,
            "prism13BNHL": prism13BNHL,
            "prism13BNVR": prism13BNVR,
            "prism13BNVL": prism13BNVL,
            "prism13BNHRunit": prism13BNHRunit,
            "prism13BNHLunit": prism13BNHLunit,
            "prism13BNVRunit": prism13BNVRunit,
            "prism13BNVLunit": prism13BNVLunit,
            "prism14AFHR": prism14AFHR,
            "prism14AFHL": prism14AFHL,
            "prism14AFVR": prism14AFVR,
            "prism14AFVL": prism14AFVL,
            "prism14AFHRunit": prism14AFHRunit,
            "prism14AFHLunit": prism14AFHLunit,
            "prism14AFVRunit": prism14AFVRunit,
            "prism14AFVLunit": prism14AFVLunit,
            "prism14ANHR": prism14ANHR,
            "prism14ANHL": prism14ANHL,
            "prism14ANVR": prism14ANVR,
            "prism14ANVL": prism14ANVL,
            "prism14ANHRunit": prism14ANHRunit,
            "prism14ANHLunit": prism14ANHLunit,
            "prism14ANVRunit": prism14ANVRunit,
            "prism14ANVLunit": prism14ANVLunit,
            "prism14BFHR": prism14BFHR,
            "prism14BFHL": prism14BFHL,
            "prism14BFVR": prism14BFVR,
            "prism14BFVL": prism14BFVL,
            "prism14BFHRunit": prism14BFHRunit,
            "prism14BFHLunit": prism14BFHLunit,
            "prism14BFVRunit": prism14BFVRunit,
            "prism14BFVLunit": prism14BFVLunit,

            "prism14BNHR": prism14BNHR,
            "prism14BNHL": prism14BNHL,
            "prism14BNVR": prism14BNVR,
            "prism14BNVL": prism14BNVL,
            "prism14BNHRunit": prism14BNHRunit,
            "prism14BNHLunit": prism14BNHLunit,
            "prism14BNVRunit": prism14BNVRunit,
            "prism14BNVLunit": prism14BNVLunit,
            "prism15AFHR": prism15AFHR,
            "prism15AFHL": prism15AFHL,
            "prism15AFVR": prism15AFVR,
            "prism15AFVL": prism15AFVL,
            "prism15AFHRunit": prism15AFHRunit,
            "prism15AFHLunit": prism15AFHLunit,
            "prism15AFVRunit": prism15AFVRunit,
            "prism15AFVLunit": prism15AFVLunit,
            "prism15ANHR": prism15ANHR,
            "prism15ANHL": prism15ANHL,
            "prism15ANVR": prism15ANVR,
            "prism15ANVL": prism15ANVL,
            "prism15ANHRunit": prism15ANHRunit,
            "prism15ANHLunit": prism15ANHLunit,
            "prism15ANVRunit": prism15ANVRunit,
            "prism15ANVLunit": prism15ANVLunit,
            "prism15BFHR": prism15BFHR,
            "prism15BFHL": prism15BFHL,
            "prism15BFVR": prism15BFVR,
            "prism15BFVL": prism15BFVL,
            "prism15BFHRunit": prism15BFHRunit,
            "prism15BFHLunit": prism15BFHLunit,
            "prism15BFVRunit": prism15BFVRunit,
            "prism15BFVLunit": prism15BFVLunit,
            "prism15BNHR": prism15BNHR,
            "prism15BNHL": prism15BNHL,
            "prism15BNVR": prism15BNVR,
            "prism15BNVL": prism15BNVL,
            "prism15BNHRunit": prism15BNHRunit,
            "prism15BNHLunit": prism15BNHLunit,
            "prism15BNVRunit": prism15BNVRunit,
            "prism15BNVLunit": prism15BNVLunit,
            "prism16FHR": prism16FHR,
            "prism16FHL": prism16FHL,
            "prism16FVR": prism16FVR,
            "prism16FVL": prism16FVL,
            "prism16FHRunit": prism16FHRunit,
            "prism16FHLunit": prism16FHLunit,
            "prism16FVRunit": prism16FVRunit,
            "prism16FVLunit": prism16FVLunit,
            "prism16NHR": prism16NHR,
            "prism16NHL": prism16NHL,
            "prism16NVR": prism16NVR,
            "prism16NVL": prism16NVL,
            "prism16NHRunit": prism16NHRunit,
            "prism16NHLunit": prism16NHLunit,
            "prism16NVRunit": prism16NVRunit,
            "prism16NVLunit": prism16NVLunit,
            "prism17FHR": prism17FHR,
            "prism17FHL": prism17FHL,
            "prism17FVR": prism17FVR,
            "prism17FVL": prism17FVL,
            "prism17FHRunit": prism17FHRunit,
            "prism17FHLunit": prism17FHLunit,
            "prism17FVRunit": prism17FVRunit,
            "prism17FVLunit": prism17FVLunit,
            "prism17NHR": prism17NHR,
            "prism17NHL": prism17NHL,
            "prism17NVR": prism17NVR,
            "prism17NVL": prism17NVL,
            "prism17NHRunit": prism17NHRunit,
            "prism17NHLunit": prism17NHLunit,
            "prism17NVRunit": prism17NVRunit,
            "prism17NVLunit": prism17NVLunit,
            "prism18AFHR": prism18AFHR,
            "prism18AFHL": prism18AFHL,
            "prism18AFVR": prism18AFVR,
            "prism18AFVL": prism18AFVL,
            "prism18AFHRunit": prism18AFHRunit,
            "prism18AFHLunit": prism18AFHLunit,
            "prism18AFVRunit": prism18AFVRunit,
            "prism18AFVLunit": prism18AFVLunit,
            "prism18ANHR": prism18ANHR,
            "prism18ANHL": prism18ANHL,
            "prism18ANVR": prism18ANVR,
            "prism18ANVL": prism18ANVL,
            "prism18ANHRunit": prism18ANHRunit,
            "prism18ANHLunit": prism18ANHLunit,
            "prism18ANVRunit": prism18ANVRunit,
            "prism18ANVLunit": prism18ANVLunit,
        }

        //console.log(json);
        becky.jsonHelper.normalization(json);
        return json;
    }


    function _getBinoHVTestValue(chartParameterItem) {
        var valBinoType = chartParameterItem.examBinoResultID;
        var farNear = chartParameterItem.IsNearFar;
        const updateDataJson = becky.WebStorage.local.getJson("subjective.update.data");
        if (!modelHelper.isNull(updateDataJson)) {
            const binoTestvalue = updateDataJson.binostate;
            //console.log(farNear);
            //console.log(valPrismType);
            switch (valBinoType.toUpperCase()) {
                case "1":
                    switch (farNear.toUpperCase()) {
                        case "FN":
                        case "F":
                            $("#labelMainPrismHorR").attr("data-text", binoTestvalue.bino1FHR);
                            $("#labelMainPrismHorL").attr("data-text", binoTestvalue.bino1FHL);
                            $("#labelMainPrismVerR").attr("data-text", binoTestvalue.bino1FVR);
                            $("#labelMainPrismVerL").attr("data-text", binoTestvalue.bino1FVL);
                            $(".prism-heading-inner-hor-R-BI").attr("data-fixed", binoTestvalue.bino1FHRunit);
                            if (binoTestvalue.bino1FHRunit == '1') {

                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BI");
                            } else if (binoTestvalue.bino1FHRunit == '0' && binoTestvalue.bino1FHR >= "0.01") {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", " ");
                            }

                            $(".prism-heading-inner-hor-L-BI").attr("data-fixed", binoTestvalue.bino1FHLunit);
                            if (binoTestvalue.bino1FHLunit == '1') {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BI");
                            } else if (binoTestvalue.bino1FHLunit == '0' && binoTestvalue.bino1FHL >= "0.01") {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", " ");
                            }

                            $(".prism-heading-inner-ver-R-BD").attr("data-fixed", binoTestvalue.bino1FVRunit);
                            if (binoTestvalue.bino1FVRunit == '1') {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BD");
                            } else if (binoTestvalue.bino1FVRunit == '0' && binoTestvalue.bino1FVR >= "0.01") {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", " ");
                            }
                            $(".prism-heading-inner-ver-L-BD").attr("data-fixed", binoTestvalue.bino1FVLunit);
                            if (binoTestvalue.bino1FVLunit == '1') {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BD");
                            } else if (binoTestvalue.bino1FVLunit == '0' && binoTestvalue.bino1FVL >= "0.01") {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", " ");
                            }
                            break;
                        case "N":
                            $("#labelMainPrismHorR").attr("data-text", binoTestvalue.bino1NHR);
                            $("#labelMainPrismHorL").attr("data-text", binoTestvalue.bino1NHL);
                            $("#labelMainPrismVerR").attr("data-text", binoTestvalue.bino1NVR);
                            $("#labelMainPrismVerL").attr("data-text", binoTestvalue.bino1NVL);

                            $(".prism-heading-inner-hor-R-BI").attr("data-fixed", binoTestvalue.bino1NHRunit);
                            if (binoTestvalue.bino1NHRunit == '1') {

                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BI");
                            } else if (binoTestvalue.bino1NHRunit == '0' && binoTestvalue.bino1NHR >= "0.01") {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", " ");
                            }

                            $(".prism-heading-inner-hor-L-BI").attr("data-fixed", binoTestvalue.bino1NHLunit);
                            if (binoTestvalue.bino1NHLunit == '1') {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BI");
                            } else if (binoTestvalue.bino1NHLunit == '0' && binoTestvalue.bino1NHL >= "0.01") {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", " ");
                            }
                            $(".prism-heading-inner-ver-R-BD").attr("data-fixed", binoTestvalue.bino1NVRunit);
                            if (binoTestvalue.bino1NVRunit == '1') {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BD");
                            } else if (binoTestvalue.bino1NVRunit == '0' && binoTestvalue.bino1NVR >= "0.01") {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", " ");
                            }
                            $(".prism-heading-inner-ver-L-BD").attr("data-fixed", binoTestvalue.bino1NVLunit);
                            if (binoTestvalue.bino1NVLunit == '1') {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BD");
                            } else if (binoTestvalue.bino1NVLunit == '0' && binoTestvalue.bino1NVL >= "0.01") {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", " ");
                            }
                            break;
                        default:
                            // becky.assertion.failure("unknown SCA");
                            break;
                    }
                    break;

                case "2":
                    switch (farNear.toUpperCase()) {
                        case "FN":
                        case "F":
                            $("#labelMainPrismHorR").attr("data-text", binoTestvalue.bino2FHR);
                            $("#labelMainPrismHorL").attr("data-text", binoTestvalue.bino2FHL);
                            $("#labelMainPrismVerR").attr("data-text", binoTestvalue.bino2FVR);
                            $("#labelMainPrismVerL").attr("data-text", binoTestvalue.bino2FVL);
                            $(".prism-heading-inner-hor-R-BI").attr("data-fixed", binoTestvalue.bino2FHRunit);
                            if (binoTestvalue.bino2FHRunit == '1') {

                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BI");
                            } else if (binoTestvalue.bino2FHRunit == '0' && binoTestvalue.bino2FHR >= "0.01") {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", " ");
                            }

                            $(".prism-heading-inner-hor-L-BI").attr("data-fixed", binoTestvalue.bino2FHLunit);
                            if (binoTestvalue.bino2FHLunit == '1') {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BI");
                            } else if (binoTestvalue.bino2FHLunit == '0' && binoTestvalue.bino2FHL >= "0.01") {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", " ");
                            }

                            $(".prism-heading-inner-ver-R-BD").attr("data-fixed", binoTestvalue.bino2FVRunit);
                            if (binoTestvalue.bino2FVRunit == '1') {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BD");
                            } else if (binoTestvalue.bino2FVRunit == '0' && binoTestvalue.bino2FVR >= "0.01") {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", " ");
                            }
                            $(".prism-heading-inner-ver-L-BD").attr("data-fixed", binoTestvalue.bino2FVLunit);
                            if (binoTestvalue.bino2FVLunit == '1') {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BD");
                            } else if (binoTestvalue.bino2FVLunit == '0' && binoTestvalue.bino2FVL >= "0.01") {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", " ");
                            }
                            break;
                        case "N":
                            $("#labelMainPrismHorR").attr("data-text", binoTestvalue.bino2NHR);
                            $("#labelMainPrismHorL").attr("data-text", binoTestvalue.bino2NHL);
                            $("#labelMainPrismVerR").attr("data-text", binoTestvalue.bino2NVR);
                            $("#labelMainPrismVerL").attr("data-text", binoTestvalue.bino2NVL);

                            $(".prism-heading-inner-hor-R-BI").attr("data-fixed", binoTestvalue.bino2NHRunit);
                            if (binoTestvalue.bino2NHRunit == '1') {

                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BI");
                            } else if (binoTestvalue.bino2NHRunit == '0' && binoTestvalue.bino2NHR >= "0.01") {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", " ");
                            }

                            $(".prism-heading-inner-hor-L-BI").attr("data-fixed", binoTestvalue.bino2NHLunit);
                            if (binoTestvalue.bino2NHLunit == '1') {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BI");
                            } else if (binoTestvalue.bino2NHLunit == '0' && binoTestvalue.bino2NHL >= "0.01") {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", " ");
                            }
                            $(".prism-heading-inner-ver-R-BD").attr("data-fixed", binoTestvalue.bino2NVRunit);
                            if (binoTestvalue.bino2NVRunit == '1') {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BD");
                            } else if (binoTestvalue.bino2NVRunit == '0' && binoTestvalue.bino2NVR >= "0.01") {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", " ");
                            }
                            $(".prism-heading-inner-ver-L-BD").attr("data-fixed", binoTestvalue.bino2NVLunit);
                            if (binoTestvalue.bino2NVLunit == '1') {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BD");
                            } else if (binoTestvalue.bino2NVLunit == '0' && binoTestvalue.bino2NVL >= "0.01") {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", " ");
                            }
                            break;
                        default:
                            // becky.assertion.failure("unknown SCA");
                            break;
                    }
                    break;
                case "3":
                    switch (farNear.toUpperCase()) {
                        case "FN":
                        case "F":
                            $("#labelMainPrismHorR").attr("data-text", binoTestvalue.bino3FHR);
                            $("#labelMainPrismHorL").attr("data-text", binoTestvalue.bino3FHL);
                            $("#labelMainPrismVerR").attr("data-text", binoTestvalue.bino3FVR);
                            $("#labelMainPrismVerL").attr("data-text", binoTestvalue.bino3FVL);
                            $(".prism-heading-inner-hor-R-BI").attr("data-fixed", binoTestvalue.bino3FHRunit);
                            if (binoTestvalue.bino3FHRunit == '1') {

                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BI");
                            } else if (binoTestvalue.bino3FHRunit == '0' && binoTestvalue.bino3FHR >= "0.01") {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", " ");
                            }

                            $(".prism-heading-inner-hor-L-BI").attr("data-fixed", binoTestvalue.bino3FHLunit);
                            if (binoTestvalue.bino3FHLunit == '1') {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BI");
                            } else if (binoTestvalue.bino3FHLunit == '0' && binoTestvalue.bino3FHL >= "0.01") {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", " ");
                            }

                            $(".prism-heading-inner-ver-R-BD").attr("data-fixed", binoTestvalue.bino3FVRunit);
                            if (binoTestvalue.bino3FVRunit == '1') {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BD");
                            } else if (binoTestvalue.bino3FVRunit == '0' && binoTestvalue.bino3FVR >= "0.01") {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", " ");
                            }
                            $(".prism-heading-inner-ver-L-BD").attr("data-fixed", binoTestvalue.bino3FVLunit);
                            if (binoTestvalue.bino3FVLunit == '1') {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BU");
                            } else if (binoTestvalue.bino3FVLunit == '0' && binoTestvalue.bino3FVL >= "0.01") {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BD");
                            } else {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", " ");
                            }
                            break;
                        case "N":
                            $("#labelMainPrismHorR").attr("data-text", binoTestvalue.bino3NHR);
                            $("#labelMainPrismHorL").attr("data-text", binoTestvalue.bino3NHL);
                            $("#labelMainPrismVerR").attr("data-text", binoTestvalue.bino3NVR);
                            $("#labelMainPrismVerL").attr("data-text", binoTestvalue.bino3NVL);

                            $(".prism-heading-inner-hor-R-BI").attr("data-fixed", binoTestvalue.bino3NHRunit);
                            if (binoTestvalue.bino3NHRunit == '1') {

                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BI");
                            } else if (binoTestvalue.bino3NHRunit == '0' && binoTestvalue.bino3NHR >= "0.01") {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", " ");
                            }

                            $(".prism-heading-inner-hor-L-BI").attr("data-fixed", binoTestvalue.bino3NHLunit);
                            if (binoTestvalue.bino3NHLunit == '1') {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BI");
                            } else if (binoTestvalue.bino3NHLunit == '0' && binoTestvalue.bino3NHL >= "0.01") {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", " ");
                            }
                            $(".prism-heading-inner-ver-R-BD").attr("data-fixed", binoTestvalue.bino3NVRunit);
                            if (binoTestvalue.bino3NVRunit == '1') {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BD");
                            } else if (binoTestvalue.bino3NVRunit == '0' && binoTestvalue.bino3NVR >= "0.01") {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", " ");
                            }
                            $(".prism-heading-inner-ver-L-BD").attr("data-fixed", binoTestvalue.bino3NVLunit);
                            if (binoTestvalue.bino3NVLunit == '1') {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BU");
                            } else if (binoTestvalue.bino3NVLunit == '0' && binoTestvalue.bino3NVL >= "0.01") {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BD");
                            } else {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", " ");
                            }
                            break;
                        default:
                            // becky.assertion.failure("unknown SCA");
                            break;
                    }
                    break;
                case "4":
                    switch (farNear.toUpperCase()) {
                        case "FN":
                        case "F":
                            $("#labelMainPrismHorR").attr("data-text", binoTestvalue.bino4FHR);
                            $("#labelMainPrismHorL").attr("data-text", binoTestvalue.bino4FHL);
                            $("#labelMainPrismVerR").attr("data-text", binoTestvalue.bino4FVR);
                            $("#labelMainPrismVerL").attr("data-text", binoTestvalue.bino4FVL);
                            $(".prism-heading-inner-hor-R-BI").attr("data-fixed", binoTestvalue.bino4FHRunit);
                            if (binoTestvalue.bino4FHRunit == '1') {

                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BI");
                            } else if (binoTestvalue.bino4FHRunit == '0' && binoTestvalue.bino4FHR >= "0.01") {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", " ");
                            }

                            $(".prism-heading-inner-hor-L-BI").attr("data-fixed", binoTestvalue.bino4FHLunit);
                            if (binoTestvalue.bino4FHLunit == '1') {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BI");
                            } else if (binoTestvalue.bino4FHLunit == '0' && binoTestvalue.bino4FHL >= "0.01") {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", " ");
                            }

                            $(".prism-heading-inner-ver-R-BD").attr("data-fixed", binoTestvalue.bino4FVRunit);
                            if (binoTestvalue.bino4FVRunit == '1') {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BD");
                            } else if (binoTestvalue.bino4FVRunit == '0' && binoTestvalue.bino4FVR >= "0.01") {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", " ");
                            }
                            $(".prism-heading-inner-ver-L-BD").attr("data-fixed", binoTestvalue.bino4FVLunit);
                            if (binoTestvalue.bino4FVLunit == '1') {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BD");
                            } else if (binoTestvalue.bino4FVLunit == '0' && binoTestvalue.bino4FVL >= "0.01") {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", " ");
                            }
                            break;
                        case "N":
                            $("#labelMainPrismHorR").attr("data-text", binoTestvalue.bino4NHR);
                            $("#labelMainPrismHorL").attr("data-text", binoTestvalue.bino4NHL);
                            $("#labelMainPrismVerR").attr("data-text", binoTestvalue.bino4NVR);
                            $("#labelMainPrismVerL").attr("data-text", binoTestvalue.bino4NVL);

                            $(".prism-heading-inner-hor-R-BI").attr("data-fixed", binoTestvalue.bino4NHRunit);
                            if (binoTestvalue.bino4NHRunit == '1') {

                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BI");
                            } else if (binoTestvalue.bino4NHRunit == '0' && binoTestvalue.bino4NHR >= "0.01") {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", " ");
                            }

                            $(".prism-heading-inner-hor-L-BI").attr("data-fixed", binoTestvalue.bino4NHLunit);
                            if (binoTestvalue.bino4NHLunit == '1') {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BI");
                            } else if (binoTestvalue.bino4NHLunit == '0' && binoTestvalue.bino4NHL >= "0.01") {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", " ");
                            }
                            $(".prism-heading-inner-ver-R-BD").attr("data-fixed", binoTestvalue.bino4NVRunit);
                            if (binoTestvalue.bino4NVRunit == '1') {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BD");
                            } else if (binoTestvalue.bino4NVRunit == '0' && binoTestvalue.bino4NVR >= "0.01") {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", " ");
                            }
                            $(".prism-heading-inner-ver-L-BD").attr("data-fixed", binoTestvalue.bino4NVLunit);
                            if (binoTestvalue.bino4NVLunit == '1') {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BD");
                            } else if (binoTestvalue.bino4NVLunit == '0' && binoTestvalue.bino4NVL >= "0.01") {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", " ");
                            }
                            break;
                        default:
                            // becky.assertion.failure("unknown SCA");
                            break;
                    }
                    break;
                case "5":
                    switch (farNear.toUpperCase()) {
                        case "FN":
                        case "F":
                            $("#labelMainPrismHorR").attr("data-text", binoTestvalue.bino5FHR);
                            $("#labelMainPrismHorL").attr("data-text", binoTestvalue.bino5FHL);
                            $("#labelMainPrismVerR").attr("data-text", binoTestvalue.bino5FVR);
                            $("#labelMainPrismVerL").attr("data-text", binoTestvalue.bino5FVL);
                            $(".prism-heading-inner-hor-R-BI").attr("data-fixed", binoTestvalue.bino5FHRunit);
                            if (binoTestvalue.bino5FHRunit == '1') {

                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BI");
                            } else if (binoTestvalue.bino5FHRunit == '0' && binoTestvalue.bino5FHR >= "0.01") {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", " ");
                            }

                            $(".prism-heading-inner-hor-L-BI").attr("data-fixed", binoTestvalue.bino5FHLunit);
                            if (binoTestvalue.bino5FHLunit == '1') {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BI");
                            } else if (binoTestvalue.bino5FHLunit == '0' && binoTestvalue.bino5FHL >= "0.01") {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", " ");
                            }

                            $(".prism-heading-inner-ver-R-BD").attr("data-fixed", binoTestvalue.bino5FVRunit);
                            if (binoTestvalue.bino5FVRunit == '1') {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BD");
                            } else if (binoTestvalue.bino5FVRunit == '0' && binoTestvalue.bino5FVR >= "0.01") {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", " ");
                            }
                            $(".prism-heading-inner-ver-L-BD").attr("data-fixed", binoTestvalue.bino5FVLunit);
                            if (binoTestvalue.bino5FVLunit == '1') {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BD");
                            } else if (binoTestvalue.bino5FVLunit == '0' && binoTestvalue.bino5FVL >= "0.01") {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", " ");
                            }

                             
                            if(binoTestvalue.bino5FHRR1 == 'R>L 7'){
                                $("#btnDLU").addClass("activeButton");
                            }
                            else if(binoTestvalue.bino5FHRR1 == 'R>L 3.5'){
                                $("#btnDLUHalf").addClass("activeButton");
                            }
                            else if(binoTestvalue.bino5FHRR1 == 'R=L'){
                                $("#btnUisD").addClass("activeButton");
                            }
                            else if(binoTestvalue.bino5FHRR1 == 'R<L 3.5'){
                                $("#btnULDHalf").addClass("activeButton");
                            }
                            else if(binoTestvalue.bino5FHRR1 == 'R<L 7'){
                                $("#btnULD").addClass("activeButton");
                            }

                            break;
                        case "N":
                            $("#labelMainPrismHorR").attr("data-text", binoTestvalue.bino5NHR);
                            $("#labelMainPrismHorL").attr("data-text", binoTestvalue.bino5NHL);
                            $("#labelMainPrismVerR").attr("data-text", binoTestvalue.bino5NVR);
                            $("#labelMainPrismVerL").attr("data-text", binoTestvalue.bino5NVL);

                            $(".prism-heading-inner-hor-R-BI").attr("data-fixed", binoTestvalue.bino5NHRunit);
                            if (binoTestvalue.bino5NHRunit == '1') {

                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BI");
                            } else if (binoTestvalue.bino5NHRunit == '0' && binoTestvalue.bino5NHR >= "0.01") {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", " ");
                            }

                            $(".prism-heading-inner-hor-L-BI").attr("data-fixed", binoTestvalue.bino5NHLunit);
                            if (binoTestvalue.bino5NHLunit == '1') {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BI");
                            } else if (binoTestvalue.bino5NHLunit == '0' && binoTestvalue.bino5NHL >= "0.01") {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", " ");
                            }
                            $(".prism-heading-inner-ver-R-BD").attr("data-fixed", binoTestvalue.bino5NVRunit);
                            if (binoTestvalue.bino5NVRunit == '1') {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BD");
                            } else if (binoTestvalue.bino5NVRunit == '0' && binoTestvalue.bino5NVR >= "0.01") {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", " ");
                            }
                            $(".prism-heading-inner-ver-L-BD").attr("data-fixed", binoTestvalue.bino5NVLunit);
                            if (binoTestvalue.bino5NVLunit == '1') {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BD");
                            } else if (binoTestvalue.bino5NVLunit == '0' && binoTestvalue.bino5NVL >= "0.01") {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", " ");
                            }

                            if(binoTestvalue.bino5NHRR1 == 'R>L 7'){
                                $("#btnDLU").addClass("activeButton");
                            }
                            else if(binoTestvalue.bino5NHRR1 == 'R>L 3.5'){
                                $("#btnDLUHalf").addClass("activeButton");
                            }
                            else if(binoTestvalue.bino5NHRR1 == 'R=L'){
                                $("#btnUisD").addClass("activeButton");
                            }
                            else if(binoTestvalue.bino5NHRR1 == 'R<L 3.5'){
                                $("#btnULDHalf").addClass("activeButton");
                            }
                            else if(binoTestvalue.bino5NHRR1 == 'R<L 7'){
                                $("#btnULD").addClass("activeButton");
                            }
                            
                            break;
                        default:
                            // becky.assertion.failure("unknown SCA");
                            break;
                    }
                    break;
                case "6":
                    switch (farNear.toUpperCase()) {
                        case "FN":
                        case "F":
                            $("#labelMainPrismHorR").attr("data-text", binoTestvalue.bino6FHR);
                            $("#labelMainPrismHorL").attr("data-text", binoTestvalue.bino6FHL);
                            $("#labelMainPrismVerR").attr("data-text", binoTestvalue.bino6FVR);
                            $("#labelMainPrismVerL").attr("data-text", binoTestvalue.bino6FVL);
                            $(".prism-heading-inner-hor-R-BI").attr("data-fixed", binoTestvalue.bino6FHRunit);
                            if (binoTestvalue.bino6FHRunit == '1') {

                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BI");
                            } else if (binoTestvalue.bino6FHRunit == '0' && binoTestvalue.bino6FHR >= "0.01") {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", " ");
                            }

                            $(".prism-heading-inner-hor-L-BI").attr("data-fixed", binoTestvalue.bino6FHLunit);
                            if (binoTestvalue.bino6FHLunit == '1') {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BI");
                            } else if (binoTestvalue.bino6FHLunit == '0' && binoTestvalue.bino6FHL >= "0.01") {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", " ");
                            }

                            $(".prism-heading-inner-ver-R-BD").attr("data-fixed", binoTestvalue.bino6FVRunit);
                            if (binoTestvalue.bino6FVRunit == '1') {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BD");
                            } else if (binoTestvalue.bino6FVRunit == '0' && binoTestvalue.bino6FVR >= "0.01") {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", " ");
                            }
                            $(".prism-heading-inner-ver-L-BD").attr("data-fixed", binoTestvalue.bino6FVLunit);
                            if (binoTestvalue.bino6FVLunit == '1') {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BD");
                            } else if (binoTestvalue.bino6FVLunit == '0' && binoTestvalue.bino6FVL >= "0.01") {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", " ");
                            }

                            if(binoTestvalue.bino6FHRR1 == 'R<L 7'){
                                $("#btnRLL").addClass("activeButton");
                            }
                            else if(binoTestvalue.bino6FHRR1 == 'R<L 3.5'){
                                $("#btnRLLhalf").addClass("activeButton");
                            }
                            else if(binoTestvalue.bino6FHRR1 == 'R=L'){
                                $("#btnLisR").addClass("activeButton");
                            }
                            else if(binoTestvalue.bino6FHRR1 == 'R>L 3.5'){
                                $("#btnLLRHalf").addClass("activeButton");
                            }
                            else if(binoTestvalue.bino6FHRR1 == 'R>L 7'){
                                $("#btnLLR").addClass("activeButton");
                            }
                            
                            break;
                        case "N":
                            $("#labelMainPrismHorR").attr("data-text", binoTestvalue.bino6NHR);
                            $("#labelMainPrismHorL").attr("data-text", binoTestvalue.bino6NHL);
                            $("#labelMainPrismVerR").attr("data-text", binoTestvalue.bino6NVR);
                            $("#labelMainPrismVerL").attr("data-text", binoTestvalue.bino6NVL);

                            $(".prism-heading-inner-hor-R-BI").attr("data-fixed", binoTestvalue.bino6NHRunit);
                            if (binoTestvalue.bino6NHRunit == '1') {

                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BI");
                            } else if (binoTestvalue.bino6NHRunit == '0' && binoTestvalue.bino6NHR >= "0.01") {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", " ");
                            }

                            $(".prism-heading-inner-hor-L-BI").attr("data-fixed", binoTestvalue.bino6NHLunit);
                            if (binoTestvalue.bino6NHLunit == '1') {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BI");
                            } else if (binoTestvalue.bino6NHLunit == '0' && binoTestvalue.bino6NHL >= "0.01") {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", " ");
                            }
                            $(".prism-heading-inner-ver-R-BD").attr("data-fixed", binoTestvalue.bino6NVRunit);
                            if (binoTestvalue.bino6NVRunit == '1') {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BD");
                            } else if (binoTestvalue.bino6NVRunit == '0' && binoTestvalue.bino6NVR >= "0.01") {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", " ");
                            }
                            $(".prism-heading-inner-ver-L-BD").attr("data-fixed", binoTestvalue.bino6NVLunit);
                            if (binoTestvalue.bino6NVLunit == '1') {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BD");
                            } else if (binoTestvalue.bino6NVLunit == '0' && binoTestvalue.bino6NVL >= "0.01") {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", " ");
                            }

                            if(binoTestvalue.bino6NHRR1 == 'R<L 7'){
                                $("#btnRLL").addClass("activeButton");
                            }
                            else if(binoTestvalue.bino6NHRR1 == 'R<L 3.5'){
                                $("#btnRLLhalf").addClass("activeButton");
                            }
                            else if(binoTestvalue.bino6NHRR1 == 'R=L'){
                                $("#btnLisR").addClass("activeButton");
                            }
                            else if(binoTestvalue.bino6NHRR1 == 'R>L 3.5'){
                                $("#btnLLRHalf").addClass("activeButton");
                            }
                            else if(binoTestvalue.bino6NHRR1 == 'R>L 7'){
                                $("#btnLLR").addClass("activeButton");
                            }
                            break;
                        default:
                            // becky.assertion.failure("unknown SCA");
                            break;
                    }
                    break;
                case "7":
                    switch (farNear.toUpperCase()) {
                        case "FN":
                        case "F":
                            $("#labelMainPrismHorR").attr("data-text", binoTestvalue.bino7FHR);
                            $("#labelMainPrismHorL").attr("data-text", binoTestvalue.bino7FHL);
                            $("#labelMainPrismVerR").attr("data-text", binoTestvalue.bino7FVR);
                            $("#labelMainPrismVerL").attr("data-text", binoTestvalue.bino7FVL);
                            $(".prism-heading-inner-hor-R-BI").attr("data-fixed", binoTestvalue.bino7FHRunit);
                            if (binoTestvalue.bino7FHRunit == '1') {

                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BI");
                            } else if (binoTestvalue.bino7FHRunit == '0' && binoTestvalue.bino7FHR >= "0.01") {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", " ");
                            }

                            $(".prism-heading-inner-hor-L-BI").attr("data-fixed", binoTestvalue.bino7FHLunit);
                            if (binoTestvalue.bino7FHLunit == '1') {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BI");
                            } else if (binoTestvalue.bino7FHLunit == '0' && binoTestvalue.bino7FHL >= "0.01") {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", " ");
                            }

                            $(".prism-heading-inner-ver-R-BD").attr("data-fixed", binoTestvalue.bino7FVRunit);
                            if (binoTestvalue.bino7FVRunit == '1') {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BD");
                            } else if (binoTestvalue.bino7FVRunit == '0' && binoTestvalue.bino7FVR >= "0.01") {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", " ");
                            }
                            $(".prism-heading-inner-ver-L-BD").attr("data-fixed", binoTestvalue.bino7FVLunit);
                            if (binoTestvalue.bino7FVLunit == '1') {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BD");
                            } else if (binoTestvalue.bino7FVLunit == '0' && binoTestvalue.bino7FVL >= "0.01") {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", " ");
                            }
                            break;
                        case "N":
                            $("#labelMainPrismHorR").attr("data-text", binoTestvalue.bino7NHR);
                            $("#labelMainPrismHorL").attr("data-text", binoTestvalue.bino7NHL);
                            $("#labelMainPrismVerR").attr("data-text", binoTestvalue.bino7NVR);
                            $("#labelMainPrismVerL").attr("data-text", binoTestvalue.bino7NVL);

                            $(".prism-heading-inner-hor-R-BI").attr("data-fixed", binoTestvalue.bino7NHRunit);
                            if (binoTestvalue.bino7NHRunit == '1') {

                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BI");
                            } else if (binoTestvalue.bino7NHRunit == '0' && binoTestvalue.bino7NHR >= "0.01") {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", " ");
                            }

                            $(".prism-heading-inner-hor-L-BI").attr("data-fixed", binoTestvalue.bino7NHLunit);
                            if (binoTestvalue.bino7NHLunit == '1') {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BI");
                            } else if (binoTestvalue.bino7NHLunit == '0' && binoTestvalue.bino7NHL >= "0.01") {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", " ");
                            }
                            $(".prism-heading-inner-ver-R-BD").attr("data-fixed", binoTestvalue.bino7NVRunit);
                            if (binoTestvalue.bino7NVRunit == '1') {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BD");
                            } else if (binoTestvalue.bino7NVRunit == '0' && binoTestvalue.bino7NVR >= "0.01") {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", " ");
                            }
                            $(".prism-heading-inner-ver-L-BD").attr("data-fixed", binoTestvalue.bino7NVLunit);
                            if (binoTestvalue.bino7NVLunit == '1') {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BD");
                            } else if (binoTestvalue.bino7NVLunit == '0' && binoTestvalue.bino7NVL >= "0.01") {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", " ");
                            }
                            break;
                        default:
                            // becky.assertion.failure("unknown SCA");
                            break;
                    }
                    break;
                case "8":
                    switch (farNear.toUpperCase()) {
                        case "FN":
                        case "F":
                            $("#labelMainPrismHorR").attr("data-text", binoTestvalue.bino8FHR);
                            $("#labelMainPrismHorL").attr("data-text", binoTestvalue.bino8FHL);
                            $("#labelMainPrismVerR").attr("data-text", binoTestvalue.bino8FVR);
                            $("#labelMainPrismVerL").attr("data-text", binoTestvalue.bino8FVL);
                            $(".prism-heading-inner-hor-R-BI").attr("data-fixed", binoTestvalue.bino8FHRunit);
                            if (binoTestvalue.bino8FHRunit == '1') {

                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BI");
                            } else if (binoTestvalue.bino8FHRunit == '0' && binoTestvalue.bino8FHR >= "0.01") {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", " ");
                            }

                            $(".prism-heading-inner-hor-L-BI").attr("data-fixed", binoTestvalue.bino8FHLunit);
                            if (binoTestvalue.bino8FHLunit == '1') {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BI");
                            } else if (binoTestvalue.bino8FHLunit == '0' && binoTestvalue.bino8FHL >= "0.01") {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", " ");
                            }

                            $(".prism-heading-inner-ver-R-BD").attr("data-fixed", binoTestvalue.bino8FVRunit);
                            if (binoTestvalue.bino8FVRunit == '1') {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BD");
                            } else if (binoTestvalue.bino8FVRunit == '0' && binoTestvalue.bino8FVR >= "0.01") {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", " ");
                            }
                            $(".prism-heading-inner-ver-L-BD").attr("data-fixed", binoTestvalue.bino8FVLunit);
                            if (binoTestvalue.bino8FVLunit == '1') {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BD");
                            } else if (binoTestvalue.bino8FVLunit == '0' && binoTestvalue.bino8FVL >= "0.01") {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", " ");
                            }
                            break;
                        case "N":
                            $("#labelMainPrismHorR").attr("data-text", binoTestvalue.bino8NHR);
                            $("#labelMainPrismHorL").attr("data-text", binoTestvalue.bino8NHL);
                            $("#labelMainPrismVerR").attr("data-text", binoTestvalue.bino8NVR);
                            $("#labelMainPrismVerL").attr("data-text", binoTestvalue.bino8NVL);

                            $(".prism-heading-inner-hor-R-BI").attr("data-fixed", binoTestvalue.bino8NHRunit);
                            if (binoTestvalue.bino8NHRunit == '1') {

                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BI");
                            } else if (binoTestvalue.bino8NHRunit == '0' && binoTestvalue.bino8NHR >= "0.01") {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", " ");
                            }

                            $(".prism-heading-inner-hor-L-BI").attr("data-fixed", binoTestvalue.bino8NHLunit);
                            if (binoTestvalue.bino8NHLunit == '1') {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BI");
                            } else if (binoTestvalue.bino8NHLunit == '0' && binoTestvalue.bino8NHL >= "0.01") {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", " ");
                            }
                            $(".prism-heading-inner-ver-R-BD").attr("data-fixed", binoTestvalue.bino8NVRunit);
                            if (binoTestvalue.bino8NVRunit == '1') {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BD");
                            } else if (binoTestvalue.bino8NVRunit == '0' && binoTestvalue.bino8NVR >= "0.01") {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", " ");
                            }
                            $(".prism-heading-inner-ver-L-BD").attr("data-fixed", binoTestvalue.bino8NVLunit);
                            if (binoTestvalue.bino8NVLunit == '1') {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BD");
                            } else if (binoTestvalue.bino8NVLunit == '0' && binoTestvalue.bino8NVL >= "0.01") {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", " ");
                            }
                            break;
                        default:
                            // becky.assertion.failure("unknown SCA");
                            break;
                    }
                    break;
                case "9":
                    switch (farNear.toUpperCase()) {
                        case "FN":
                        case "F":
                            $("#labelMainPrismHorR").attr("data-text", binoTestvalue.bino9FHR);
                            $("#labelMainPrismHorL").attr("data-text", binoTestvalue.bino9FHL);
                            $("#labelMainPrismVerR").attr("data-text", binoTestvalue.bino9FVR);
                            $("#labelMainPrismVerL").attr("data-text", binoTestvalue.bino9FVL);
                            $(".prism-heading-inner-hor-R-BI").attr("data-fixed", binoTestvalue.bino9FHRunit);
                            if (binoTestvalue.bino9FHRunit == '1') {

                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BI");
                            } else if (binoTestvalue.bino9FHRunit == '0' && binoTestvalue.bino9FHR >= "0.01") {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", " ");
                            }

                            $(".prism-heading-inner-hor-L-BI").attr("data-fixed", binoTestvalue.bino9FHLunit);
                            if (binoTestvalue.bino9FHLunit == '1') {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BI");
                            } else if (binoTestvalue.bino9FHLunit == '0' && binoTestvalue.bino9FHL >= "0.01") {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", " ");
                            }

                            $(".prism-heading-inner-ver-R-BD").attr("data-fixed", binoTestvalue.bino9FVRunit);
                            if (binoTestvalue.bino9FVRunit == '1') {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BD");
                            } else if (binoTestvalue.bino9FVRunit == '0' && binoTestvalue.bino9FVR >= "0.01") {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", " ");
                            }
                            $(".prism-heading-inner-ver-L-BD").attr("data-fixed", binoTestvalue.bino9FVLunit);
                            if (binoTestvalue.bino9FVLunit == '1') {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BD");
                            } else if (binoTestvalue.bino9FVLunit == '0' && binoTestvalue.bino9FVL >= "0.01") {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", " ");
                            }
                            break;
                        case "N":
                            $("#labelMainPrismHorR").attr("data-text", binoTestvalue.bino9NHR);
                            $("#labelMainPrismHorL").attr("data-text", binoTestvalue.bino9NHL);
                            $("#labelMainPrismVerR").attr("data-text", binoTestvalue.bino9NVR);
                            $("#labelMainPrismVerL").attr("data-text", binoTestvalue.bino9NVL);

                            $(".prism-heading-inner-hor-R-BI").attr("data-fixed", binoTestvalue.bino9NHRunit);
                            if (binoTestvalue.bino9NHRunit == '1') {

                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BI");
                            } else if (binoTestvalue.bino9NHRunit == '0' && binoTestvalue.bino9NHR >= "0.01") {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", " ");
                            }

                            $(".prism-heading-inner-hor-L-BI").attr("data-fixed", binoTestvalue.bino9NHLunit);
                            if (binoTestvalue.bino9NHLunit == '1') {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BI");
                            } else if (binoTestvalue.bino9NHLunit == '0' && binoTestvalue.bino9NHL >= "0.01") {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", " ");
                            }
                            $(".prism-heading-inner-ver-R-BD").attr("data-fixed", binoTestvalue.bino9NVRunit);
                            if (binoTestvalue.bino9NVRunit == '1') {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BD");
                            } else if (binoTestvalue.bino9NVRunit == '0' && binoTestvalue.bino9NVR >= "0.01") {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", " ");
                            }
                            $(".prism-heading-inner-ver-L-BD").attr("data-fixed", binoTestvalue.bino9NVLunit);
                            if (binoTestvalue.bino9NVLunit == '1') {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BD");
                            } else if (binoTestvalue.bino9NVLunit == '0' && binoTestvalue.bino9NVL >= "0.01") {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", " ");
                            }
                            break;
                        default:
                            // becky.assertion.failure("unknown SCA");
                            break;
                    }
                    break;
                case "10":
                    switch (farNear.toUpperCase()) {
                        case "FN":
                        case "F":
                            $("#labelMainPrismHorR").attr("data-text", binoTestvalue.bino10FHR);
                            $("#labelMainPrismHorL").attr("data-text", binoTestvalue.bino10FHL);
                            $("#labelMainPrismVerR").attr("data-text", binoTestvalue.bino10FVR);
                            $("#labelMainPrismVerL").attr("data-text", binoTestvalue.bino10FVL);
                            $(".prism-heading-inner-hor-R-BI").attr("data-fixed", binoTestvalue.bino10FHRunit);
                            if (binoTestvalue.bino10FHRunit == '1') {

                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BI");
                            } else if (binoTestvalue.bino10FHRunit == '0' && binoTestvalue.bino10FHR >= "0.01") {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", " ");
                            }

                            $(".prism-heading-inner-hor-L-BI").attr("data-fixed", binoTestvalue.bino10FHLunit);
                            if (binoTestvalue.bino10FHLunit == '1') {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BI");
                            } else if (binoTestvalue.bino10FHLunit == '0' && binoTestvalue.bino10FHL >= "0.01") {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", " ");
                            }

                            $(".prism-heading-inner-ver-R-BD").attr("data-fixed", binoTestvalue.bino10FVRunit);
                            if (binoTestvalue.bino10FVRunit == '1') {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BD");
                            } else if (binoTestvalue.bino10FVRunit == '0' && binoTestvalue.bino10FVR >= "0.01") {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", " ");
                            }
                            $(".prism-heading-inner-ver-L-BD").attr("data-fixed", binoTestvalue.bino10FVLunit);
                            if (binoTestvalue.bino10FVLunit == '1') {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BD");
                            } else if (binoTestvalue.bino10FVLunit == '0' && binoTestvalue.bino10FVL >= "0.01") {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", " ");
                            }
                            break;
                        case "N":
                            $("#labelMainPrismHorR").attr("data-text", binoTestvalue.bino10NHR);
                            $("#labelMainPrismHorL").attr("data-text", binoTestvalue.bino10NHL);
                            $("#labelMainPrismVerR").attr("data-text", binoTestvalue.bino10NVR);
                            $("#labelMainPrismVerL").attr("data-text", binoTestvalue.bino10NVL);

                            $(".prism-heading-inner-hor-R-BI").attr("data-fixed", binoTestvalue.bino10NHRunit);
                            if (binoTestvalue.bino10NHRunit == '1') {

                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BI");
                            } else if (binoTestvalue.bino10NHRunit == '0' && binoTestvalue.bino10NHR >= "0.01") {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", " ");
                            }

                            $(".prism-heading-inner-hor-L-BI").attr("data-fixed", binoTestvalue.bino10NHLunit);
                            if (binoTestvalue.bino10NHLunit == '1') {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BI");
                            } else if (binoTestvalue.bino10NHLunit == '0' && binoTestvalue.bino10NHL >= "0.01") {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", " ");
                            }
                            $(".prism-heading-inner-ver-R-BD").attr("data-fixed", binoTestvalue.bino10NVRunit);
                            if (binoTestvalue.bino10NVRunit == '1') {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BD");
                            } else if (binoTestvalue.bino10NVRunit == '0' && binoTestvalue.bino10NVR >= "0.01") {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", " ");
                            }
                            $(".prism-heading-inner-ver-L-BD").attr("data-fixed", binoTestvalue.bino10NVLunit);
                            if (binoTestvalue.bino10NVLunit == '1') {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BD");
                            } else if (binoTestvalue.bino10NVLunit == '0' && binoTestvalue.bino10NVL >= "0.01") {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", " ");
                            }
                            break;
                        default:
                            // becky.assertion.failure("unknown SCA");
                            break;
                    }
                    break;
                case "11":
                    switch (farNear.toUpperCase()) {
                        case "FN":
                        case "F":
                            $("#labelMainPrismHorR").attr("data-text", binoTestvalue.bino11FHR);
                            $("#labelMainPrismHorL").attr("data-text", binoTestvalue.bino11FHL);
                            $("#labelMainPrismVerR").attr("data-text", binoTestvalue.bino11FVR);
                            $("#labelMainPrismVerL").attr("data-text", binoTestvalue.bino11FVL);
                            $(".prism-heading-inner-hor-R-BI").attr("data-fixed", binoTestvalue.bino11FHRunit);
                            if (binoTestvalue.bino11FHRunit == '1') {

                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BI");
                            } else if (binoTestvalue.bino11FHRunit == '0' && binoTestvalue.bino11FHR >= "0.01") {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", " ");
                            }

                            $(".prism-heading-inner-hor-L-BI").attr("data-fixed", binoTestvalue.bino11FHLunit);
                            if (binoTestvalue.bino11FHLunit == '1') {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BI");
                            } else if (binoTestvalue.bino11FHLunit == '0' && binoTestvalue.bino11FHL >= "0.01") {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", " ");
                            }

                            $(".prism-heading-inner-ver-R-BD").attr("data-fixed", binoTestvalue.bino11FVRunit);
                            if (binoTestvalue.bino11FVRunit == '1') {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BD");
                            } else if (binoTestvalue.bino11FVRunit == '0' && binoTestvalue.bino11FVR >= "0.01") {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", " ");
                            }
                            $(".prism-heading-inner-ver-L-BD").attr("data-fixed", binoTestvalue.bino11FVLunit);
                            if (binoTestvalue.bino11FVLunit == '1') {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BD");
                            } else if (binoTestvalue.bino11FVLunit == '0' && binoTestvalue.bino11FVL >= "0.01") {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", " ");
                            }
                            break;
                        case "N":
                            $("#labelMainPrismHorR").attr("data-text", binoTestvalue.bino11NHR);
                            $("#labelMainPrismHorL").attr("data-text", binoTestvalue.bino11NHL);
                            $("#labelMainPrismVerR").attr("data-text", binoTestvalue.bino11NVR);
                            $("#labelMainPrismVerL").attr("data-text", binoTestvalue.bino11NVL);

                            $(".prism-heading-inner-hor-R-BI").attr("data-fixed", binoTestvalue.bino11NHRunit);
                            if (binoTestvalue.bino11NHRunit == '1') {

                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BI");
                            } else if (binoTestvalue.bino11NHRunit == '0' && binoTestvalue.bino11NHR >= "0.01") {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", " ");
                            }

                            $(".prism-heading-inner-hor-L-BI").attr("data-fixed", binoTestvalue.bino11NHLunit);
                            if (binoTestvalue.bino11NHLunit == '1') {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BI");
                            } else if (binoTestvalue.bino11NHLunit == '0' && binoTestvalue.bino11NHL >= "0.01") {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", " ");
                            }
                            $(".prism-heading-inner-ver-R-BD").attr("data-fixed", binoTestvalue.bino11NVRunit);
                            if (binoTestvalue.bino11NVRunit == '1') {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BD");
                            } else if (binoTestvalue.bino11NVRunit == '0' && binoTestvalue.bino11NVR >= "0.01") {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", " ");
                            }
                            $(".prism-heading-inner-ver-L-BD").attr("data-fixed", binoTestvalue.bino11NVLunit);
                            if (binoTestvalue.bino11NVLunit == '1') {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BD");
                            } else if (binoTestvalue.bino11NVLunit == '0' && binoTestvalue.bino11NVL >= "0.01") {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", " ");
                            }
                            break;
                        default:
                            // becky.assertion.failure("unknown SCA");
                            break;
                    }
                    break;
                case "12":
                    switch (farNear.toUpperCase()) {
                        case "FN":
                        case "F":
                            $("#labelMainPrismHorR").attr("data-text", binoTestvalue.bino12FHR);
                            $("#labelMainPrismHorL").attr("data-text", binoTestvalue.bino12FHL);
                            $("#labelMainPrismVerR").attr("data-text", binoTestvalue.bino12FVR);
                            $("#labelMainPrismVerL").attr("data-text", binoTestvalue.bino12FVL);
                            $(".prism-heading-inner-hor-R-BI").attr("data-fixed", binoTestvalue.bino12FHRunit);
                            if (binoTestvalue.bino12FHRunit == '1') {

                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BI");
                            } else if (binoTestvalue.bino12FHRunit == '0' && binoTestvalue.bino12FHR >= "0.01") {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", " ");
                            }

                            $(".prism-heading-inner-hor-L-BI").attr("data-fixed", binoTestvalue.bino12FHLunit);
                            if (binoTestvalue.bino12FHLunit == '1') {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BI");
                            } else if (binoTestvalue.bino12FHLunit == '0' && binoTestvalue.bino12FHL >= "0.01") {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", " ");
                            }

                            $(".prism-heading-inner-ver-R-BD").attr("data-fixed", binoTestvalue.bino12FVRunit);
                            if (binoTestvalue.bino12FVRunit == '1') {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BD");
                            } else if (binoTestvalue.bino12FVRunit == '0' && binoTestvalue.bino12FVR >= "0.01") {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", " ");
                            }
                            $(".prism-heading-inner-ver-L-BD").attr("data-fixed", binoTestvalue.bino12FVLunit);
                            if (binoTestvalue.bino12FVLunit == '1') {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BD");
                            } else if (binoTestvalue.bino12FVLunit == '0' && binoTestvalue.bino12FVL >= "0.01") {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", " ");
                            }
                            break;
                        case "N":
                            $("#labelMainPrismHorR").attr("data-text", binoTestvalue.bino12NHR);
                            $("#labelMainPrismHorL").attr("data-text", binoTestvalue.bino12NHL);
                            $("#labelMainPrismVerR").attr("data-text", binoTestvalue.bino12NVR);
                            $("#labelMainPrismVerL").attr("data-text", binoTestvalue.bino12NVL);

                            $(".prism-heading-inner-hor-R-BI").attr("data-fixed", binoTestvalue.bino12NHRunit);
                            if (binoTestvalue.bino12NHRunit == '1') {

                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BI");
                            } else if (binoTestvalue.bino12NHRunit == '0' && binoTestvalue.bino12NHR >= "0.01") {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", " ");
                            }

                            $(".prism-heading-inner-hor-L-BI").attr("data-fixed", binoTestvalue.bino12NHLunit);
                            if (binoTestvalue.bino12NHLunit == '1') {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BI");
                            } else if (binoTestvalue.bino12NHLunit == '0' && binoTestvalue.bino12NHL >= "0.01") {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", " ");
                            }
                            $(".prism-heading-inner-ver-R-BD").attr("data-fixed", binoTestvalue.bino12NVRunit);
                            if (binoTestvalue.bino12NVRunit == '1') {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BD");
                            } else if (binoTestvalue.bino12NVRunit == '0' && binoTestvalue.bino12NVR >= "0.01") {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", " ");
                            }
                            $(".prism-heading-inner-ver-L-BD").attr("data-fixed", binoTestvalue.bino12NVLunit);
                            if (binoTestvalue.bino12NVLunit == '1') {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BD");
                            } else if (binoTestvalue.bino12NVLunit == '0' && binoTestvalue.bino12NVL >= "0.01") {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", " ");
                            }
                            break;
                        default:
                            // becky.assertion.failure("unknown SCA");
                            break;
                    }
                    break;
                case "13":
                    switch (farNear.toUpperCase()) {
                        case "FN":
                        case "F":
                            $("#labelMainPrismHorR").attr("data-text", binoTestvalue.bino13FHR);
                            $("#labelMainPrismHorL").attr("data-text", binoTestvalue.bino13FHL);
                            $("#labelMainPrismVerR").attr("data-text", binoTestvalue.bino13FVR);
                            $("#labelMainPrismVerL").attr("data-text", binoTestvalue.bino13FVL);
                            $(".prism-heading-inner-hor-R-BI").attr("data-fixed", binoTestvalue.bino13FHRunit);
                            if (binoTestvalue.bino13FHRunit == '1') {

                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BI");
                            } else if (binoTestvalue.bino13FHRunit == '0' && binoTestvalue.bino13FHR >= "0.01") {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", " ");
                            }

                            $(".prism-heading-inner-hor-L-BI").attr("data-fixed", binoTestvalue.bino13FHLunit);
                            if (binoTestvalue.bino13FHLunit == '1') {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BI");
                            } else if (binoTestvalue.bino13FHLunit == '0' && binoTestvalue.bino13FHL >= "0.01") {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", " ");
                            }

                            $(".prism-heading-inner-ver-R-BD").attr("data-fixed", binoTestvalue.bino13FVRunit);
                            if (binoTestvalue.bino13FVRunit == '1') {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BD");
                            } else if (binoTestvalue.bino13FVRunit == '0' && binoTestvalue.bino13FVR >= "0.01") {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", " ");
                            }
                            $(".prism-heading-inner-ver-L-BD").attr("data-fixed", binoTestvalue.bino13FVLunit);
                            if (binoTestvalue.bino13FVLunit == '1') {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BD");
                            } else if (binoTestvalue.bino13FVLunit == '0' && binoTestvalue.bino13FVL >= "0.01") {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", " ");
                            }
                            break;
                        case "N":
                            $("#labelMainPrismHorR").attr("data-text", binoTestvalue.bino13NHR);
                            $("#labelMainPrismHorL").attr("data-text", binoTestvalue.bino13NHL);
                            $("#labelMainPrismVerR").attr("data-text", binoTestvalue.bino13NVR);
                            $("#labelMainPrismVerL").attr("data-text", binoTestvalue.bino13NVL);

                            $(".prism-heading-inner-hor-R-BI").attr("data-fixed", binoTestvalue.bino13NHRunit);
                            if (binoTestvalue.bino13NHRunit == '1') {

                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BI");
                            } else if (binoTestvalue.bino13NHRunit == '0' && binoTestvalue.bino13NHR >= "0.01") {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", " ");
                            }

                            $(".prism-heading-inner-hor-L-BI").attr("data-fixed", binoTestvalue.bino13NHLunit);
                            if (binoTestvalue.bino13NHLunit == '1') {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BI");
                            } else if (binoTestvalue.bino13NHLunit == '0' && binoTestvalue.bino13NHL >= "0.01") {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", " ");
                            }
                            $(".prism-heading-inner-ver-R-BD").attr("data-fixed", binoTestvalue.bino13NVRunit);
                            if (binoTestvalue.bino13NVRunit == '1') {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BD");
                            } else if (binoTestvalue.bino13NVRunit == '0' && binoTestvalue.bino13NVR >= "0.01") {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", " ");
                            }
                            $(".prism-heading-inner-ver-L-BD").attr("data-fixed", binoTestvalue.bino13NVLunit);
                            if (binoTestvalue.bino13NVLunit == '1') {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BD");
                            } else if (binoTestvalue.bino13NVLunit == '0' && binoTestvalue.bino13NVL >= "0.01") {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", " ");
                            }
                            break;
                        default:
                            // becky.assertion.failure("unknown SCA");
                            break;
                    }
                    break;
                case "14":
                    switch (farNear.toUpperCase()) {
                        case "FN":
                        case "F":
                            $("#labelMainPrismHorR").attr("data-text", binoTestvalue.bino14FHR);
                            $("#labelMainPrismHorL").attr("data-text", binoTestvalue.bino14FHL);
                            $("#labelMainPrismVerR").attr("data-text", binoTestvalue.bino14FVR);
                            $("#labelMainPrismVerL").attr("data-text", binoTestvalue.bino14FVL);
                            $(".prism-heading-inner-hor-R-BI").attr("data-fixed", binoTestvalue.bino14FHRunit);
                            if (binoTestvalue.bino14FHRunit == '1') {

                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BI");
                            } else if (binoTestvalue.bino14FHRunit == '0' && binoTestvalue.bino14FHR >= "0.01") {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", " ");
                            }

                            $(".prism-heading-inner-hor-L-BI").attr("data-fixed", binoTestvalue.bino14FHLunit);
                            if (binoTestvalue.bino14FHLunit == '1') {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BI");
                            } else if (binoTestvalue.bino14FHLunit == '0' && binoTestvalue.bino14FHL >= "0.01") {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", " ");
                            }

                            $(".prism-heading-inner-ver-R-BD").attr("data-fixed", binoTestvalue.bino14FVRunit);
                            if (binoTestvalue.bino14FVRunit == '1') {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BD");
                            } else if (binoTestvalue.bino14FVRunit == '0' && binoTestvalue.bino14FVR >= "0.01") {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", " ");
                            }
                            $(".prism-heading-inner-ver-L-BD").attr("data-fixed", binoTestvalue.bino14FVLunit);
                            if (binoTestvalue.bino14FVLunit == '1') {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BD");
                            } else if (binoTestvalue.bino14FVLunit == '0' && binoTestvalue.bino14FVL >= "0.01") {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", " ");
                            }
                            break;
                        case "N":
                            $("#labelMainPrismHorR").attr("data-text", binoTestvalue.bino14NHR);
                            $("#labelMainPrismHorL").attr("data-text", binoTestvalue.bino14NHL);
                            $("#labelMainPrismVerR").attr("data-text", binoTestvalue.bino14NVR);
                            $("#labelMainPrismVerL").attr("data-text", binoTestvalue.bino14NVL);

                            $(".prism-heading-inner-hor-R-BI").attr("data-fixed", binoTestvalue.bino14NHRunit);
                            if (binoTestvalue.bino14NHRunit == '1') {

                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BI");
                            } else if (binoTestvalue.bino14NHRunit == '0' && binoTestvalue.bino14NHR >= "0.01") {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", " ");
                            }

                            $(".prism-heading-inner-hor-L-BI").attr("data-fixed", binoTestvalue.bino14NHLunit);
                            if (binoTestvalue.bino14NHLunit == '1') {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BI");
                            } else if (binoTestvalue.bino14NHLunit == '0' && binoTestvalue.bino14NHL >= "0.01") {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", " ");
                            }
                            $(".prism-heading-inner-ver-R-BD").attr("data-fixed", binoTestvalue.bino14NVRunit);
                            if (binoTestvalue.bino14NVRunit == '1') {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BD");
                            } else if (binoTestvalue.bino14NVRunit == '0' && binoTestvalue.bino14NVR >= "0.01") {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", " ");
                            }
                            $(".prism-heading-inner-ver-L-BD").attr("data-fixed", binoTestvalue.bino14NVLunit);
                            if (binoTestvalue.bino14NVLunit == '1') {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BD");
                            } else if (binoTestvalue.bino14NVLunit == '0' && binoTestvalue.bino14NVL >= "0.01") {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", " ");
                            }
                            break;
                        default:
                            // becky.assertion.failure("unknown SCA");
                            break;
                    }
                    break;
                case "15":
                    switch (farNear.toUpperCase()) {
                        case "FN":
                        case "F":
                            $("#labelMainPrismHorR").attr("data-text", binoTestvalue.bino15FHR);
                            $("#labelMainPrismHorL").attr("data-text", binoTestvalue.bino15FHL);
                            $("#labelMainPrismVerR").attr("data-text", binoTestvalue.bino15FVR);
                            $("#labelMainPrismVerL").attr("data-text", binoTestvalue.bino15FVL);
                            $(".prism-heading-inner-hor-R-BI").attr("data-fixed", binoTestvalue.bino15FHRunit);
                            if (binoTestvalue.bino15FHRunit == '1') {

                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BI");
                            } else if (binoTestvalue.bino15FHRunit == '0' && binoTestvalue.bino15FHR >= "0.01") {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", " ");
                            }

                            $(".prism-heading-inner-hor-L-BI").attr("data-fixed", binoTestvalue.bino15FHLunit);
                            if (binoTestvalue.bino15FHLunit == '1') {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BI");
                            } else if (binoTestvalue.bino15FHLunit == '0' && binoTestvalue.bino15FHL >= "0.01") {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", " ");
                            }

                            $(".prism-heading-inner-ver-R-BD").attr("data-fixed", binoTestvalue.bino15FVRunit);
                            if (binoTestvalue.bino15FVRunit == '1') {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BD");
                            } else if (binoTestvalue.bino15FVRunit == '0' && binoTestvalue.bino15FVR >= "0.01") {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", " ");
                            }
                            $(".prism-heading-inner-ver-L-BD").attr("data-fixed", binoTestvalue.bino15FVLunit);
                            if (binoTestvalue.bino15FVLunit == '1') {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BD");
                            } else if (binoTestvalue.bino15FVLunit == '0' && binoTestvalue.bino15FVL >= "0.01") {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", " ");
                            }
                            break;
                        case "N":
                            $("#labelMainPrismHorR").attr("data-text", binoTestvalue.bino15NHR);
                            $("#labelMainPrismHorL").attr("data-text", binoTestvalue.bino15NHL);
                            $("#labelMainPrismVerR").attr("data-text", binoTestvalue.bino15NVR);
                            $("#labelMainPrismVerL").attr("data-text", binoTestvalue.bino15NVL);

                            $(".prism-heading-inner-hor-R-BI").attr("data-fixed", binoTestvalue.bino15NHRunit);
                            if (binoTestvalue.bino15NHRunit == '1') {

                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BI");
                            } else if (binoTestvalue.bino15NHRunit == '0' && binoTestvalue.bino15NHR >= "0.01") {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", " ");
                            }

                            $(".prism-heading-inner-hor-L-BI").attr("data-fixed", binoTestvalue.bino15NHLunit);
                            if (binoTestvalue.bino15NHLunit == '1') {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BI");
                            } else if (binoTestvalue.bino15NHLunit == '0' && binoTestvalue.bino15NHL >= "0.01") {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", " ");
                            }
                            $(".prism-heading-inner-ver-R-BD").attr("data-fixed", binoTestvalue.bino15NVRunit);
                            if (binoTestvalue.bino15NVRunit == '1') {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BD");
                            } else if (binoTestvalue.bino15NVRunit == '0' && binoTestvalue.bino15NVR >= "0.01") {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", " ");
                            }
                            $(".prism-heading-inner-ver-L-BD").attr("data-fixed", binoTestvalue.bino15NVLunit);
                            if (binoTestvalue.bino15NVLunit == '1') {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BD");
                            } else if (binoTestvalue.bino15NVLunit == '0' && binoTestvalue.bino15NVL >= "0.01") {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", " ");
                            }
                            break;
                        default:
                            // becky.assertion.failure("unknown SCA");
                            break;
                    }
                    break;
                case "16":
                    switch (farNear.toUpperCase()) {
                        case "FN":
                        case "F":
                            $("#labelMainPrismHorR").attr("data-text", binoTestvalue.bino16FHR);
                            $("#labelMainPrismHorL").attr("data-text", binoTestvalue.bino16FHL);
                            $("#labelMainPrismVerR").attr("data-text", binoTestvalue.bino16FVR);
                            $("#labelMainPrismVerL").attr("data-text", binoTestvalue.bino16FVL);
                            $(".prism-heading-inner-hor-R-BI").attr("data-fixed", binoTestvalue.bino16FHRunit);
                            if (binoTestvalue.bino16FHRunit == '1') {

                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BI");
                            } else if (binoTestvalue.bino16FHRunit == '0' && binoTestvalue.bino16FHR >= "0.01") {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", " ");
                            }

                            $(".prism-heading-inner-hor-L-BI").attr("data-fixed", binoTestvalue.bino16FHLunit);
                            if (binoTestvalue.bino16FHLunit == '1') {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BI");
                            } else if (binoTestvalue.bino16FHLunit == '0' && binoTestvalue.bino16FHL >= "0.01") {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", " ");
                            }

                            $(".prism-heading-inner-ver-R-BD").attr("data-fixed", binoTestvalue.bino16FVRunit);
                            if (binoTestvalue.bino16FVRunit == '1') {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BD");
                            } else if (binoTestvalue.bino16FVRunit == '0' && binoTestvalue.bino16FVR >= "0.01") {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", " ");
                            }
                            $(".prism-heading-inner-ver-L-BD").attr("data-fixed", binoTestvalue.bino16FVLunit);
                            if (binoTestvalue.bino16FVLunit == '1') {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BD");
                            } else if (binoTestvalue.bino16FVLunit == '0' && binoTestvalue.bino16FVL >= "0.01") {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", " ");
                            }
                            break;
                        case "N":
                            $("#labelMainPrismHorR").attr("data-text", binoTestvalue.bino16NHR);
                            $("#labelMainPrismHorL").attr("data-text", binoTestvalue.bino16NHL);
                            $("#labelMainPrismVerR").attr("data-text", binoTestvalue.bino16NVR);
                            $("#labelMainPrismVerL").attr("data-text", binoTestvalue.bino16NVL);

                            $(".prism-heading-inner-hor-R-BI").attr("data-fixed", binoTestvalue.bino16NHRunit);
                            if (binoTestvalue.bino16NHRunit == '1') {

                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BI");
                            } else if (binoTestvalue.bino16NHRunit == '0' && binoTestvalue.bino16NHR >= "0.01") {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", " ");
                            }

                            $(".prism-heading-inner-hor-L-BI").attr("data-fixed", binoTestvalue.bino16NHLunit);
                            if (binoTestvalue.bino16NHLunit == '1') {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BI");
                            } else if (binoTestvalue.bino16NHLunit == '0' && binoTestvalue.bino16NHL >= "0.01") {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", " ");
                            }
                            $(".prism-heading-inner-ver-R-BD").attr("data-fixed", binoTestvalue.bino16NVRunit);
                            if (binoTestvalue.bino16NVRunit == '1') {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BD");
                            } else if (binoTestvalue.bino16NVRunit == '0' && binoTestvalue.bino16NVR >= "0.01") {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", " ");
                            }
                            $(".prism-heading-inner-ver-L-BD").attr("data-fixed", binoTestvalue.bino16NVLunit);
                            if (binoTestvalue.bino16NVLunit == '1') {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BD");
                            } else if (binoTestvalue.bino16NVLunit == '0' && binoTestvalue.bino16NVL >= "0.01") {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", " ");
                            }
                            break;
                        default:
                            // becky.assertion.failure("unknown SCA");
                            break;
                    }
                    break;
                case "17":
                    switch (farNear.toUpperCase()) {
                        case "FN":
                        case "F":
                            $("#labelMainPrismHorR").attr("data-text", binoTestvalue.bino17FHR);
                            $("#labelMainPrismHorL").attr("data-text", binoTestvalue.bino17FHL);
                            $("#labelMainPrismVerR").attr("data-text", binoTestvalue.bino17FVR);
                            $("#labelMainPrismVerL").attr("data-text", binoTestvalue.bino17FVL);
                            $(".prism-heading-inner-hor-R-BI").attr("data-fixed", binoTestvalue.bino17FHRunit);
                            if (binoTestvalue.bino17FHRunit == '1') {

                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BI");
                            } else if (binoTestvalue.bino17FHRunit == '0' && binoTestvalue.bino17FHR >= "0.01") {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", " ");
                            }

                            $(".prism-heading-inner-hor-L-BI").attr("data-fixed", binoTestvalue.bino17FHLunit);
                            if (binoTestvalue.bino17FHLunit == '1') {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BI");
                            } else if (binoTestvalue.bino17FHLunit == '0' && binoTestvalue.bino17FHL >= "0.01") {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", " ");
                            }

                            $(".prism-heading-inner-ver-R-BD").attr("data-fixed", binoTestvalue.bino17FVRunit);
                            if (binoTestvalue.bino17FVRunit == '1') {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BD");
                            } else if (binoTestvalue.bino17FVRunit == '0' && binoTestvalue.bino17FVR >= "0.01") {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", " ");
                            }
                            $(".prism-heading-inner-ver-L-BD").attr("data-fixed", binoTestvalue.bino17FVLunit);
                            if (binoTestvalue.bino17FVLunit == '1') {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BD");
                            } else if (binoTestvalue.bino17FVLunit == '0' && binoTestvalue.bino17FVL >= "0.01") {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", " ");
                            }
                            break;
                        case "N":
                            $("#labelMainPrismHorR").attr("data-text", binoTestvalue.bino17NHR);
                            $("#labelMainPrismHorL").attr("data-text", binoTestvalue.bino17NHL);
                            $("#labelMainPrismVerR").attr("data-text", binoTestvalue.bino17NVR);
                            $("#labelMainPrismVerL").attr("data-text", binoTestvalue.bino17NVL);

                            $(".prism-heading-inner-hor-R-BI").attr("data-fixed", binoTestvalue.bino17NHRunit);
                            if (binoTestvalue.bino17NHRunit == '1') {

                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BI");
                            } else if (binoTestvalue.bino17NHRunit == '0' && binoTestvalue.bino17NHR >= "0.01") {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", " ");
                            }

                            $(".prism-heading-inner-hor-L-BI").attr("data-fixed", binoTestvalue.bino17NHLunit);
                            if (binoTestvalue.bino17NHLunit == '1') {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BI");
                            } else if (binoTestvalue.bino17NHLunit == '0' && binoTestvalue.bino17NHL >= "0.01") {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BO");
                            } else {
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", " ");
                            }
                            $(".prism-heading-inner-ver-R-BD").attr("data-fixed", binoTestvalue.bino17NVRunit);
                            if (binoTestvalue.bino17NVRunit == '1') {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BD");
                            } else if (binoTestvalue.bino17NVRunit == '0' && binoTestvalue.bino17NVR >= "0.01") {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-R-BD").attr("data-text", " ");
                            }
                            $(".prism-heading-inner-ver-L-BD").attr("data-fixed", binoTestvalue.bino17NVLunit);
                            if (binoTestvalue.bino17NVLunit == '1') {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BD");
                            } else if (binoTestvalue.bino17NVLunit == '0' && binoTestvalue.bino17NVL >= "0.01") {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", "BU");
                            } else {
                                $(".prism-heading-inner-ver-L-BD").attr("data-text", " ");
                            }
                            break;
                        default:
                            // becky.assertion.failure("unknown SCA");
                            break;
                    }
                    break;
                default:
                    //becky.assertion.failure("unknown eye");
                    break;
            }
        }
        console.log(chartParameterItem);




    }


    function setBinoTestvalues(aModel) {
        const chartindex = Number(localStorage['chartindex']);

        //console.log(chartindex);
        const chartParameterItem = becky.subjective.arrayChartParameter.chartParameter.filter(
            chartParameterItem_ => chartParameterItem_.chartID === chartindex)[0];

        if (becky.assertion.isUndefined(chartParameterItem)) {
            return;
        }
        var valBinoType = chartParameterItem.examBinoResultID;
        var farNear = chartParameterItem.IsNearFar;

        const updateDataJson = becky.WebStorage.local.getJson("subjective.update.data")
        if (modelHelper.isUndefined(aModel)) {
            var bino1FHR = 0;
            var bino1FHL = 0;
            var bino1FVR = 0;
            var bino1FVL = 0;
            var bino1FHRunit = 0;
            var bino1FHLunit = 0;
            var bino1FVRunit = 0;
            var bino1FVLunit = 0;
            var bino1NHR = 0;
            var bino1NHL = 0;
            var bino1NVR = 0;
            var bino1NVL = 0;
            var bino1NHRunit = 0;
            var bino1NHLunit = 0;
            var bino1NVRunit = 0;
            var bino1NVLunit = 0;
            var bino2FHR = 0;
            var bino2FHL = 0;
            var bino2FVR = 0;
            var bino2FVL = 0;
            var bino2FHRunit = 0;
            var bino2FHLunit = 0;
            var bino2FVRunit = 0;
            var bino2FVLunit = 0;
            var bino2NHR = 0;
            var bino2NHL = 0;
            var bino2NVR = 0;
            var bino2NVL = 0;
            var bino2NHRunit = 0;
            var bino2NHLunit = 0;
            var bino2NVRunit = 0;
            var bino2NVLunit = 0;
            var bino3FHR = 0;
            var bino3FHL = 0;
            var bino3FVR = 0;
            var bino3FVL = 0;
            var bino3FHRunit = 0;
            var bino3FHLunit = 0;
            var bino3FVRunit = 0;
            var bino3FVLunit = 0;
            var bino3NHR = 0;
            var bino3NHL = 0;
            var bino3NVR = 0;
            var bino3NVL = 0;
            var bino3NHRunit = 0;
            var bino3NHLunit = 0;
            var bino3NVRunit = 0;
            var bino3NVLunit = 0;
            var bino4FHR = 0;
            var bino4FHL = 0;
            var bino4FVR = 0;
            var bino4FVL = 0;
            var bino4FHRunit = 0;
            var bino4FHLunit = 0;
            var bino4FVRunit = 0;
            var bino4FVLunit = 0;
            var bino4NHR = 0;
            var bino4NHL = 0;
            var bino4NVR = 0;
            var bino4NVL = 0;
            var bino4NHRunit = 0;
            var bino4NHLunit = 0;
            var bino4NVRunit = 0;
            var bino4NVLunit = 0;
            var bino5FHR = 0;
            var bino5FHL = 0;
            var bino5FVR = 0;
            var bino5FVL = 0;
            var bino5FHRunit = 0;
            var bino5FHLunit = 0;
            var bino5FVRunit = 0;
            var bino5FVLunit = 0;
            var bino5FHRR1 = 0;
            var bino5FHRR1unit = 0;
            var bino5NHR = 0;
            var bino5NHL = 0;
            var bino5NVR = 0;
            var bino5NVL = 0;
            var bino5NHRunit = 0;
            var bino5NHLunit = 0;
            var bino5NVRunit = 0;
            var bino5NVLunit = 0;
            var bino5NHRR1 = 0;
            var bino5NHRR1unit = 0;
            var bino6FHR = 0;
            var bino6FHL = 0;
            var bino6FVR = 0;
            var bino6FVL = 0;
            var bino6FHRunit = 0;
            var bino6FHLunit = 0;
            var bino6FVRunit = 0;
            var bino6FVLunit = 0;
            var bino6FHRR1 = 0;
            var bino6FHRR1unit = 0;
            var bino6NHR = 0;
            var bino6NHL = 0;
            var bino6NVR = 0;
            var bino6NVL = 0;
            var bino6NHRunit = 0;
            var bino6NHLunit = 0;
            var bino6NVRunit = 0;
            var bino6NVLunit = 0;
            var bino6NHRR1 = 0;
            var bino6NHRR1unit = 0;
            var bino7FHR = 0;
            var bino7FHL = 0;
            var bino7FVR = 0;
            var bino7FVL = 0;
            var bino7FHRunit = 0;
            var bino7FHLunit = 0;
            var bino7FVRunit = 0;
            var bino7FVLunit = 0;
            var bino7NHR = 0;
            var bino7NHL = 0;
            var bino7NVR = 0;
            var bino7NVL = 0;
            var bino7NHRunit = 0;
            var bino7NHLunit = 0;
            var bino7NVRunit = 0;
            var bino7NVLunit = 0;
            var bino8FHR = 0;
            var bino8FHL = 0;
            var bino8FVR = 0;
            var bino8FVL = 0;
            var bino8FHRunit = 0;
            var bino8FHLunit = 0;
            var bino8FVRunit = 0;
            var bino8FVLunit = 0;
            var bino8NHR = 0;
            var bino8NHL = 0;
            var bino8NVR = 0;
            var bino8NVL = 0;
            var bino8NHRunit = 0;
            var bino8NHLunit = 0;
            var bino8NVRunit = 0;
            var bino8NVLunit = 0;
            var bino9FHR = 0;
            var bino9FHL = 0;
            var bino9FVR = 0;
            var bino9FVL = 0;
            var bino9FHRunit = 0;
            var bino9FHLunit = 0;
            var bino9FVRunit = 0;
            var bino9FVLunit = 0;
            var bino9NHR = 0;
            var bino9NHL = 0;
            var bino9NVR = 0;
            var bino9NVL = 0;
            var bino9NHRunit = 0;
            var bino9NHLunit = 0;
            var bino9NVRunit = 0;
            var bino9NVLunit = 0;
            var bino9FHRR1 = 0;
            var bino9FHRR2 = 0;
            var bino9FHRR3 = 0;
            var bino9FHRR4 = 0;
            var bino9FHRR5 = 0;
            var bino9FHRR6 = 0;
            var bino9FHRR1unit = 0;
            var bino9FHRR2unit = 0;
            var bino9FHRR3unit = 0;
            var bino9FHRR4unit = 0;
            var bino9FHRR5unit = 0;
            var bino9FHRR6unit = 0;
            var bino10FHR = 0;
            var bino10FHL = 0;
            var bino10FVR = 0;
            var bino10FVL = 0;
            var bino10FHRunit = 0;
            var bino10FHLunit = 0;
            var bino10FVRunit = 0;
            var bino10FVLunit = 0;
            var bino10NHR = 0;
            var bino10NHL = 0;
            var bino10NVR = 0;
            var bino10NVL = 0;
            var bino10NHRunit = 0;
            var bino10NHLunit = 0;
            var bino10NVRunit = 0;
            var bino10NVLunit = 0;
			var bino10NHRR1 = 0;
            var bino10NHRR2 = 0;
            var bino10NHRR3 = 0;
            var bino10NHRR4 = 0;
            var bino10NHRR5 = 0;
            var bino10NHRR6 = 0;
            var bino10NHRR1unit = 0;
            var bino10NHRR2unit = 0;
            var bino10NHRR3unit = 0;
            var bino10NHRR4unit = 0;
            var bino10NHRR5unit = 0;
            var bino10NHRR6unit = 0;
            var bino11FHR = 0;
            var bino11FHL = 0;
            var bino11FVR = 0;
            var bino11FVL = 0;
            var bino11FHRunit = 0;
            var bino11FHLunit = 0;
            var bino11FVRunit = 0;
            var bino11FVLunit = 0;
            var bino11NHR = 0;
            var bino11NHL = 0;
            var bino11NVR = 0;
            var bino11NVL = 0;
            var bino11NHRunit = 0;
            var bino11NHLunit = 0;
            var bino11NVRunit = 0;
            var bino11NVLunit = 0;
            var bino12FHR = 0;
            var bino12FHL = 0;
            var bino12FVR = 0;
            var bino12FVL = 0;
            var bino12FHRunit = 0;
            var bino12FHLunit = 0;
            var bino12FVRunit = 0;
            var bino12FVLunit = 0;
            var bino12FHRR1 = 0;
            var bino12FHRR2 = 0;
            var bino12FHRR1unit = 0;
            var bino12FHRR2unit = 0;
            var bino12NHR = 0;
            var bino12NHL = 0;
            var bino12NVR = 0;
            var bino12NVL = 0;
            var bino12NHRunit = 0;
            var bino12NHLunit = 0;
            var bino12NVRunit = 0;
            var bino12NVLunit = 0;
            var bino13FHR = 0;
            var bino13FHL = 0;
            var bino13FVR = 0;
            var bino13FVL = 0;
            var bino13FHRunit = 0;
            var bino13FHLunit = 0;
            var bino13FVRunit = 0;
            var bino13FVLunit = 0;
            var bino13FHRR3 = 0;
            var bino13FHRR4 = 0;
            var bino13FHRR3unit = 0;
            var bino13FHRR4unit = 0;
            var bino13NHR = 0;
            var bino13NHL = 0;
            var bino13NVR = 0;
            var bino13NVL = 0;
            var bino13NHRunit = 0;
            var bino13NHLunit = 0;
            var bino13NVRunit = 0;
            var bino13NVLunit = 0;
            var bino14FHR = 0;
            var bino14FHL = 0;
            var bino14FVR = 0;
            var bino14FVL = 0;
            var bino14FHRunit = 0;
            var bino14FHLunit = 0;
            var bino14FVRunit = 0;
            var bino14FVLunit = 0;
            var bino14FHRR1 = 0;
            var bino14FHRR2 = 0;
            var bino14FHRR3 = 0;
            var bino14FHRR1unit = 0;
            var bino14FHRR2unit = 0;
            var bino14FHRR3unit = 0;
            var bino14NHR = 0;
            var bino14NHL = 0;
            var bino14NVR = 0;
            var bino14NVL = 0;
            var bino14NHRunit = 0;
            var bino14NHLunit = 0;
            var bino14NVRunit = 0;
            var bino14NVLunit = 0;
            var bino15FHR = 0;
            var bino15FHL = 0;
            var bino15FVR = 0;
            var bino15FVL = 0;
            var bino15FHRunit = 0;
            var bino15FHLunit = 0;
            var bino15FVRunit = 0;
            var bino15FVLunit = 0;
            var bino15FHRR4 = 0;
            var bino15FHRR5 = 0;
            var bino15FHRR6 = 0;
            var bino15FHRR4unit = 0;
            var bino15FHRR5unit = 0;
            var bino15FHRR6unit = 0;
            var bino15NHR = 0;
            var bino15NHL = 0;
            var bino15NVR = 0;
            var bino15NVL = 0;
            var bino15NHRunit = 0;
            var bino15NHLunit = 0;
            var bino15NVRunit = 0;
            var bino15NVLunit = 0;
            var bino16FHR = 0;
            var bino16FHL = 0;
            var bino16FVR = 0;
            var bino16FVL = 0;
            var bino16FHRunit = 0;
            var bino16FHLunit = 0;
            var bino16FVRunit = 0;
            var bino16FVLunit = 0;
            var bino16FHRR1 = 0;
            var bino16FHRR2 = 0;
            var bino16FHRR1unit = 0;
            var bino16FHRR2unit = 0;
            var bino16NHR = 0;
            var bino16NHL = 0;
            var bino16NVR = 0;
            var bino16NVL = 0;
            var bino16NHRunit = 0;
            var bino16NHLunit = 0;
            var bino16NVRunit = 0;
            var bino16NVLunit = 0;
            var bino17FHR = 0;
            var bino17FHL = 0;
            var bino17FVR = 0;
            var bino17FVL = 0;
            var bino17FHRunit = 0;
            var bino17FHLunit = 0;
            var bino17FVRunit = 0;
            var bino17FVLunit = 0;
            var bino17FHRR3 = 0;
            var bino17FHRR4 = 0;
            var bino17FHRR3unit = 0;
            var bino17FHRR4unit = 0;
            var bino17NHR = 0;
            var bino17NHL = 0;
            var bino17NVR = 0;
            var bino17NVL = 0;
            var bino17NHRunit = 0;
            var bino17NHLunit = 0;
            var bino17NVRunit = 0;
            var bino17NVLunit = 0;
            if (!modelHelper.isNull(updateDataJson)) {
                const binovalues = updateDataJson.binostate;
                var bino1FHR = binovalues.bino1FHR;
                var bino1FHL = binovalues.bino1FHL;
                var bino1FVR = binovalues.bino1FVR;
                var bino1FVL = binovalues.bino1FVL;
                var bino1FHRunit = binovalues.bino1FHRunit;
                var bino1FHLunit = binovalues.bino1FHLunit;
                var bino1FVRunit = binovalues.bino1FVRunit;
                var bino1FVLunit = binovalues.bino1FVLunit;
                var bino1NHR = binovalues.bino1NHR;
                var bino1NHL = binovalues.bino1NHL;
                var bino1NVR = binovalues.bino1NVR;
                var bino1NVL = binovalues.bino1NVL;
                var bino1NHRunit = binovalues.bino1NHRunit;
                var bino1NHLunit = binovalues.bino1NHLunit;
                var bino1NVRunit = binovalues.bino1NVRunit;
                var bino1NVLunit = binovalues.bino1NVLunit;
                var bino2FHR = binovalues.bino2FHR;
                var bino2FHL = binovalues.bino2FHL;
                var bino2FVR = binovalues.bino2FVR;
                var bino2FVL = binovalues.bino2FVL;
                var bino2FHRunit = binovalues.bino2FHRunit;
                var bino2FHLunit = binovalues.bino2FHLunit;
                var bino2FVRunit = binovalues.bino2FVRunit;
                var bino2FVLunit = binovalues.bino2FVLunit;
                var bino2NHR = binovalues.bino2NHR;
                var bino2NHL = binovalues.bino2NHL;
                var bino2NVR = binovalues.bino2NVR;
                var bino2NVL = binovalues.bino2NVL;
                var bino2NHRunit = binovalues.bino2NHRunit;
                var bino2NHLunit = binovalues.bino2NHLunit;
                var bino2NVRunit = binovalues.bino2NVRunit;
                var bino2NVLunit = binovalues.bino2NVLunit;
                var bino3FHR = binovalues.bino3FHR;
                var bino3FHL = binovalues.bino3FHL;
                var bino3FVR = binovalues.bino3FVR;
                var bino3FVL = binovalues.bino3FVL;
                var bino3FHRunit = binovalues.bino3FHRunit;
                var bino3FHLunit = binovalues.bino3FHLunit;
                var bino3FVRunit = binovalues.bino3FVRunit;
                var bino3FVLunit = binovalues.bino3FVLunit;
                var bino3NHR = binovalues.bino3NHR;
                var bino3NHL = binovalues.bino3NHL;
                var bino3NVR = binovalues.bino3NVR;
                var bino3NVL = binovalues.bino3NVL;
                var bino3NHRunit = binovalues.bino3NHRunit;
                var bino3NHLunit = binovalues.bino3NHLunit;
                var bino3NVRunit = binovalues.bino3NVRunit;
                var bino3NVLunit = binovalues.bino3NVLunit;
                // var bino4FHR = binovalues.bino4FHR;
                // var bino4FHL = binovalues.bino4FHL;
                // var bino4FVR = binovalues.bino4FVR;
                // var bino4FVL = binovalues.bino4FVL;
                // var bino4FHRunit = binovalues.bino4FHRunit;
                // var bino4FHLunit = binovalues.bino4FHLunit;
                // var bino4FVRunit = binovalues.bino4FVRunit;
                // var bino4FVLunit = binovalues.bino4FVLunit;
                // var bino4NHR = binovalues.bino4NHR;
                // var bino4NHL = binovalues.bino4NHL;
                // var bino4NVR = binovalues.bino4NVR;
                // var bino4NVL = binovalues.bino4NVL;
                // var bino4NHRunit = binovalues.bino4NHRunit;
                // var bino4NHLunit = binovalues.bino4NHLunit;
                // var bino4NVRunit = binovalues.bino4NVRunit;
                // var bino4NVLunit = binovalues.bino4NVLunit;
                // var bino5FHR = binovalues.bino5FHR;
                // var bino5FHL = binovalues.bino5FHL;
                // var bino5FVR = binovalues.bino5FVR;
                // var bino5FVL = binovalues.bino5FVL;
                var bino5FHRR1 = binovalues.bino5FHRR1;
                var bino5FHRR1unit = binovalues.bino5FHRR1unit;
                // var bino5FHRunit = binovalues.bino5FHRunit;
                // var bino5FHLunit = binovalues.bino5FHLunit;
                // var bino5FVRunit = binovalues.bino5FVRunit;
                // var bino5FVLunit = binovalues.bino5FVLunit;
                // var bino5NHR = binovalues.bino5NHR;
                // var bino5NHL = binovalues.bino5NHL;
                // var bino5NVR = binovalues.bino5NVR;
                // var bino5NVL = binovalues.bino5NVL;
                // var bino5NHRunit = binovalues.bino5NHRunit;
                // var bino5NHLunit = binovalues.bino5NHLunit;
                // var bino5NVRunit = binovalues.bino5NVRunit;
                // var bino5NVLunit = binovalues.bino5NVLunit;
                var bino5NHRR1 = binovalues.bino5NHRR1;
                var bino5NHRR1unit = binovalues.bino5NHRR1unit;
                // var bino6FHR = binovalues.bino6FHR;
                // var bino6FHL = binovalues.bino6FHL;
                // var bino6FVR = binovalues.bino6FVR;
                // var bino6FVL = binovalues.bino6FVL;
                var bino6FHRR1 = binovalues.bino6FHRR1;
                var bino6FHRR1unit = binovalues.bino6FHRR1unit;
                // var bino6FHRunit = binovalues.bino6FHRunit;
                // var bino6FHLunit = binovalues.bino6FHLunit;
                // var bino6FVRunit = binovalues.bino6FVRunit;
                // var bino6FVLunit = binovalues.bino6FVLunit;
                // var bino6NHR = binovalues.bino6NHR;
                // var bino6NHL = binovalues.bino6NHL;
                // var bino6NVR = binovalues.bino6NVR;
                // var bino6NVL = binovalues.bino6NVL;
                // var bino6NHRunit = binovalues.bino6NHRunit;
                // var bino6NHLunit = binovalues.bino6NHLunit;
                // var bino6NVRunit = binovalues.bino6NVRunit;
                // var bino6NVLunit = binovalues.bino6NVLunit;
                var bino6NHRR1 = binovalues.bino6NHRR1;
                var bino6NHRR1unit = binovalues.bino6NHRR1unit;
                // var bino7FHR = binovalues.bino7FHR;
                // var bino7FHL = binovalues.bino7FHL;
                // var bino7FVR = binovalues.bino7FVR;
                // var bino7FVL = binovalues.bino7FVL;
                // var bino7FHRunit = binovalues.bino7FHRunit;
                // var bino7FHLunit = binovalues.bino7FHLunit;
                // var bino7FVRunit = binovalues.bino7FVRunit;
                // var bino7FVLunit = binovalues.bino7FVLunit;
                // var bino7NHR = binovalues.bino7NHR;
                // var bino7NHL = binovalues.bino7NHL;
                // var bino7NVR = binovalues.bino7NVR;
                // var bino7NVL = binovalues.bino7NVL;
                // var bino7NHRunit = binovalues.bino7NHRunit;
                // var bino7NHLunit = binovalues.bino7NHLunit;
                // var bino7NVRunit = binovalues.bino7NVRunit;
                // var bino7NVLunit = binovalues.bino7NVLunit;
                // var bino8FHR = binovalues.bino8FHR;
                // var bino8FHL = binovalues.bino8FHL;
                // var bino8FVR = binovalues.bino8FVR;
                // var bino8FVL = binovalues.bino8FVL;
                // var bino8FHRunit = binovalues.bino8FHRunit;
                // var bino8FHLunit = binovalues.bino8FHLunit;
                // var bino8FVRunit = binovalues.bino8FVRunit;
                // var bino8FVLunit = binovalues.bino8FVLunit;
                // var bino8NHR = binovalues.bino8NHR;
                // var bino8NHL = binovalues.bino8NHL;
                // var bino8NVR = binovalues.bino8NVR;
                // var bino8NVL = binovalues.bino8NVL;
                // var bino8NHRunit = binovalues.bino8NHRunit;
                // var bino8NHLunit = binovalues.bino8NHLunit;
                // var bino8NVRunit = binovalues.bino8NVRunit;
                // var bino8NVLunit = binovalues.bino8NVLunit;
                // var bino9FHR = binovalues.bino9FHR;
                // var bino9FHL = binovalues.bino9FHL;
                // var bino9FVR = binovalues.bino9FVR;
                // var bino9FVL = binovalues.bino9FVL;
                // var bino9FHRunit = binovalues.bino9FHRunit;
                // var bino9FHLunit = binovalues.bino9FHLunit;
                // var bino9FVRunit = binovalues.bino9FVRunit;
                // var bino9FVLunit = binovalues.bino9FVLunit;
                var bino9FHRR1 = binovalues.bino9FHRR1;
                var bino9FHRR2 = binovalues.bino9FHRR2;
                var bino9FHRR3 = binovalues.bino9FHRR3;
                var bino9FHRR4 = binovalues.bino9FHRR4;
                var bino9FHRR5 = binovalues.bino9FHRR5;
                var bino9FHRR6 = binovalues.bino9FHRR6;
                var bino9FHRR1unit = binovalues.bino9FHRR1unit;
                var bino9FHRR2unit = binovalues.bino9FHRR2unit;
                var bino9FHRR3unit = binovalues.bino9FHRR3unit;
                var bino9FHRR4unit = binovalues.bino9FHRR4unit;
                var bino9FHRR5unit = binovalues.bino9FHRR5unit;
                var bino9FHRR6unit = binovalues.bino9FHRR6unit;
                // var bino9NHR = binovalues.bino9NHR;
                // var bino9NHL = binovalues.bino9NHL;
                // var bino9NVR = binovalues.bino9NVR;
                // var bino9NVL = binovalues.bino9NVL;
                // var bino9NHRunit = binovalues.bino9NHRunit;
                // var bino9NHLunit = binovalues.bino9NHLunit;
                // var bino9NVRunit = binovalues.bino9NVRunit;
                // var bino9NVLunit = binovalues.bino9NVLunit;
                // var bino10FHR = binovalues.bino10FHR;
                // var bino10FHL = binovalues.bino10FHL;
                // var bino10FVR = binovalues.bino10FVR;
                // var bino10FVL = binovalues.bino10FVL;
                // var bino10FHRunit = binovalues.bino10FHRunit;
                // var bino10FHLunit = binovalues.bino10FHLunit;
                // var bino10FVRunit = binovalues.bino10FVRunit;
                // var bino10FVLunit = binovalues.bino10FVLunit;
                // var bino10NHR = binovalues.bino10NHR;
                // var bino10NHL = binovalues.bino10NHL;
                // var bino10NVR = binovalues.bino10NVR;
                // var bino10NVL = binovalues.bino10NVL;
                // var bino10NHRunit = binovalues.bino10NHRunit;
                // var bino10NHLunit = binovalues.bino10NHLunit;
                // var bino10NVRunit = binovalues.bino10NVRunit;
                // var bino10NVLunit = binovalues.bino10NVLunit;
				var bino10NHRR1 = binovalues.bino10NHRR1;
                var bino10NHRR2 = binovalues.bino10NHRR2;
                var bino10NHRR3 = binovalues.bino10NHRR3;
                var bino10NHRR4 = binovalues.bino10NHRR4;
                var bino10NHRR5 = binovalues.bino10NHRR5;
                var bino10NHRR6 = binovalues.bino10NHRR6;
				var bino10NHRR1unit = binovalues.bino10NHRR1unit;
                var bino10NHRR2unit = binovalues.bino10NHRR2unit;
                var bino10NHRR3unit = binovalues.bino10NHRR3unit;
                var bino10NHRR4unit = binovalues.bino10NHRR4unit;
                var bino10NHRR5unit = binovalues.bino10NHRR5unit;
                var bino10NHRR6unit = binovalues.bino10NHRR6unit;
                // var bino11FHR = binovalues.bino11FHR;
                // var bino11FHL = binovalues.bino11FHL;
                // var bino11FVR = binovalues.bino11FVR;
                // var bino11FVL = binovalues.bino11FVL;
                // var bino11FHRunit = binovalues.bino11FHRunit;
                // var bino11FHLunit = binovalues.bino11FHLunit;
                // var bino11FVRunit = binovalues.bino11FVRunit;
                // var bino11FVLunit = binovalues.bino11FVLunit;
                // var bino11NHR = binovalues.bino11NHR;
                // var bino11NHL = binovalues.bino11NHL;
                // var bino11NVR = binovalues.bino11NVR;
                // var bino11NVL = binovalues.bino11NVL;
                // var bino11NHRunit = binovalues.bino11NHRunit;
                // var bino11NHLunit = binovalues.bino11NHLunit;
                // var bino11NVRunit = binovalues.bino11NVRunit;
                // var bino11NVLunit = binovalues.bino11NVLunit;
                // var bino12FHR = binovalues.bino12FHR;
                // var bino12FHL = binovalues.bino12FHL;
                // var bino12FVR = binovalues.bino12FVR;
                // var bino12FVL = binovalues.bino12FVL;
                // var bino12FHRunit = binovalues.bino12FHRunit;
                // var bino12FHLunit = binovalues.bino12FHLunit;
                // var bino12FVRunit = binovalues.bino12FVRunit;
                // var bino12FVLunit = binovalues.bino12FVLunit;
                var bino12FHRR1 = binovalues.bino12FHRR1;
                var bino12FHRR2 = binovalues.bino12FHRR2;
                var bino12FHRR1unit = binovalues.bino12FHRR1unit;
                var bino12FHRR2unit = binovalues.bino12FHRR2unit;
                // var bino12NHR = binovalues.bino12NHR;
                // var bino12NHL = binovalues.bino12NHL;
                // var bino12NVR = binovalues.bino12NVR;
                // var bino12NVL = binovalues.bino12NVL;
                // var bino12NHRunit = binovalues.bino12NHRunit;
                // var bino12NHLunit = binovalues.bino12NHLunit;
                // var bino12NVRunit = binovalues.bino12NVRunit;
                // var bino12NVLunit = binovalues.bino12NVLunit;
                // var bino13FHR = binovalues.bino13FHR;
                // var bino13FHL = binovalues.bino13FHL;
                // var bino13FVR = binovalues.bino13FVR;
                // var bino13FVL = binovalues.bino13FVL;
                // var bino13FHRunit = binovalues.bino13FHRunit;
                // var bino13FHLunit = binovalues.bino13FHLunit;
                // var bino13FVRunit = binovalues.bino13FVRunit;
                // var bino13FVLunit = binovalues.bino13FVLunit;
                var bino13FHRR3 = binovalues.bino13FHRR3;
                var bino13FHRR4 = binovalues.bino13FHRR4;
                var bino13FHRR3unit = binovalues.bino13FHRR3unit;
                var bino13FHRR4unit = binovalues.bino13FHRR4unit;
                // var bino13NHR = binovalues.bino13NHR;
                // var bino13NHL = binovalues.bino13NHL;
                // var bino13NVR = binovalues.bino13NVR;
                // var bino13NVL = binovalues.bino13NVL;
                // var bino13NHRunit = binovalues.bino13NHRunit;
                // var bino13NHLunit = binovalues.bino13NHLunit;
                // var bino13NVRunit = binovalues.bino13NVRunit;
                // var bino13NVLunit = binovalues.bino13NVLunit;
                // var bino14FHR = binovalues.bino14FHR;
                // var bino14FHL = binovalues.bino14FHL;
                // var bino14FVR = binovalues.bino14FVR;
                // var bino14FVL = binovalues.bino14FVL;
                // var bino14FHRunit = binovalues.bino14FHRunit;
                // var bino14FHLunit = binovalues.bino14FHLunit;
                // var bino14FVRunit = binovalues.bino14FVRunit;
                // var bino14FVLunit = binovalues.bino14FVLunit;
                var bino14FHRR1 = binovalues.bino14FHRR1;
                var bino14FHRR2 = binovalues.bino14FHRR2;
                var bino14FHRR3 = binovalues.bino14FHRR3;
                var bino14FHRR1unit = binovalues.bino14FHRR1unit;
                var bino14FHRR2unit = binovalues.bino14FHRR2unit;
                var bino14FHRR3unit = binovalues.bino14FHRR3unit;
                // var bino14NHR = binovalues.bino14NHR;
                // var bino14NHL = binovalues.bino14NHL;
                // var bino14NVR = binovalues.bino14NVR;
                // var bino14NVL = binovalues.bino14NVL;
                // var bino14NHRunit = binovalues.bino14NHRunit;
                // var bino14NHLunit = binovalues.bino14NHLunit;
                // var bino14NVRunit = binovalues.bino14NVRunit;
                // var bino14NVLunit = binovalues.bino14NVLunit;
                // var bino15FHR = binovalues.bino15FHR;
                // var bino15FHL = binovalues.bino15FHL;
                // var bino15FVR = binovalues.bino15FVR;
                // var bino15FVL = binovalues.bino15FVL;
                // var bino15FHRunit = binovalues.bino15FHRunit;
                // var bino15FHLunit = binovalues.bino15FHLunit;
                // var bino15FVRunit = binovalues.bino15FVRunit;
                // var bino15FVLunit = binovalues.bino15FVLunit;
                var bino15FHRR4 = binovalues.bino15FHRR4;
                var bino15FHRR5 = binovalues.bino15FHRR5;
                var bino15FHRR6 = binovalues.bino15FHRR6;
                var bino15FHRR4unit = binovalues.bino15FHRR4unit;
                var bino15FHRR5unit = binovalues.bino15FHRR5unit;
                var bino15FHRR6unit = binovalues.bino15FHRR5unit;
                // var bino15NHR = binovalues.bino15NHR;
                // var bino15NHL = binovalues.bino15NHL;
                // var bino15NVR = binovalues.bino15NVR;
                // var bino15NVL = binovalues.bino15NVL;
                // var bino15NHRunit = binovalues.bino15NHRunit;
                // var bino15NHLunit = binovalues.bino15NHLunit;
                // var bino15NVRunit = binovalues.bino15NVRunit;
                // var bino15NVLunit = binovalues.bino15NVLunit;
                // var bino16FHR = binovalues.bino16FHR;
                // var bino16FHL = binovalues.bino16FHL;
                // var bino16FVR = binovalues.bino16FVR;
                // var bino16FVL = binovalues.bino16FVL;
                // var bino16FHRunit = binovalues.bino16FHRunit;
                // var bino16FHLunit = binovalues.bino16FHLunit;
                // var bino16FVRunit = binovalues.bino16FVRunit;
                // var bino16FVLunit = binovalues.bino16FVLunit;
                var bino16FHRR1 = binovalues.bino16FHRR1;
                var bino16FHRR2 = binovalues.bino16FHRR2;
                var bino16FHRR1unit = binovalues.bino16FHRR1unit;
                var bino16FHRR2unit = binovalues.bino16FHRR2unit;
                // var bino16NHR = binovalues.bino16NHR;
                // var bino16NHL = binovalues.bino16NHL;
                // var bino16NVR = binovalues.bino16NVR;
                // var bino16NVL = binovalues.bino16NVL;
                // var bino16NHRunit = binovalues.bino16NHRunit;
                // var bino16NHLunit = binovalues.bino16NHLunit;
                // var bino16NVRunit = binovalues.bino16NVRunit;
                // var bino16NVLunit = binovalues.bino16NVLunit;
                // var bino17FHR = binovalues.bino17FHR;
                // var bino17FHL = binovalues.bino17FHL;
                // var bino17FVR = binovalues.bino17FVR;
                // var bino17FVL = binovalues.bino17FVL;
                // var bino17FHRunit = binovalues.bino17FHRunit;
                // var bino17FHLunit = binovalues.bino17FHLunit;
                // var bino17FVRunit = binovalues.bino17FVRunit;
                // var bino17FVLunit = binovalues.bino17FVLunit;
                var bino17FHRR3 = binovalues.bino17FHRR3;
                var bino17FHRR4 = binovalues.bino17FHRR4;
                var bino17FHRR3unit = binovalues.bino17FHRR3unit;
                var bino17FHRR4unit = binovalues.bino17FHRR4unit;
                // var bino17NHR = binovalues.bino17NHR;
                // var bino17NHL = binovalues.bino17NHL;
                // var bino17NVR = binovalues.bino17NVR;
                // var bino17NVL = binovalues.bino17NVL;
                // var bino17NHRunit = binovalues.bino17NHRunit;
                // var bino17NHLunit = binovalues.bino17NHLunit;
                // var bino17NVRunit = binovalues.bino17NVRunit;
                // var bino17NVLunit = binovalues.bino17NVLunit;
            }
        } else {
            var bino1FHR = aModel.bino1FHR;
            var bino1FHL = aModel.bino1FHL;
            var bino1FVR = aModel.bino1FVR;
            var bino1FVL = aModel.bino1FVL;
            var bino1FHRunit = aModel.bino1FHRunit;
            var bino1FHLunit = aModel.bino1FHLunit;
            var bino1FVRunit = aModel.bino1FVRunit;
            var bino1FVLunit = aModel.bino1FVLunit;
            var bino1NHR = aModel.bino1NHR;
            var bino1NHL = aModel.bino1NHL;
            var bino1NVR = aModel.bino1NVR;
            var bino1NVL = aModel.bino1NVL;
            var bino1NHRunit = aModel.bino1NHRunit;
            var bino1NHLunit = aModel.bino1NHLunit;
            var bino1NVRunit = aModel.bino1NVRunit;
            var bino1NVLunit = aModel.bino1NVLunit;
            var bino2FHR = aModel.bino2FHR;
            var bino2FHL = aModel.bino2FHL;
            var bino2FVR = aModel.bino2FVR;
            var bino2FVL = aModel.bino2FVL;
            var bino2FHRunit = aModel.bino2FHRunit;
            var bino2FHLunit = aModel.bino2FHLunit;
            var bino2FVRunit = aModel.bino2FVRunit;
            var bino2FVLunit = aModel.bino2FVLunit;
            var bino2NHR = aModel.bino2NHR;
            var bino2NHL = aModel.bino2NHL;
            var bino2NVR = aModel.bino2NVR;
            var bino2NVL = aModel.bino2NVL;
            var bino2NHRunit = aModel.bino2NHRunit;
            var bino2NHLunit = aModel.bino2NHLunit;
            var bino2NVRunit = aModel.bino2NVRunit;
            var bino2NVLunit = aModel.bino2NVLunit;
            var bino3FHR = aModel.bino3FHR;
            var bino3FHL = aModel.bino3FHL;
            var bino3FVR = aModel.bino3FVR;
            var bino3FVL = aModel.bino3FVL;
            var bino3FHRunit = aModel.bino3FHRunit;
            var bino3FHLunit = aModel.bino3FHLunit;
            var bino3FVRunit = aModel.bino3FVRunit;
            var bino3FVLunit = aModel.bino3FVLunit;
            var bino3NHR = aModel.bino3NHR;
            var bino3NHL = aModel.bino3NHL;
            var bino3NVR = aModel.bino3NVR;
            var bino3NVL = aModel.bino3NVL;
            var bino3NHRunit = aModel.bino3NHRunit;
            var bino3NHLunit = aModel.bino3NHLunit;
            var bino3NVRunit = aModel.bino3NVRunit;
            var bino3NVLunit = aModel.bino3NVLunit;
            // var bino4FHR = aModel.bino4FHR;
            // var bino4FHL = aModel.bino4FHL;
            // var bino4FVR = aModel.bino4FVR;
            // var bino4FVL = aModel.bino4FVL;
            // var bino4FHRunit = aModel.bino4FHRunit;
            // var bino4FHLunit = aModel.bino4FHLunit;
            // var bino4FVRunit = aModel.bino4FVRunit;
            // var bino4FVLunit = aModel.bino4FVLunit;
            // var bino4NHR = aModel.bino4NHR;
            // var bino4NHL = aModel.bino4NHL;
            // var bino4NVR = aModel.bino4NVR;
            // var bino4NVL = aModel.bino4NVL;
            // var bino4NHRunit = aModel.bino4NHRunit;
            // var bino4NHLunit = aModel.bino4NHLunit;
            // var bino4NVRunit = aModel.bino4NVRunit;
            // var bino4NVLunit = aModel.bino4NVLunit;
            // var bino5FHR = aModel.bino5FHR;
            // var bino5FHL = aModel.bino5FHL;
            // var bino5FVR = aModel.bino5FVR;
            // var bino5FVL = aModel.bino5FVL;
            // var bino5FHRunit = aModel.bino5FHRunit;
            // var bino5FHLunit = aModel.bino5FHLunit;
            // var bino5FVRunit = aModel.bino5FVRunit;
            // var bino5FVLunit = aModel.bino5FVLunit;
            var bino5FHRR1 = aModel.bino5FHRR1;
            var bino5FHRR1unit = aModel.bino5FHRR1unit;
            // var bino5NHR = aModel.bino5NHR;
            // var bino5NHL = aModel.bino5NHL;
            // var bino5NVR = aModel.bino5NVR;
            // var bino5NVL = aModel.bino5NVL;
            // var bino5NHRunit = aModel.bino5NHRunit;
            // var bino5NHLunit = aModel.bino5NHLunit;
            // var bino5NVRunit = aModel.bino5NVRunit;
            // var bino5NVLunit = aModel.bino5NVLunit;
            var bino5NHRR1 = aModel.bino5NHRR1;
            var bino5NHRR1unit = aModel.bino5NHRR1unit;
            // var bino6FHR = aModel.bino6FHR;
            // var bino6FHL = aModel.bino6FHL;
            // var bino6FVR = aModel.bino6FVR;
            // var bino6FVL = aModel.bino6FVL;
            var bino6FHRR1 = aModel.bino6FHRR1;
            var bino6FHRR1unit = aModel.bino6FHRR1unit;
            // var bino6FHRunit = aModel.bino6FHRunit;
            // var bino6FHLunit = aModel.bino6FHLunit;
            // var bino6FVRunit = aModel.bino6FVRunit;
            // var bino6FVLunit = aModel.bino6FVLunit;
            // var bino6NHR = aModel.bino6NHR;
            // var bino6NHL = aModel.bino6NHL;
            // var bino6NVR = aModel.bino6NVR;
            // var bino6NVL = aModel.bino6NVL;
            // var bino6NHRunit = aModel.bino6NHRunit;
            // var bino6NHLunit = aModel.bino6NHLunit;
            // var bino6NVRunit = aModel.bino6NVRunit;
            // var bino6NVLunit = aModel.bino6NVLunit;
            var bino6NHRR1 = aModel.bino6NHRR1;
            var bino6NHRR1unit = aModel.bino6NHRR1unit;
            // var bino7FHR = aModel.bino7FHR;
            // var bino7FHL = aModel.bino7FHL;
            // var bino7FVR = aModel.bino7FVR;
            // var bino7FVL = aModel.bino7FVL;
            // var bino7FHRunit = aModel.bino7FHRunit;
            // var bino7FHLunit = aModel.bino7FHLunit;
            // var bino7FVRunit = aModel.bino7FVRunit;
            // var bino7FVLunit = aModel.bino7FVLunit;
            // var bino7NHR = aModel.bino7NHR;
            // var bino7NHL = aModel.bino7NHL;
            // var bino7NVR = aModel.bino7NVR;
            // var bino7NVL = aModel.bino7NVL;
            // var bino7NHRunit = aModel.bino7NHRunit;
            // var bino7NHLunit = aModel.bino7NHLunit;
            // var bino7NVRunit = aModel.bino7NVRunit;
            // var bino7NVLunit = aModel.bino7NVLunit;
            // var bino8FHR = aModel.bino8FHR;
            // var bino8FHL = aModel.bino8FHL;
            // var bino8FVR = aModel.bino8FVR;
            // var bino8FVL = aModel.bino8FVL;
            // var bino8FHRunit = aModel.bino8FHRunit;
            // var bino8FHLunit = aModel.bino8FHLunit;
            // var bino8FVRunit = aModel.bino8FVRunit;
            // var bino8FVLunit = aModel.bino8FVLunit;
            // var bino8NHR = aModel.bino8NHR;
            // var bino8NHL = aModel.bino8NHL;
            // var bino8NVR = aModel.bino8NVR;
            // var bino8NVL = aModel.bino8NVL;
            // var bino8NHRunit = aModel.bino8NHRunit;
            // var bino8NHLunit = aModel.bino8NHLunit;
            // var bino8NVRunit = aModel.bino8NVRunit;
            // var bino8NVLunit = aModel.bino8NVLunit;
            // var bino9FHR = aModel.bino9FHR;
            // var bino9FHL = aModel.bino9FHL;
            // var bino9FVR = aModel.bino9FVR;
            // var bino9FVL = aModel.bino9FVL;
            // var bino9FHRunit = aModel.bino9FHRunit;
            // var bino9FHLunit = aModel.bino9FHLunit;
            // var bino9FVRunit = aModel.bino9FVRunit;
            // var bino9FVLunit = aModel.bino9FVLunit;
            var bino9FHRR1 = aModel.bino9FHRR1;
            var bino9FHRR2 = aModel.bino9FHRR2;
            var bino9FHRR3 = aModel.bino9FHRR3;
            var bino9FHRR4 = aModel.bino9FHRR4;
            var bino9FHRR5 = aModel.bino9FHRR5;
            var bino9FHRR6 = aModel.bino9FHRR6;
            var bino9FHRR1unit = aModel.bino9FHRR1unit;
            var bino9FHRR2unit = aModel.bino9FHRR2unit;
            var bino9FHRR3unit = aModel.bino9FHRR3unit;
            var bino9FHRR4unit = aModel.bino9FHRR4unit;
            var bino9FHRR5unit = aModel.bino9FHRR5unit;
            var bino9FHRR6unit = aModel.bino9FHRR6unit;
            // var bino9NHR = aModel.bino9NHR;
            // var bino9NHL = aModel.bino9NHL;
            // var bino9NVR = aModel.bino9NVR;
            // var bino9NVL = aModel.bino9NVL;
            // var bino9NHRunit = aModel.bino9NHRunit;
            // var bino9NHLunit = aModel.bino9NHLunit;
            // var bino9NVRunit = aModel.bino9NVRunit;
            // var bino9NVLunit = aModel.bino9NVLunit;
            // var bino10FHR = aModel.bino10FHR;
            // var bino10FHL = aModel.bino10FHL;
            // var bino10FVR = aModel.bino10FVR;
            // var bino10FVL = aModel.bino10FVL;
            // var bino10FHRunit = aModel.bino10FHRunit;
            // var bino10FHLunit = aModel.bino10FHLunit;
            // var bino10FVRunit = aModel.bino10FVRunit;
            // var bino10FVLunit = aModel.bino10FVLunit;
            // var bino10NHR = aModel.bino10NHR;
            // var bino10NHL = aModel.bino10NHL;
            // var bino10NVR = aModel.bino10NVR;
            // var bino10NVL = aModel.bino10NVL;
            // var bino10NHRunit = aModel.bino10NHRunit;
            // var bino10NHLunit = aModel.bino10NHLunit;
            // var bino10NVRunit = aModel.bino10NVRunit;
            // var bino10NVLunit = aModel.bino10NVLunit;
			var bino10NHRR1 = aModel.bino10NHRR1;
             var bino10NHRR2 = aModel.bino10NHRR2;
                var bino10NHRR3 = aModel.bino10NHRR3;
                var bino10NHRR4 = aModel.bino10NHRR4;
                var bino10NHRR5 = aModel.bino10NHRR5;
                var bino10NHRR6 = aModel.bino10NHRR6;
				var bino10NHRR1unit = aModel.bino10NHRR1unit;
                var bino10NHRR2unit = aModel.bino10NHRR2unit;
                var bino10NHRR3unit = aModel.bino10NHRR3unit;
                var bino10NHRR4unit = aModel.bino10NHRR4unit;
                var bino10NHRR5unit = aModel.bino10NHRR5unit;
                var bino10NHRR6unit = aModel.bino10NHRR6unit;   
            // var bino11FHR = aModel.bino11FHR;
            // var bino11FHL = aModel.bino11FHL;
            // var bino11FVR = aModel.bino11FVR;
            // var bino11FVL = aModel.bino11FVL;
            // var bino11FHRunit = aModel.bino11FHRunit;
            // var bino11FHLunit = aModel.bino11FHLunit;
            // var bino11FVRunit = aModel.bino11FVRunit;
            // var bino11FVLunit = aModel.bino11FVLunit;
            // var bino11NHR = aModel.bino11NHR;
            // var bino11NHL = aModel.bino11NHL;
            // var bino11NVR = aModel.bino11NVR;
            // var bino11NVL = aModel.bino11NVL;
            // var bino11NHRunit = aModel.bino11NHRunit;
            // var bino11NHLunit = aModel.bino11NHLunit;
            // var bino11NVRunit = aModel.bino11NVRunit;
            // var bino11NVLunit = aModel.bino11NVLunit;
            // var bino12FHR = aModel.bino12FHR;
            // var bino12FHL = aModel.bino12FHL;
            // var bino12FVR = aModel.bino12FVR;
            // var bino12FVL = aModel.bino12FVL;
            // var bino12FHRunit = aModel.bino12FHRunit;
            // var bino12FHLunit = aModel.bino12FHLunit;
            // var bino12FVRunit = aModel.bino12FVRunit;
            // var bino12FVLunit = aModel.bino12FVLunit;
            var bino12FHRR1 = aModel.bino12FHRR1;
            var bino12FHRR2 = aModel.bino12FHRR2;
            var bino12FHRR1unit = aModel.bino12FHRR1unit;
            var bino12FHRR2unit = aModel.bino12FHRR2unit;
            // var bino12NHR = aModel.bino12NHR;
            // var bino12NHL = aModel.bino12NHL;
            // var bino12NVR = aModel.bino12NVR;
            // var bino12NVL = aModel.bino12NVL;
            // var bino12NHRunit = aModel.bino12NHRunit;
            // var bino12NHLunit = aModel.bino12NHLunit;
            // var bino12NVRunit = aModel.bino12NVRunit;
            // var bino12NVLunit = aModel.bino12NVLunit;
            // var bino13FHR = aModel.bino13FHR;
            // var bino13FHL = aModel.bino13FHL;
            // var bino13FVR = aModel.bino13FVR;
            // var bino13FVL = aModel.bino13FVL;
            // var bino13FHRunit = aModel.bino13FHRunit;
            // var bino13FHLunit = aModel.bino13FHLunit;
            // var bino13FVRunit = aModel.bino13FVRunit;
            // var bino13FVLunit = aModel.bino13FVLunit;
            var bino13FHRR3 = aModel.bino13FHRR3;
            var bino13FHRR4 = aModel.bino13FHRR4;
            var bino13FHRR3unit = aModel.bino13FHRR3unit;
            var bino13FHRR4unit = aModel.bino13FHRR4unit;
            // var bino13NHR = aModel.bino13NHR;
            // var bino13NHL = aModel.bino13NHL;
            // var bino13NVR = aModel.bino13NVR;
            // var bino13NVL = aModel.bino13NVL;
            // var bino13NHRunit = aModel.bino13NHRunit;
            // var bino13NHLunit = aModel.bino13NHLunit;
            // var bino13NVRunit = aModel.bino13NVRunit;
            // var bino13NVLunit = aModel.bino13NVLunit;
            // var bino14FHR = aModel.bino14FHR;
            // var bino14FHL = aModel.bino14FHL;
            // var bino14FVR = aModel.bino14FVR;
            // var bino14FVL = aModel.bino14FVL;
            // var bino14FHRunit = aModel.bino14FHRunit;
            // var bino14FHLunit = aModel.bino14FHLunit;
            // var bino14FVRunit = aModel.bino14FVRunit;
            // var bino14FVLunit = aModel.bino14FVLunit;
            var bino14FHRR1 = aModel.bino14FHRR1;
            var bino14FHRR2 = aModel.bino14FHRR2;
            var bino14FHRR3 = aModel.bino14FHRR3;
            var bino14FHRR1unit = aModel.bino14FHRR1unit;
            var bino14FHRR2unit = aModel.bino14FHRR2unit;
            var bino14FHRR3unit = aModel.bino14FHRR3unit;
            // var bino14NHR = aModel.bino14NHR;
            // var bino14NHL = aModel.bino14NHL;
            // var bino14NVR = aModel.bino14NVR;
            // var bino14NVL = aModel.bino14NVL;
            // var bino14NHRunit = aModel.bino14NHRunit;
            // var bino14NHLunit = aModel.bino14NHLunit;
            // var bino14NVRunit = aModel.bino14NVRunit;
            // var bino14NVLunit = aModel.bino14NVLunit;
            // var bino15FHR = aModel.bino15FHR;
            // var bino15FHL = aModel.bino15FHL;
            // var bino15FVR = aModel.bino15FVR;
            // var bino15FVL = aModel.bino15FVL;
            // var bino15FHRunit = aModel.bino15FHRunit;
            // var bino15FHLunit = aModel.bino15FHLunit;
            // var bino15FVRunit = aModel.bino15FVRunit;
            // var bino15FVLunit = aModel.bino15FVLunit;
            var bino15FHRR4 = aModel.bino15FHRR4;
            var bino15FHRR5 = aModel.bino15FHRR5;
            var bino15FHRR6 = aModel.bino15FHRR6;
            var bino15FHRR4unit = aModel.bino15FHRR4unit;
            var bino15FHRR5unit = aModel.bino15FHRR5unit;
            var bino15FHRR6unit = aModel.bino15FHRR5unit;
            // var bino15NHR = aModel.bino15NHR;
            // var bino15NHL = aModel.bino15NHL;
            // var bino15NVR = aModel.bino15NVR;
            // var bino15NVL = aModel.bino15NVL;
            // var bino15NHRunit = aModel.bino15NHRunit;
            // var bino15NHLunit = aModel.bino15NHLunit;
            // var bino15NVRunit = aModel.bino15NVRunit;
            // var bino15NVLunit = aModel.bino15NVLunit;
            // var bino16FHR = aModel.bino16FHR;
            // var bino16FHL = aModel.bino16FHL;
            // var bino16FVR = aModel.bino16FVR;
            // var bino16FVL = aModel.bino16FVL;
            // var bino16FHRunit = aModel.bino16FHRunit;
            // var bino16FHLunit = aModel.bino16FHLunit;
            // var bino16FVRunit = aModel.bino16FVRunit;
            // var bino16FVLunit = aModel.bino16FVLunit;
            var bino16FHRR1 = aModel.bino16FHRR1;
            var bino16FHRR2 = aModel.bino16FHRR2;
            var bino16FHRR1unit = aModel.bino16FHRR1unit;
            var bino16FHRR2unit = aModel.bino16FHRR2unit;
            // var bino16NHR = aModel.bino16NHR;
            // var bino16NHL = aModel.bino16NHL;
            // var bino16NVR = aModel.bino16NVR;
            // var bino16NVL = aModel.bino16NVL;
            // var bino16NHRunit = aModel.bino16NHRunit;
            // var bino16NHLunit = aModel.bino16NHLunit;
            // var bino16NVRunit = aModel.bino16NVRunit;
            // var bino16NVLunit = aModel.bino16NVLunit;
            // var bino17FHR = aModel.bino17FHR;
            // var bino17FHL = aModel.bino17FHL;
            // var bino17FVR = aModel.bino17FVR;
            // var bino17FVL = aModel.bino17FVL;
            // var bino17FHRunit = aModel.bino17FHRunit;
            // var bino17FHLunit = aModel.bino17FHLunit;
            // var bino17FVRunit = aModel.bino17FVRunit;
            // var bino17FVLunit = aModel.bino17FVLunit;
            var bino17FHRR3 = aModel.bino17FHRR3;
            var bino17FHRR4 = aModel.bino17FHRR4;
            var bino17FHRR3unit = aModel.bino17FHRR3unit;
            var bino17FHRR4unit = aModel.bino17FHRR4unit;
            // var bino17NHR = aModel.bino17NHR;
            // var bino17NHL = aModel.bino17NHL;
            // var bino17NVR = aModel.bino17NVR;
            // var bino17NVL = aModel.bino17NVL;
            // var bino17NHRunit = aModel.bino17NHRunit;
            // var bino17NHLunit = aModel.bino17NHLunit;
            // var bino17NVRunit = aModel.bino17NVRunit;
            // var bino17NVLunit = aModel.bino17NVLunit;
        }

        switch (valBinoType.toLowerCase()) {
            case "1":
                switch (farNear.toUpperCase()) {
                    case "FN":
                    case "F":
                        bino1FHR = $("#labelMainPrismHorR").attr("data-text");
                        bino1FHL = $("#labelMainPrismHorL").attr("data-text");
                        bino1FVR = $("#labelMainPrismVerR").attr("data-text");
                        bino1FVL = $("#labelMainPrismVerL").attr("data-text");

                        bino1FHRunit = $(".prism-heading-inner-hor-R-BI").attr("data-fixed");
                        bino1FHLunit = $(".prism-heading-inner-hor-L-BI").attr("data-fixed");
                        bino1FVRunit = $(".prism-heading-inner-ver-R-BD").attr("data-fixed");
                        bino1FVLunit = $(".prism-heading-inner-ver-L-BD").attr("data-fixed");
                        break;
                    case "N":
                        bino1NHR = $("#labelMainPrismHorR").attr("data-text");
                        bino1NHL = $("#labelMainPrismHorL").attr("data-text");
                        bino1NVR = $("#labelMainPrismVerR").attr("data-text");
                        bino1NVL = $("#labelMainPrismVerL").attr("data-text");

                        bino1NHRunit = $(".prism-heading-inner-hor-R-BI").attr("data-fixed");
                        bino1NHLunit = $(".prism-heading-inner-hor-L-BI").attr("data-fixed");
                        bino1NVRunit = $(".prism-heading-inner-ver-R-BD").attr("data-fixed");
                        bino1NVLunit = $(".prism-heading-inner-ver-L-BD").attr("data-fixed");
                        break;
                    default:
                        // becky.assertion.failure("unknown SCA");
                        break;
                }
                break;
            case "2":
                switch (farNear.toUpperCase()) {
                    case "FN":
                    case "F":
                        bino2FHR = $("#labelMainPrismHorR").attr("data-text");
                        bino2FHL = $("#labelMainPrismHorL").attr("data-text");
                        bino2FVR = $("#labelMainPrismVerR").attr("data-text");
                        bino2FVL = $("#labelMainPrismVerL").attr("data-text");

                        bino2FHRunit = $(".prism-heading-inner-hor-R-BI").attr("data-fixed");
                        bino2FHLunit = $(".prism-heading-inner-hor-L-BI").attr("data-fixed");
                        bino2FVRunit = $(".prism-heading-inner-ver-R-BD").attr("data-fixed");
                        bino2FVLunit = $(".prism-heading-inner-ver-L-BD").attr("data-fixed");
                        break;
                    case "N":
                        bino2NHR = $("#labelMainPrismHorR").attr("data-text");
                        bino2NHL = $("#labelMainPrismHorL").attr("data-text");
                        bino2NVR = $("#labelMainPrismVerR").attr("data-text");
                        bino2NVL = $("#labelMainPrismVerL").attr("data-text");

                        bino2NHRunit = $(".prism-heading-inner-hor-R-BI").attr("data-fixed");
                        bino2NHLunit = $(".prism-heading-inner-hor-L-BI").attr("data-fixed");
                        bino2NVRunit = $(".prism-heading-inner-ver-R-BD").attr("data-fixed");
                        bino2NVLunit = $(".prism-heading-inner-ver-L-BD").attr("data-fixed");
                        break;
                    default:
                        // becky.assertion.failure("unknown SCA");
                        break;
                }
                break;
            case "3":
                switch (farNear.toUpperCase()) {
                    case "FN":
                    case "F":
                        bino3FHR = $("#labelMainPrismHorR").attr("data-text");
                        bino3FHL = $("#labelMainPrismHorL").attr("data-text");
                        bino3FVR = $("#labelMainPrismVerR").attr("data-text");
                        bino3FVL = $("#labelMainPrismVerL").attr("data-text");

                        bino3FHRunit = $(".prism-heading-inner-hor-R-BI").attr("data-fixed");
                        bino3FHLunit = $(".prism-heading-inner-hor-L-BI").attr("data-fixed");
                        bino3FVRunit = $(".prism-heading-inner-ver-R-BD").attr("data-fixed");
                        bino3FVLunit = $(".prism-heading-inner-ver-L-BD").attr("data-fixed");
                        break;
                    case "N":
                        bino3NHR = $("#labelMainPrismHorR").attr("data-text");
                        bino3NHL = $("#labelMainPrismHorL").attr("data-text");
                        bino3NVR = $("#labelMainPrismVerR").attr("data-text");
                        bino3NVL = $("#labelMainPrismVerL").attr("data-text");

                        bino3NHRunit = $(".prism-heading-inner-hor-R-BI").attr("data-fixed");
                        bino3NHLunit = $(".prism-heading-inner-hor-L-BI").attr("data-fixed");
                        bino3NVRunit = $(".prism-heading-inner-ver-R-BD").attr("data-fixed");
                        bino3NVLunit = $(".prism-heading-inner-ver-L-BD").attr("data-fixed");
                        break;
                    default:
                        // becky.assertion.failure("unknown SCA");
                        break;
                }
                break;
            case "4":
                switch (farNear.toUpperCase()) {
                    case "FN":
                    case "F":
                        bino4FHR = $("#labelMainPrismHorR").attr("data-text");
                        bino4FHL = $("#labelMainPrismHorL").attr("data-text");
                        bino4FVR = $("#labelMainPrismVerR").attr("data-text");
                        bino4FVL = $("#labelMainPrismVerL").attr("data-text");

                        bino4FHRunit = $(".prism-heading-inner-hor-R-BI").attr("data-fixed");
                        bino4FHLunit = $(".prism-heading-inner-hor-L-BI").attr("data-fixed");
                        bino4FVRunit = $(".prism-heading-inner-ver-R-BD").attr("data-fixed");
                        bino4FVLunit = $(".prism-heading-inner-ver-L-BD").attr("data-fixed");
                        break;
                    case "N":
                        bino4NHR = $("#labelMainPrismHorR").attr("data-text");
                        bino4NHL = $("#labelMainPrismHorL").attr("data-text");
                        bino4NVR = $("#labelMainPrismVerR").attr("data-text");
                        bino4NVL = $("#labelMainPrismVerL").attr("data-text");

                        bino4NHRunit = $(".prism-heading-inner-hor-R-BI").attr("data-fixed");
                        bino4NHLunit = $(".prism-heading-inner-hor-L-BI").attr("data-fixed");
                        bino4NVRunit = $(".prism-heading-inner-ver-R-BD").attr("data-fixed");
                        bino4NVLunit = $(".prism-heading-inner-ver-L-BD").attr("data-fixed");
                        break;
                    default:
                        // becky.assertion.failure("unknown SCA");
                        break;
                }
                break;
            case "5":
                switch (farNear.toUpperCase()) {
                    case "FN":
                    case "F":
                        bino5FHR = $("#labelMainPrismHorR").attr("data-text");
                        bino5FHL = $("#labelMainPrismHorL").attr("data-text");
                        bino5FVR = $("#labelMainPrismVerR").attr("data-text");
                        bino5FVL = $("#labelMainPrismVerL").attr("data-text");

                        bino5FHRunit = $(".prism-heading-inner-hor-R-BI").attr("data-fixed");
                        bino5FHLunit = $(".prism-heading-inner-hor-L-BI").attr("data-fixed");
                        bino5FVRunit = $(".prism-heading-inner-ver-R-BD").attr("data-fixed");
                        bino5FVLunit = $(".prism-heading-inner-ver-L-BD").attr("data-fixed");

                        break;
                    case "N":
                        bino5NHR = $("#labelMainPrismHorR").attr("data-text");
                        bino5NHL = $("#labelMainPrismHorL").attr("data-text");
                        bino5NVR = $("#labelMainPrismVerR").attr("data-text");
                        bino5NVL = $("#labelMainPrismVerL").attr("data-text");

                        bino5NHRunit = $(".prism-heading-inner-hor-R-BI").attr("data-fixed");
                        bino5NHLunit = $(".prism-heading-inner-hor-L-BI").attr("data-fixed");
                        bino5NVRunit = $(".prism-heading-inner-ver-R-BD").attr("data-fixed");
                        bino5NVLunit = $(".prism-heading-inner-ver-L-BD").attr("data-fixed");
                        break;
                    default:
                        // becky.assertion.failure("unknown SCA");
                        break;
                }
                break;
            case "6":
                switch (farNear.toUpperCase()) {
                    case "FN":
                    case "F":
                        bino6FHR = $("#labelMainPrismHorR").attr("data-text");
                        bino6FHL = $("#labelMainPrismHorL").attr("data-text");
                        bino6FVR = $("#labelMainPrismVerR").attr("data-text");
                        bino6FVL = $("#labelMainPrismVerL").attr("data-text");

                        bino6FHRunit = $(".prism-heading-inner-hor-R-BI").attr("data-fixed");
                        bino6FHLunit = $(".prism-heading-inner-hor-L-BI").attr("data-fixed");
                        bino6FVRunit = $(".prism-heading-inner-ver-R-BD").attr("data-fixed");
                        bino6FVLunit = $(".prism-heading-inner-ver-L-BD").attr("data-fixed");
                        break;
                    case "N":
                        bino6NHR = $("#labelMainPrismHorR").attr("data-text");
                        bino6NHL = $("#labelMainPrismHorL").attr("data-text");
                        bino6NVR = $("#labelMainPrismVerR").attr("data-text");
                        bino6NVL = $("#labelMainPrismVerL").attr("data-text");

                        bino6NHRunit = $(".prism-heading-inner-hor-R-BI").attr("data-fixed");
                        bino6NHLunit = $(".prism-heading-inner-hor-L-BI").attr("data-fixed");
                        bino6NVRunit = $(".prism-heading-inner-ver-R-BD").attr("data-fixed");
                        bino6NVLunit = $(".prism-heading-inner-ver-L-BD").attr("data-fixed");
                        break;
                    default:
                        // becky.assertion.failure("unknown SCA");
                        break;
                }
                break;
            case "7":
                switch (farNear.toUpperCase()) {
                    case "FN":
                    case "F":
                        bino7FHR = $("#labelMainPrismHorR").attr("data-text");
                        bino7FHL = $("#labelMainPrismHorL").attr("data-text");
                        bino7FVR = $("#labelMainPrismVerR").attr("data-text");
                        bino7FVL = $("#labelMainPrismVerL").attr("data-text");

                        bino7FHRunit = $(".prism-heading-inner-hor-R-BI").attr("data-fixed");
                        bino7FHLunit = $(".prism-heading-inner-hor-L-BI").attr("data-fixed");
                        bino7FVRunit = $(".prism-heading-inner-ver-R-BD").attr("data-fixed");
                        bino7FVLunit = $(".prism-heading-inner-ver-L-BD").attr("data-fixed");
                        break;
                    case "N":
                        bino7NHR = $("#labelMainPrismHorR").attr("data-text");
                        bino7NHL = $("#labelMainPrismHorL").attr("data-text");
                        bino7NVR = $("#labelMainPrismVerR").attr("data-text");
                        bino7NVL = $("#labelMainPrismVerL").attr("data-text");

                        bino7NHRunit = $(".prism-heading-inner-hor-R-BI").attr("data-fixed");
                        bino7NHLunit = $(".prism-heading-inner-hor-L-BI").attr("data-fixed");
                        bino7NVRunit = $(".prism-heading-inner-ver-R-BD").attr("data-fixed");
                        bino7NVLunit = $(".prism-heading-inner-ver-L-BD").attr("data-fixed");
                        break;
                    default:
                        // becky.assertion.failure("unknown SCA");
                        break;
                }
                break;
            case "8":
                switch (farNear.toUpperCase()) {
                    case "FN":
                    case "F":
                        bino8FHR = $("#labelMainPrismHorR").attr("data-text");
                        bino8FHL = $("#labelMainPrismHorL").attr("data-text");
                        bino8FVR = $("#labelMainPrismVerR").attr("data-text");
                        bino8FVL = $("#labelMainPrismVerL").attr("data-text");

                        bino8FHRunit = $(".prism-heading-inner-hor-R-BI").attr("data-fixed");
                        bino8FHLunit = $(".prism-heading-inner-hor-L-BI").attr("data-fixed");
                        bino8FVRunit = $(".prism-heading-inner-ver-R-BD").attr("data-fixed");
                        bino8FVLunit = $(".prism-heading-inner-ver-L-BD").attr("data-fixed");
                        break;
                    case "N":
                        bino8NHR = $("#labelMainPrismHorR").attr("data-text");
                        bino8NHL = $("#labelMainPrismHorL").attr("data-text");
                        bino8NVR = $("#labelMainPrismVerR").attr("data-text");
                        bino8NVL = $("#labelMainPrismVerL").attr("data-text");

                        bino8NHRunit = $(".prism-heading-inner-hor-R-BI").attr("data-fixed");
                        bino8NHLunit = $(".prism-heading-inner-hor-L-BI").attr("data-fixed");
                        bino8NVRunit = $(".prism-heading-inner-ver-R-BD").attr("data-fixed");
                        bino8NVLunit = $(".prism-heading-inner-ver-L-BD").attr("data-fixed");
                        break;
                    default:
                        // becky.assertion.failure("unknown SCA");
                        break;
                }
                break;
            case "9":
                switch (farNear.toUpperCase()) {
                    case "FN":
                    case "F":
                        bino9FHR = $("#labelMainPrismHorR").attr("data-text");
                        bino9FHL = $("#labelMainPrismHorL").attr("data-text");
                        bino9FVR = $("#labelMainPrismVerR").attr("data-text");
                        bino9FVL = $("#labelMainPrismVerL").attr("data-text");

                        bino9FHRunit = $(".prism-heading-inner-hor-R-BI").attr("data-fixed");
                        bino9FHLunit = $(".prism-heading-inner-hor-L-BI").attr("data-fixed");
                        bino9FVRunit = $(".prism-heading-inner-ver-R-BD").attr("data-fixed");
                        bino9FVLunit = $(".prism-heading-inner-ver-L-BD").attr("data-fixed");
                        bino9FHRR1 = $("#labelABI2").attr("data-text");
                        bino9FHRR2 = $("#labelABR2").attr("data-text");
                        bino9FHRR3 = $("#labelAR2").attr("data-text");
                        bino9FHRR4 = $("#labelABO2").attr("data-text");
                        bino9FHRR5 = $("#labelABRO2").attr("data-text");
                        bino9FHRR6 = $("#labelARO2").attr("data-text");

                        break;
                    case "N":
                        bino9NHR = $("#labelMainPrismHorR").attr("data-text");
                        bino9NHL = $("#labelMainPrismHorL").attr("data-text");
                        bino9NVR = $("#labelMainPrismVerR").attr("data-text");
                        bino9NVL = $("#labelMainPrismVerL").attr("data-text");

                        bino9NHRunit = $(".prism-heading-inner-hor-R-BI").attr("data-fixed");
                        bino9NHLunit = $(".prism-heading-inner-hor-L-BI").attr("data-fixed");
                        bino9NVRunit = $(".prism-heading-inner-ver-R-BD").attr("data-fixed");
                        bino9NVLunit = $(".prism-heading-inner-ver-L-BD").attr("data-fixed");
                        break;
                    default:
                        // becky.assertion.failure("unknown SCA");
                        break;
                }
                break;
            case "10":
                switch (farNear.toUpperCase()) {
                    case "FN":
                    case "F":
                        bino10FHR = $("#labelMainPrismHorR").attr("data-text");
                        bino10FHL = $("#labelMainPrismHorL").attr("data-text");
                        bino10FVR = $("#labelMainPrismVerR").attr("data-text");
                        bino10FVL = $("#labelMainPrismVerL").attr("data-text");

                        bino10FHRunit = $(".prism-heading-inner-hor-R-BI").attr("data-fixed");
                        bino10FHLunit = $(".prism-heading-inner-hor-L-BI").attr("data-fixed");
                        bino10FVRunit = $(".prism-heading-inner-ver-R-BD").attr("data-fixed");
                        bino10FVLunit = $(".prism-heading-inner-ver-L-BD").attr("data-fixed");
                        break;
                    case "N":
                        bino10NHR = $("#labelMainPrismHorR").attr("data-text");
                        bino10NHL = $("#labelMainPrismHorL").attr("data-text");
                        bino10NVR = $("#labelMainPrismVerR").attr("data-text");
                        bino10NVL = $("#labelMainPrismVerL").attr("data-text");

                        bino10NHRunit = $(".prism-heading-inner-hor-R-BI").attr("data-fixed");
                        bino10NHLunit = $(".prism-heading-inner-hor-L-BI").attr("data-fixed");
                        bino10NVRunit = $(".prism-heading-inner-ver-R-BD").attr("data-fixed");
                        bino10NVLunit = $(".prism-heading-inner-ver-L-BD").attr("data-fixed");
						
						bino10FHRR1 = $("#labelABI").attr("data-text");
                        bino10FHRR2 = $("#labelABR").attr("data-text");
                        bino10FHRR3 = $("#labelAR").attr("data-text");
                        bino10FHRR4 = $("#labelABO").attr("data-text");
                        bino10FHRR5 = $("#labelABRO").attr("data-text");
                        bino10FHRR6 = $("#labelARO").attr("data-text");
                        break;
                    default:
                        // becky.assertion.failure("unknown SCA");
                        break;
                }
                break;
            case "11":
                switch (farNear.toUpperCase()) {
                    case "FN":
                    case "F":
                        bino11FHR = $("#labelMainPrismHorR").attr("data-text");
                        bino11FHL = $("#labelMainPrismHorL").attr("data-text");
                        bino11FVR = $("#labelMainPrismVerR").attr("data-text");
                        bino11FVL = $("#labelMainPrismVerL").attr("data-text");

                        bino11FHRunit = $(".prism-heading-inner-hor-R-BI").attr("data-fixed");
                        bino11FHLunit = $(".prism-heading-inner-hor-L-BI").attr("data-fixed");
                        bino11FVRunit = $(".prism-heading-inner-ver-R-BD").attr("data-fixed");
                        bino11FVLunit = $(".prism-heading-inner-ver-L-BD").attr("data-fixed");
                        break;
                    case "N":
                        bino11NHR = $("#labelMainPrismHorR").attr("data-text");
                        bino11NHL = $("#labelMainPrismHorL").attr("data-text");
                        bino11NVR = $("#labelMainPrismVerR").attr("data-text");
                        bino11NVL = $("#labelMainPrismVerL").attr("data-text");

                        bino11NHRunit = $(".prism-heading-inner-hor-R-BI").attr("data-fixed");
                        bino11NHLunit = $(".prism-heading-inner-hor-L-BI").attr("data-fixed");
                        bino11NVRunit = $(".prism-heading-inner-ver-R-BD").attr("data-fixed");
                        bino11NVLunit = $(".prism-heading-inner-ver-L-BD").attr("data-fixed");
                        break;
                    default:
                        // becky.assertion.failure("unknown SCA");
                        break;
                }
                break;
            case "12":
                switch (farNear.toUpperCase()) {
                    case "FN":
                    case "F":
                        bino12FHR = $("#labelMainPrismHorR").attr("data-text");
                        bino12FHL = $("#labelMainPrismHorL").attr("data-text");
                        bino12FVR = $("#labelMainPrismVerR").attr("data-text");
                        bino12FVL = $("#labelMainPrismVerL").attr("data-text");

                        bino12FHRunit = $(".prism-heading-inner-hor-R-BI").attr("data-fixed");
                        bino12FHLunit = $(".prism-heading-inner-hor-L-BI").attr("data-fixed");
                        bino12FVRunit = $(".prism-heading-inner-ver-R-BD").attr("data-fixed");
                        bino12FVLunit = $(".prism-heading-inner-ver-L-BD").attr("data-fixed");

                        bino12FHRR1 = $("#labelABO").attr("data-text");
                        bino12FHRR2 = $("#labelABRO").attr("data-text");

                        break;
                    case "N":
                        bino12NHR = $("#labelMainPrismHorR").attr("data-text");
                        bino12NHL = $("#labelMainPrismHorL").attr("data-text");
                        bino12NVR = $("#labelMainPrismVerR").attr("data-text");
                        bino12NVL = $("#labelMainPrismVerL").attr("data-text");

                        bino12NHRunit = $(".prism-heading-inner-hor-R-BI").attr("data-fixed");
                        bino12NHLunit = $(".prism-heading-inner-hor-L-BI").attr("data-fixed");
                        bino12NVRunit = $(".prism-heading-inner-ver-R-BD").attr("data-fixed");
                        bino12NVLunit = $(".prism-heading-inner-ver-L-BD").attr("data-fixed");
                        break;
                    default:
                        // becky.assertion.failure("unknown SCA");
                        break;
                }
                break;
            case "13":
                switch (farNear.toUpperCase()) {
                    case "FN":
                    case "F":
                        bino13FHR = $("#labelMainPrismHorR").attr("data-text");
                        bino13FHL = $("#labelMainPrismHorL").attr("data-text");
                        bino13FVR = $("#labelMainPrismVerR").attr("data-text");
                        bino13FVL = $("#labelMainPrismVerL").attr("data-text");

                        bino13FHRunit = $(".prism-heading-inner-hor-R-BI").attr("data-fixed");
                        bino13FHLunit = $(".prism-heading-inner-hor-L-BI").attr("data-fixed");
                        bino13FVRunit = $(".prism-heading-inner-ver-R-BD").attr("data-fixed");
                        bino13FVLunit = $(".prism-heading-inner-ver-L-BD").attr("data-fixed");
                        break;
                    case "N":
                        bino13NHR = $("#labelMainPrismHorR").attr("data-text");
                        bino13NHL = $("#labelMainPrismHorL").attr("data-text");
                        bino13NVR = $("#labelMainPrismVerR").attr("data-text");
                        bino13NVL = $("#labelMainPrismVerL").attr("data-text");

                        bino13NHRunit = $(".prism-heading-inner-hor-R-BI").attr("data-fixed");
                        bino13NHLunit = $(".prism-heading-inner-hor-L-BI").attr("data-fixed");
                        bino13NVRunit = $(".prism-heading-inner-ver-R-BD").attr("data-fixed");
                        bino13NVLunit = $(".prism-heading-inner-ver-L-BD").attr("data-fixed");
                        break;
                    default:
                        // becky.assertion.failure("unknown SCA");
                        break;
                }
                break;
            case "14":
                switch (farNear.toUpperCase()) {
                    case "FN":
                    case "F":
                        bino14FHR = $("#labelMainPrismHorR").attr("data-text");
                        bino14FHL = $("#labelMainPrismHorL").attr("data-text");
                        bino14FVR = $("#labelMainPrismVerR").attr("data-text");
                        bino14FVL = $("#labelMainPrismVerL").attr("data-text");

                        bino14FHRunit = $(".prism-heading-inner-hor-R-BI").attr("data-fixed");
                        bino14FHLunit = $(".prism-heading-inner-hor-L-BI").attr("data-fixed");
                        bino14FVRunit = $(".prism-heading-inner-ver-R-BD").attr("data-fixed");
                        bino14FVLunit = $(".prism-heading-inner-ver-L-BD").attr("data-fixed");
                        break;
                    case "N":
                        bino14NHR = $("#labelMainPrismHorR").attr("data-text");
                        bino14NHL = $("#labelMainPrismHorL").attr("data-text");
                        bino14NVR = $("#labelMainPrismVerR").attr("data-text");
                        bino14NVL = $("#labelMainPrismVerL").attr("data-text");

                        bino14NHRunit = $(".prism-heading-inner-hor-R-BI").attr("data-fixed");
                        bino14NHLunit = $(".prism-heading-inner-hor-L-BI").attr("data-fixed");
                        bino14NVRunit = $(".prism-heading-inner-ver-R-BD").attr("data-fixed");
                        bino14NVLunit = $(".prism-heading-inner-ver-L-BD").attr("data-fixed");
                        break;
                    default:
                        // becky.assertion.failure("unknown SCA");
                        break;
                }
                break;
            case "15":
                switch (farNear.toUpperCase()) {
                    case "FN":
                    case "F":
                        bino15FHR = $("#labelMainPrismHorR").attr("data-text");
                        bino15FHL = $("#labelMainPrismHorL").attr("data-text");
                        bino15FVR = $("#labelMainPrismVerR").attr("data-text");
                        bino15FVL = $("#labelMainPrismVerL").attr("data-text");

                        bino15FHRunit = $(".prism-heading-inner-hor-R-BI").attr("data-fixed");
                        bino15FHLunit = $(".prism-heading-inner-hor-L-BI").attr("data-fixed");
                        bino15FVRunit = $(".prism-heading-inner-ver-R-BD").attr("data-fixed");
                        bino15FVLunit = $(".prism-heading-inner-ver-L-BD").attr("data-fixed");
                        break;
                    case "N":
                        bino15NHR = $("#labelMainPrismHorR").attr("data-text");
                        bino15NHL = $("#labelMainPrismHorL").attr("data-text");
                        bino15NVR = $("#labelMainPrismVerR").attr("data-text");
                        bino15NVL = $("#labelMainPrismVerL").attr("data-text");

                        bino15NHRunit = $(".prism-heading-inner-hor-R-BI").attr("data-fixed");
                        bino15NHLunit = $(".prism-heading-inner-hor-L-BI").attr("data-fixed");
                        bino15NVRunit = $(".prism-heading-inner-ver-R-BD").attr("data-fixed");
                        bino15NVLunit = $(".prism-heading-inner-ver-L-BD").attr("data-fixed");
                        break;
                    default:
                        // becky.assertion.failure("unknown SCA");
                        break;
                }
                break;
            case "16":
                switch (farNear.toUpperCase()) {
                    case "FN":
                    case "F":
                        bino16FHR = $("#labelMainPrismHorR").attr("data-text");
                        bino16FHL = $("#labelMainPrismHorL").attr("data-text");
                        bino16FVR = $("#labelMainPrismVerR").attr("data-text");
                        bino16FVL = $("#labelMainPrismVerL").attr("data-text");

                        bino16FHRunit = $(".prism-heading-inner-hor-R-BI").attr("data-fixed");
                        bino16FHLunit = $(".prism-heading-inner-hor-L-BI").attr("data-fixed");
                        bino16FVRunit = $(".prism-heading-inner-ver-R-BD").attr("data-fixed");
                        bino16FVLunit = $(".prism-heading-inner-ver-L-BD").attr("data-fixed");
                        break;
                    case "N":
                        bino16NHR = $("#labelMainPrismHorR").attr("data-text");
                        bino16NHL = $("#labelMainPrismHorL").attr("data-text");
                        bino16NVR = $("#labelMainPrismVerR").attr("data-text");
                        bino16NVL = $("#labelMainPrismVerL").attr("data-text");

                        bino16NHRunit = $(".prism-heading-inner-hor-R-BI").attr("data-fixed");
                        bino16NHLunit = $(".prism-heading-inner-hor-L-BI").attr("data-fixed");
                        bino16NVRunit = $(".prism-heading-inner-ver-R-BD").attr("data-fixed");
                        bino16NVLunit = $(".prism-heading-inner-ver-L-BD").attr("data-fixed");
                        break;
                    default:
                        // becky.assertion.failure("unknown SCA");
                        break;
                }
                break;
            case "17":
                switch (farNear.toUpperCase()) {
                    case "FN":
                    case "F":
                        bino17FHR = $("#labelMainPrismHorR").attr("data-text");
                        bino17FHL = $("#labelMainPrismHorL").attr("data-text");
                        bino17FVR = $("#labelMainPrismVerR").attr("data-text");
                        bino17FVL = $("#labelMainPrismVerL").attr("data-text");

                        bino17FHRunit = $(".prism-heading-inner-hor-R-BI").attr("data-fixed");
                        bino17FHLunit = $(".prism-heading-inner-hor-L-BI").attr("data-fixed");
                        bino17FVRunit = $(".prism-heading-inner-ver-R-BD").attr("data-fixed");
                        bino17FVLunit = $(".prism-heading-inner-ver-L-BD").attr("data-fixed");
                        break;
                    case "N":
                        bino17NHR = $("#labelMainPrismHorR").attr("data-text");
                        bino17NHL = $("#labelMainPrismHorL").attr("data-text");
                        bino17NVR = $("#labelMainPrismVerR").attr("data-text");
                        bino17NVL = $("#labelMainPrismVerL").attr("data-text");

                        bino17NHRunit = $(".prism-heading-inner-hor-R-BI").attr("data-fixed");
                        bino17NHLunit = $(".prism-heading-inner-hor-L-BI").attr("data-fixed");
                        bino17NVRunit = $(".prism-heading-inner-ver-R-BD").attr("data-fixed");
                        bino17NVLunit = $(".prism-heading-inner-ver-L-BD").attr("data-fixed");
                        break;
                    default:
                        // becky.assertion.failure("unknown SCA");
                        break;
                }
                break;

            default:
                //becky.assertion.failure("unknown eye");
                break;
        }


        //console.log(chartindex);


        const json = {
            "bino1FHR": bino1FHR,
            "bino1FHL": bino1FHL,
            "bino1FVR": bino1FVR,
            "bino1FVL": bino1FVL,
            "bino1FHRunit": bino1FHRunit,
            "bino1FHLunit": bino1FHLunit,
            "bino1FVRunit": bino1FVRunit,
            "bino1FVLunit": bino1FVLunit,
            "bino1NHR": bino1NHR,
            "bino1NHL": bino1NHL,
            "bino1NVR": bino1NVR,
            "bino1NVL": bino1NVL,
            "bino1NHRunit": bino1NHRunit,
            "bino1NHLunit": bino1NHLunit,
            "bino1NVRunit": bino1NVRunit,
            "bino1NVLunit": bino1NVLunit,
            "bino2FHR": bino2FHR,
            "bino2FHL": bino2FHL,
            "bino2FVR": bino2FVR,
            "bino2FVL": bino2FVL,
            "bino2FHRunit": bino2FHRunit,
            "bino2FHLunit": bino2FHLunit,
            "bino2FVRunit": bino2FVRunit,
            "bino2FVLunit": bino2FVLunit,
            "bino2NHR": bino2NHR,
            "bino2NHL": bino2NHL,
            "bino2NVR": bino2NVR,
            "bino2NVL": bino2NVL,
            "bino2NHRunit": bino2NHRunit,
            "bino2NHLunit": bino2NHLunit,
            "bino2NVRunit": bino2NVRunit,
            "bino2NVLunit": bino2NVLunit,
            "bino3FHR": bino3FHR,
            "bino3FHL": bino3FHL,
            "bino3FVR": bino3FVR,
            "bino3FVL": bino3FVL,
            "bino3FHRunit": bino3FHRunit,
            "bino3FHLunit": bino3FHLunit,
            "bino3FVRunit": bino3FVRunit,
            "bino3FVLunit": bino3FVLunit,
            "bino3NHR": bino3NHR,
            "bino3NHL": bino3NHL,
            "bino3NVR": bino3NVR,
            "bino3NVL": bino3NVL,
            "bino3NHRunit": bino3NHRunit,
            "bino3NHLunit": bino3NHLunit,
            "bino3NVRunit": bino3NVRunit,
            "bino3NVLunit": bino3NVLunit,
            "bino4FHR": bino4FHR,
            "bino4FHL": bino4FHL,
            "bino4FVR": bino4FVR,
            "bino4FVL": bino4FVL,
            "bino4FHRunit": bino4FHRunit,
            "bino4FHLunit": bino4FHLunit,
            "bino4FVRunit": bino4FVRunit,
            "bino4FVLunit": bino4FVLunit,
            "bino4NHR": bino4NHR,
            "bino4NHL": bino4NHL,
            "bino4NVR": bino4NVR,
            "bino4NVL": bino4NVL,
            "bino4NHRunit": bino4NHRunit,
            "bino4NHLunit": bino4NHLunit,
            "bino4NVRunit": bino4NVRunit,
            "bino4NVLunit": bino4NVLunit,
            "bino5FHR": bino5FHR,
            "bino5FHL": bino5FHL,
            "bino5FVR": bino5FVR,
            "bino5FVL": bino5FVL,
            "bino5FHRunit": bino5FHRunit,
            "bino5FHLunit": bino5FHLunit,
            "bino5FVRunit": bino5FVRunit,
            "bino5FVLunit": bino5FVLunit,
            "bino5FHRR1": bino5FHRR1,
            "bino5FHRR1unit": bino5FHRR1unit,
            "bino5NHR": bino5NHR,
            "bino5NHL": bino5NHL,
            "bino5NVR": bino5NVR,
            "bino5NVL": bino5NVL,
            "bino5NHRunit": bino5NHRunit,
            "bino5NHLunit": bino5NHLunit,
            "bino5NVRunit": bino5NVRunit,
            "bino5NVLunit": bino5NVLunit,
            "bino5NHRR1": bino5NHRR1,
            "bino5NHRR1unit": bino5NHRR1unit,
            "bino6FHR": bino6FHR,
            "bino6FHL": bino6FHL,
            "bino6FVR": bino6FVR,
            "bino6FVL": bino6FVL,
            "bino6FHRunit": bino6FHRunit,
            "bino6FHLunit": bino6FHLunit,
            "bino6FVRunit": bino6FVRunit,
            "bino6FVLunit": bino6FVLunit,
            "bino6FHRR1": bino6FHRR1,
            "bino6FHRR1unit": bino6FHRR1unit,
            "bino6NHR": bino6NHR,
            "bino6NHL": bino6NHL,
            "bino6NVR": bino6NVR,
            "bino6NVL": bino6NVL,
            "bino6NHRunit": bino6NHRunit,
            "bino6NHLunit": bino6NHLunit,
            "bino6NVRunit": bino6NVRunit,
            "bino6NVLunit": bino6NVLunit,
            "bino6NHRR1": bino6NHRR1,
            "bino6NHRR1unit": bino6NHRR1unit,
            "bino7FHR": bino7FHR,
            "bino7FHL": bino7FHL,
            "bino7FVR": bino7FVR,
            "bino7FVL": bino7FVL,
            "bino7FHRunit": bino7FHRunit,
            "bino7FHLunit": bino7FHLunit,
            "bino7FVRunit": bino7FVRunit,
            "bino7FVLunit": bino7FVLunit,
            "bino7NHR": bino7NHR,
            "bino7NHL": bino7NHL,
            "bino7NVR": bino7NVR,
            "bino7NVL": bino7NVL,
            "bino7NHRunit": bino7NHRunit,
            "bino7NHLunit": bino7NHLunit,
            "bino7NVRunit": bino7NVRunit,
            "bino7NVLunit": bino7NVLunit,
            "bino8FHR": bino8FHR,
            "bino8FHL": bino8FHL,
            "bino8FVR": bino8FVR,
            "bino8FVL": bino8FVL,
            "bino8FHRunit": bino8FHRunit,
            "bino8FHLunit": bino8FHLunit,
            "bino8FVRunit": bino8FVRunit,
            "bino8FVLunit": bino8FVLunit,
            "bino8NHR": bino8NHR,
            "bino8NHL": bino8NHL,
            "bino8NVR": bino8NVR,
            "bino8NVL": bino8NVL,
            "bino8NHRunit": bino8NHRunit,
            "bino8NHLunit": bino8NHLunit,
            "bino8NVRunit": bino8NVRunit,
            "bino8NVLunit": bino8NVLunit,
            "bino9FHR": bino9FHR,
            "bino9FHL": bino9FHL,
            "bino9FVR": bino9FVR,
            "bino9FVL": bino9FVL,
            "bino9FHRunit": bino9FHRunit,
            "bino9FHLunit": bino9FHLunit,
            "bino9FVRunit": bino9FVRunit,
            "bino9FVLunit": bino9FVLunit,
            "bino9FHRR1": bino9FHRR1,
            "bino9FHRR2": bino9FHRR2,
            "bino9FHRR3": bino9FHRR3,
            "bino9FHRR4": bino9FHRR4,
            "bino9FHRR5": bino9FHRR5,
            "bino9FHRR6": bino9FHRR6,
            "bino9FHRR1unit": bino9FHRR1unit,
            "bino9FHRR2unit": bino9FHRR2unit,
            "bino9FHRR3unit": bino9FHRR3unit,
            "bino9FHRR4unit": bino9FHRR4unit,
            "bino9FHRR5unit": bino9FHRR5unit,
            "bino9FHRR6unit": bino9FHRR6unit,
            "bino9NHR": bino9NHR,
            "bino9NHL": bino9NHL,
            "bino9NVR": bino9NVR,
            "bino9NVL": bino9NVL,
            "bino9NHRunit": bino9NHRunit,
            "bino9NHLunit": bino9NHLunit,
            "bino9NVRunit": bino9NVRunit,
            "bino9NVLunit": bino9NVLunit,
            "bino10FHR": bino10FHR,
            "bino10FHL": bino10FHL,
            "bino10FVR": bino10FVR,
            "bino10FVL": bino10FVL,
            "bino10FHRunit": bino10FHRunit,
            "bino10FHLunit": bino10FHLunit,
            "bino10FVRunit": bino10FVRunit,
            "bino10FVLunit": bino10FVLunit,
            "bino10NHR": bino10NHR,
            "bino10NHL": bino10NHL,
            "bino10NVR": bino10NVR,
            "bino10NVL": bino10NVL,
            "bino10NHRunit": bino10NHRunit,
            "bino10NHLunit": bino10NHLunit,
            "bino10NVRunit": bino10NVRunit,
            "bino10NVLunit": bino10NVLunit,
			"bino10NHRR1": bino10NHRR1,
            "bino10NHRR2": bino10NHRR2,
            "bino10NHRR3": bino10NHRR3,
            "bino10NHRR4": bino10NHRR4,
            "bino10NHRR5": bino10NHRR5,
            "bino10NHRR6": bino10NHRR6,
            "bino10NHRR1unit": bino10NHRR1unit,
            "bino10NHRR2unit": bino10NHRR2unit,
            "bino10NHRR3unit": bino10NHRR3unit,
            "bino10NHRR4unit": bino10NHRR4unit,
            "bino10NHRR5unit": bino10NHRR5unit,
            "bino10NHRR6unit": bino10NHRR6unit,
            "bino11FHR": bino11FHR,
            "bino11FHL": bino11FHL,
            "bino11FVR": bino11FVR,
            "bino11FVL": bino11FVL,
            "bino11FHRunit": bino11FHRunit,
            "bino11FHLunit": bino11FHLunit,
            "bino11FVRunit": bino11FVRunit,
            "bino11FVLunit": bino11FVLunit,
            "bino11NHR": bino11NHR,
            "bino11NHL": bino11NHL,
            "bino11NVR": bino11NVR,
            "bino11NVL": bino11NVL,
            "bino11NHRunit": bino11NHRunit,
            "bino11NHLunit": bino11NHLunit,
            "bino11NVRunit": bino11NVRunit,
            "bino11NVLunit": bino11NVLunit,
            "bino12FHR": bino12FHR,
            "bino12FHL": bino12FHL,
            "bino12FVR": bino12FVR,
            "bino12FVL": bino12FVL,
            "bino12FHRunit": bino12FHRunit,
            "bino12FHLunit": bino12FHLunit,
            "bino12FVRunit": bino12FVRunit,
            "bino12FVLunit": bino12FVLunit,
            "bino12FHRR1": bino12FHRR1,
            "bino12FHRR2": bino12FHRR2,
            "bino12FHRR1unit": bino12FHRR1unit,
            "bino12FHRR2unit": bino12FHRR2unit,
            "bino12NHR": bino12NHR,
            "bino12NHL": bino12NHL,
            "bino12NVR": bino12NVR,
            "bino12NVL": bino12NVL,
            "bino12NHRunit": bino12NHRunit,
            "bino12NHLunit": bino12NHLunit,
            "bino12NVRunit": bino12NVRunit,
            "bino12NVLunit": bino12NVLunit,
            "bino13FHR": bino13FHR,
            "bino13FHL": bino13FHL,
            "bino13FVR": bino13FVR,
            "bino13FVL": bino13FVL,
            "bino13FHRunit": bino13FHRunit,
            "bino13FHLunit": bino13FHLunit,
            "bino13FVRunit": bino13FVRunit,
            "bino13FVLunit": bino13FVLunit,
            "bino13FHRR3": bino13FHRR3,
            "bino13FHRR4": bino13FHRR4,
            "bino13FHRR3unit": bino13FHRR3unit,
            "bino13FHRR4unit": bino13FHRR4unit,
            "bino13NHR": bino13NHR,
            "bino13NHL": bino13NHL,
            "bino13NVR": bino13NVR,
            "bino13NVL": bino13NVL,
            "bino13NHRunit": bino13NHRunit,
            "bino13NHLunit": bino13NHLunit,
            "bino13NVRunit": bino13NVRunit,
            "bino13NVLunit": bino13NVLunit,
            "bino14FHR": bino14FHR,
            "bino14FHL": bino14FHL,
            "bino14FVR": bino14FVR,
            "bino14FVL": bino14FVL,
            "bino14FHRunit": bino14FHRunit,
            "bino14FHLunit": bino14FHLunit,
            "bino14FVRunit": bino14FVRunit,
            "bino14FVLunit": bino14FVLunit,
            "bino14FHRR1": bino14FHRR1,
            "bino14FHRR2": bino14FHRR2,
            "bino14FHRR3": bino14FHRR3,
            "bino14FHRR1unit": bino14FHRR1unit,
            "bino14FHRR2unit": bino14FHRR2unit,
            "bino14FHRR3unit": bino14FHRR3unit,
            "bino14NHR": bino14NHR,
            "bino14NHL": bino14NHL,
            "bino14NVR": bino14NVR,
            "bino14NVL": bino14NVL,
            "bino14NHRunit": bino14NHRunit,
            "bino14NHLunit": bino14NHLunit,
            "bino14NVRunit": bino14NVRunit,
            "bino14NVLunit": bino14NVLunit,
            "bino15FHR": bino15FHR,
            "bino15FHL": bino15FHL,
            "bino15FVR": bino15FVR,
            "bino15FVL": bino15FVL,
            "bino15FHRunit": bino15FHRunit,
            "bino15FHLunit": bino15FHLunit,
            "bino15FVRunit": bino15FVRunit,
            "bino15FVLunit": bino15FVLunit,
            "bino15FHRR4": bino15FHRR4,
            "bino15FHRR5": bino15FHRR5,
            "bino15FHRR6": bino15FHRR6,
            "bino15FHRR4unit": bino15FHRR4unit,
            "bino15FHRR5unit": bino15FHRR5unit,
            "bino15FHRR6unit": bino15FHRR6unit,
            "bino15NHR": bino15NHR,
            "bino15NHL": bino15NHL,
            "bino15NVR": bino15NVR,
            "bino15NVL": bino15NVL,
            "bino15NHRunit": bino15NHRunit,
            "bino15NHLunit": bino15NHLunit,
            "bino15NVRunit": bino15NVRunit,
            "bino15NVLunit": bino15NVLunit,
            "bino16FHR": bino16FHR,
            "bino16FHL": bino16FHL,
            "bino16FVR": bino16FVR,
            "bino16FVL": bino16FVL,
            "bino16FHRunit": bino16FHRunit,
            "bino16FHLunit": bino16FHLunit,
            "bino16FVRunit": bino16FVRunit,
            "bino16FVLunit": bino16FVLunit,
            "bino16FHRR1": bino16FHRR1,
            "bino16FHRR2": bino16FHRR2,
            "bino16FHRR1unit": bino16FHRR1unit,
            "bino16FHRR2unit": bino16FHRR2unit,
            "bino16NHR": bino16NHR,
            "bino16NHL": bino16NHL,
            "bino16NVR": bino16NVR,
            "bino16NVL": bino16NVL,
            "bino16NHRunit": bino16NHRunit,
            "bino16NHLunit": bino16NHLunit,
            "bino16NVRunit": bino16NVRunit,
            "bino16NVLunit": bino16NVLunit,
            "bino17FHR": bino17FHR,
            "bino17FHL": bino17FHL,
            "bino17FVR": bino17FVR,
            "bino17FVL": bino17FVL,
            "bino17FHRunit": bino17FHRunit,
            "bino17FHLunit": bino17FHLunit,
            "bino17FVRunit": bino17FVRunit,
            "bino17FVLunit": bino17FVLunit,
            "bino17FHRR3": bino17FHRR3,
            "bino17FHRR4": bino17FHRR4,
            "bino17FHRR3unit": bino17FHRR3unit,
            "bino17FHRR4unit": bino17FHRR4unit,
            "bino17NHR": bino17NHR,
            "bino17NHL": bino17NHL,
            "bino17NVR": bino17NVR,
            "bino17NVL": bino17NVL,
            "bino17NHRunit": bino17NHRunit,
            "bino17NHLunit": bino17NHLunit,
            "bino17NVRunit": bino17NVRunit,
            "bino17NVLunit": bino17NVLunit

        }
        console.log(json);
        return json;



    }

    /*!
     * @brief 更新(画面の状態)
     *
     * @param[in] object aModel 引数が未指定:View→Model, 引数有り:Model→View
     * @return object 戻り値が存在するのは View→Model のみ
     */
    function _updateDataScreenState(aModel) {
        if (modelHelper.isUndefined(aModel)) {
            // View -> Model
            const json = {
                //isBgInvert  : $(".chart-table .bg").hasClass("bg-invert"),
                //isBgRG      : $(".chart-table .bg").hasClass("bg-rg"),
                examTitle: $("#labelExamTitle").attr("data-text"),
                farNear: _getSelectFarNear(),
                binoMono: _getSelectBinoMono(),
                crossCylinderIndex: $("#groupCrossCylinder").attr("data-select-index"),
                currentEye: _getSelectEye(),
                currentSCA: _getSelectSCA(),
                currentAutoID: $("#currentAutoID").attr("data-value"),
            };
            // データの正規化
            becky.jsonHelper.normalization(json);
            return json;
        } else {
            // Model -> View

            // Todo. リーンスタートアップでは isBgInvert, isBgRG は保留

            $("#labelExamTitle").attr("data-text", aModel.examTitle);
            $("#btnMenuFarNear").val(aModel.farNear);
            $("#btnMenuBinoMono").val(aModel.binoMono);
            $("#groupCrossCylinder").attr("data-select-index", aModel.crossCylinderIndex);
            _setSelectEye(aModel.currentEye);
            _setSelectSCA(aModel.currentSCA);
            $("#currentAutoID").attr("data-value", aModel.currentAutoID);
        }
    }

    /*!
     * @brief 更新(全て)
     *
     * @param[in] object aModel 引数が未指定:View→Model, 引数有り:Model→View
     * @return object 戻り値が存在するのは View→Model のみ
     */
    function _updateData(aModel) {

        if (modelHelper.isUndefined(aModel)) {
            // View -> Model
            return {
                sessionPatientID: becky.session.sessionPatientID,
                measurementValue: _updateDataMeasurementValue(),
                screenState: _updateDataScreenState(),
                prismstate: getsamechartIDvalues(),
                binostate: setBinoTestvalues()
            };


        } else {
            // Model -> View
            _updateDataMeasurementValue(aModel.measurementValue);
            _updateDataScreenState(aModel.screenState);
            getsamechartIDvalues(aModel.prismstate);
            setBinoTestvalues(aModel.binostate);

        }

    }


    $(document).ready(function () {

        // 端末に一時保存されているものがあれば復元
        {
            const updateDataJson = becky.WebStorage.local.getJson("subjective.update.data");
            if (!modelHelper.isNullOrEmpty(updateDataJson) &&
                becky.session.sessionPatientID === updateDataJson.sessionPatientID) {
                const upd = _updateData(updateDataJson);
                //const upd = _updateData(ChartContainer);

            }

        }

        // data-text 属性を監視するオプション(MutationObserverInit)
        const optionsAttributeFilterDataValue = {
            attributes: true,
            attributeFilter: ["data-value"],
        };

        (async function () {
            try {
                becky.operatorLog.createSubjectiveNode();

                const resetOptParamLR = {
                    LED: {
                        Fixation: "Off",
                    },
                    OpticalPath: false,
                };
                await becky.LeanStartup.post("ResetOpt", {
                    L: resetOptParamLR,
                    R: resetOptParamLR,
                });

                // 視標の設定
                await _postChartCommand(_currentChart);
                // フォロプター
                await _postPhoropterCommand(_currentChart);
                // 端末に一時保存(リロード対策)
                _saveDataToWebStorage();
            } catch (resultJson) {
                // 失敗
                // エラーメッセージ表示
                //becky.LeanStartup.alertErrorMessage(resultJson);
            } finally {
                // 次へ遷移可能
                becky.navi.showNext();
            }
        }());

        //! @brief 近見が(一度でも)選択されたか？
        let isSelectedNear = false;

        // クリック時にカレントの切り替えを行う
        $(".current").parent().children().click(function () {
            viewHelper.selectClassSingle("current", $(this));
        });

        // タブヘッダ(Tab header)
        $(".tab-box .tab-header").click(function () {
            const $tabHeader = $(this);
            $("#tabChart").attr("data-tab-index", $tabHeader.index());
        }); {
            const optionsAttributeFilterTabIndex = {
                attributes: true,
                attributeFilter: ["data-tab-index"],
            };
            becky.MutationObserver.byID(
                "#tabChart",
                records => records.forEach(record_ => {
                    const target = record_.target;
                    const tabIndex = target.dataset.tabIndex;
                    const $tab = $(".tab-box .tab-content-group .tab-content").eq(tabIndex);
                    if (!becky.assertion.isNullOrEmpty($tab)) {
                        viewHelper.selectClassSingle("current", $tab);

                    }
                    const $tabHead = $(".tab-box .tab-header-group .tab-header").eq(tabIndex);
                    if (!becky.assertion.isNullOrEmpty($tabHead)) {
                        viewHelper.selectClassSingle("current", $tabHead);

                    }
                }),
                optionsAttributeFilterTabIndex);
        }

        // ドロップダウンリスト
        $(".select-box .select-title").each((i, element) => {
            _updateSelectTitle($(element));
        });
        $(".select-box .select-selector").change(function () {
            _updateSelectTitle($(this).siblings(".select-title"));
        });

        {
            // 左右両眼の監視
            becky.MutationObserver.byID(
                "#currentEye",
                records => records.forEach(record_ => {
                    const target = record_.target;
                    const value = target.dataset.value;
                    switch (value) {
                        case "R":
                            _setSelectEyeR_FromEvent();
                            break;
                        case "L":
                            _setSelectEyeL_FromEvent();
                            break;
                        case "B":
                            _setSelectEyeB_FromEvent();
                            break;
                        default:
                            becky.assertion.failure("unknown eye");
                            break;
                    }
                    // クロスシリンダー
                    _updateCrossCylinderClasses();
                }),
                optionsAttributeFilterDataValue);
            // 左右両眼の変更イベントを呼ぶ(初期化)
            becky.dataSync.callChangeEventAttr(document.getElementById("currentEye"), "data-value");
            // SCA の監視
            /*becky.MutationObserver.byID(
                "#currentSCA",
                records => records.forEach(record_ => {
                    const target = record_.target;
                    const value = target.dataset.value;
                    switch (value) {
                        case "Sph":
                            _setSelectSph_FromEvent();
                            break;
                        case "Cyl":
                            _setSelectCyl_FromEvent();
                            break;
                        case "Axs":
                            _setSelectAxs_FromEvent();
                            break;
                        case "ADD":
                            _setSelectADD_FromEvent();
                            break;
                        case "PrismHor":
                            _setSelectPrismHor_FromEvent();
                            break;
                        case "PrismVer":
                            _setSelectPrismVer_FromEvent();
                            break;
                        default:
                            becky.assertion.failure("unknown eye");
                            break;
                    }
                    // クロスシリンダー
                    _updateCrossCylinderClasses();
                    // +/- ボタンの中央部
                    $(".icon.icon-axis").html(_getDefMessageBySubjective("controller" + value.toUpperCase()));
                }),
                optionsAttributeFilterDataValue);
            // SCA の変更イベントを呼ぶ(初期化)
            becky.dataSync.callChangeEventAttr(document.getElementById("currentSCA"), "data-value");*/
            // AutoID の監視
            becky.MutationObserver.byID(
                "#currentAutoID",
                records => records.forEach(record_ => {
                    const target = record_.target;
                    const value = target.dataset.value;
                    const chart = _getChartByAutoID(becky.subjective.arrayFlatChartPageParameter, value);
                    // if (becky.assertion.isUndefined(chart)) {
                    //     return;
                    // }
                    const chartParameterItem = becky.subjective.arrayChartParameter.chartParameter.filter(
                        chartParameterItem_ => chartParameterItem_.chartID === chart.chartID)[0];
                    // if (becky.assertion.isUndefined(chartParameterItem)) {
                    //     return;
                    // }
                    localStorage['chartindex'] = chartParameterItem.chartID;
                    // getsamechartIDvalues();


                    // 操作コントローラーのレイアウトの更新
                    _updateChartTable(chart);
                    _updateControllerLayout(chart);
                    
                    _updateMenuInit(chart);
                    
                    _updateSelectSCA_FromChart(chart);
                    // カレント更新
                    _setCurrentChart(chart);
                    if (chartParameterItem.IsPrismChart == '1' && chartParameterItem.IsPrismHV == "HV") {
                        $("#labelMainPrismHor").show();
                        $("#labelMainPrismVer").show();
                       // $(".prism-buttons").show();
                        $(".horizontal-icons").show();
                        $(".vertical-icons").hide();
                        $("#labelMainPrismHor").trigger("click");

                    } else if (chartParameterItem.IsPrismChart == '1' && chartParameterItem.IsPrismHV == "H") {
                        $("#labelMainPrismHor").show();
                        $("#labelMainPrismVer").show();
                        $(".horizontal-icons").show();
                        $(".vertical-icons").hide();
                        $("#labelMainPrismHor").trigger("click");
                        $("#btnControllerEyeL").trigger("click");
                    } else if (chartParameterItem.IsPrismChart == '1' && chartParameterItem.IsPrismHV == "V") {
                        $("#labelMainPrismHor").show();
                        $("#labelMainPrismVer").show();
                        $(".horizontal-icons").hide();
                        $(".vertical-icons").show();
                        $("#labelMainPrismVer").trigger("click");
                        $("#btnControllerEyeR").trigger("click");
                    }
                    if (chartParameterItem.IsPrismChart == '2' && chartParameterItem.IsPrismHV == "HV") {
                        $("#labelMainPrismHor").show();
                        $("#labelMainPrismVer").show();
                       // $(".prism-buttons").show();
                        $(".horizontal-icons").show();
                        $(".vertical-icons").hide();
                        //$("#labelMainPrismHor").trigger("click");
                    } else if (chartParameterItem.IsPrismChart == '2' && chartParameterItem.IsPrismHV == "H") {
                        $("#labelMainPrismHor").show();
                        $("#labelMainPrismVer").show();
                        $(".horizontal-icons").show();
                        $(".vertical-icons").hide();
                        _setSelectSCA("PrismHor");
                        $("#btnControllerEyeL").trigger("click");

                    } else if (chartParameterItem.IsPrismChart == '2' && chartParameterItem.IsPrismHV == "V") {
                        $("#labelMainPrismHor").show();
                        $("#labelMainPrismVer").show();
                        $(".horizontal-icons").hide();
                        $(".vertical-icons").show();
                        _setSelectSCA("PrismVer");
                        $("#btnControllerEyeR").trigger("click");

                    }


                    // 視標のサムネイル
                    const $tabContent = $("[data-auto-id=" + chart.autoID + "]");
                    if (!modelHelper.isNull($tabContent)) {
                        if (!$tabContent.hasClass("current")) {
                            // 枠
                            $("[data-auto-id]").removeClass("current");
                            $tabContent.addClass("current");
                            // タブ
                            const $tabContentParent = $tabContent.parent();
                            const tabIndex = $tabContentParent.parent().children().index($tabContentParent);
                            if (tabIndex != $("#tabChart").attr("data-tab-index")) {
                                // 差がある場合のみ反映
                                $("#tabChart").attr("data-tab-index", tabIndex);
                            }
                        }
                    }
                }),
                optionsAttributeFilterDataValue);
            // ChartID の変更イベントを呼ぶ(初期化)
            becky.dataSync.callChangeEventAttr(document.getElementById("currentAutoID"), "data-value");
        }

        // 軸(x) の更新処理
        becky.MutationObserver.byID(
            "btnMenuA",
            records => records.forEach(record_ => {
                const target = record_.target;
                const value = target.dataset.value;
                $("#labelMainAxsStep").text(value);
            }),
            optionsAttributeFilterDataValue);

        // Axis の値の監視
        {
            // data-text 属性を監視するオプション(MutationObserverInit)
            const optionsAttributeFilterDataText = {
                attributes: true,
                attributeFilter: ["data-text"],
                attributeOldValue: true, // 値の変化量が必要
            };
            becky.MutationObserver.bySelectorAll(
                "#labelMainAxsR, #labelMainAxsL",
                records => records.forEach(record_ => {
                    const target = record_.target;
                    const nOldValue = parseInt(record_.oldValue, 10);
                    const nNewValue = parseInt(target.dataset.text, 10);
                    if (nOldValue === nNewValue) {
                        // 差が無い
                        return;
                    }
                    const strRL = target.id.slice(-1);
                    const icon = document.getElementById("iconEyeMark" + strRL);
                    let nDeg = 0;
                    if (isNaN(nOldValue)) {
                        // 絶対値
                        nDeg = -nNewValue; // 逆回転
                    } else {
                        // 相対値
                        let nDiffValue = nOldValue - nNewValue;
                        if (-90 > nDiffValue) {
                            // 想定パターン:5 -> 180
                            nDiffValue = 180 + nDiffValue;
                        } else if (90 < nDiffValue) {
                            // 想定パターン:180 -> 5
                            nDiffValue = nDiffValue - 180;
                        }
                        nDeg = parseInt(icon.dataset.rotate, 10) + nDiffValue;
                    }
                    icon.style.transform = "rotate(" + nDeg + "deg)";
                    icon.dataset.rotate = nDeg;
                }),
                optionsAttributeFilterDataText);
        }

        // メインデータの球面度数エリア
        $("#trMainSph").click(function () {
            if (_isSelectSph()) {
                return;
            }
            const backupSS = _updateDataScreenState(); // 戻せるように記憶しておく
            const backupPP = _createPhoropterParam(_currentChart);
            $("#btnMenuFarNear").val("far");
            _setSelectSCA("Sph");
            //$("#groupCrossCylinder").attr("data-select-index", 0); // クロスシリンダー(1)に戻す
            _updateControllerLayout({
                examID: 1000
            });
            const newPP = _createPhoropterParam(_currentChart);
            if (becky.jsonHelper.isEquals(backupPP, newPP)) {
                // フォロプターコマンドを呼ぶ必要はない
                return;
            }
            (async function () {
                // ボタンを無効化
                const pointerEvents = _getPointerEventsByCommand();
                pointerEvents.begin();
                try {
                    const nLCOS_ID = _createLCOS_CommandID(backupPP, newPP);
                    if (!modelHelper.isNull(nLCOS_ID)) {
                        // LCOS消灯
                        await _postLCOS_Command(nLCOS_ID);
                        try {
                            // フォロプター
                            await _postPhoropterCommand(_currentChart);
                        } finally {
                            // LCOS復帰
                            await _postChartCommand(_currentChart);
                        }
                    } else {
                        // フォロプター
                        await _postPhoropterCommand(_currentChart);
                    }
                    // 端末に一時保存(リロード対策)
                    _saveDataToWebStorage();
                } catch (resultJson) {
                    // 失敗したら値を戻す
                    _updateDataScreenState(backupSS);
                    // エラーメッセージ表示
                    becky.LeanStartup.alertErrorMessage(resultJson);
                } finally {
                    // 完了時にボタンを有効化
                    pointerEvents.end();
                }
            }());
        });

        // メインデータの乱視度数エリア
        $("#trMainCyl").click(function () {
            if (_isSelectCyl()) {
                return;
            }
            const backupSS = _updateDataScreenState(); // 戻せるように記憶しておく
            const backupPP = _createPhoropterParam(_currentChart);
            $("#btnMenuFarNear").val("far");
            _setSelectSCA("Cyl");
            $("#groupCrossCylinder").attr("data-select-index", 0); // クロスシリンダー(1)に戻す
            switch (_currentChart.examID) {
                case 1020: // [遠]乱視テスト
                    _updateControllerLayout({
                        examID: _currentChart.examID
                    });
                    break;
                case 1021: // [遠]ジャクソンクロスシリンダー
                    _updateControllerLayout({
                        examID: _currentChart.examID
                    });
                    break;
                default:
                    _updateControllerLayout({
                        examID: 1020
                    });
                    break;
            }
            const newPP = _createPhoropterParam(_currentChart);
            if (becky.jsonHelper.isEquals(backupPP, newPP)) {
                // フォロプターコマンドを呼ぶ必要はない
                return;
            }
            (async function () {
                // ボタンを無効化
                const pointerEvents = _getPointerEventsByCommand();
                pointerEvents.begin();
                try {
                    const nLCOS_ID = _createLCOS_CommandID(backupPP, newPP);
                    if (!modelHelper.isNull(nLCOS_ID)) {
                        // LCOS消灯
                        await _postLCOS_Command(nLCOS_ID);
                        try {
                            // フォロプター
                            await _postPhoropterCommand(_currentChart);
                        } finally {
                            // LCOS復帰
                            await _postChartCommand(_currentChart);
                        }
                    } else {
                        // フォロプター
                        await _postPhoropterCommand(_currentChart);
                    }
                    // 端末に一時保存(リロード対策)
                    _saveDataToWebStorage();
                } catch (resultJson) {
                    // 失敗したら値を戻す
                    _updateDataScreenState(backupSS);
                    // エラーメッセージ表示
                    becky.LeanStartup.alertErrorMessage(resultJson);
                } finally {
                    // 完了時にボタンを有効化
                    pointerEvents.end();
                }
            }());
        });

        // メインデータの乱視軸エリア
        $("#trMainAxs").click(function () {
            if (_isSelectAxs()) {
                return;
            }
            const backupSS = _updateDataScreenState(); // 戻せるように記憶しておく
            const backupPP = _createPhoropterParam(_currentChart);
            $("#btnMenuFarNear").val("far");
            _setSelectSCA("Axs");
            $("#groupCrossCylinder").attr("data-select-index", 0); // クロスシリンダー(1)に戻す
            switch (_currentChart.examID) {
                case 1020: // [遠]乱視テスト
                    _updateControllerLayout({
                        examID: _currentChart.examID
                    });
                    break;
                case 1021: // [遠]ジャクソンクロスシリンダー
                    _updateControllerLayout({
                        examID: _currentChart.examID
                    });
                    break;
                default:
                    _updateControllerLayout({
                        examID: 1020
                    });
                    break;
            }
            const newPP = _createPhoropterParam(_currentChart);
            if (becky.jsonHelper.isEquals(backupPP, newPP)) {
                // フォロプターコマンドを呼ぶ必要はない
                return;
            }
            (async function () {
                // ボタンを無効化
                const pointerEvents = _getPointerEventsByCommand();
                pointerEvents.begin();
                try {
                    const nLCOS_ID = _createLCOS_CommandID(backupPP, newPP);
                    if (!modelHelper.isNull(nLCOS_ID)) {
                        // LCOS消灯
                        await _postLCOS_Command(nLCOS_ID);
                        try {
                            // フォロプター
                            await _postPhoropterCommand(_currentChart);
                        } finally {
                            // LCOS復帰
                            await _postChartCommand(_currentChart);
                        }
                    } else {
                        // フォロプター
                        await _postPhoropterCommand(_currentChart);
                    }
                    // 端末に一時保存(リロード対策)
                    _saveDataToWebStorage();
                } catch (resultJson) {
                    // 失敗したら値を戻す
                    _updateDataScreenState(backupSS);
                    // エラーメッセージ表示
                    becky.LeanStartup.alertErrorMessage(resultJson);
                } finally {
                    // 完了時にボタンを有効化
                    pointerEvents.end();
                }
            }());
        });

        /*Horizontal tab select for prism */
        $("#labelMainPrismHor").click(function () {

            if (_isSelectHor()) {
                return;
            }
            const chartindex = Number(localStorage['chartindex']);
            const chartParameterItem = becky.subjective.arrayChartParameter.chartParameter.filter(
                chartParameterItem_ => chartParameterItem_.chartID === chartindex)[0];
            if (becky.assertion.isUndefined(chartParameterItem)) {
                return;
            }
            let horizontalprismId = chartParameterItem.PrismtRuleChartIDH.toString();
            let IsPrismChart = chartParameterItem.IsPrismChart.toString();
            if(IsPrismChart ==1){
            if (horizontalprismId >= 1) {

                const charts = becky.subjective.arrayFlatChartPageParameter.filter(chartParameterItem => horizontalprismId == chartParameterItem.chartID);
                const chartTable = charts[0];
                _selectCurrentChart(chartTable);
                const $btn = $(this);
                const autoID = $btn.attr("data-auto-id");
                const nExamID = chartTable.examID;
                // get chart value of exam chart json
                const examParameterItem = becky.subjective.arrayExamParameter.examParameter.filter(
                    examParameterItem_ => examParameterItem_.examID === nExamID)[0];
                const strTitle = examParameterItem.titleExam;
                $("#labelExamTitle").attr("data-text", strTitle);
                _setSelectPrismHor_FromEvent();
                _setSelectSCA("PrismHor");
                $("#btnControllerEyeL").trigger("click");
                $(".vertical-icons").hide();
                localStorage['chartindex'] = chartTable.chartID;
            } else {
                // const backupSS = _updateDataScreenState(); // 戻せるように記憶しておく
                // const backupPP = _createPhoropterParam(_currentChart);
                $("#btnMenuFarNear").val("far");
                _setSelectSCA("PrismHor");
                $("#btnControllerEyeL").trigger("click");
                $(".horizontal-icons").show();
                $(".vertical-icons").hide();
                //$(".prism-hv-control").trigger("click");
            }
            }
            if(IsPrismChart ==2)
            {
                $("#btnMenuFarNear").val("far");
                _setSelectSCA("PrismHor");
                $("#btnControllerEyeL").trigger("click");
                $(".vertical-icons").show();
                $(".horizontal-icons").show();
               
            }   
        });

        $("#labelMainPrismVer").click(function () {

            if (_isSelectHor()) {
                return;
            }
            const chartindex = Number(localStorage['chartindex']);
            const chartParameterItem = becky.subjective.arrayChartParameter.chartParameter.filter(
                chartParameterItem_ => chartParameterItem_.chartID === chartindex)[0];
            if (becky.assertion.isUndefined(chartParameterItem)) {
                return;
            }
            let verticalprismId = chartParameterItem.PrismtRuleChartIDV.toString();
            let IsPrismChart = chartParameterItem.IsPrismChart.toString();
            if(IsPrismChart ==1)
            {
            if (verticalprismId >= 1) {
                const charts = becky.subjective.arrayFlatChartPageParameter.filter(chartParameterItem => verticalprismId == chartParameterItem.chartID);
                const chartTable = charts[0];
                _selectCurrentChart(chartTable);
                const $btn = $(this);
                const autoID = $btn.attr("data-auto-id");
                const nExamID = chartTable.examID;
                // get chart value of exam chart json

                const examParameterItem = becky.subjective.arrayExamParameter.examParameter.filter(
                    examParameterItem_ => examParameterItem_.examID === nExamID)[0];
                const strTitle = examParameterItem.titleExam;
                $("#labelExamTitle").attr("data-text", strTitle);
                _setSelectPrismVer_FromEvent();
                _setSelectSCA("PrismVer");
                $("#btnControllerEyeR").trigger("click");
                $(".horizontal-icons").hide();
                localStorage['chartindex'] = chartTable.chartID;
            } else {
                $("#btnMenuFarNear").val("far");
                _setSelectSCA("PrismVer");
                $("#btnControllerEyeR").trigger("click");
                $(".horizontal-icons").hide();
                $(".vertical-icons").show();
                // $(".prism-hv-control").trigger("click");
            }
            }
            if(IsPrismChart ==2)
            {
                $("#btnMenuFarNear").val("far");
                _setSelectSCA("PrismVer");
                $("#btnControllerEyeR").trigger("click");
                $(".horizontal-icons").show();
                $(".vertical-icons").show();

            }
        });

        // コントローラーの位置
        {
            // 位置は端末毎に記録されている
            const classModeL = "mode-left";
            const classModeR = "mode-right";
            const $modeLeftRight = $("." + classModeL + ", ." + classModeR);
            const webStorageIO = becky.WebStorage.local.IO("subjective.controller.position");
            let controllerPos = webStorageIO.getString();
            if ("R" === controllerPos) {
                $modeLeftRight.toggleClass(classModeL + " " + classModeR);
            }
            $(".btn-changelayout").click(function () {
                $modeLeftRight.toggleClass(classModeL + " " + classModeR);
                if ($modeLeftRight.hasClass(classModeL)) {
                    controllerPos = "L";
                } else if ($modeLeftRight.hasClass(classModeR)) {
                    controllerPos = "R";
                } else {
                    becky.assertion.failure("unknown mode-*");
                }
                webStorageIO.setString(controllerPos);
            });
        }

        // コントローラーの左右(両)眼
        $("[id^=btnControllerEye]").click(function () {
            const backupSS = _updateDataScreenState(); // 戻せるように記憶しておく
            const strRLB = $(this).attr("id").slice(-1);
            _setSelectEye(strRLB);

            (async function () {
                // ボタンを無効化
                const pointerEvents = _getPointerEventsByCommand();
                pointerEvents.begin();
                try {
                    // 視標の設定
                    await _postChartCommand(_currentChart);
                    // フォロプター
                    await _postPhoropterCommand(_currentChart);
                    // 端末に一時保存(リロード対策)
                    _saveDataToWebStorage();
                } catch (resultJson) {
                    // 失敗したら値を戻す
                    _updateDataScreenState(backupSS);
                    //getsamechartIDvalues(samechartId);
                    // エラーメッセージ表示
                    //becky.LeanStartup.alertErrorMessage(resultJson);
                } finally {
                    // 完了時にボタンを有効化
                    pointerEvents.end();
                }
            }());
        });

        // コントローラーの調整ボタン
        $("[id^=btnControllerAdjust]").click(function () {
            const $btnControllerAdjust = $(this);

            const currentSCA = _getSelectSCA();
            switch (currentSCA) {
                case "PrismHor":
                    _operationPrism($btnControllerAdjust, currentSCA)
                    break;
                case "PrismVer":
                    _operationPrism($btnControllerAdjust, currentSCA)
                    break;
                default:
                    _operationSCA($btnControllerAdjust);
                    return;
            }

        });


        function _operationSCA($btnControllerAdjust) {
            //const $btnControllerAdjust = $(this);
            const vector = parseInt($btnControllerAdjust.val(), 10);
            becky.assertion.assert(1 === vector || -1 === vector);

            let target = null;
            let step = null;
            const currentSCA = _getSelectSCA();
            switch (currentSCA) {
                case "Sph":
                    target = "labelMainSph";
                    step = "btnMenuS";
                    break;
                case "Cyl":
                    target = "labelMainCyl";
                    step = "btnMenuC";
                    break;
                case "Axs":
                    target = "labelMainAxs";
                    step = "btnMenuA";
                    break;
                case "ADD":
                    target = "labelMainADD_";
                    step = "btnMenuS"; // 加入(ADD)は Sph のステップを使用する
                    break;
                case "PrismHor":
                    target = "labelMainPrismHor";
                    //step = "btnMenuS"; // 加入(ADD)は Sph のステップを使用する
                    break;
                case "PrismVer":
                    target = "labelMainPrismVer";
                    // step = "btnMenuS"; // 加入(ADD)は Sph のステップを使用する
                    break;
                default:
                    becky.assertion.failure("unknown select type");
                    return;
            }

            let stepValue = null;

            switch (currentSCA) {
                case "PrismHor":
                    stepValue = '1';
                    break;
                case "PrismVer":
                    stepValue = '1';
                    break;
                default:
                    stepValue = $("#" + step).attr("data-value");
                    break;
            }

            const fStepValue = parseFloat(stepValue);
            const fAddValue = fStepValue * vector;

            let $labels = null;
            const eyeValue = _getSelectEye();
            switch (eyeValue) {
                case "B":
                    $labels = $("[id^=" + target + "]");
                    break;
                case "R":
                case "L":
                    $labels = $("#" + target + eyeValue);
                    break;
                default:
                    becky.assertion.failure("unknown eye");
                    break;
            }
            if (becky.assertion.isNullOrEmpty($labels)) {
                return;
            }

            // 値変更前
            const orgJson = _updateDataMeasurementValue();

            $labels.each((i, element) => {
                const $label = $(element);
                const dValue = $label.attr("data-text");
                if (modelHelper.isUndefined(dValue)) {
                    return;
                }
                let fValue = parseFloat(dValue);
                fValue += fAddValue;

                const dMin = $label.attr("data-min");
                const dMax = $label.attr("data-max");
                const dLoop = $label.attr("data-loop");
                const isDefMin = !modelHelper.isUndefined(dMin);
                const isDefMax = !modelHelper.isUndefined(dMax);
                const isDefLoop = !modelHelper.isUndefined(dLoop);
                if (isDefMin) {
                    const nMin = Number(dMin);
                    if (nMin > fValue) {
                        if (isDefLoop && isDefMax) {
                            // 最大値が無いとループできない
                            const nMax = Number(dMax);
                            fValue = nMax + fValue;
                        } else {
                            fValue = nMin;
                        }
                    }
                }
                if (isDefMax) {
                    const nMax = Number(dMax);
                    if (nMax < fValue) {
                        if (isDefLoop && isDefMin) {
                            // 最小値が無いとループできない
                            const nMin = Number(dMin);
                            fValue = nMin + fValue - nMax - 1;
                        } else {
                            fValue = nMax;
                        }
                    }
                }

                $label.attr("data-text", fValue);
                _updateMainColor($label);
                /*Display BI/BO is greater than '0' */
                var biText = $("#labelMainPrismHorR").text();
                var boText = $("#labelMainPrismHorL").text();
                var bdText = $("#labelMainPrismVerR").text();
                var buText = $("#labelMainPrismVerL").text();
                if (biText == '0') {
                    $(".prism-heading-inner-hor-R-BI").hide();
                } else {
                    $(".prism-heading-inner-hor-R-BI").show();
                }
                if (boText == '0') {
                    $(".prism-heading-inner-hor-L-BI").hide();
                } else {
                    $(".prism-heading-inner-hor-L-BI").show();
                }
                if (bdText == '0') {
                    $(".prism-heading-inner-ver-R-BD").hide();
                } else {
                    $(".prism-heading-inner-ver-R-BD").show();
                }
                if (buText == '0') {
                    $(".prism-heading-inner-ver-L-BD").hide();
                } else {
                    $(".prism-heading-inner-ver-L-BD").show();
                }

            });

            if (isSelectedNear && _isSelectSph()) {

                // 例外
                // 近見が(一度でも)選択された場合
                // Sph の変更と一緒に加入(ADD)も変更する！？
                let $labelADDs = null;
                switch (eyeValue) {
                    case "B":
                        $labelADDs = $("[id^=labelMainADD_]");
                        break;
                    case "R":
                        $labelADDs = $("#labelMainADD_R");
                        break;
                    case "L":
                        $labelADDs = $("#labelMainADD_L");
                        break;
                    default:
                        becky.assertion.failure("unknown eye");
                        break;
                }
                if (becky.assertion.isNullOrEmpty($labelADDs)) {
                    return;
                }
                $labelADDs.each((i, element) => {
                    const $labelADD = $(element);
                    const dValue = $labelADD.attr("data-text");
                    if (modelHelper.isUndefined(dValue)) {
                        return;
                    }
                    let fValue = parseFloat(dValue);
                    fValue -= fAddValue; // 値の増減は逆
                    $labelADD.attr("data-text", fValue);
                    _updateMainColor($labelADD);
                });
            }

            if (1021 == _currentChart.examID) {
                // 例外
                // クロスシリンダー時
                // Cyl の変更と一緒に Sph も変更する
                becky.assertion.assert("B" !== eyeValue, '"B" !== eyeValue'); // 両眼は無いはず
                const nowJson = _updateDataMeasurementValue();
                if (_isSelectSph()) {
                    // 途中で Sph が変更された場合を考慮
                    ["Sph", "Cyl"].forEach(sc_ => {
                        const key = sc_ + eyeValue;
                        _crossCylinderBase[key] = nowJson[key];
                    });
                } else if (_isSelectCyl()) {
                    const moveStep = 0.5; // 刻みで変動
                    const diffCyl = _crossCylinderBase["Cyl" + eyeValue] - nowJson["Cyl" + eyeValue];
                    const addSph = Math.trunc(diffCyl / moveStep) * (moveStep / 2);
                    const newSph = _crossCylinderBase["Sph" + eyeValue] + addSph; {
                        const $labelSph = $("#labelMainSph" + eyeValue);
                        $labelSph.attr("data-text", newSph);
                        _updateMainColor($labelSph);
                    }
                }
            }

            if (_isSelectCyl()) {
                // 例外
                // Cyl が 0 を超える場合はキャンセルする
                const cylValues = [];
                $labels.each((i, element) => {
                    const $label = $(element);
                    const dValue = $label.attr("data-text");
                    const strID = $label.attr("id");
                    if (modelHelper.isUndefined(dValue)) {
                        return;
                    }
                    if (becky.assertion.isNull(strID.match(/labelMainCyl/))) {
                        return;
                    }
                    cylValues.push(dValue);
                });
                const isCylOver0 = cylValues.some(cylValue_ => 0 < cylValue_);
                if (isCylOver0) {
                    // 値を戻す
                    _updateDataMeasurementValue(orgJson);
                    return;
                }
            }
            //console.log(orgJson);
            (async function () {

                // ボタンを無効化
                const pointerEvents = _getPointerEventsByCommand();
                pointerEvents.begin();
                //console.log(_currentChart);
                try {
                    // フォロプター
                    await _postChartCommand(_currentChart);
                    await _postPhoropterCommand(_currentChart);
                    // 端末に一時保存(リロード対策)
                    _saveDataToWebStorage();
                } catch (resultJson) {
                    // 失敗したら値を戻す
                    _updateDataMeasurementValue(orgJson);
                    //getsamechartIDvalues(samechartId);
                    // エラーメッセージ表示
                    becky.LeanStartup.alertErrorMessage(resultJson);
                } finally {
                    // 完了時にボタンを有効化
                    pointerEvents.end();
                }
            }());


        };

        function _operationPrism($btnControllerAdjust, currentSCA) {

            const vector = parseInt($btnControllerAdjust.val(), 10);
            becky.assertion.assert(1 === vector || -1 === vector);
            let vectorR = null;
            let vectorL = null;

            let targetR = null;
            let targetL = null;
            let step = null;
            let stepValue = null;
            var biTextHorR = $("#labelMainPrismHorR").text();
            var biTextHorL = $("#labelMainPrismHorL").text();

            var biTextVerR = $("#labelMainPrismVerR").text();
            var biTextVerL = $("#labelMainPrismVerL").text();

            var prismActionHorR = $(".prism-heading-inner-hor-R-BI").attr("data-fixed");
            var prismActionHorL = $(".prism-heading-inner-hor-L-BI").attr("data-fixed");

            var prismActionVerR = $(".prism-heading-inner-ver-R-BD").attr("data-fixed");
            var prismActionVerL = $(".prism-heading-inner-ver-L-BD").attr("data-fixed");

            const eyeValue = _getSelectEye();

            switch (currentSCA) {
                case "PrismHor":
                    targetR = "labelMainPrismHorR";
                    targetL = "labelMainPrismHorL";
                    step = "btnMenuPrism_Stap"; // 加入(ADD)は Sph のステップを使用する
                    stepValue = $("#" + step).attr("data-value");

                    if (vector == 1) {
                        if (biTextHorR == '0.00') {
                            $(".prism-heading-inner-hor-R-BI").attr("data-text", "BI ");
                            $(".prism-heading-inner-hor-R-BI").attr("data-fixed", 1);
                            vectorR = 1;
                        } else {
                            if (prismActionHorR == '1') {
                                vectorR = 1;
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BI ");
                                $(".prism-heading-inner-hor-R-BI").attr("data-fixed", 1);
                            } else {
                                vectorR = -1;
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BO ");
                                $(".prism-heading-inner-hor-R-BI").attr("data-fixed", 0);
                            }
                        }

                        if (biTextHorL == '0.00') {
                            $(".prism-heading-inner-hor-L-BI").attr("data-text", "BI ");
                            $(".prism-heading-inner-hor-L-BI").attr("data-fixed", 1);
                            vectorL = 1;
                        } else {
                            if (prismActionHorL == '1') {
                                vectorL = 1;
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BI ");
                                $(".prism-heading-inner-hor-L-BI").attr("data-fixed", 1);
                            } else {
                                vectorL = -1;
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BO ");
                                $(".prism-heading-inner-hor-L-BI").attr("data-fixed", 0);
                            }
                        }
                    } else {
                        if (biTextHorR == '0.00') {
                            $(".prism-heading-inner-hor-R-BI").attr("data-text", "BO ");
                            $(".prism-heading-inner-hor-R-BI").attr("data-fixed", 0);
                            vectorR = 1;
                        } else {
                            if (prismActionHorR == '1') {
                                vectorR = -1;
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BI ");
                                $(".prism-heading-inner-hor-R-BI").attr("data-fixed", 1);
                            } else {
                                vectorR = 1;
                                $(".prism-heading-inner-hor-R-BI").attr("data-text", "BO ");
                                $(".prism-heading-inner-hor-R-BI").attr("data-fixed", 0);
                            }
                        }

                        if (biTextHorL == '0.00') {
                            $(".prism-heading-inner-hor-L-BI").attr("data-text", "BO ");
                            $(".prism-heading-inner-hor-L-BI").attr("data-fixed", 0);
                            vectorL = 1;
                        } else {
                            if (prismActionHorL == '1') {
                                vectorL = -1;
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BI ");
                                $(".prism-heading-inner-hor-L-BI").attr("data-fixed", 1);
                            } else {
                                vectorL = 1;
                                $(".prism-heading-inner-hor-L-BI").attr("data-text", "BO ");
                                $(".prism-heading-inner-hor-L-BI").attr("data-fixed", 0);
                            }
                        }
                    }
                    break;
                case "PrismVer":
                    targetR = "labelMainPrismVerR";
                    targetL = "labelMainPrismVerL";

                    step = "btnMenuPrism_Stap"; // 加入(ADD)は Sph のステップを使用する
                    stepValue = $("#" + step).attr("data-value");;

                    switch (eyeValue) {
                        case "B":
                            if (vector == 1) {
                                if (biTextVerR == '0.00') {
                                    $(".prism-heading-inner-ver-R-BD").attr("data-text", "BD ");
                                    $(".prism-heading-inner-ver-R-BD").attr("data-fixed", 1);
                                    vectorR = 1;
                                } else {
                                    if (prismActionVerR == '1') {
                                        vectorR = 1;
                                        $(".prism-heading-inner-ver-R-BD").attr("data-text", "BD ");
                                        $(".prism-heading-inner-ver-R-BD").attr("data-fixed", 1);
                                    } else {
                                        vectorR = -1;
                                        $(".prism-heading-inner-ver-R-BD").attr("data-text", "BU ");
                                        $(".prism-heading-inner-ver-R-BD").attr("data-fixed", 0);
                                    }
                                }

                                if (biTextVerL == '0.00') {
                                    $(".prism-heading-inner-ver-L-BD").attr("data-text", "BU ");
                                    $(".prism-heading-inner-ver-L-BD").attr("data-fixed", 1);
                                    vectorL = 1;
                                } else {
                                    if (prismActionVerL == '1') {
                                        vectorL = 1;
                                        $(".prism-heading-inner-ver-L-BD").attr("data-text", "BU ");
                                        $(".prism-heading-inner-ver-R-BD").attr("data-fixed", 1);
                                    } else {
                                        vectorL = -1;
                                        $(".prism-heading-inner-ver-L-BD").attr("data-text", "BD ");
                                        $(".prism-heading-inner-ver-L-BD").attr("data-fixed", 0);
                                    }
                                }
                            } else {
                                if (biTextVerR == '0.00') {
                                    $(".prism-heading-inner-ver-R-BD").attr("data-text", "BU ");
                                    $(".prism-heading-inner-ver-R-BD").attr("data-fixed", 0);
                                    vectorR = 1;
                                } else {
                                    if (prismActionVerR == '1') {
                                        vectorR = -1;
                                        $(".prism-heading-inner-ver-R-BD").attr("data-text", "BD ");
                                        $(".prism-heading-inner-ver-R-BD").attr("data-fixed", 1);
                                    } else {
                                        vectorR = 1;
                                        $(".prism-heading-inner-ver-R-BD").attr("data-text", "BU ");
                                        $(".prism-heading-inner-ver-R-BD").attr("data-fixed", 0);
                                    }
                                }

                                if (biTextVerL == '0.00') {
                                    $(".prism-heading-inner-ver-L-BD").attr("data-text", "BD ");
                                    $(".prism-heading-inner-ver-L-BD").attr("data-fixed", 0);
                                    vectorL = 1;
                                } else {
                                    if (prismActionVerL == '1') {
                                        vectorL = -1;
                                        $(".prism-heading-inner-ver-L-BD").attr("data-text", "BU ");
                                        $(".prism-heading-inner-ver-L-BD").attr("data-fixed", 1);
                                    } else {
                                        vectorL = 1;
                                        $(".prism-heading-inner-ver-L-BD").attr("data-text", "BD ");
                                        $(".prism-heading-inner-ver-L-BD").attr("data-fixed", 0);
                                    }
                                }
                            }

                            break;
                        case "R":

                            if (vector == 1) {
                                if (biTextVerR == '0.00') {
                                    $(".prism-heading-inner-ver-R-BD").attr("data-text", "BD ");
                                    $(".prism-heading-inner-ver-R-BD").attr("data-fixed", 1);
                                    vectorR = 1;
                                } else {
                                    if (prismActionVerR == '1') {
                                        vectorR = 1;
                                        $(".prism-heading-inner-ver-R-BD").attr("data-text", "BD ");
                                        $(".prism-heading-inner-ver-R-BD").attr("data-fixed", 1);
                                    } else {
                                        vectorR = -1;
                                        $(".prism-heading-inner-ver-R-BD").attr("data-text", "BU ");
                                        $(".prism-heading-inner-ver-R-BD").attr("data-fixed", 0);
                                    }
                                }
                            } else {
                                if (biTextVerR == '0.00') {
                                    $(".prism-heading-inner-ver-R-BD").attr("data-text", "BU ");
                                    $(".prism-heading-inner-ver-R-BD").attr("data-fixed", 0);
                                    vectorR = 1;
                                } else {
                                    if (prismActionVerR == '1') {
                                        vectorR = -1;
                                        $(".prism-heading-inner-ver-R-BD").attr("data-text", "BD ");
                                        $(".prism-heading-inner-ver-R-BD").attr("data-fixed", 1);
                                    } else {
                                        vectorR = 1;
                                        $(".prism-heading-inner-ver-R-BD").attr("data-text", "BU ");
                                        $(".prism-heading-inner-ver-R-BD").attr("data-fixed", 0);
                                    }
                                }
                            }


                            break;
                        case "L":
                            if (vector == 1) {
                                if (biTextVerL == '0.00') {
                                    $(".prism-heading-inner-ver-L-BD").attr("data-text", "BD ");
                                    $(".prism-heading-inner-ver-L-BD").attr("data-fixed", 0);
                                    vectorL = 1;
                                } else {
                                    if (prismActionVerL == '1') {
                                        vectorL = -1;
                                        $(".prism-heading-inner-ver-L-BD").attr("data-text", "BU ");
                                        $(".prism-heading-inner-ver-L-BD").attr("data-fixed", 1);
                                    } else {
                                        vectorL = 1;
                                        $(".prism-heading-inner-ver-L-BD").attr("data-text", "BD ");
                                        $(".prism-heading-inner-ver-L-BD").attr("data-fixed", 0);
                                    }
                                }
                            } else {
                                if (biTextVerL == '0.00') {
                                    $(".prism-heading-inner-ver-L-BD").attr("data-text", "BU ");
                                    $(".prism-heading-inner-ver-L-BD").attr("data-fixed", 1);
                                    vectorL = 1;
                                } else {
                                    if (prismActionVerL == '1') {
                                        vectorL = 1;
                                        $(".prism-heading-inner-ver-L-BD").attr("data-text", "BU ");
                                        $(".prism-heading-inner-ver-L-BD").attr("data-fixed", 1);
                                    } else {
                                        vectorL = -1;
                                        $(".prism-heading-inner-ver-L-BD").attr("data-text", "BD ");
                                        $(".prism-heading-inner-ver-L-BD").attr("data-fixed", 0);
                                    }
                                }
                            }

                            break;
                        default:
                            becky.assertion.failure("unknown eye");
                            break;
                    }


                    break;
                default:
                    becky.assertion.failure("unknown select type");
                    return;

            }

            const fStepValue = parseFloat(stepValue);
            const fAddValueR = parseFloat(fStepValue * vectorR);
            const fAddValueL = parseFloat(fStepValue * vectorL);

            let $labelsR = null;
            let $labelsL = null;

            let fValueR = null;
            let fValueL = null;

            // const eyeValue = _getSelectEye();
            switch (eyeValue) {
                case "B":
                    $labelsR = $("[id^=" + targetR + "]");
                    $labelsL = $("[id^=" + targetL + "]");

                    if (!becky.assertion.isNullOrEmpty($labelsR) && !becky.assertion.isNullOrEmpty($labelsL)) {
                        let dValueR = $labelsR.attr("data-text");
                        let dValueL = $labelsL.attr("data-text");

                        fValueR = parseFloat(dValueR);
                        fValueR += parseFloat(fAddValueR);

                        fValueL = parseFloat(dValueL);
                        fValueL += parseFloat(fAddValueL);

                        let dMaxR = $labelsR.attr("data-max");
                        let dMaxL = $labelsL.attr("data-max");


                        if ((parseFloat(dMaxR) >= parseFloat(fValueR)) && (parseFloat(dMaxL) >= parseFloat(fValueL))) {
                            _updateHorVerMaxValue($labelsR, parseFloat(fAddValueR.toFixed(2)));
                            _updateHorVerMaxValue($labelsL, parseFloat(fAddValueL.toFixed(2)));
                        } else {
                            return;
                        }

                        dValueR = $labelsR.attr("data-text");
                        fValueR = parseFloat(dValueR);

                        dValueL = $labelsL.attr("data-text");
                        fValueL = parseFloat(dValueL);
                    }
                    break;
                case "R":
                    $labelsR = $("[id^=" + targetR + "]");
                    _updateHorVerMaxValue($labelsR, parseFloat(fAddValueR.toFixed(2)));

                    const dValueR1 = $labelsR.attr("data-text");
                    fValueR = parseFloat(dValueR1);

                    break;
                case "L":
                    $labelsL = $("[id^=" + targetL + "]");
                    _updateHorVerMaxValue($labelsL, parseFloat(fAddValueL.toFixed(2)));

                    const dValueL1 = $labelsL.attr("data-text");
                    fValueL = parseFloat(dValueL1);

                    break;
                default:
                    becky.assertion.failure("unknown eye");
                    break;
            }
            //if (becky.assertion.isNullOrEmpty($labels)) {
            //    return;
            //}

            // 値変更前
            const orgJson = _updateDataMeasurementValue();

            switch (currentSCA) {
                case "PrismHor": {
                    switch (eyeValue) {
                        case "B":
                            if (fValueR == '0.00') {
                                $(".prism-heading-inner-hor-R-BI").hide();
                            } else {
                                $(".prism-heading-inner-hor-R-BI").show();
                            }
                            if (fValueL == '0.00') {
                                $(".prism-heading-inner-hor-L-BI").hide();
                            } else {
                                $(".prism-heading-inner-hor-L-BI").show();
                            }
                            break;
                        case "R":
                            if (fValueR == '0.00') {
                                $(".prism-heading-inner-hor-R-BI").hide();
                            } else {
                                $(".prism-heading-inner-hor-R-BI").show();
                            }
                            break;
                        case "L":
                            if (fValueL == '0.00') {
                                $(".prism-heading-inner-hor-L-BI").hide();
                            } else {
                                $(".prism-heading-inner-hor-L-BI").show();
                            }
                            break;
                        default:
                            $(".prism-heading-inner-hor-L-BI").show();
                            break;
                    }
                }
                break;
            case "PrismVer": {
                switch (eyeValue) {
                    case "B":
                        if (fValueR == '0.00') {
                            $(".prism-heading-inner-ver-R-BD").hide();
                        } else {
                            $(".prism-heading-inner-ver-R-BD").show();
                        }

                        if (fValueL == '0.00') {
                            $(".prism-heading-inner-ver-L-BD").hide();
                        } else {
                            $(".prism-heading-inner-ver-L-BD").show();
                        }
                        break;
                    case "R":
                        if (fValueR == '0.00') {
                            $(".prism-heading-inner-ver-R-BD").hide();
                        } else {
                            $(".prism-heading-inner-ver-R-BD").show();
                        }
                        break;
                    case "L":
                        if (fValueL == '0.00') {
                            $(".prism-heading-inner-ver-L-BD").hide();
                        } else {
                            $(".prism-heading-inner-ver-L-BD").show();
                        }
                        break;
                    default:
                        $(".prism-heading-inner-ver-L-BD").show();
                        break;
                }
            }
            break;
            default:
                becky.assertion.failure("unknown select type");
                break;
            }

            (async function () {

                // ボタンを無効化
                const pointerEvents = _getPointerEventsByCommand();
                pointerEvents.begin();

                try {
                    // フォロプター
                    await _postChartCommand(_currentChart);
                    await _postPhoropterCommand(_currentChart);
                    // 端末に一時保存(リロード対策)
                    _saveDataToWebStorage();
                    //     const webStorageIO = becky.WebStorage.local.IO("subjective.update.data");
                    //  const updateDataJson = webStorageIO.getJson();
                    //   _updateChartContainer(updateDataJson, _currentChart);
                } catch (resultJson) {
                    // 失敗したら値を戻す
                    _updateDataMeasurementValue(orgJson);
                    // エラーメッセージ表示
                    becky.LeanStartup.alertErrorMessage(resultJson);
                } finally {
                    // 完了時にボタンを有効化
                    pointerEvents.end();
                }
            }());
        };


        // クロスシリンダー回転
        $(".btn-group-switch-circle .btn").click(function () {
            const backupSS = _updateDataScreenState(); // 戻せるように記憶しておく
            $("#groupCrossCylinder").attr("data-select-index", $(this).index());
            (async function () {
                // ボタンを無効化
                const pointerEvents = _getPointerEventsByCommand();
                pointerEvents.begin();
                try {
                    // LCOS消灯
                    // ただし、融像を維持するため、黒画像ではなく融像枠画像
                    await _postLCOS_Command(1);
                    try {
                        // フォロプター
                        await _postPhoropterCommand(_currentChart);
                    } finally {
                        // LCOS復帰
                        await _postChartCommand(_currentChart);
                    }
                    // 端末に一時保存(リロード対策)
                    _saveDataToWebStorage();
                } catch (resultJson) {
                    // 失敗したら値を戻す
                    _updateDataScreenState(backupSS);
                    // エラーメッセージ表示
                    becky.LeanStartup.alertErrorMessage(resultJson);
                } finally {
                    // 完了時にボタンを有効化
                    pointerEvents.end();
                }
            }());
        }); {
            const optionsAttributeFilter = {
                attributes: true,
                attributeFilter: ["data-select-index"],
            };
            const idCrossCylinder = "groupCrossCylinder";
            becky.MutationObserver.byID(
                idCrossCylinder,
                records => records.forEach(record_ => {
                    const target = record_.target;
                    const selectIndex = target.dataset.selectIndex;
                    const $btn = $(".btn-group-switch-circle .btn").eq(selectIndex);
                    if (!becky.assertion.isNullOrEmpty($btn)) {
                        viewHelper.selectClassSingle("current", $btn);
                    }
                    _updateCrossCylinderClasses();
                }),
                optionsAttributeFilter);
            // 変更イベントを呼ぶ(初期化)
            becky.dataSync.callChangeEventAttr(document.getElementById(idCrossCylinder), "data-select-index");
        }

        // 乱視/軸の切り替え
        $(".btn-astigmat-axis").click(function () {
            const backupSS = _updateDataScreenState(); // 戻せるように記憶しておく
            const backupPP = _createPhoropterParam(_currentChart);
            _toggleSelectCylAxs();
            $("#groupCrossCylinder").attr("data-select-index", 0); // クロスシリンダー(1)に戻す
            const newPP = _createPhoropterParam(_currentChart);
            if (becky.jsonHelper.isEquals(backupPP, newPP)) {
                // フォロプターコマンドを呼ぶ必要はない
                return;
            }
            (async function () {
                // ボタンを無効化
                const pointerEvents = _getPointerEventsByCommand();
                pointerEvents.begin();
                try {
                    const nLCOS_ID = _createLCOS_CommandID(backupPP, newPP);
                    if (!modelHelper.isNull(nLCOS_ID)) {
                        // LCOS消灯
                        await _postLCOS_Command(nLCOS_ID);
                        try {
                            // フォロプター
                            await _postPhoropterCommand(_currentChart);
                        } finally {
                            // LCOS復帰
                            await _postChartCommand(_currentChart);
                        }
                    } else {
                        // フォロプター
                        await _postPhoropterCommand(_currentChart);
                    }
                    // 端末に一時保存(リロード対策)
                    _saveDataToWebStorage();
                } catch (resultJson) {
                    // 失敗したら値を戻す
                    _updateDataScreenState(backupSS);
                    // エラーメッセージ表示
                    becky.LeanStartup.alertErrorMessage(resultJson);
                } finally {
                    // 完了時にボタンを有効化
                    pointerEvents.end();
                }
            }());
        });

        // タブ内の視力表(サムネイル)
        $("[data-auto-id]").click(function () {
            
            $(".btn-menu").removeClass("activeButton");
            $(".default-chart-near").hide();
            $(".default-chart-far").hide();
            $(".controller-default").hide();
            if (becky.assertion.isNullOrEmpty(becky.subjective.arrayFlatChartPageParameter)) {
                return;
            }
            const backupSS = _updateDataScreenState(); // 戻せるように記憶しておく
            const backupPP = _createPhoropterParam(_currentChart);
            const $btn = $(this);
            const autoID = $btn.attr("data-auto-id");
            const chart = _getChartByAutoID(becky.subjective.arrayFlatChartPageParameter, autoID);
             //////////////////////////////////////////////////////////////////////////////////
               //get chart Parameter from Chart Page parameter
            const chartParameterItem = becky.subjective.arrayChartParameter.chartParameter.filter(
                chartParameterItem_ => chartParameterItem_.chartID === chart.chartID)[0];
            if (becky.assertion.isUndefined(chartParameterItem)) {
                return;
            }
             //if(chart.chartID == 77 || chart.chartID == 76 || chart.chartID == 78)
             if(chartParameterItem.PrismtRuleH == '14A')
             {
                 localStorage['clicked'] = 1;                    
             }
             if(chartParameterItem.PrismtRuleH == '15A')
             {
                   if(localStorage['clicked'] != 1)
                   {
                        alert('#14A result is necessary for this examPlease complete #14A before doing this exam');
                        return;
                   } 
             }
             
             //////////////////////////////////////////////////////////////////////////////////////
            
            if (chart.autoID === _currentChart.autoID) {
                // 同じ視標が選択された
                return;
            }

           
                $("#btnBlurredBI2").attr("disabled", true);
                $("#btnBlurredBI2").css('color', 'darkgray');
          

            const nExamID = chart.examID;
            // get chart value of exam chart json
            const examParameterItem = becky.subjective.arrayExamParameter.examParameter.filter(
                examParameterItem_ => examParameterItem_.examID === nExamID)[0];
            //alert(examParameterItem.examID);
            
            const langparameter = becky.subjective.langParameter;
           

            //const strTitle = examParameterItem.titleExam;
            if(langparameter == 'US'){
                var strTitle = examParameterItem.titleExam;
            }
            if(langparameter == 'JP'){
                var strTitle = examParameterItem.jptitleExam;
             }
                
            //const strTitle1 = _getDefMessageBySubjective("titleExamID" + nExamID);
            
            // 検査名
           
            const webStorageIO = becky.WebStorage.local.IO("subjective.update.data");
            const updateDataJson = webStorageIO.getJson();
            //console.log("current chart value");
            //console.log(updateDataJson);
            //   _updateChartContainer(updateDataJson, chart);


            $("#labelExamTitle").attr("data-text", strTitle);


            
            //const chartIDContainer = chart.chartID;
            //const chartContainer = _updateChartContainer(autoID, chartIDContainer);
            _getPrismHVTestValue(chartParameterItem);
            _getBinoHVTestValue(chartParameterItem);

            // 例外:[近]加入度測定
            if (2030 === chart.examID) {
                // 強制的に近見に切り替える
                $("#btnMenuFarNear").val("near");
            }
            localStorage['chartindex'] = chartParameterItem.chartID;



            // 選択眼/SCAの選択状態の更新(Chartから)
            _updateSelectEyeFromChart(chart);
            _updateSelectSCA_FromChart(chart);

            $("#groupCrossCylinder").attr("data-select-index", 0); // クロスシリンダー(1)に戻す
            $("#currentAutoID").attr("data-value", chart.autoID);
            const newPP = _createPhoropterParam(chart);
            (async function () {
                // ボタンを無効化
                const pointerEvents = _getPointerEventsByCommand();
                pointerEvents.begin();
                try {
                    // Todo. 素直にbool型で判定できるようにしたい
                    if ("on_" === becky.settingJson.subjective.alignmentWhenSightMarksAreSelected) {
                        // アライメント
                        await _postAlignmentCommand();
                    }

                    const nLCOS_ID = _createLCOS_CommandID(backupPP, newPP);
                    if (!modelHelper.isNull(nLCOS_ID)) {
                        // LCOS消灯
                        await _postLCOS_Command(nLCOS_ID);
                        try {
                            // フォロプター
                            await _postPhoropterCommand(chart);
                        } catch (resultJson) {
                            // LCOS復帰
                            await _postChartCommand(_currentChart);
                        }
                        // 視標の設定
                        await _postChartCommand(chart);
                    } else {
                        // 視標の設定
                        await _postChartCommand(chart);
                        // フォロプター
                        await _postPhoropterCommand(chart);
                    }
                    // 端末に一時保存(リロード対策)
                    _saveDataToWebStorage();
                } catch (resultJson) {
                    // 失敗したら値を戻す
                    _updateDataScreenState(backupSS);
                    // エラーメッセージ表示
                    becky.LeanStartup.alertErrorMessage(resultJson);
                } finally {
                    // 完了時にボタンを有効化
                    pointerEvents.end();
                }
            }());
            _resetChartRG();
        });

        $("#btnChartInvert").click(function () {
            const $chartTableBg = $(".chart-table .bg");
            $chartTableBg.toggleClass("bg-invert");
            const isBgInvert = $chartTableBg.hasClass("bg-invert");
            const strParam = isBgInvert ? "1" : "0";
            $(".chart-table .image img").attr("style", "filter: Invert(" + strParam + ")");
            // RG は排他なので無効化
            _resetChartRG();
        });

        $("#btnChartRG").click(function () {
            const $chartTableBg = $(".chart-table .bg");
            $chartTableBg.toggleClass("bg-rg");
            // 通常状態に戻す
            $(".chart-table div").removeClass("active");
            $(".chart-table .hitarea div").addClass("active");
            // 反転は排他なので無効化
            _resetChartInvert();
        });

        {
            /*!
             * @brief メニューの選択状態を解除する
             */
            function _deselectMenu() {
                $(".menu-item").removeClass("current");
                $(".menu-slidenavi").hide();
            }

            $(".btn-menu-bar, .btn-menu").click(function () {
                const $this = $(this);
                const $menuitem = $this.parent();
                const isThisCurrent = $menuitem.hasClass("current");

                _deselectMenu();

                const $menuNavi = $this.prev(".menu-slidenavi");
                if (!isThisCurrent && !modelHelper.isNullOrEmpty($menuNavi)) {
                    $menuNavi.fadeIn("fast"); // show() の仲間
                    $menuitem.addClass("current");
                }
            });

            // メニュー領域外をクリックしたらメニューを閉じる
            let bIsMenuIn = false;
            $(".btn-menu-bar, .btn-menu, .menu-slidenavi").hover(function () {
                bIsMenuIn = true;
            }, function () {
                bIsMenuIn = false;
            });
            $("body").click(function () {
                if (!bIsMenuIn) {
                    _deselectMenu();
                }
            });
        }

        // SCAのステップ数の変更
        ["btnMenuS", "btnMenuC", "btnMenuA"].forEach(idMenu_ => {
            becky.MutationObserver.byID(idMenu_,
                records => records.forEach(record_ => _onUpdateHtmlMenuStep(record_.target, idMenu_)),
                optionsAttributeFilterDataValue);
            // 変更イベントを呼ぶ(初期化)
            becky.dataSync.callChangeEventAttr(document.getElementById(idMenu_), "data-value");
            // メニューアイテムの選択時
            $("[data-for=" + idMenu_ + "] .slidenavi-item").click(function () {
                // 新しい値を反映
                $("#" + idMenu_).attr("data-value", $(this).attr("data-value"));
            });
        });

        // ウォース4点テスト 専用
        {
            const idResultValue = "btnMenuChartID9_ResultValue";
            becky.MutationObserver.byID(idResultValue,
                records => records.forEach(record_ => {
                    const target = record_.target;
                    const value = target.dataset.value;
                    let itemText = "";
                    if (modelHelper.isNullOrEmpty(value)) {
                        $("[data-for=btnMenuChartID9] .slidenavi-item").removeClass("current");
                        $("#btnMenuChartID9_ResultValue").removeClass("current");
                    } else {
                        const $currentItem = $("[data-for=btnMenuChartID9] [data-value='" + value + "']");
                        $currentItem.addClass("current").siblings().removeClass("current");
                        $("#btnMenuChartID9_ResultValue").addClass("current");
                        itemText = $currentItem.text();
                    }
                    $("#btnMenuChartID9_ResultValue > div").attr("data-text", itemText);
                }),
                optionsAttributeFilterDataValue);
            // 変更イベントを呼ぶ(初期化)
            becky.dataSync.callChangeEventAttr(document.getElementById(idResultValue), "data-value");
            // メニューアイテムの選択時(When selecting a menu item)

            $("[data-for=btnMenuChartID9] .slidenavi-item").click(function () {
                const $this = $(this);
                $("#btnMenuChartID9_ResultValue").attr("data-value", $this.attr("data-value"));
            });
        }

        // ジャクソンクロスシリンダー 専用
        {
            const idMenu = "btnMenuCC_Power";
            becky.MutationObserver.byID(idMenu,
                records => records.forEach(record_ => _onUpdateHtmlMenuStep(record_.target, idMenu)),
                optionsAttributeFilterDataValue);
            // 変更イベントを呼ぶ(初期化)
            becky.dataSync.callChangeEventAttr(document.getElementById(idMenu), "data-value");
            // メニューアイテムの選択時
            $("[data-for=" + idMenu + "] .slidenavi-item").click(function () {
                const backupCC = $("#" + idMenu).attr("data-value"); // 戻せるように記憶しておく
                const backupPP = _createPhoropterParam(_currentChart);
                // 新しい値を反映
                $("#" + idMenu).attr("data-value", $(this).attr("data-value"));
                const newPP = _createPhoropterParam(_currentChart);
                if (becky.jsonHelper.isEquals(backupPP, newPP)) {
                    // フォロプターコマンドを呼ぶ必要はない
                    return;
                }
                (async function () {
                    // ボタンを無効化
                    const pointerEvents = _getPointerEventsByCommand();
                    pointerEvents.begin();
                    try {
                        // フォロプター
                        await _postPhoropterCommand(_currentChart);
                        // 端末に一時保存(リロード対策)
                        _saveDataToWebStorage();
                    } catch (resultJson) {
                        // 失敗したら値を戻す
                        $("#" + idMenu).attr("data-value", backupCC);
                        // エラーメッセージ表示
                        becky.LeanStartup.alertErrorMessage(resultJson);
                    } finally {
                        // 完了時にボタンを有効化
                        pointerEvents.end();
                    }
                }());
            });
        } {
            const idMenu = "btnMenuPrism_Stap";
            becky.MutationObserver.byID(idMenu,
                records => records.forEach(record_ => _onUpdateHtmlMenuStep(record_.target, idMenu)),
                optionsAttributeFilterDataValue);
            // Call change event (initialization)
            becky.dataSync.callChangeEventAttr(document.getElementById(idMenu), "data-value");
            // When selecting a menu item
            $("[data-for=" + idMenu + "] .slidenavi-item").click(function () {
                const backupCC = $("#" + idMenu).attr("data-value"); // 戻せるように記憶しておく
                const backupPP = _createPhoropterParam(_currentChart);
                // Reflect new value
                $("#" + idMenu).attr("data-value", $(this).attr("data-value"));
                const newPP = _createPhoropterParam(_currentChart);
                if (becky.jsonHelper.isEquals(backupPP, newPP)) {
                    // There is no need to call the follow command
                    return;
                }
                (async function () {
                    // Disable button
                    const pointerEvents = _getPointerEventsByCommand();
                    pointerEvents.begin();
                    try {
                        // フォロプター
                        await _postPhoropterCommand(_currentChart);
                        // 端末に一時保存(リロード対策)
                        _saveDataToWebStorage();
                    } catch (resultJson) {
                        // 失敗したら値を戻す
                        $("#" + idMenu).attr("data-value", backupCC);
                        // エラーメッセージ表示
                        becky.LeanStartup.alertErrorMessage(resultJson);
                    } finally {
                        // 完了時にボタンを有効化
                        pointerEvents.end();
                    }
                }());
            });
        }

        // メニューアイテムの選択時
        $(".slidenavi-item").click(function () {
            // 選択した項目を見せるために緩急を付けて閉じる
            asyncHelper.delay(150).then(function () {
                $(".menu-item").removeClass("current");
                $(".menu-slidenavi").hide();
            });
        });

        // 参照データ
        $("#btnMenuReferenceData").click(function () {
            // show / hide
            $(".area-side-a, .area-side-b").fadeToggle("fast"); // toggle() の仲間
        });

        // value 属性を監視するオプション(MutationObserverInit)
        const optionsAttributeFilterValue = {
            attributes: true,
            attributeFilter: ["value"],
        };

        // 遠見/近見
        const idFarNear = "#btnMenuFarNear";
        becky.MutationObserver.byID(
            idFarNear,
            records => records.forEach(record_ => {
                _updateLblFarNear(record_.target);

                const newVal = record_.target.value;
                const oldVal = _toggleVal_FarNear(newVal);
                $("#trMainVA" + newVal).show();
                $("#trMainVA" + oldVal).hide();
                $("#inputExaminationDistancePoint_" + newVal).show();
                $("#inputExaminationDistancePoint_" + oldVal).hide();

                //_updateChartTable(_currentChart);
                //_updateControllerLayout(_currentChart);

                //  $(".prism-hv-control").trigger("click");
                //_updateMenuInit(_currentChart);

                _updateSelectSCA_FromFarNear();

                if (_isSelectNear()) {
                    // 近見が(一度でも)選択された事を記録
                    isSelectedNear = true;
                }
            }),
            optionsAttributeFilterValue);
        const $btnFarNear = $(idFarNear);
        $btnFarNear.val($btnFarNear.val()); // 更新イベントを発生させる
        $btnFarNear.click(function () {
            const $btn = $(this);
            const val = $btn.val();
            const newVal = _toggleVal_FarNear(val);
            // 新しい値を反映
            $btn.val(newVal);
            const chartindex = Number(localStorage['chartindex']);
            const chartParameterItem = becky.subjective.arrayChartParameter.chartParameter.filter(
                chartParameterItem_ => chartParameterItem_.chartID === chartindex)[0];
            if ((chartParameterItem.IsPrismChart == '1' || chartParameterItem.IsPrismChart == '2') && (chartParameterItem.IsNearFar === 'N')) {
                //$(".default-chart-near").toggle();
                const nearchart = becky.subjective.arrayFlatChartPageParameter.filter(chart_ => "2222" == chart_.chartID);
                const nearchartTable = nearchart[0];
                _selectCurrentChart(nearchartTable);
                $(".controller-default").toggle();
                _setSelectSCA("Hor");
                $("#btnMenuS").hide();
                const charts = becky.subjective.arrayFlatChartPageParameter.filter(chart_ => chartindex == chart_.chartID);
                const chartTable = charts[0];
                const nExamID = chartTable.examID;
                const examParameterItem = becky.subjective.arrayExamParameter.examParameter.filter(
                    examParameterItem_ => examParameterItem_.examID === nExamID)[0];
                if ($("#labelMenu_far").hasClass("txt-large")) {
                    const strTitle = examParameterItem.titleExam;
                    $("#labelExamTitle").attr("data-text", strTitle);
                } else if ($("#labelMenu_near").hasClass("txt-large")) {
                    const strTitle = examParameterItem.defaultTitle;
                    $("#labelExamTitle").attr("data-text", strTitle);
                }
            }
            if ((chartParameterItem.IsPrismChart == '1'|| chartParameterItem.IsPrismChart == '2') && (chartParameterItem.IsNearFar === 'F')) {
                const farchart = becky.subjective.arrayFlatChartPageParameter.filter(chart_ => "1111" == chart_.chartID);
                const farchartTable = farchart[0];
                _selectCurrentChart(farchartTable);
                $(".controller-default").toggle();
                _setSelectSCA("Hor");
                $("#btnMenuS").hide();
                const nExamID = chartTable.examID;
                const examParameterItem = becky.subjective.arrayExamParameter.examParameter.filter(
                    examParameterItem_ => examParameterItem_.examID === nExamID)[0];
                if ($("#labelMenu_near").hasClass("txt-large")) {
                    const strTitle = examParameterItem.titleExam;
                    $("#labelExamTitle").attr("data-text", strTitle);
                } else if ($("#labelMenu_far").hasClass("txt-large")) {
                    const strTitle = examParameterItem.defaultTitle;
                    $("#labelExamTitle").attr("data-text", strTitle);
                }
            }

            (async function () {
                // ボタンを無効化
                const pointerEvents = _getPointerEventsByCommand();
                pointerEvents.begin();
                try {
                    // LCOS消灯
                    await _postLCOS_Command(0);
                    try {
                        // フォロプター
                        await _postPhoropterCommand(_currentChart);
                    } finally {
                        // LCOS復帰
                        await _postChartCommand(_currentChart);
                    }
                    // 端末に一時保存(リロード対策)
                    _saveDataToWebStorage();
                } catch (resultJson) {
                    // 失敗したら値を戻す
                    $btn.val(val);
                    // エラーメッセージ表示
                    becky.LeanStartup.alertErrorMessage(resultJson);
                } finally {
                    // 完了時にボタンを有効化
                    pointerEvents.end();
                }
            }());
        });

        // 両眼開放/片眼遮蔽
        //Blink open/eye mask
        const idBinoMono = "#btnMenuBinoMono";
        becky.MutationObserver.byID(
            idBinoMono,
            records => records.forEach(record_ => {
                _updateLblBinoMono(record_.target);
            }),
            optionsAttributeFilterValue);
        const $btnBinoMono = $(idBinoMono);
        $btnBinoMono.val($btnBinoMono.val()); // 更新イベントを発生させる
        $btnBinoMono.click(function () {
            const backupSS = _updateDataScreenState(); // 戻せるように記憶しておく
            const backupCP = _createChartParam(_currentChart);
            const $btn = $(this);
            const val = $btn.val();
            const newVal = _toggleVal_BinoMono(val);
            // 新しい値を反映
            $btn.val(newVal);
            const newCP = _createChartParam(_currentChart);
            if (becky.jsonHelper.isEquals(backupCP, newCP)) {
                // Chart コマンドを呼ぶ必要はない
                return;
            }
            (async function () {
                // ボタンを無効化
                const pointerEvents = _getPointerEventsByCommand();
                pointerEvents.begin();
                try {
                    // 視標の設定
                    await _postChartCommand(_currentChart);
                    // 端末に一時保存(リロード対策)
                    _saveDataToWebStorage();
                } catch (resultJson) {
                    // 失敗したら値を戻す
                    _updateDataScreenState(backupSS);
                    // エラーメッセージ表示
                    becky.LeanStartup.alertErrorMessage(resultJson);
                } finally {
                    // 完了時にボタンを有効化
                    pointerEvents.end();
                }
            }());
        });

        // オートアライメント
        $("#btnAutoAlignment").click(function () {
            (async function () {
                // ボタンを無効化
                const pointerEvents = _getPointerEventsByCommand();
                pointerEvents.begin();
                // 再び、ボタンが押せるようになるまで暗くする
                const $btnLabel = $("#btnAutoAlignment > div");
                $btnLabel.attr("style", "color: #1a1a1a; text-shadow: 1px 1px #ccc4"); // ccc + 4
                try {
                    // アライメント
                    await _postAlignmentCommand();
                } catch (resultJson) {
                    // エラーメッセージ表示
                    becky.LeanStartup.alertErrorMessage(resultJson);
                } finally {
                    // 暗くしたものを戻す
                    $btnLabel.removeAttr("style");
                    // 完了時にボタンを有効化
                    pointerEvents.end();
                }
            }());
        });

        // 駆動リセット
        $("#btnResetBaseXYZ").click(function () {
            (async function () {
                // ボタンを無効化
                const pointerEvents = _getPointerEventsByCommand();
                pointerEvents.begin();
                // 再び、ボタンが押せるようになるまで暗くする
                const $btnLabel = $("#btnResetBaseXYZ > div");
                $btnLabel.attr("style", "color: #1a1a1a; text-shadow: 1px 1px #ccc4"); // ccc + 4
                try {
                    // リセットベース
                    await _postResetBaseXYZCommand();
                } catch (resultJson) {
                    // エラーメッセージ表示
                    becky.LeanStartup.alertErrorMessage(resultJson);
                } finally {
                    // 暗くしたものを戻す
                    $btnLabel.removeAttr("style");
                    // 完了時にボタンを有効化
                    pointerEvents.end();
                }
            }());
        });

        // 検査距離
        {
            let nBackupValue = 0;
            $("[id^=inputExaminationDistancePoint_]").focus(function () {
                nBackupValue = parseInt($(this).val(), 10);
            }).blur(function () {
                const newValue = $(this).val().trim();
                if (modelHelper.isNullOrEmpty(newValue)) {
                    $(this).val(nBackupValue); // 値を戻す
                    return;
                }
                const pattern = /^([1-9]\d*|0)$/;
                if (!pattern.test(newValue)) {
                    // 不正値
                    $(this).val(nBackupValue); // 値を戻す
                    return;
                }
                let nNewValue = parseInt(newValue, 10); {
                    // 最小値と最大値で値を丸め込む
                    //Round the value to the minimum and maximum
                    const nMin = parseInt($(this).attr("min"), 10);
                    const nMax = parseInt($(this).attr("max"), 10);
                    nNewValue = Math.min(Math.max(nMin, nNewValue), nMax);
                }
                if (nBackupValue === nNewValue) {
                    // 変化が無い場合
                    $(this).val(nBackupValue); // 値を戻す
                    return;
                }
                // 新しい値を反映
                //Reflect new value
                $(this).val(nNewValue);
                (async function () {
                    // ボタンを無効化
                    const pointerEvents = _getPointerEventsByCommand();
                    pointerEvents.begin();
                    try {
                        // LCOS消灯
                        await _postLCOS_Command(0);
                        try {
                            // フォロプター
                            await _postPhoropterCommand(_currentChart);
                        } finally {
                            // LCOS復帰
                            await _postChartCommand(_currentChart);
                        }
                        // 端末に一時保存(リロード対策)
                        _saveDataToWebStorage();
                    } catch (resultJson) {
                        // 失敗したら値を戻す
                        $(this).val(nBackupValue);
                        // エラーメッセージ表示
                        becky.LeanStartup.alertErrorMessage(resultJson);
                    } finally {
                        // 完了時にボタンを有効化
                        pointerEvents.end();
                    }
                }());
            }).keyup(function (event) {
                // Enter
                if (13 === event.keyCode) {
                    $(this).blur(); // フォーカスを外す
                    return;
                }
            });
        }

        const $btnNaviNext = $("#btnNaviNext");
        $btnNaviNext.attr("href", "#"); // href によるリンクを無効化
        $btnNaviNext.click(function () {
            const $form = $("<form/>", {
                action: "subjective.php",
                method: "post",
            });
            const measurementValueJson = _updateDataMeasurementValue();
            Object.getOwnPropertyNames(measurementValueJson).forEach(name_ => {
                $("<input/>", {
                    type: "hidden",
                    name: name_,
                    value: measurementValueJson[name_],
                }).appendTo($form);
            });
            const screenStateValueJson = _updateDataScreenState()
            //console.log(screenStateValueJson);
            Object.getOwnPropertyNames(screenStateValueJson).forEach(name_ => {
                $("<input/>", {
                    type: "hidden",
                    name: name_,
                    value: screenStateValueJson[name_],
                }).appendTo($form);
            });

            const samechartIDJson = getsamechartIDvalues();
            //console.log(samechartIDJson);
            Object.getOwnPropertyNames(samechartIDJson).forEach(name_ => {
                $("<input/>", {
                    type: "hidden",
                    name: name_,
                    value: samechartIDJson[name_],
                }).appendTo($form);
            });

            const binoStateValueJson = setBinoTestvalues();
            //console.log(samechartIDJson);
            Object.getOwnPropertyNames(binoStateValueJson).forEach(name_ => {
                $("<input/>", {
                    type: "hidden",
                    name: name_,
                    value: binoStateValueJson[name_],
                }).appendTo($form);
            });

            // 登録という事を識別する為の情報
            //Information to identify registration
            $("<input/>").attr({
                type: "hidden",
                name: "subjective_register",
                value: "Register",
            }).appendTo($form);
            $form.appendTo(document.body);
            $form.submit();
            // 次へのタッチイベントを無効化
            becky.navi.disableNext();
        });

        // data-* Create a change event
        becky.dataSync.createChangeEvent();

        // Change button background processing
        _buttonClickBackGroundOverlay($("[id^=btnControllerAdjust], .btn-changelayout, .btn-astigmat-axis, #btnChartInvert, #btnChartRG, #btnMenuReferenceData, #btnMenuFarNear, #btnMenuBinoMono, #btnAutoAlignment, #btnResetBaseXYZ"));
    });


    /*!
     * Left, Right, Up and Down buttons visible on page load and chart change
     */
    function _visibleChartButtonsOnLoad(transnextChartID, transprevChartID) {

        $(".left").hide();
        $(".right").hide();
        if (transnextChartID == 0) {
            $(".down").hide();
        } else {
            $(".down").show();
        }

        if (transprevChartID == 0) {
            $(".up").hide();
        } else {
            $(".up").show();
        }
    };
    /*!
     * Left, Right, Up and Down buttons visible on mask selection
     */
    function _visibleChartButtonsOnMaskSelection(chartRow, chartCol, transnextChartID, transprevChartID, selIndex, selIsTop) {
        $(".up").show();
        $(".left").show();
        $(".right").show();

        const $this = $(".chart-table .side .active");
        const isSide = $this.parent().hasClass("side");
        const isThisActive = $this.hasClass("active");
        const $hitarea_div = $(".chart-table .hitarea div");
        const hitAreaActive = $hitarea_div.hasClass("active");
        const $chartTableActive = $(".chart-table .active");
        const index = $this.index();
        const index2 = $(".chart-table .hitarea .active").index();

        //No Mask Selected
        if (selIndex == -1) {
            $(".up").hide();
            $(".down").hide();
            $(".left").hide();
            $(".right").hide();
        }

        //IsTop true=Column and False=Row
        if (selIsTop == 1) {
            //No Mask Selected
            if (selIndex == 0) {
                //If previous chart not available
                if (transprevChartID == 0) {
                    $(".up").hide();
                    $(".left").hide();
                }
                $(".down").show();
                $(".right").show();
                if (transnextChartID == 0) {
                    $(".down").hide();
                }
            } else if (selIndex + 1 == chartCol) {
                if (transnextChartID == 0) {
                    $(".down").hide();
                    $(".right").hide();
                }
                $(".up").show();
                $(".left").show();
            } else {
                $(".up").show();
                $(".left").show();
                $(".right").show();
            }


            //Start row  Up and Left
            if (transprevChartID == 0) {
                $(".up").hide();

                if (selIndex == 0) {
                    $(".left").hide();
                } else {
                    $(".left").show();
                }
            }

            //End Column Down and Right
            if (transnextChartID == 0) {
                $(".down").hide();

                if (selIndex + 1 == chartCol) {
                    $(".right").hide();
                } else {
                    $(".right").show();
                }
            }
        }
        //IsTop false=Column and true=Row
        else {
            $(".left").hide();
            $(".right").hide();
            if (selIndex == 0) {
                //If previous chart not available
                if (transprevChartID == 0) {
                    $(".up").hide();
                    $(".left").hide();
                }
                $(".down").show();
            } else if (selIndex + 1 == chartRow) {
                if (transnextChartID == 0) {
                    if (selIndex < chartRow) {
                        $(".down").show();
                    } else
                        $(".down").hide();
                    $(".right").hide();
                }
                $(".up").show();
            } else {
                $(".up").show();
                $(".down").show();
            }
            //Start row  Up and Left
            if (transprevChartID == 0) {
                if (selIndex > 0) {
                    $(".up").show();
                } else
                    $(".up").hide();

                if (selIndex == 0) {
                    $(".up").hide();
                } else {
                    $(".up").show();
                }
            }

            //End Column Down and Right
            if (transnextChartID == 0) {
                if (selIndex < chartRow) {
                    $(".down").show();
                } else
                    $(".down").hide();

                if (selIndex + 1 == chartRow) {
                    $(".down").hide();
                } else {
                    $(".down").show();
                }
            }
        }
    };

    /*!
     * Left, Right, Up and Down buttons visible on mask single cell selection
     */
    function _visibleChartButtonsOnCellSelection(chartRow, chartCol, transnextChartID, transprevChartID) {

        $(".up").show();
        $(".down").show();
        $(".left").show();
        $(".right").show();

        const $this = $(".chart-table .top .active");
        const isTop = $this.parent().hasClass("top");
        const isThisActive = $this.hasClass("active");
        const $hitarea_div = $(".chart-table .hitarea div");
        const hitAreaActive = $hitarea_div.hasClass("active");
        const $chartTableActive = $(".chart-table .active");
        const index = $this.index();
        const index2 = $(".chart-table .hitarea .active").index();
        let nActiveCount = 0;

        //No Mask Selected
        if (index2 == 0) {
            //If previous chart not available
            if (transprevChartID == 0) {
                $(".up").hide();
                $(".left").hide();
            }
            $(".down").show();
            $(".right").show();
        } else if ((index2 + 1 == (chartRow * chartCol)) && chartRow > 2) {
            if ((transnextChartID == 0) || (transnextChartID == null)) {
                $(".down").hide();
                $(".right").hide();
            }
            $(".up").show();
            $(".left").show();
        } else if (chartRow <= 2) {
            if (index2 + 1 == (chartRow * chartCol)) {
                if ((transnextChartID == 0) || (transnextChartID == null)) {
                    $(".down").hide();
                    $(".right").hide();
                }
                $(".up").show();
                $(".left").show();
            }
            if (index2 >= chartCol * (chartRow - 1)) {
                if ((transnextChartID == 0) || (transnextChartID == null)) {
                    $(".down").hide();
                }
            }
        } else if (chartRow > 2) {
            if (index2 + 1 == (chartRow * chartCol)) {
                if ((transnextChartID == 0) || (transnextChartID == null)) {
                    $(".down").hide();
                    $(".right").hide();
                }
                $(".up").show();
                $(".left").show();
            }
            if (index2 >= chartCol * (chartRow - 1)) {
                if ((transnextChartID == 0) || (transnextChartID == null)) {
                    $(".down").hide();
                }
            }
        } else {
            $(".up").show();
            $(".down").show();
            $(".left").show();
            $(".right").show();
        }

        //Start Cell Column Up and Left
        if (transprevChartID == 0) {
            if (index2 < chartCol) {
                $(".up").hide();
                if (index2 == 0) {
                    $(".left").hide();
                } else {
                    if (index2 >= 0) {
                        $(".left").show();
                    }
                }
            } else {
                $(".up").show();
                $(".left").show();
            }
        }
    };

    function _visibleChartButtonsUpdateChart(refChartID) {
        const chartParameterItem = becky.subjective.arrayChartParameter.chartParameter.filter(
            chartParameterItem_ => chartParameterItem_.chartID === refChartID)[0];
        if (becky.assertion.isUndefined(chartParameterItem)) {
            return;
        }
        let transnextChartID = chartParameterItem.transition.nextChartID;
        let transprevChartID = chartParameterItem.transition.prevChartID;
    }

    function _updateHorVerMaxValue($labels, fAddValue) {
        if (!becky.assertion.isNullOrEmpty($labels)) {
            const fAValue = fAddValue;
            const dValue = $labels.attr("data-text");
            let fValue = parseFloat(dValue);
            fValue += parseFloat(fAValue);

            const dMin = $labels.attr("data-min");
            const dMax = $labels.attr("data-max");
            const dLoop = $labels.attr("data-loop");
            const isDefMin = !modelHelper.isUndefined(dMin);
            const isDefMax = !modelHelper.isUndefined(dMax);
            const isDefLoop = !modelHelper.isUndefined(dLoop);
            if (isDefMin) {
                const nMin = Number(dMin);
                if (nMin > fValue) {
                    if (isDefLoop && isDefMax) {
                        // 最大値が無いとループできない
                        const nMax = Number(dMax);
                        fValue = nMax + fValue;
                    } else {
                        fValue = nMin;
                    }
                }
            }
            if (isDefMax) {
                const nMax = Number(dMax);
                if (nMax < fValue) {
                    if (isDefLoop && isDefMin) {
                        // 最小値が無いとループできない
                        const nMin = Number(dMin);
                        fValue = nMin + fValue - nMax - 1;
                    } else {
                        fValue = dValue;
                    }
                }
            }
            $labels.attr("data-text", fValue.toFixed(2));
            _updateMainColor($labels);
        };
    };



    /*Prism buttons */
    $(".btn-clear").unbind().click(function () {});
    $(".btn-restore").unbind().click(function () {});
    $(".btn-allclear").unbind().click(function () {});
    $(window).on('load', function () {
        // Set the URL of the live image
        ["L", "R"].forEach(pos => {
            document.getElementById("imgEye" + pos).setAttribute("src", becky.liveHttpUri[pos]);
        });

        $(".horizontal-icons").show();
        $(".vertical-icons").hide();
        $("#labelMainPrismHor").trigger("click");
        $("#labelMainPrismHorR").attr("data-text", "0.00");
        $("#labelMainPrismHorL").attr("data-text", "0.00");
        $("#labelMainPrismVerR").attr("data-text", "0.00");
        $("#labelMainPrismVerL").attr("data-text", "0.00");
        



        const webStorageIO = becky.WebStorage.local.IO("subjective.update.data");
        const updateDataJson = webStorageIO.getJson();

        if (!modelHelper.isNull(updateDataJson)) {
            //const prismTestvalue = updateDataJson.prismstate;
            updateDataJson.prismstate.prism3FHR = "0.00";
            updateDataJson.prismstate.prism3FHL = "0.00";
            updateDataJson.prismstate.prism3FVR = "0.00";
            updateDataJson.prismstate.prism3FVL = "0.00";

            updateDataJson.prismstate.prism3NHR = "0.00";
            updateDataJson.prismstate.prism3NHL = "0.00";
            updateDataJson.prismstate.prism3NVR = "0.00";
            updateDataJson.prismstate.prism3NVL = "0.00";

            updateDataJson.prismstate.prism8FHR = "0.00";
            updateDataJson.prismstate.prism8FHL = "0.00";
            updateDataJson.prismstate.prism8FVR = "0.00";
            updateDataJson.prismstate.prism8FVL = "0.00";

            updateDataJson.prismstate.prism8NHR = "0.00";
            updateDataJson.prismstate.prism8NHL = "0.00";
            updateDataJson.prismstate.prism8NVR = "0.00";
            updateDataJson.prismstate.prism8NVL = "0.00";

            updateDataJson.prismstate.prism9FHR = "0.00";
            updateDataJson.prismstate.prism9FHL = "0.00";
            updateDataJson.prismstate.prism9FVR = "0.00";
            updateDataJson.prismstate.prism9FVL = "0.00";

            // updateDataJson.prismstate.prism9FHRunit = "0.00";
            // updateDataJson.prismstate.prism9FHLunit = "0.00";
            // updateDataJson.prismstate.prism9FVRunit = "0.00";
            // updateDataJson.prismstate.prism9FVLunit = "0.00";

            updateDataJson.prismstate.prism9NHR = "0.00";
            updateDataJson.prismstate.prism9NHL = "0.00";
            updateDataJson.prismstate.prism9NVR = "0.00";
            updateDataJson.prismstate.prism9NVL = "0.00";

            updateDataJson.prismstate.prism10FHR = "0.00";
            updateDataJson.prismstate.prism10FHL = "0.00";
            updateDataJson.prismstate.prism10FVR = "0.00";
            updateDataJson.prismstate.prism10FVL = "0.00";

            // updateDataJson.prismstate.prism10FHRunit = "0.00";
            // updateDataJson.prismstate.prism10FHLunit = "0.00";
            // updateDataJson.prismstate.prism10FVRunit = "0.00";
            // updateDataJson.prismstate.prism10FVLunit = "0.00";

            updateDataJson.prismstate.prism10NHR = "0.00";
            updateDataJson.prismstate.prism10NHL = "0.00";
            updateDataJson.prismstate.prism10NVR = "0.00";
            updateDataJson.prismstate.prism10NVL = "0.00";

            updateDataJson.prismstate.prism10NHRunit = "0.00";
            updateDataJson.prismstate.prism10NHLunit = "0.00";
            updateDataJson.prismstate.prism10NVRunit = "0.00";
            updateDataJson.prismstate.prism10NVLunit = "0.00";

            updateDataJson.prismstate.prism12AFHR = "0.00";
            updateDataJson.prismstate.prism12AFHL = "0.00";
            updateDataJson.prismstate.prism12AFVR = "0.00";
            updateDataJson.prismstate.prism12AFVL = "0.00";

            // updateDataJson.prismstate.prism12AFHRunit = "0.00";
            // updateDataJson.prismstate.prism12AFHLunit = "0.00";
            // updateDataJson.prismstate.prism12AFVRunit = "0.00";
            // updateDataJson.prismstate.prism12AFVLunit = "0.00";

            updateDataJson.prismstate.prism12ANHR = "0.00";
            updateDataJson.prismstate.prism12ANHL = "0.00";
            updateDataJson.prismstate.prism12ANVR = "0.00";
            updateDataJson.prismstate.prism12ANVL = "0.00";

            // updateDataJson.prismstate.prism12ANHRunit = "0.00";
            // updateDataJson.prismstate.prism12ANHLunit = "0.00";
            // updateDataJson.prismstate.prism12ANVRunit = "0.00";
            // updateDataJson.prismstate.prism12ANVLunit = "0.00";

            updateDataJson.prismstate.prism12BFHR = "0.00";
            updateDataJson.prismstate.prism12BFHL = "0.00";
            updateDataJson.prismstate.prism12BFVR = "0.00";
            updateDataJson.prismstate.prism12BFVL = "0.00";

            // updateDataJson.prismstate.prism12BFHRunit = "0.00";
            // updateDataJson.prismstate.prism12BFHLunit = "0.00";
            // updateDataJson.prismstate.prism12BFVRunit = "0.00";
            // updateDataJson.prismstate.prism12BFVLunit = "0.00";

            updateDataJson.prismstate.prism12BNHR = "0.00";
            updateDataJson.prismstate.prism12BNHL = "0.00";
            updateDataJson.prismstate.prism12BNVR = "0.00";
            updateDataJson.prismstate.prism12BNVL = "0.00";

            // updateDataJson.prismstate.prism12BNHRunit = "0.00";
            // updateDataJson.prismstate.prism12BNHLunit = "0.00";
            // updateDataJson.prismstate.prism12BNVRunit = "0.00";
            // updateDataJson.prismstate.prism12BNVLunit = "0.00";

            updateDataJson.prismstate.prism13AFHR = "0.00";
            updateDataJson.prismstate.prism13AFHL = "0.00";
            updateDataJson.prismstate.prism13AFVR = "0.00";
            updateDataJson.prismstate.prism13AFVL = "0.00";

            // updateDataJson.prismstate.prism13AFHRunit = "0.00";
            // updateDataJson.prismstate.prism13AFHLunit = "0.00";
            // updateDataJson.prismstate.prism13AFVRunit = "0.00";
            // updateDataJson.prismstate.prism13AFVLunit = "0.00";

            updateDataJson.prismstate.prism13ANHR = "0.00";
            updateDataJson.prismstate.prism13ANHL = "0.00";
            updateDataJson.prismstate.prism13ANVR = "0.00";
            updateDataJson.prismstate.prism13ANVL = "0.00";

            // updateDataJson.prismstate.prism13ANHRunit = "0.00";
            // updateDataJson.prismstate.prism13ANHLunit = "0.00";
            // updateDataJson.prismstate.prism13ANVRunit = "0.00";
            // updateDataJson.prismstate.prism13ANVLunit = "0.00";


            updateDataJson.prismstate.prism13BFHR = "0.00";
            updateDataJson.prismstate.prism13BFHL = "0.00";
            updateDataJson.prismstate.prism13BFVR = "0.00";
            updateDataJson.prismstate.prism13BFVL = "0.00";

            // updateDataJson.prismstate.prism13BFHRunit = "0.00";
            // updateDataJson.prismstate.prism13BFHLunit = "0.00";
            // updateDataJson.prismstate.prism13BFVRunit = "0.00";
            // updateDataJson.prismstate.prism13BFVLunit = "0.00";

            updateDataJson.prismstate.prism13BNHR = "0.00";
            updateDataJson.prismstate.prism13BNHL = "0.00";
            updateDataJson.prismstate.prism13BNVR = "0.00";
            updateDataJson.prismstate.prism13BNVL = "0.00";

            // updateDataJson.prismstate.prism13BNHRunit = "0.00";
            // updateDataJson.prismstate.prism13BNHLunit = "0.00";
            // updateDataJson.prismstate.prism13BNVRunit = "0.00";
            // updateDataJson.prismstate.prism13BNVLunit = "0.00";

            updateDataJson.prismstate.prism14AFHR = "0.00";
            updateDataJson.prismstate.prism14AFHL = "0.00";
            updateDataJson.prismstate.prism14AFVR = "0.00";
            updateDataJson.prismstate.prism14AFVL = "0.00";

            // updateDataJson.prismstate.prism14AFHRunit = "0.00";
            // updateDataJson.prismstate.prism14AFHLunit = "0.00";
            // updateDataJson.prismstate.prism14AFVRunit = "0.00";
            // updateDataJson.prismstate.prism14AFVLunit = "0.00";

            updateDataJson.prismstate.prism14ANHR = "0.00";
            updateDataJson.prismstate.prism14ANHL = "0.00";
            updateDataJson.prismstate.prism14ANVR = "0.00";
            updateDataJson.prismstate.prism14ANVL = "0.00";

            // updateDataJson.prismstate.prism14ANHRunit = "0.00";
            // updateDataJson.prismstate.prism14ANHLunit = "0.00";
            // updateDataJson.prismstate.prism14ANVRunit = "0.00";
            // updateDataJson.prismstate.prism14ANVLunit = "0.00";

            updateDataJson.prismstate.prism14BFHR = "0.00";
            updateDataJson.prismstate.prism14BFHL = "0.00";
            updateDataJson.prismstate.prism14BFVR = "0.00";
            updateDataJson.prismstate.prism14BFVL = "0.00";

            // updateDataJson.prismstate.prism14BFHRunit = "0.00";
            // updateDataJson.prismstate.prism14BFHLunit = "0.00";
            // updateDataJson.prismstate.prism14BFVRunit = "0.00";
            // updateDataJson.prismstate.prism14BFVLunit = "0.00";

            updateDataJson.prismstate.prism14BNHR = "0.00";
            updateDataJson.prismstate.prism14BNHL = "0.00";
            updateDataJson.prismstate.prism14BNVR = "0.00";
            updateDataJson.prismstate.prism14BNVL = "0.00";

            // updateDataJson.prismstate.prism14BNHRunit = "0.00";
            // updateDataJson.prismstate.prism14BNHLunit = "0.00";
            // updateDataJson.prismstate.prism14BNVRunit = "0.00";
            // updateDataJson.prismstate.prism14BNVLunit = "0.00";

            updateDataJson.prismstate.prism15AFHR = "0.00";
            updateDataJson.prismstate.prism15AFHL = "0.00";
            updateDataJson.prismstate.prism15AFVR = "0.00";
            updateDataJson.prismstate.prism15AFVL = "0.00";

            // updateDataJson.prismstate.prism15AFHRunit = "0.00";
            // updateDataJson.prismstate.prism15AFHLunit = "0.00";
            // updateDataJson.prismstate.prism15AFVRunit = "0.00";
            // updateDataJson.prismstate.prism15AFVLunit = "0.00";

            updateDataJson.prismstate.prism15ANHR = "0.00";
            updateDataJson.prismstate.prism15ANHL = "0.00";
            updateDataJson.prismstate.prism15ANVR = "0.00";
            updateDataJson.prismstate.prism15ANVL = "0.00";

            // updateDataJson.prismstate.prism15ANHRunit = "0.00";
            // updateDataJson.prismstate.prism15ANHLunit = "0.00";
            // updateDataJson.prismstate.prism15ANVRunit = "0.00";
            // updateDataJson.prismstate.prism15ANVLunit = "0.00";

            updateDataJson.prismstate.prism15BFHR = "0.00";
            updateDataJson.prismstate.prism15BFHL = "0.00";
            updateDataJson.prismstate.prism15BFVR = "0.00";
            updateDataJson.prismstate.prism15BFVL = "0.00";

            // updateDataJson.prismstate.prism15BFHRunit = "0.00";
            // updateDataJson.prismstate.prism15BFHLunit = "0.00";
            // updateDataJson.prismstate.prism15BFVRunit = "0.00";
            // updateDataJson.prismstate.prism15BFVLunit = "0.00";

            updateDataJson.prismstate.prism15BNHR = "0.00";
            updateDataJson.prismstate.prism15BNHL = "0.00";
            updateDataJson.prismstate.prism15BNVR = "0.00";
            updateDataJson.prismstate.prism15BNVL = "0.00";

            // updateDataJson.prismstate.prism15BNHRunit = "0.00";
            // updateDataJson.prismstate.prism15BNHLunit = "0.00";
            // updateDataJson.prismstate.prism15BNVRunit = "0.00";
            // updateDataJson.prismstate.prism15BNVLunit = "0.00";

            updateDataJson.prismstate.prism16FHR = "0.00";
            updateDataJson.prismstate.prism16FHL = "0.00";
            updateDataJson.prismstate.prism16FVR = "0.00";
            updateDataJson.prismstate.prism16FVL = "0.00";

            // updateDataJson.prismstate.prism16FHRunit = "0.00";
            // updateDataJson.prismstate.prism16FHLunit = "0.00";
            // updateDataJson.prismstate.prism16FVRunit = "0.00";
            // updateDataJson.prismstate.prism16FVLunit = "0.00";

            updateDataJson.prismstate.prism16NHR = "0.00";
            updateDataJson.prismstate.prism16NHL = "0.00";
            updateDataJson.prismstate.prism16NVR = "0.00";
            updateDataJson.prismstate.prism16NVL = "0.00";

            // updateDataJson.prismstate.prism16NHRunit = "0.00";
            // updateDataJson.prismstate.prism16NHLunit = "0.00";
            // updateDataJson.prismstate.prism16NVRunit = "0.00";
            // updateDataJson.prismstate.prism16NVLunit = "0.00";

            updateDataJson.prismstate.prism17FHR = "0.00";
            updateDataJson.prismstate.prism17FHL = "0.00";
            updateDataJson.prismstate.prism17FVR = "0.00";
            updateDataJson.prismstate.prism17FVL = "0.00";

            // updateDataJson.prismstate.prism17FHRunit = "0.00";
            // updateDataJson.prismstate.prism17FHLunit = "0.00";
            // updateDataJson.prismstate.prism17FVRunit = "0.00";
            // updateDataJson.prismstate.prism17FVLunit = "0.00";

            updateDataJson.prismstate.prism17NHR = "0.00";
            updateDataJson.prismstate.prism17NHL = "0.00";
            updateDataJson.prismstate.prism17NVR = "0.00";
            updateDataJson.prismstate.prism17NVL = "0.00";

            // updateDataJson.prismstate.prism17NHRunit = "0.00";
            // updateDataJson.prismstate.prism17NHLunit = "0.00";
            // updateDataJson.prismstate.prism17NVRunit = "0.00";
            // updateDataJson.prismstate.prism17NVLunit = "0.00";

            updateDataJson.prismstate.prism18AFHR = "0.00";
            updateDataJson.prismstate.prism18AFHL = "0.00";
            updateDataJson.prismstate.prism18AFVR = "0.00";
            updateDataJson.prismstate.prism18AFVL = "0.00";

            updateDataJson.prismstate.prism18ANHR = "0.00";
            updateDataJson.prismstate.prism18ANHL = "0.00";
            updateDataJson.prismstate.prism18ANVR = "0.00";
            updateDataJson.prismstate.prism18ANVL = "0.00";

            webStorageIO.setJson(updateDataJson);

        }


        let biText = $(".prism-heading-inner-hor-R-BI").attr("data-fixed");
        let boText = $(".prism-heading-inner-hor-L-BI").attr("data-fixed");
        let bdText = $(".prism-heading-inner-ver-R-BD").attr("data-fixed");
        let buText = $(".prism-heading-inner-ver-L-BD").attr("data-fixed");

        // if (biText == '1') {
        //     $(".prism-heading-inner-hor-R-BI").attr("data-text", "BI ");
        // } else {
        //     $(".prism-heading-inner-hor-R-BI").attr("data-text", "BI ");
        // }

        // if (boText == '1') {
        //     $(".prism-heading-inner-hor-L-BI").attr("data-text", "BI ");
        // } else {
        //     $(".prism-heading-inner-hor-L-BI").attr("data-text", "BO ");
        // }

        // if (bdText == '1') {
        //     $(".prism-heading-inner-ver-R-BD").attr("data-text", "BD ");
        // } else {
        //     $(".prism-heading-inner-ver-R-BD").attr("data-text", "BU ");
        // }

        // if (buText == '1') {
        //     $(".prism-heading-inner-ver-L-BD").attr("data-text", "BU ");
        // } else {
        //     $(".prism-heading-inner-ver-L-BD").attr("data-text", "BD ");
        // }


    });


}()); //即時関数の終端y