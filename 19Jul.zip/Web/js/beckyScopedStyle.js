/*! @file
 * @brief あるスコープで一時的にスタイルを変える
 *
 * 使用例
 * const pointerEvents = becky.scopedStyle.css($("#button"), "pointer-events", "none", "auto");
 * pointerEvents.begin();
 * try {
 * 	(時間のかかる非同期処理)
 * } finally {
 * 	pointerEvents.end();
 * }
 */
"use strict";

// 名前空間
var becky = becky || {};
becky.scopedStyle = becky.scopedStyle || {};

/*!
 * @brief 単一/複数設定できる jQuery.css
 *
 * @param[in,out] selector $target 設定対象
 * @param[in] string aName CSS名
 * @param[in] string aValue CSS値
 * @return void
 */
becky.scopedStyle._css = function($target, aName, aValue)
{
	if (1 < $target.length) {
		$target.each((i, element) =>
			$(element).css(aName, aValue));
	} else {
		$target.css(aName, aValue);
	}
}

/*!
 * @brief 単一/複数設定できる jQuery.css
 *
 * @param[in,out] selector $target 設定対象
 * @param[in] string aName CSS名
 * @param[in] string aValueBegin 最初に呼びたいCSS値
 * @param[in] string aValueEnd 最後に呼びたいCSS値
 * @return object begin(), end()
 */
becky.scopedStyle.css = function($target, aName, aValueBegin, aValueEnd)
{
	if (becky.assertion.isNullOrEmpty($target)) {
		return null;
	}
	return {
		begin: () => becky.scopedStyle._css($target, aName, aValueBegin),
		end  : () => becky.scopedStyle._css($target, aName, aValueEnd  ),
	};
}
