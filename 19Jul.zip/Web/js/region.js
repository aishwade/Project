/*! @file
 * @brief リージョン設定で使用するスクリプト
 */

// 即時関数を使って閉じ込める
(function(){
"use strict";

$(document).ready(function(){
	$("#select_1-2_1").selectmenu();
});

}());//即時関数の終端
