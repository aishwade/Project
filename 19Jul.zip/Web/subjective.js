/*! @file
 * @brief 自覚で使用するスクリプト
 *
 * 依存するもの
 * - viewHelper.js
 * - ajaxHelper.js
 * - beckyMutationObserver.js
 * - beckyDataSync.js
 * - beckyWebStorageHelper.js
 * - beckyWebStorageIO.js
 * - beckyAsyncAjax.js
 * - beckyLeanStartupAjax.js
 * - beckyScopedStyle.js
 */

// 即時関数を使って閉じ込める
(function(){
	"use strict";
	
	//! @brief chartPage.parameter.json の chartPageN のカレント
	let _currentChart = null;
	//! @brief 遠見/近見 切り替え時にセットするSCA
	const _changeFarNearSetSCA = {
		far : "Sph",
		near: "ADD",
	}
	//! @brief 例外:クロスシリンダーの計算に使用する基準値
	const _crossCylinderBase = {};
	
	/*!
	 * @brief カレントの視標を更新
	 *
	 * @param[in] array chartTable chartPage.parameter.json の chartPageN の単一要素
	 */
	function _setCurrentChart(chartTable)
	{
		_currentChart = chartTable;
		// 例外:クロスシリンダー対応
		const mv = _updateDataMeasurementValue();
		["Sph", "Cyl"].forEach(sc_ => {
			["L", "R"].forEach(pos_ => {
				const key = sc_ + pos_;
				_crossCylinderBase[key] = mv[key];
			});
		});
		// 端末に一時保存(リロード対策)
		const webStorageIO = becky.WebStorage.local.IO("subjective.update.data");
		const updateDataJson = webStorageIO.getJson();
		if (!modelHelper.isNull(updateDataJson)) {
			updateDataJson.screenState.currentAutoID = chartTable.autoID;
			webStorageIO.setJson(updateDataJson);
		}
	}
	
	/*!
	 * @brief コマンド呼び出しイベントの排他制御オブジェクト
	 * 開始:begin(), 終了:end()
	 *
	 * @return becky.scopedStyle.css
	 */
	function _getPointerEventsByCommand()
	{
		const selectors = [
			"#btnSetting" , // 設定
			"#btnNaviNext", // 次へ
			".confirm-box .btn-group-va", // 視標の隣のボタン
			".area-center",      // メインデータのエリア
			".controller-a",     // コントローラーの左右(両)眼
			".controller-b",     // コントローラーの調整ボタン
			".controller-c",     // クロスシリンダー回転
			".controller-d",     // 乱視/軸の切り替え
			"[data-auto-id]",    // タブ内の視力表(サムネイル)
			"#btnMenuFarNear",   // 遠見/近見
			"#btnMenuBinoMono",  // 両眼開放/片眼遮蔽
			"#btnAutoAlignment", // オートアライメント
			"#btnResetBaseXYZ",  // 駆動リセット
			"#btnMenuCC_Power",  // クロスシリンダー power
			"[id^=inputExaminationDistancePoint_]", // 検査距離
		];
		//becky.debug.scope(() => {
		//	selectors.forEach(selector_ => {
		//		becky.assertion.assert(!modelHelper.isNullOrEmpty($(selector_)));
		//	});
		//});
		const $target = $(selectors.join(","));
		return becky.scopedStyle.css($target, "pointer-events", "none", "auto");
	}
	
	/*!
	 * @brief 配列の文字列をトグルした値を返す
	 *
	 * @param[in] string aVal 対象の値
	 * @param[in] array aDefs 定義文字列郡
	 * @return string 対象をトグルした値
	 */
	function _toggleVal_Base(aVal, aDefs)
	{
		if (becky.assertion.isNullOrEmpty(aDefs)) {
			return;
		}
		becky.assertion.assert(2 === aDefs.length, "2 === aDefs.length");
		const index = aDefs.indexOf(aVal);
		becky.assertion.assert(0 <= index, "_toggleVal_Base");
		const toggledIndex = 0 !== index ? 0 : 1;
		return aDefs[toggledIndex];
	}
	
	/*!
	 * @brief 文字を大きくするスタイルを適用
	 *
	 * @param[in,out] element $label 対象
	 */
	function _toTextLarge($label)
	{
		$label.removeClass("txt-small").addClass("txt-large");
	}
	
	/*!
	 * @brief 文字を小さくするスタイルを適用
	 *
	 * @param[in,out] element $label 対象
	 */
	function _toTextSmall($label)
	{
		$label.removeClass("txt-large").addClass("txt-small");
	}
	
	/*!
	 * @brief (自覚)メッセージの定義リストから文字列を得る
	 *
	 * @param[in] string aKeyBySubjective (自覚)メッセージの定義名
	 * @return string メッセージ文字列
	 */
	function _getDefMessageBySubjective(aKeyBySubjective)
	{
		if (becky.assertion.isNullOrEmpty(aKeyBySubjective)) {
			return "";
		}
		return viewHelper.getDefMessage("subjective/" + aKeyBySubjective);
	}
	
	/*!
	 * @brief 要素が表示状態か？
	 *
	 * @param[in] element $element 調査対象
	 * @retval true  表示状態
	 * @retval false 非表示状態
	 */
	function _isShow($element)
	{
		return $element.is(":visible");
	}
	
	/*!
	 * @brief 要素が非表示状態か？
	 *
	 * @param[in] element $element 調査対象
	 * @retval true  非表示状態
	 * @retval false 表示状態
	 */
	function _isHide($element)
	{
		return !_isShow($element);
	}
	
	/*!
	 * @brief 選択されている眼を得る
	 *
	 * @retval "R" 右眼が選択されている
	 * @retval "L" 左眼が選択されている
	 * @retval "B" 両眼が選択されている
	 */
	function _getSelectEye()
	{
		return $("#currentEye").attr("data-value");
	}
	
	/*!
	 * @brief 右眼が選択されているか？
	 *
	 * @retval true  右眼が選択されている(両眼選択を含む)
	 * @retval false 右眼は選択されていない
	 */
	function _isSelectEyeR()
	{
		const eyeValue = _getSelectEye();
		switch (eyeValue) {
			case "R":
				return true;
			case "L":
				return false;
			case "B":
				return true;
			default:
				becky.assertion.failure("unknown eye");
				return false;
		}
	}
	
	/*!
	 * @brief 左眼が選択されているか？
	 *
	 * @retval true  左眼が選択されている(両眼選択を含む)
	 * @retval false 左眼は選択されていない
	 */
	function _isSelectEyeL()
	{
		const eyeValue = _getSelectEye();
		switch (eyeValue) {
			case "R":
				return false;
			case "L":
				return true;
			case "B":
				return true;
			default:
				becky.assertion.failure("unknown eye");
				return false;
		}
	}
	
	/*!
	 * @brief 両眼が選択されているか？
	 *
	 * @retval true  両眼が選択されている
	 * @retval false 両眼は選択されていない
	 */
	function _isSelectEyeB()
	{
		const eyeValue = _getSelectEye();
		switch (eyeValue) {
			case "R":
				return false;
			case "L":
				return false;
			case "B":
				return true;
			default:
				becky.assertion.failure("unknown eye");
				return false;
		}
	}
	
	/*!
	 * @brief 左右両眼を選択状態にする
	 * Model を更新
	 *
	 * @param[in] string aVal 選択対象
	 */
	function _setSelectEye(aVal)
	{
		switch (aVal) {
			case "B":
			case "R":
			case "L":
				break;
			default:
				becky.assertion.failure("unknown eye");
				return;
		}
		$("#currentEye").attr("data-value", aVal);
	}
	
	/*!
	 * @brief 右眼を選択状態にする
	 * 変更イベントから呼ばれる事を想定
	 * 左眼の選択状態は解除される
	 */
	function _setSelectEyeR_FromEvent()
	{
		const $btnControllerEyeR = $("#btnControllerEyeR");
		if (!$btnControllerEyeR.hasClass("current")) {
			viewHelper.selectClassSingle("current", $btnControllerEyeR);
		}
		$(".data-table").addClass("current-a").removeClass("current-b");
	
		const isSelectEyes = {
			R: true ,
			L: false,
		};
		_updateMainClasses(isSelectEyes, null);
	}
	
	/*!
	 * @brief 左眼を選択状態にする
	 * 変更イベントから呼ばれる事を想定
	 * 右眼の選択状態は解除される
	 */
	function _setSelectEyeL_FromEvent()
	{
		const $btnControllerEyeL = $("#btnControllerEyeL");
		if (!$btnControllerEyeL.hasClass("current")) {
			viewHelper.selectClassSingle("current", $btnControllerEyeL);
		}
		$(".data-table").addClass("current-b").removeClass("current-a");
	
		const isSelectEyes = {
			R: false,
			L: true ,
		};
		_updateMainClasses(isSelectEyes, null);
	}
	
	/*!
	 * @brief 両眼を選択状態にする
	 * 変更イベントから呼ばれる事を想定
	 */
	function _setSelectEyeB_FromEvent()
	{
		const $btnControllerEyeB = $("#btnControllerEyeB");
		if (!$btnControllerEyeB.hasClass("current")) {
			viewHelper.selectClassSingle("current", $btnControllerEyeB);
		}
		$(".data-table").addClass("current-a current-b");
	
		// 両眼のクロスシリンダーなし
	
		const isSelectEyes = {
			R: true,
			L: true,
		};
		_updateMainClasses(isSelectEyes, null);
	}
	
	/*!
	 * @brief Sph, Cyl, Axs, ADD のどれが選択されているか？
	 *
	 * @retval "Sph" Sph が選択されている
	 * @retval "Cyl" Cyl が選択されている
	 * @retval "Axs" Axs が選択されている
	 * @retval "ADD" ADD が選択されている
	 */
	function _getSelectSCA()
	{
		return $("#currentSCA").attr("data-value");
	}
	
	/*!
	 * @brief Sph が選択されているか？
	 *
	 * @retval true  Sph が選択されている
	 * @retval false Sph は選択されていない
	 */
	function _isSelectSph()
	{
		return "Sph" === _getSelectSCA();
	}
	
	/*!
	 * @brief Cyl が選択されているか？
	 *
	 * @retval true  Cyl が選択されている
	 * @retval false Cyl は選択されていない
	 */
	function _isSelectCyl()
	{
		return "Cyl" === _getSelectSCA();
	}
	
	/*!
	 * @brief Axs が選択されているか？
	 *
	 * @retval true  Axs が選択されている
	 * @retval false Axs は選択されていない
	 */
	function _isSelectAxs()
	{
		return "Axs" === _getSelectSCA();
	}
	
	/*!
	 * @brief ADD が選択されているか？
	 *
	 * @retval true  ADD が選択されている
	 * @retval false ADD は選択されていない
	 */
	function _isSelectADD()
	{
		return "ADD" === _getSelectSCA();
	}
	
	/*!
	 * @brief Sph, Cyl, Axs, ADD を選択する
	 * Model を更新
	 *
	 * @param[in] string aVal 選択対象
	 */
	function _setSelectSCA(aVal)
	{
		switch (aVal) {
			case "Sph":
			case "Cyl":
			case "Axs":
			case "ADD":
				break;
			default:
				becky.assertion.failure("unknown SCA");
				return;
		}
		$("#currentSCA").attr("data-value", aVal);
		// 遠見/近見 切り替え時にセットするSCAを更新
		const selectFarNear = _getSelectFarNear();
		_changeFarNearSetSCA[selectFarNear] = aVal;
	}
	
	/*!
	 * @brief Sph を選択する
	 * 変更イベントから呼ばれる事を想定
	 */
	function _setSelectSph_FromEvent()
	{
		const $btnMenuS = $("#btnMenuS");
		const $btnMenuC = $("#btnMenuC");
		const $btnMenuA = $("#btnMenuA");
		const $menuItemS = $btnMenuS.parent(".menu-item");
		const $menuItemC = $btnMenuC.parent(".menu-item");
		const $menuItemA = $btnMenuA.parent(".menu-item");
	
		$menuItemS.show();
		$menuItemC.hide();
		$menuItemA.hide();
	
		const isSelectSCAs = {
			Sph:  true,
			Cyl: false,
			Axs: false,
			ADD: false,
		};
		_updateMainClasses(null, isSelectSCAs);
	}
	
	/*!
	 * @brief Cyl を選択する
	 * 変更イベントから呼ばれる事を想定
	 */
	function _setSelectCyl_FromEvent()
	{
		const $btnMenuS = $("#btnMenuS");
		const $btnMenuC = $("#btnMenuC");
		const $btnMenuA = $("#btnMenuA");
		const $menuItemS = $btnMenuS.parent(".menu-item");
		const $menuItemC = $btnMenuC.parent(".menu-item");
		const $menuItemA = $btnMenuA.parent(".menu-item");
	
		$menuItemS.hide();
		$menuItemC.show();
		$menuItemA.hide();
	
		const isSelectSCAs = {
			Sph: false,
			Cyl:  true,
			Axs: false,
			ADD: false,
		};
		_updateMainClasses(null, isSelectSCAs);
	}
	
	/*!
	 * @brief Axs を選択する
	 * 変更イベントから呼ばれる事を想定
	 */
	function _setSelectAxs_FromEvent()
	{
		const $btnMenuS = $("#btnMenuS");
		const $btnMenuC = $("#btnMenuC");
		const $btnMenuA = $("#btnMenuA");
		const $menuItemS = $btnMenuS.parent(".menu-item");
		const $menuItemC = $btnMenuC.parent(".menu-item");
		const $menuItemA = $btnMenuA.parent(".menu-item");
	
		$menuItemS.hide();
		$menuItemC.hide();
		$menuItemA.show();
	
		const isSelectSCAs = {
			Sph: false,
			Cyl: false,
			Axs:  true,
			ADD: false,
		};
		_updateMainClasses(null, isSelectSCAs);
	}
	
	/*!
	 * @brief ADD を選択する
	 * 変更イベントから呼ばれる事を想定
	 */
	function _setSelectADD_FromEvent()
	{
		const $btnMenuS = $("#btnMenuS");
		const $btnMenuC = $("#btnMenuC");
		const $btnMenuA = $("#btnMenuA");
		const $menuItemS = $btnMenuS.parent(".menu-item");
		const $menuItemC = $btnMenuC.parent(".menu-item");
		const $menuItemA = $btnMenuA.parent(".menu-item");
	
		$menuItemS.show(); // 加入(ADD)は Sph のステップを使用する
		$menuItemC.hide();
		$menuItemA.hide();
	
		const isSelectSCAs = {
			Sph: false,
			Cyl: false,
			Axs: false,
			ADD:  true,
		};
		_updateMainClasses(null, isSelectSCAs);
	}
	
	/*!
	 * @brief Cyl/Axs の選択状態をトグルする
	 */
	function _toggleSelectCylAxs()
	{
		const currentSCA = _getSelectSCA();
		switch (currentSCA) {
			case "Cyl":
				_setSelectSCA("Axs");
				break;
			case "Axs":
				_setSelectSCA("Cyl");
				break;
			default:
				break;
		}
	}
	
	/*!
	 * @brief 遠見/近見 の値を得る
	 *
	 * @retval string "far"  遠見
	 * @return string "near" 近見
	 */
	function _getSelectFarNear()
	{
		return $("#btnMenuFarNear").val();
	}
	
	/*!
	 * @brief 遠見 が選択されているか？
	 *
	 * @retval bool true  遠見
	 * @retval bool false 遠見ではない
	 */
	function _isSelectFar()
	{
		return "far" === _getSelectFarNear();
	}
	
	/*!
	 * @brief 近見 が選択されているか？
	 *
	 * @retval bool true  近見
	 * @retval bool false 近見ではない
	 */
	function _isSelectNear()
	{
		return "near" === _getSelectFarNear();
	}
	
	/*!
	 * @brief 両眼開放/片眼遮蔽 の値を得る
	 *
	 * @retval string "bino" 両眼開放
	 * @return string "mono" 片眼遮蔽
	 */
	function _getSelectBinoMono()
	{
		return $("#btnMenuBinoMono").val();
	}
	
	/*!
	 * @brief 片眼遮蔽 が選択されているか？
	 *
	 * @retval bool true  片眼遮蔽
	 * @retval bool false 片眼遮蔽ではない
	 */
	function _isSelectMono()
	{
		return "mono" === _getSelectBinoMono();
	}
	
	/*!
	 * @brief クロスシリンダーの status を得る
	 *
	 * @param[in] array chartTable chartPage.parameter.json の chartPageN の単一要素
	 * @return int クロスシリンダーの status
	 */
	function _getCrossCylinderStatus(chartTable)
	{
		if (becky.assertion.isUndefined(chartTable)) {
			return 0;
		}
		switch (chartTable.examID) {
			case 1021: // [遠]ジャクソンクロスシリンダー
				break;
			case 2030: // [近]加入度測定
				return 3;
			default:
				return 0;
		}
		const currentSCA = _getSelectSCA();
		switch (currentSCA) {
			case "Cyl":
				// 度数検査
				return 2;
			case "Axs":
				// 軸検査
				return 1;
			default:
				becky.assertion.failure("unknown select type");
				return 0;
		}
	}
	
	/*!
	 * @brief クロスシリンダーの power を得る
	 *
	 * @return int クロスシリンダーの power
	 */
	function _getCrossCylinderPower()
	{
		const strDataValue = $("#btnMenuCC_Power").attr("data-value");
		const fDataValue = parseFloat(strDataValue);
		return fDataValue;
	}
	
	/*!
	 * @brief クロスシリンダーのRG値を得る
	 *
	 * @param[in] array chartTable chartPage.parameter.json の chartPageN の単一要素
	 * @return int クロスシリンダーのRG値
	 */
	function _getCrossCylinderRG(chartTable)
	{
		// chartTable が指定されなかった場合は UI に設定されている状態のみで値を返す。
		// 指定されている場合は、検査の種類も考慮した値を返す。
		if (!modelHelper.isUndefined(chartTable)) {
			switch (chartTable.examID) {
				case 1021: // [遠]ジャクソンクロスシリンダー
					break;
				default:
					return 0;
			}
		}
		const strSelectIndex = $("#groupCrossCylinder").attr("data-select-index");
		const nSelectIndex = parseInt(strSelectIndex, 10);
		return nSelectIndex + 1;
	}
	
	/*!
	 * @brief クロスシリンダーを得る(Phoropter 向け)
	 *
	 * @param[in] array chartTable chartPage.parameter.json の chartPageN の単一要素
	 * @return int クロスシリンダーの値
	 */
	function _getCrossCylinderByPhoropter(chartTable)
	{
		return {
			status: _getCrossCylinderStatus(chartTable),
			power: _getCrossCylinderPower(),
			RG: _getCrossCylinderRG(chartTable),
		};
	}
	
	/*!
	 * @brief RGFilter 値を得る
	 *
	 * @param[in] array chartTable chartPage.parameter.json の chartPageN の単一要素
	 * @return int RGFilter 値
	 */
	function _getRGFilter(chartTable)
	{
		switch (chartTable.examID) {
			case 1010: // [遠]R/Gテスト
				return 1;
			default:
				return 0;
		}
	}
	
	/*!
	 * @brief select-title クラスを持つ要素に対して更新を行う
	 *
	 * @param[in,out] element $selectTitle 対象のセレクタ
	 */
	function _updateSelectTitle($selectTitle)
	{
		if (becky.assertion.isNullOrEmpty($selectTitle)) {
			return;
		}
	
		const val = $selectTitle.parents(".select-box").find(".select-selector").val();
		$selectTitle.find(".txt-select-title").text(val);
	}
	
	/*!
	 * @brief メニューのステップの更新処理
	 * MutationObserver 経由で呼ばれる
	 * 
	 * @param[in] Node aRecordTarget 対象のレコード
	 * @param[in] string aMenuID 対象のメニューID
	 */
	function _onUpdateHtmlMenuStep(aRecordTarget, aMenuID)
	{
		const value = aRecordTarget.dataset.value;
		const $currentItem = $("[data-for=" + aMenuID + "] [data-value='" + value + "']");
		$currentItem.addClass("current").siblings().removeClass("current");
		const itemText = $currentItem.text();
		$("#" + aMenuID + " > div").attr("data-text", itemText);
	}
	
	/*!
	 * @brief 遠見/近見 をトグルした値を返す
	 *
	 * @param[in] string aVal 対象の値
	 * @return string 対象をトグルした値
	 */
	function _toggleVal_FarNear(aVal)
	{
		return _toggleVal_Base(aVal, ["far", "near"]);
	}
	
	/*!
	 * @brief 遠見/近見 のラベルを更新する
	 *
	 * @param[in] Node aRecordTarget 対象のレコード
	 */
	function _updateLblFarNear(aRecordTarget)
	{
		const val = aRecordTarget.value;
		const toggleVal = _toggleVal_FarNear(val);
		_toTextLarge($("#labelMenu_" + val      ));
		_toTextSmall($("#labelMenu_" + toggleVal));
		const text = viewHelper.getDefMessage("global/" + val);
		$("#labelHeaderCenter").text(text);
	}
	
	/*!
	 * @brief 両眼開放/片眼遮蔽 をトグルした値を返す
	 *
	 * @param[in] string aVal 対象の値
	 * @return string 対象をトグルした値
	 */
	function _toggleVal_BinoMono(aVal)
	{
		return _toggleVal_Base(aVal, ["bino", "mono"]);
	}
	
	/*!
	 * @brief 両眼開放/片眼遮蔽 のラベルを更新する
	 *
	 * @param[in] Node aRecordTarget 対象のレコード
	 */
	function _updateLblBinoMono(aRecordTarget)
	{
		const val = aRecordTarget.value;
		const toggleVal = _toggleVal_BinoMono(val);
		_toTextLarge($("#labelMenu_" + val      ));
		_toTextSmall($("#labelMenu_" + toggleVal));
	}
	
	/*!
	 * @brief 視力表の反転を解除
	 */
	function _resetChartInvert()
	{
		$(".chart-table .image img").attr("style", "filter: Invert(0)");
		$(".chart-table .hitarea").attr("style", "filter: Invert(0)");
		$(".chart-table .top").attr("style", "filter: Invert(0)");
		$(".chart-table .side").attr("style", "filter: Invert(0)");
		$(".chart-table .bg").removeClass("bg-invert");
		//$(".chart-table .bg").removeClass("bg-rg");
		
		
	}
	
	/*!
	 * @brief 視力表の RG を解除
	 */
	function _resetChartRG()
	{
		$(".chart-table .bg").removeClass("bg-rg");
	}
	
	/*!
	 * @brief 視力表の反転/RG ボタンの更新
	 *
	 * @param[in] array chartTable chartPage.parameter.json の chartPageN の単一要素
	 */
	function _updateChartInvertAndRG(chartTable)
	{
		const chartParameterItem = becky.subjective.arrayChartParameter.chartParameter.filter(
			chartParameterItem_ => chartParameterItem_.chartID === chartTable.chartID)[0];
	if (becky.assertion.isUndefined(chartParameterItem)) {
		return;
	}
		
		let bInvert = false;
		let bRG = chartParameterItem.filterRG;

	
		const $btnInvert = $("#btnChartInvert");
		if (bInvert) {
			$btnInvert.show();
		} else {
			$btnInvert.hide();
			// 画像の背景スタイルも更新
			_resetChartInvert();
		}
	
		const $btnRG = $("#btnChartRG");
		if (bRG) {
			$btnRG.show();
		} else {
			$btnRG.hide();
			// 画像の背景スタイルも更新
			_resetChartRG();
		}
	}
	
	/*!
	 * @brief 視力表テーブルのレイアウト更新
	 *
	 * @param[in] int totalColumnCount 列数
	 * @param[in] int totalRowCount 行数
	 */
	function _updateChartTableLayout(chartTable, totalColumnCount, totalRowCount)
	{
        const chartParameterItem = becky.subjective.arrayChartParameter.chartParameter.filter(
            chartParameterItem_ => chartParameterItem_.chartID === chartTable.chartID)[0];
        if (becky.assertion.isUndefined(chartParameterItem)) {
            return;
        }
		let one_letter = chartParameterItem.letter;
		let updown_nomask = chartParameterItem.noMaskOper.updown;
		let down_nomask = chartParameterItem.noMaskOper.down;
		let up_nomask = chartParameterItem.noMaskOper.up;
		let leftright_nomask = chartParameterItem.noMaskOper.leftright;
		let left_nomask = chartParameterItem.noMaskOper.left;
		let right_nomask = chartParameterItem.noMaskOper.right;
		let transnextChartID = chartParameterItem.transition.nextChartID;
		let transprevChartID = chartParameterItem.transition.prevChartID;
		
			
		// イベントの解除
		const top_side_div = ".chart-table .top div, .chart-table .side div";
		$(top_side_div).unbind();
		const hitarea_div = ".chart-table .hitarea div";
		$(hitarea_div).unbind();
		
		const $top = $(".chart-table .top");
		{	// 三角(下向き)
			const val = viewHelper.repeatString("<div>&#x25BC;</div>", totalColumnCount);
			$top.html(val);
		}
	
		const $up = $(".chart-shift .up");
		{	// 三角(下向き)
			const val = viewHelper.repeatString("<div>&#9650;</div>", 1);
			$up.html(val);
		}
		const $updummy = $(".chart-shift .updummy");
		{	// 三角(下向き)
			const val = viewHelper.repeatString("<div>&#9650;</div>", 1);
			$updummy.html(val);
		}
		const $down = $(".chart-shift .cursor-btn .down");
		{	// 三角(下向き)
			const val = viewHelper.repeatString("<div>&#9660;</div>", 1);
			$down.html(val);
		}
		const $downdummy = $(".chart-shift .cursor-btn .downdummy");
		{	// 三角(下向き)
			const val = viewHelper.repeatString("<div>&#9660;</div>", 1);
			$downdummy.html(val);
		}
		const $left = $(".chart-buttons .left");
		{	// 三角(下向き)
			const val = viewHelper.repeatString("<div>&#9664;</div>", 1);
			$left.html(val);
		}
		const $leftdummy = $(".chart-buttons .leftdummy");
		{	// 三角(下向き)
			const val = viewHelper.repeatString("<div>&#9664;</div>", 1);
			$leftdummy.html(val);
		}
		const $right = $(".chart-buttons .right");
		{	// 三角(下向き)
			const val = viewHelper.repeatString("<div>&#9654;</div>", 1);
			$right.html(val);
		}
		const $rightdummy = $(".chart-buttons .rightdummy");
		{	// 三角(下向き)
			const val = viewHelper.repeatString("<div>&#9654;</div>", 1);
			$rightdummy.html(val);
		}
		const $side = $(".chart-table .side");
		{	// 三角(右向き)
			const val = viewHelper.repeatString("<div>&#x25C0;</div>", totalRowCount);
			$side.html(val);
		}
		const $hitarea = $(".chart-table .hitarea");
		{
			const val = viewHelper.repeatString('<div class="active"></div>', totalColumnCount * totalRowCount);
			$hitarea.html(val);
		}
		
	
		const singleWidth  =  $top.width()  / totalColumnCount;
		const singleHeight = $side.height() / totalRowCount;
	
		 $top.children().width (singleWidth );
		$side.children().height(singleHeight);
		$hitarea.children().width(singleWidth).height(singleHeight);
	
		// イベントの(再)登録
	
		// 行・列の選択
		//masking row/column
		$(top_side_div).click(function(){	
			const $this = $(this);
			const isTop  = $this.parent().hasClass("top" );
			const isSide = $this.parent().hasClass("side");
			const isThisActive = $this.hasClass("active");
			const $hitarea_div = $(".chart-table .hitarea div");
			const index = $this.index();
			//const index_top = $(isTop).index;

			if (isThisActive) {
				$this.removeClass("active");
				$hitarea_div.addClass("active");
			} else {
				$(".chart-table div").removeClass("active");
				$this.addClass("active");
				//const index = $this.index();
				
				$hitarea_div.removeClass("active");
					   if (isTop) {													 
					for (let i = 0; i < totalColumnCount * totalRowCount; i += totalColumnCount) {
						$hitarea_div.eq(index +  i).addClass("active");
					}				
				}
				 if (isSide) {
					for (let i = 0; i < totalColumnCount; ++i) {
						$hitarea_div.eq(index * totalColumnCount + i).addClass("active");
					}
             }
               	
            }

            if (isThisActive)
            {
                $(".right").hide();
                $(".left").hide();
                $(".up").show();
                $(".down").show();

                if (transprevChartID == 0) {
                    $(".up").hide();
                }
                if (transnextChartID == 0) {
                    $(".down").hide();
                }                
            }
            else
            {
                _visibleChartButtonsOnMaskSelection(totalRowCount, totalColumnCount, transnextChartID, transprevChartID, index, isTop);
            }           
            
			// RG は排他なので無効化
			_resetChartRG();
			
		});
		//right click event
		/*Chart Transition*/
		function selectCurrentChart(chartTable){
			_updateChartTableLayout(chartTable);
				_updateChartTable(chartTable);
                _updateControllerLayout(chartTable);
                _updateMenuInit(chartTable);
                _updateSelectSCA_FromChart(chartTable);
            // カレント更新
			   _setCurrentChart(chartTable);
			console.log(chartTable);
			console.log(chartTable.autoID);
								_setCurrentChart(chartTable);
			const $tabContent = $("[data-auto-id=" + chartTable.autoID + "]");
				if (!modelHelper.isNull($tabContent)) {
					if (!$tabContent.hasClass("current")) {
						$("[data-auto-id]").removeClass("current");
							$tabContent.addClass("current");
							const $tabContentParent = $tabContent.parent();
							const tabIndex = $tabContentParent.parent().children().index($tabContentParent);
							if (tabIndex != $("#tabChart").attr("data-tab-index")) {
								// 差がある場合のみ反映
								$("#tabChart").attr("data-tab-index", tabIndex);
							}
						}
					}
					
					 
				}
		/*Cell Selection during Previous Chart Transition on Left Button Click */
		function selectLastCell(chartTable){
			selectCurrentChart(chartTable);
			//var index = localStorage['index'];
			$(hitarea_div).last().trigger("click");	
		}
		 /*Cell Selection during Next Chart Transition on Right Button Click */
		 function selectFirstCell(chartTable){
			//var index = localStorage['index'];
			selectCurrentChart(chartTable);
			$(hitarea_div).first().trigger("click");	
        }

        /*Cell Selection during Next Chart Transition on Down Button Click */
        function selectNextChartCellOnDown(chartTable) {

            var index = localStorage['index'];
            selectCurrentChart(chartTable);
                var currentCol = localStorage['currentCol'];
                var currentRow = localStorage['currentRow'];
                var intIndex = 0;

                if (totalColumnCount == currentCol) {
					if(totalRowCount==currentRow){
						intIndex = index - (currentCol * (currentRow - 1));
					}
					else if(totalRowCount>currentRow){
						intIndex = currentRow
					}
					else
					intIndex = index - currentCol
				}
				else if (totalColumnCount > currentCol) {
					if(index==totalColumnCount*(totalRowCount-1)){
						intIndex =0
					}
					else if(index==totalColumnCount*(totalRowCount-1) + 2){
						intIndex = 1
					}
					else if(index>totalColumnCount*(totalRowCount-1) + 2){
						intIndex = currentCol-1
					}
				}
				else if (totalColumnCount < currentCol) {
					if(index==totalColumnCount){
						intIndex =0
					}
					else if(index==totalColumnCount+1){
						intIndex = totalRowCount
					}
					else if(index==totalColumnCount*totalRowCount-1){
						intIndex = currentCol-1
					}
				}          
            $(hitarea_div).eq(intIndex).trigger("click");
        }

        /*Cell Selection during Previous Chart Transition on Up Button Click */
        function selectNextChartCellOnUp(chartTable) {

            var index = parseInt(localStorage['index']);
            selectCurrentChart(chartTable);
            var currentCol = parseInt(localStorage['currentCol']);
            var currentRow = parseInt(localStorage['currentRow']);
            var intIndex1 = parseInt(0);

            if (totalColumnCount == currentCol) {
                intIndex1 = index + (currentCol * (currentRow - 1));
            }
            else if (totalColumnCount > currentCol) {
                if(index>2){
					intIndex1 = currentRow*currentCol -1
				}
				else if(index<=1){
					intIndex1 = currentCol
				}
				else if(index==2){
					intIndex1 = currentCol + 1
				}
            }
            else if (totalColumnCount < currentCol) {
				if(index>1){
					intIndex1 = currentRow*currentCol -1
				}
				else if(index==1){
					intIndex1 = currentCol*(currentRow-1) + 2
				}
				else if(index<1){
					intIndex1 = currentCol*(currentRow-1)
				}
            }

            $(hitarea_div).eq(intIndex1).trigger("click");            
        }

		/*On chart transition, select first row of next chart */
		function selectFirstDown(chartTable){
			
			selectCurrentChart(chartTable);
			$(".chart-table .side div").first().trigger("click");	
		}
		function selectFirstCol(chartTable){
			
			selectCurrentChart(chartTable);
			$(".chart-table .top div").first().trigger("click");	
		}
		function selectLastCol(chartTable){
			
			selectCurrentChart(chartTable);
			$(".chart-table .top div").last().trigger("click");	
		}
		/*On chart transition, select last column of previous chart */
		function selectLast(chartTable){
			var index_top = localStorage['index_top']; //Current chart selected column index
			
            if (index_top == null)
                {
                    selectCurrentChart(chartTable);
                 }
            else {
			        selectCurrentChart(chartTable)
			        var currentCol=localStorage['currentCol'];
                    if ((currentCol > 3) && totalColumnCount > 3) {
                        $(".chart-table .top div").eq(index_top).trigger("click");
                    }
                    else
                    {
			            if(currentCol>3) {
				            if(index_top<1){
					            $(".chart-table .top div").first().trigger("click");
				            }
				            if(index_top>1){
					            $(".chart-table .top div").last().trigger("click");
				            }
				            if(index_top==1){
					            $(".chart-table .top div").eq(2).trigger("click");
				            }		
			            }
			             if(currentCol<=3){
				            if(index_top>2){
					            $(".chart-table .top div").last().trigger("click");
				            }
				            if(index_top==2){
					            $(".chart-table .top div").eq(1).trigger("click");
				            }
				            if(index_top<=1){
					            $(".chart-table .top div").first().trigger("click");
				            }
			            }
                    }	
                }
		 }
		
		 /*On chart transition, select last row of previous chart */
		 function selectLastDown(chartTable){
			selectCurrentChart(chartTable);
			$(".chart-table .side div").last().trigger("click");	
		 }
		 /*Masking and chart transition on click of right button */
		$(".right").unbind().click(function(){
			const $this = $(".chart-table .top .active");
			const isTop  = $this.parent().hasClass("top" );
			const isThisActive = $this.hasClass("active");
			const $hitarea_div = $(".chart-table .hitarea div");
			const hitAreaActive = $hitarea_div.hasClass("active");
			const index = $this.index();
			const index2 = $(".chart-table .hitarea .active").index();
			const $chartTableActive = $(".chart-table .active");
			let nActiveCount = 0;
			if(leftright_nomask==0||right_nomask==0) {$(".right").hide();}
			else
			/*If column is masked */
			if (isThisActive) {
				console.log(index);
				if (isTop) {
					if(totalRowCount*totalColumnCount>=10){
						if(index==3 &&(transnextChartID==0)){
						 $(".right").hide();
						}
					}
				}
				$this.removeClass("active");
				$hitarea_div.removeClass("active");	
				if (isTop) {
					
					if(index == (totalColumnCount-1)){
						for (let i = 1; i < totalColumnCount * totalRowCount; i +=totalColumnCount) {
							$hitarea_div.eq(index +i-1).addClass("active");	
							console.log(index);
							(async function(){
							const pointerEvents = _getPointerEventsByCommand();
							chartTable.maskCell = 'NULL';
							chartTable.Row = totalRowCount;
							chartTable.Col = totalColumnCount;
							await _postMaskCommand(chartTable);
							}());
													
						}
						$this.addClass("active");
					   }	
					   else
					for (let i = 1; i < totalColumnCount * totalRowCount; i +=totalColumnCount) {
						
						$hitarea_div.eq(index +i).addClass("active");	
												
					}
                    if ((index) == (totalColumnCount - 1))
						{							
								//chartTable.chartID=transnextChartID;
								if((transnextChartID==0) || (transnextChartID==null) ){
									$(".right").hide();
								}
								else{
          						const charts = becky.subjective.arrayFlatChartPageParameter.filter(chart_ => transnextChartID == chart_.chartID);
								chartTable = charts[0];
								selectFirstCol(chartTable);
								(async function(){
							const pointerEvents = _getPointerEventsByCommand();
							chartTable.maskCell = 'NULL';
							chartTable.Row = totalRowCount;
							chartTable.Col = totalColumnCount;
							await _postMaskCommand(chartTable);
							}());
							}
							
					}
					_visibleChartButtonsOnMaskSelection(totalRowCount, totalColumnCount, transnextChartID, transprevChartID, index+1, isTop)
				}
				$this.next().addClass("active");	
				if(index==-1)
				{
					const charts = becky.subjective.arrayFlatChartPageParameter.filter(chart_ => transnextChartID == chart_.chartID);
						chartTable = charts[0];
                        selectCurrentChart(chartTable);
                    //Change long chart without selecting mask
                    (async function () {
                        const pointerEvents = _getPointerEventsByCommand();
						await _postChartCommand(chartTable);
                    }());
				}	
			}
			else
			 /*If single cell is masked */
			if (!modelHelper.isNullOrEmpty($chartTableActive)) {
				nActiveCount = $chartTableActive.length;
				const isSingleActive = 1 == nActiveCount;
				if (hitAreaActive && isSingleActive) {
					$hitarea_div.removeClass("active");
					console.log(totalColumnCount);
					for (let i = 1; i <= totalColumnCount * totalRowCount; i+=totalColumnCount*totalRowCount) {
						$hitarea_div.eq(i+index2).addClass("active");										
					}
					if(transnextChartID==0 || transnextChartID==null){
						if ((index2+1)==(totalRowCount*totalColumnCount-1)){
						$(".right").hide();
						}
						if(index2+1>=totalColumnCount*(totalRowCount-1)){

							$(".down").hide();
						}
						else $(".right").show();
					}
					if ((index2+1)==(totalRowCount*totalColumnCount)) { 
					
						{
							const charts = becky.subjective.arrayFlatChartPageParameter.filter(chart_ => transnextChartID == chart_.chartID);
							chartTable = charts[0];
							selectFirstCell(chartTable);
						}
						
						}
						else 
						if(index2>totalRowCount-1){
							$(".up").show();
						}
						$(".left").show();
						
						;
						(async function(){
							const pointerEvents = _getPointerEventsByCommand();
							chartTable.Row = totalRowCount;
							chartTable.Col = totalColumnCount;
							await _postMaskCommand(chartTable);
							}());
					
				
				} else {
					$hitarea_div.addClass("active");
				}
			}
			else
			// RG は排他なので無効化
			_resetChartRG();
		});
	//left click event
	$(".left").unbind().click(function(){
		const $this = $(".chart-table .top .active");
		const isTop  = $this.parent().hasClass("top" );
		const isThisActive = $this.hasClass("active");
		const $hitarea_div = $(".chart-table .hitarea div");
		const hitAreaActive = $hitarea_div.hasClass("active");
		const $chartTableActive = $(".chart-table .active");
		const index = $this.index();
		const index2 = $(".chart-table .hitarea .active").index();
		let nActiveCount = 0;
		if(leftright_nomask==0||left_nomask==0) {$(".left").hide();}

        if (index2 == 1 && isTop) {
			{	
				$this.removeClass("active");
				$hitarea_div.removeClass("active");	
					for (let i = 1; i < totalColumnCount * totalRowCount; i+=totalColumnCount) {
						$hitarea_div.eq(index-i).addClass("active");
					}
					$this.prev().addClass("active");
            }
            if ((transprevChartID == 0) || (transprevChartID == null)) {
                $(".left").hide();
                 }
			
		}
			else
			/* If column is masked*/
		if (isThisActive) {
			console.log(index);
			if (isTop) {
				console.log(index);
				if(index==0)
						{
								{
								const charts = becky.subjective.arrayFlatChartPageParameter.filter(chart_ => transprevChartID == chart_.chartID);
								chartTable = charts[0];
								selectLastCol(chartTable);
								(async function(){
							const pointerEvents = _getPointerEventsByCommand();
							chartTable.maskCell = index;
							chartTable.Row = totalRowCount;
							chartTable.Col = totalColumnCount;
							await _postMaskCommand(chartTable);
							}());
							}
						}	
						else
					if(index>0){	
			$this.removeClass("active");
			$hitarea_div.removeClass("active");	
				for (let i = 1; i < totalColumnCount * totalRowCount; i+=totalColumnCount) {
					$hitarea_div.eq(index-i).addClass("active");
				}
				$this.prev().addClass("active");
				_visibleChartButtonsOnMaskSelection(totalRowCount, totalColumnCount, transnextChartID, transprevChartID, index-1, isTop)
			}
		}
		}		
		else
		/*If single cell is masked */
			if (!modelHelper.isNullOrEmpty($chartTableActive)) {
				nActiveCount = $chartTableActive.length;
				const isSingleActive = 1 == nActiveCount;
				if (hitAreaActive && isSingleActive) {
					$hitarea_div.removeClass("active");
					for (let i = 1; i < totalColumnCount * totalRowCount; i+=totalColumnCount*totalRowCount) {
						$hitarea_div.eq(index2-i).addClass("active");										
					}
					if(index2<=totalColumnCount*(totalRowCount-1)){
						$(".down").show();
					}
					if((transprevChartID==0) || (transprevChartID==null)){
						if(index2==1){
						$(".left").hide();
						}
						else{
							if (index2<=totalColumnCount)
							$(".up").hide();
						}
					} 
					if (index2<1)
					{
							//chartTable.chartID=transprevChartID;
							const charts = becky.subjective.arrayFlatChartPageParameter.filter(chart_ => transprevChartID == chart_.chartID);
							chartTable = charts[0];
							selectLastCell(chartTable);
							(async function(){
							const pointerEvents = _getPointerEventsByCommand();
							chartTable.maskCell = index;
							chartTable.Row = totalRowCount;
							chartTable.Col = totalColumnCount;
							await _postMaskCommand(chartTable);
							}());
						
						}
						else $(".right").show();
				} 
				else {
					$hitarea_div.addClass("active");
				
				}
			}	
		// RG は排他なので無効化
		_resetChartRG();
		
	});
	/*Up Button Click event */
	$(".up").unbind().click(function(){
		const $this = $(".chart-table .side .active");
		const $this_top = $(".chart-table .top .active");
		const index = $this.index();
		const index_top = $this_top.index();
		localStorage['index_top'] = index_top;
		const isSide = $this.parent().hasClass("side");
		const isTop = $this_top.parent().hasClass("top");
		const isThisActive = $this.hasClass("active");
		const isTopActive = $this_top.hasClass("active");
		const $hitarea_div = $(".chart-table .hitarea div");
		const $chartTableActive = $(".chart-table .active");
		const index2 = $(".chart-table .hitarea .active").index();
		localStorage['index'] = index2;
		const hitAreaActive = $hitarea_div.hasClass("active");
        let nActiveCount = 0;


		if(updown_nomask==0||up_nomask==0) {$(".up").hide();}
		
	else
		/*If row is selected */
		if (isThisActive) {		
            $this.removeClass("active");
			$hitarea_div.addClass("active");
			$(".chart-table div").removeClass("active");
			$hitarea_div.removeClass("active");
				 if (isSide) {
					const index3 = $this.prev().index();
					const firstindex = $this.eq(0).index();
				for (let i = 0; i < totalColumnCount; ++i) {
						$hitarea_div.eq(index3 * totalColumnCount+i).addClass("active");
				}
					if (index == 0 || index == -1)
					{							 
								//chartTable.chartID=transnextChartID;
							const charts = becky.subjective.arrayFlatChartPageParameter.filter(chart_ => transprevChartID == chart_.chartID);
							chartTable = charts[0];
							selectLastDown(chartTable);
							(async function(){
							const pointerEvents = _getPointerEventsByCommand();
							chartTable.maskCell = index;
							chartTable.Row = totalRowCount;
							chartTable.Col = totalColumnCount;
							await _postMaskCommand(chartTable);
							}());				
					}	
				$this.prev().addClass("active");

			}
			
            _visibleChartButtonsOnMaskSelection(totalRowCount, totalColumnCount, transnextChartID, transprevChartID, index-1, isTop);
		}
		else
		if (isTopActive){
			if (isTop) {													 
										 
							//chartTable.chartID=transnextChartID;
						const charts = becky.subjective.arrayFlatChartPageParameter.filter(chart_ => transprevChartID == chart_.chartID);
						chartTable = charts[0];
						selectLast(chartTable);
			
		}
		}
		else
		/*If single cell is selected */
		if (!modelHelper.isNullOrEmpty($chartTableActive)) {
			nActiveCount = $chartTableActive.length;
			const isSingleActive = 1 == nActiveCount;
			if (hitAreaActive && isSingleActive) {
				$hitarea_div.removeClass("active");			
				for (let i = 0; i < totalColumnCount * totalRowCount; i+=(totalColumnCount-1)) {
					$hitarea_div.eq(index2-totalColumnCount).addClass("active");
				}
				if(totalRowCount<=2)
				{
					if (index2<=totalColumnCount*totalRowCount){
						if((transprevChartID==0) || (transprevChartID==null)){
							if(index2==totalColumnCount){
								$(".left").hide();
							}
							$(".up").hide();
						}
						$(".down").show();
						$(".right").show();  
					}
				}
				else if(totalRowCount>2)
				{
					if (index2<=totalColumnCount*totalRowCount){
						if((transprevChartID==0) || (transprevChartID==null)){
							if(index2==totalColumnCount){
								$(".left").hide();
							}
							if(index2<=totalColumnCount+totalRowCount+1){
							$(".up").hide();
							}
						}
						$(".down").show();
						$(".right").show();  
					}
				}
				else {
				if (index2<totalColumnCount*(totalRowCount-1)){
					if((transprevChartID==0) || (transprevChartID==null)){
						if(index2==totalColumnCount){
							$(".left").hide();
						}
						$(".up").hide();
						 
					}
				}					
				}
                if (index2<totalColumnCount)
				{
						const charts = becky.subjective.arrayFlatChartPageParameter.filter(chart_ => transprevChartID == chart_.chartID);
								chartTable = charts[0];
                                //Select current selected index
                                //selectLastCell(chartTable);
                                selectNextChartCellOnUp(chartTable);
								(async function(){
								const pointerEvents = _getPointerEventsByCommand();
								chartTable.maskCell = index;
								chartTable.Row = totalRowCount;
								chartTable.Col = totalColumnCount;
								await _postMaskCommand(chartTable);
								}());
					}
            }
            else 	/*If no mask */
                if (index == -1) {
                    if ((transprevChartID == 0) || (transprevChartID == null)) {
                        _visibleChartButtonsOnLoad(transnextChartID, transprevChartID);
                    }
                    else {
                        const charts = becky.subjective.arrayFlatChartPageParameter.filter(chart_ => transprevChartID == chart_.chartID);
                        chartTable = charts[0];
                        selectCurrentChart(chartTable);
                      
                        const chartParameterItem = becky.subjective.arrayChartParameter.chartParameter.filter(
                            chartParameterItem_ => chartParameterItem_.chartID === transprevChartID)[0];
                        if (becky.assertion.isUndefined(chartParameterItem)) {
                            return;
                        }                      
                        _visibleChartButtonsOnLoad(chartParameterItem.transition.nextChartID, chartParameterItem.transition.prevChartID);

                        (async function () {
                            const pointerEvents = _getPointerEventsByCommand();
	                        await _postChartCommand(chartTable);
                        }());
                    }                    
                }	
            else {
                $hitarea_div.addClass("active");
                }
	}
		// RG は排他なので無効化
		else _resetChartRG();
	});
		//down button masking
	$(".down").unbind().click(function(){
			const $this = $(".chart-table .side .active");
			const $this_top =  $(".chart-table .top .active");
			const index = $this.index();
			const index_top = $this_top.index();
			localStorage['index_top'] = index_top;
			const isSide = $this.parent().hasClass("side");
			const isTop = $this_top.parent().hasClass("top");
			const isThisActive = $this.hasClass("active");
			const isTopActive = $this_top.hasClass("active");
			const $hitarea_div = $(".chart-table .hitarea div");
			const $chartTableActive = $(".chart-table .active");
			const index2 = $(".chart-table .hitarea .active").index();
			localStorage['index'] = index2;
			const hitAreaActive = $hitarea_div.hasClass("active");
			let nActiveCount = 0;

        if (updown_nomask == 0 || down_nomask == 0) { $(".down").hide(); }

        else
            /*Mask Movement when row is selected */
            if (isThisActive) {
                console.log(index2)
                $this.removeClass("active");
                $hitarea_div.addClass("active");
                $(".chart-table div").removeClass("active");
                $this.next().addClass("active");
                const index3 = $this.next().index();
                $hitarea_div.removeClass("active");
                if (isSide) {
					
                    for (let i = 0; i < totalColumnCount; ++i) {
                        $hitarea_div.eq(index3 * totalColumnCount + i).addClass("active");
                        $this.next().addClass("active")
                    }
                    
                    if ((index + 1) == (totalRowCount)) {
                            //chartTable.chartID=transnextChartID;
                            const charts = becky.subjective.arrayFlatChartPageParameter.filter(chart_ => transnextChartID == chart_.chartID);
                            chartTable = charts[0];
                            selectFirstDown(chartTable);
                          (async function () {
                                const pointerEvents = _getPointerEventsByCommand();
                                chartTable.maskCell = index;
                                chartTable.Row = totalRowCount;
                                chartTable.Col = totalColumnCount;
                                await _postMaskCommand(chartTable);
                            }());
                        
                    }

					$this.next().addClass("active")
					_visibleChartButtonsOnMaskSelection(totalRowCount, totalColumnCount, transnextChartID, transprevChartID, index+1, isTop)

                }
			}
			if (isTopActive){
				if (isTop) {													 
											 
								//chartTable.chartID=transnextChartID;
							const charts = becky.subjective.arrayFlatChartPageParameter.filter(chart_ => transnextChartID == chart_.chartID);
							chartTable = charts[0];
							selectLast(chartTable);
				
			}
			}
            else
                /*Mask movement when single cell is selected */
                if (!modelHelper.isNullOrEmpty($chartTableActive)) {
					
                    nActiveCount = $chartTableActive.length;
                    const isSingleActive = 1 == nActiveCount;
                    if (hitAreaActive && isSingleActive) {
                        $hitarea_div.removeClass("active");
                        for (let i = 0; i < totalRowCount * totalColumnCount; i += totalColumnCount * totalRowCount) {
                            $hitarea_div.eq(i + index2 + totalColumnCount).addClass("active");
						}
						if(totalRowCount<=2){
							if (index2>=0){
								if ((transnextChartID == 0) || (transnextChartID == null)) {
									if(index2+1==totalColumnCount*(totalRowCount-1)){
										$(".right").hide();
									}
								$(".down").hide();
								}
							}
						}
						else
						if (index2>totalColumnCount-1){
							if ((transnextChartID == 0) || (transnextChartID == null)) {
								if(index2+1==totalColumnCount*(totalRowCount-1)){
									$(".right").hide();
								}
							$(".down").hide();
							}
						}

                        if ((index2 + totalColumnCount) >= (totalRowCount * totalColumnCount)) {
                            //chartTable.chartID=transprevChartID;
                            const charts = becky.subjective.arrayFlatChartPageParameter.filter(chart_ => transnextChartID == chart_.chartID);
                            chartTable = charts[0];
                           selectNextChartCellOnDown(chartTable);

						}
						else 
						{$(".up").show();
						$(".left").show()
							};
                    }
                    else if (index == -1) {
						/*When no mask is selected - chart transition */
						
                        if ((transnextChartID == 0) || (transnextChartID == null)) {
                            _visibleChartButtonsOnLoad(transnextChartID, transprevChartID);
                        }
                        else {
                            const charts = becky.subjective.arrayFlatChartPageParameter.filter(chart_ => transnextChartID == chart_.chartID);
                            chartTable = charts[0];
                            selectCurrentChart(chartTable);

                            const chartParameterItem = becky.subjective.arrayChartParameter.chartParameter.filter(
                                chartParameterItem_ => chartParameterItem_.chartID === transnextChartID)[0];
                            if (becky.assertion.isUndefined(chartParameterItem)) {
                                return;
                            }
                            _visibleChartButtonsOnLoad(chartParameterItem.transition.nextChartID, chartParameterItem.transition.prevChartID);

                            (async function () {
                                const pointerEvents = _getPointerEventsByCommand();
                                await _postChartCommand(chartTable);
                            }());
                        }                       

                    }
					
                }
             
                else 
					_resetChartRG();
		});

		// 単一の選択
		//masking single element
		$(hitarea_div).click(function(){
			const $this = $(this);
			const index=$this.index();
			const isThisActive = $this.hasClass("active");
			const $chartTableActive = $(".chart-table .active");
			localStorage['index'] = index;
			let nActiveCount = 0;
			if (!modelHelper.isNullOrEmpty($chartTableActive)) {
				nActiveCount = $chartTableActive.length;
			}
			console.log(index);
			(async function(){
				// ボタンを無効化
				const pointerEvents = _getPointerEventsByCommand();
				//await _postChartCommand(chartTable);
				chartTable.maskCell = index;
				chartTable.Row = totalRowCount;
				chartTable.Col = totalColumnCount;
				//console.log(chartTable);
				await _postMaskCommand(chartTable);
				
			}());
	
			$(".chart-table div").removeClass("active");
	
			const isSingleActive = one_letter == nActiveCount;
			if(one_letter==1){
			if (isThisActive && isSingleActive) {
                $(".chart-table .hitarea div").addClass("active");
                $(".left").hide();
                $(".right").hide();
			} else{
				$this.addClass("active");
				//Left, right, up, down buttons on single cell selection
			     _visibleChartButtonsOnCellSelection(totalRowCount, totalColumnCount, transnextChartID, transprevChartID);
			}
            }
			// RG は排他なので無効化
			_resetChartRG();
		
		});
		
	}
	
	/*!
	 * @brief 視力表テーブルのボタン更新
	 *
	 * @param[in] (array of (integer or string)) aBtnValues ボタンに表示する内容(数値または文字列)の配列
	 * @param[in] bool aIsSingleLine ボタンが単一(列)か？
	 */
	function _updateChartTableButtons(aBtnValues, aIsSingleLine)
	{
		// ボタンのイベント解除 & 削除
		//Cancel button event & delete
		{
			const group = ".confirm-box .btn-group-va";
			const button = group + " button";
			const $button = $(button);
			if (!modelHelper.isNullOrEmpty($button)) {
				$button.unbind();
			}
			$(group).text("");
		}
		// ボタン生成
		//Button generation
		{
			let group = null;
			if (aIsSingleLine) {
				group = ".confirm-box .btn-group-b";
			} else {
				group = ".confirm-box .btn-group-c";
			}
			if (!modelHelper.isNullOrEmpty(aBtnValues)) {
				const $buttons = aBtnValues.map(btnValue => {
					const $div = $("<div/>").attr({
						class: "btn-inner",
					}).text(btnValue);
					const $button = $("<button/>").attr({
						type: "button",
						class: "btn btn-confirm",
						value: btnValue,
					}).append($div);
					return $button;
				});
				$(group).append($buttons);
			}
		}
		// 例外
		// ボタンが複数(列)という条件の場合「視力」ボタンを生成する
		//If the button has multiple (rows) conditions, generate the "eyesight" button
		if (!aIsSingleLine) {
			const captionVA = viewHelper.getDefMessage("global/va");
			const $div = $("<div/>").attr({
				class: "btn-inner",
			}).text(captionVA);
			const $button = $("<button/>").attr({
				type: "button",
				class: "btn btn-confirm",
				id: "btnShowVA",
			}).append($div);
			$(".confirm-box .btn-group-b").append($button);
		}
		{
			const group = ".confirm-box .btn-group-va";
			const button = group + " button";
			const $button = $(button); // すぐ上で生成したボタンを含めるため再代入
			if (!modelHelper.isNullOrEmpty($button)) {
				// ボタンの背景処理を変更する
				_buttonClickBackGroundOverlay($button);
			}
		}
	}
	
	/*!
	 * @brief 視力表テーブルの更新
	 *
	 * @param[in] array chartTable chartPage.parameter.json の chartPageN の単一要素
	 */
	function _updateChartTable(chartTable)
	{
		const chartParameterItem = becky.subjective.arrayChartParameter.chartParameter.filter(
				chartParameterItem_ => chartParameterItem_.chartID === chartTable.chartID)[0];
		if (becky.assertion.isUndefined(chartParameterItem)) {
			return;
		}
		
		
		// 反転/RG ボタンの更新
		_updateChartInvertAndRG(chartTable);
	
		// Todo. chart.parameter.json に定義すべき
		let col = chartParameterItem.col;
		let row = chartParameterItem.row;
        let one_letter = chartParameterItem.letter;
		let prevChart = chartParameterItem.transition.prevChartID;
		let nextChart = chartParameterItem.transition.nextChartID;
		_updateChartTableLayout(chartTable, col, row);
        localStorage['currentCol'] = col;
        localStorage['currentRow'] = row;
		
		/* show/hide mask navigation icons based on row/column count */
	
		const top_side_col = ".chart-table .top div";
		const top_side_row = ".chart-table .side div";

		if (col<=1){
				$(top_side_col).hide();
				$(".sidecursors").hide();
				$("#btnChartRG").hide();
				
		}
		else if (col>=2)
		{
			$(top_side_col).show();
			$(".sidecursors").show();
			$("#btnChartRG").show();
		}
		
		if (row<=1){
				$(top_side_row).hide();
				$(".sidecursors").hide();
				$("#btnChartRG").hide();
		}
		else if (row>=2)
		{
			$(top_side_row).show();
			$(".sidecursors").show();
			$("#btnChartRG").show();
        }

        $(".right").hide();
        $(".left").hide();

       
		// 視力表画像の切り替え
		let imgExt = "";
		switch (chartTable.chartID) {
			case 2004:
			case 2005:
			case 2006:
			case 2007:
			case 2104:
			case 2105:
			case 2106:
			case 2107:
			case 2204:
			case 2205:
			case 2206:
			case 2207:
			case 3156:
			case 3157:
				imgExt = ".svg";
				break;
			default:
				imgExt = ".png";
				break;
				
		}
		const imgSrc = "../img/large/large_" + chartTable.chartID + imgExt;
		$(".chart-table .image img").attr("src", imgSrc);
				
		let btnValues = null;
		switch (chartTable.examID) {
			case 1020: // [遠]乱視テスト
			case 1021: // [遠]ジャクソンクロスシリンダー
				btnValues = [0, 45, 90, 135, ];
				break;
			default:
				if (!becky.assertion.isUndefined(chartParameterItem.va) &&
					!becky.assertion.isUndefined(chartParameterItem.va.string)) {
					btnValues = chartParameterItem.va.string;
				}
				break;
		}
	
		const isSingleLine = modelHelper.isNullOrEmpty(btnValues) || 6 > btnValues.length;
		_updateChartTableButtons(btnValues, isSingleLine);
	
		// 「視力」ボタン関連のイベント
		{
			const $btnShowVA = $("#btnShowVA");
			const $chartTable = $(".chart-table");
			const $vaTable = $(".confirm-box .btn-group-c");
			const $vaTableButton = $(".confirm-box .btn-group-c button");
			const fncShowVA = function(){
				$chartTable.toggle();
				$vaTable.toggle();
			
			};
			const fncHideVA = function(){
				$chartTable.show();
				$vaTable.hide();
			};
			$btnShowVA.click(fncShowVA);
			
			$vaTableButton.click(fncHideVA);
			fncHideVA();
		}
	
		// 検査毎に異なるボタンイベントの登録を行う
		const $btnChartTable = $(".confirm-box .btn-group-va button");
		switch (chartTable.examID) {
			case 1000: // [遠]球面度テスト / 遠用視力測定
				$btnChartTable.click(function(){
					const val = $(this).val();
					if (modelHelper.isNullOrEmpty(val)) {
						return;
					}
	
					let $labelMainVA = null;
					let strFarNear = "";
					const farNear = _getSelectFarNear();
					switch (farNear) {
						case "far":
							strFarNear = "_Far";
							break;
						case "near":
							strFarNear = "_Near";
							break;
						default:
							becky.assertion.failure("unknown far near");
							break;
					}
					const eyeValue = _getSelectEye();
					switch (eyeValue) {
						case "B":
						case "R":
						case "L":
							$labelMainVA = $("#labelMainVA" + strFarNear + eyeValue);
							break;
						default:
							becky.assertion.failure("unknown eye");
							return;
					}
	
					$labelMainVA.attr("data-text", val);
					$labelMainVA.attr("data-unit", chartParameterItem.va.format);
				});
				break;
			case 1020: // [遠]乱視テスト
			case 1021: // [遠]ジャクソンクロスシリンダー
				$btnChartTable.click(function(){
					let val = $(this).val();
					if (modelHelper.isNullOrEmpty(val)) {
						return;
					}
	
					// 軸の 0 は 180 として扱う
					if (0 == val) {
						val = 180;
					}
	
					let $labelMainAxs = null;
					const eyeValue = _getSelectEye();
					switch (eyeValue) {
						case "B":
							$labelMainAxs = $("[id^=labelMainAxs]");
							break;
						case "R":
						case "L":
							$labelMainAxs = $("#labelMainAxs" + eyeValue);
							break;
						default:
							becky.assertion.failure("unknown eye");
							return;
					}
	
					// 値変更前
					const orgJson = _updateDataMeasurementValue();
	
					$labelMainAxs.each((i, element) => {
						const $label = $(element);
						const dValue = $label.attr("data-text");
						if (modelHelper.isUndefined(dValue)) {
							// おそらく、#labelMainAxsCaption
							return;
						}
	
						$label.attr("data-text", val);
					});
	
					(async function(){
						// ボタンを無効化
						const pointerEvents = _getPointerEventsByCommand();
						pointerEvents.begin();
						try {
							// フォロプター
							await _postPhoropterCommand(_currentChart);
							// 端末に一時保存(リロード対策)
							_saveDataToWebStorage();
						} catch (resultJson) {
							// 失敗したら値を戻す
							_updateDataMeasurementValue(orgJson);
							// エラーメッセージ表示
							becky.LeanStartup.alertErrorMessage(resultJson);
						} finally {
							// 完了時にボタンを有効化
							pointerEvents.end();
						}
					}());
			
				});
				break;
			case 1010: // [遠]R/G テスト
			case 1092: // [遠]ウォース4点テスト
			case 2030: // [近]加入度測定
				break;
			default:
				becky.assertion.failure("unknown chart examID");
				break;
		}
	
		switch (chartTable.examID) {
			case 1021: // [遠]ジャクソンクロスシリンダー
				$(".eye-mark").show();
				break;
			default:
				$(".eye-mark").hide();
				break;
        }

       _visibleChartButtonsOnLoad(nextChart, prevChart);
	}
	
	/*!
	 * @brief 選択眼の更新
	 *
	 * @param[in] array chartTable chartPage.parameter.json の chartPageN の単一要素
	 */
	function _updateSelectEyeFromChart(chartTable)
	{
		if (modelHelper.isUndefined(chartTable.testEyeID)) {
			return;
		}
	
		switch (chartTable.testEyeID) {
			case 0: // 検査対象眼の変更をせず、直前の状態を引き継ぐ
				break;
			case 1: // 片眼右眼検査
				_setSelectEye("R");
				break;
			case 2: // 片眼左眼検査
				_setSelectEye("L");
				break;
			case 3: // 直前の被検眼が片眼ならその状態を引き継ぎ、それ以外なら片眼(右)として扱う
				if (_isSelectEyeB()) {
					_setSelectEye("R");
				}
				break;
			case 4: // 両眼検査で、データ変更対象が両眼
				_setSelectEye("B");
				break;
			case 5: // 両眼検査で、データ変更対象が右眼
				_setSelectEye("R");
				break;
			case 6: // 両眼検査で、データ変更対象が左眼
				_setSelectEye("L");
				break;
			default:
				becky.assertion.failure("unknown chart testEyeID");
				break;
		}
	}
	
	/*!
	 * @brief 操作コントローラーのレイアウトの更新を行う
	 *
	 * @param[in] array chartTable chartPage.parameter.json の chartPageN の単一要素
	 */
	function _updateControllerLayout(chartTable)
	{
		let htmls = null;
		let visibles = null;
		let disableEyeBino = false;
		switch (chartTable.examID) {
			case 1000: // [遠]球面度テスト / 遠用視力測定
			case 2030: // [近]加入度測定
				htmls = {
					L: {
						main: "( + )",
						tips: "",
					},
					R: {
						main: "( - )",
						tips: "",
					},
				};
				visibles = {
					C: false,
					D: false,
					E: false,
				};
				break;
			case 1010: // [遠]R/G テスト
				htmls = {
					L: {
						main: "G",
						tips: "( + )",
					},
					R: {
						main: "R",
						tips: "( - )",
					},
				};
				visibles = {
					C: false,
					D: false,
					E: false,
				};
				break;
			case 1020: // [遠]乱視テスト
				htmls = {
					L: {
						main: "( + )",
						tips: "",
					},
					R: {
						main: "( - )",
						tips: "",
					},
					AreaD: _getDefMessageBySubjective("controllerPowerAxis"),
				};
				visibles = {
					C: false,
					D:  true,
					E: false,
				};
				break;
			case 1021: // [遠]ジャクソンクロスシリンダー
				htmls = {
					L: {
						main: "( + )",
						tips: "",
					},
					R: {
						main: "( - )",
						tips: "",
					},
					AreaD: _getDefMessageBySubjective("controllerPowerAxis"),
				};
				visibles = {
					C:  true,
					D:  true,
					E: false,
				};
				disableEyeBino = true; // 両眼を無効化
				break;
			case 1092: // [遠]ウォース4点テスト
				// 原則、直前のものを使用する。ただし、controller-c のみ非表示にする
				visibles = {
					C: false,
				};
				break;
			default:
				becky.assertion.failure("unknown chart examID");
				htmls = {
					L: {
						main: "",
						tips: "",
					},
					R: {
						main: "",
						tips: "",
					},
				};
				visibles = {
					C:  true,
					D:  true,
					E:  true,
				};
				break;
		}
	
		_updateSelectEyeFromChart(chartTable);
	
		if (modelHelper.isNull(htmls) &&
			modelHelper.isNull(visibles)) {
			return;
		}
	
		if (_isSelectNear()) {
			// ADD が有効
			switch (chartTable.examID) {
				case 2030: // [近]加入度測定
					htmls = {
						L: {
							main: '<span id="imgAddPlus"></span>',
							tips: "",
						},
						R: {
							main: '<span id="imgAddMinus"></span>',
							tips: "",
						},
					};
					visibles = {
						C: false,
						D: false,
						E: false,
					};
					break;
				default:
					htmls = {
						L: {
							main: "( + )",
							tips: "",
						},
						R: {
							main: "( - )",
							tips: "",
						},
					};
					visibles = {
						C: false,
						D: false,
						E: false,
					};
					break;
			}
		}
	
		if (!modelHelper.isNull(htmls)) {
			$(".icon.icon-G").html(htmls.L.main);
			$(".icon.icon-R").html(htmls.R.main);
			$(".icon.icon-plus-brackets:eq(0)").html(htmls.L.tips);
			$(".icon.icon-plus-brackets:eq(1)").html(htmls.R.tips);
			if (!modelHelper.isNullOrEmpty(htmls.AreaD)) {
				$(".icon.icon-astigmat-axis").html(htmls.AreaD);
			}
		}
		if (!modelHelper.isUndefined(visibles.C)) {
			const $buttonC = $(".controller-c"); // 仮
			if (visibles.C) {
				$buttonC.show();
			} else {
				$buttonC.hide();
			}
		}
		if (!modelHelper.isUndefined(visibles.D)) {
			const $buttonD = $(".controller-d"); // 仮
			if (visibles.D) {
				$buttonD.show();
			} else {
				$buttonD.hide();
			}
		}
		if (!modelHelper.isUndefined(visibles.E)) {
			const $buttonE = $(".controller-e"); // 仮
			if (visibles.E) {
				$buttonE.show();
			} else {
				$buttonE.hide();
			}
		}
		if (disableEyeBino) {
			$("#btnControllerEyeB").addClass("disabled");
		} else {
			$("#btnControllerEyeB").removeClass("disabled");
		}
	}
	
	/*!
	 * @brief メニューの初期化
	 * 検査の切り替えタイミングで呼び出す
	 *
	 * @param[in] array chartTable chartPage.parameter.json の chartPageN の単一要素
	 */
	function _updateMenuInit(chartTable)
	{
		let btnMenuEnables = null;
		switch (chartTable.examID) {
			case 1000: // [遠]球面度テスト / 遠用視力測定
			case 1010: // [遠]R/G テスト
			case 2030: // [近]加入度測定
				btnMenuEnables = "#btnMenuReferenceData, #btnMenuFarNear, #btnMenuBinoMono, #btnMenuS";
				break;
			case 1020: // [遠]乱視テスト
				btnMenuEnables = "#btnMenuReferenceData, #btnMenuFarNear, #btnMenuBinoMono, #btnMenuC";
				break;
			case 1021: // [遠]ジャクソンクロスシリンダー
				btnMenuEnables = "#btnMenuReferenceData, #btnMenuFarNear, #btnMenuBinoMono, #btnMenuC, #btnMenuCC_Power";
				break;
			case 1092: // [遠]ウォース4点テスト
				btnMenuEnables = "#btnMenuChartID9, #btnMenuChartID9_ResultValue";
				break;
			default:
				becky.assertion.failure("unknown chart examID");
				break;
		}
		if (modelHelper.isNullOrEmpty(btnMenuEnables)) {
			return;
		}
	
		// 全検査共通で必ず表示
		//btnMenuEnables += ", #btnMenu1";
	
		$(".menu-item").hide();
		$(btnMenuEnables).each((i, element) => {
			$(element).parent().show();
		});
	}
	
	/*!
	 * @brief S/C/A 選択状態の更新を行う
	 * 遠見/近見 の切り替えイベントから
	 */
	function _updateSelectSCA_FromFarNear()
	{
		_setSelectSCA(_isSelectNear() ? _changeFarNearSetSCA.near : _changeFarNearSetSCA.far);
	}
	
	/*!
	 * @brief S/C/A 選択状態の更新を行う
	 * Chart 情報を元に更新する
	 *
	 * @param[in] array chartTable chartPage.parameter.json の chartPageN の単一要素
	 */
	function _updateSelectSCA_FromChart(chartTable)
	{
		if (becky.assertion.isUndefined(chartTable)) {
			return;
		}
	
		const bIsSelectNear = _isSelectNear();
	
		switch (chartTable.examID) {
			case 1000: // [遠]球面度テスト / 遠用視力測定
			case 1010: // [遠]R/G テスト
			case 2030: // [近]加入度測定
				if (bIsSelectNear) {
					// ADD が有効
					_setSelectSCA("ADD");
				} else {
					// Sph が有効
					_setSelectSCA("Sph");
				}
				break;
			case 1020: // [遠]乱視テスト
			case 1021: // [遠]ジャクソンクロスシリンダー
				if (bIsSelectNear) {
					// ADD が有効
					_setSelectSCA("ADD");
				} else {
					// Axs が有効
					_setSelectSCA("Axs");
				}
				break;
			case 1092: // [遠]ウォース4点テスト
				// 直前のものを使用
				break;
			default:
				becky.assertion.failure("unknown chart examID");
				break;
		}
	}
	
	/*!
	 * @brief メインのフォーカスの更新を行う
	 *
	 * @param[in] array aIsSelectEyes R/L   の選択状態の配列
	 * @param[in] array aIsSelectSCAs S/C/A の選択状態の配列
	 */
	function _updateMainFocus(aIsSelectEyes, aIsSelectSCAs)
	{
		// 選択状態が取得できない場合は画面から取得
		if (modelHelper.isNullOrEmpty(aIsSelectEyes)) {
			aIsSelectEyes = {
				R: _isSelectEyeR(),
				L: _isSelectEyeL(),
			};
		}
		if (modelHelper.isNullOrEmpty(aIsSelectSCAs)) {
			aIsSelectSCAs = {
				Sph: _isSelectSph(),
				Cyl: _isSelectCyl(),
				Axs: _isSelectAxs(),
				ADD: _isSelectADD(),
			};
		}
	
		const prefix = "labelMain";
		// いったん全て解除
		$("[id^=" + prefix + "]").parents(".td").removeClass("focus");
	
		Object.keys(aIsSelectSCAs).forEach(function(aSCA){
			const bIsSelect = this[aSCA];
			if (!bIsSelect) return;
			let suffix = "";
			switch (aSCA) {
				case "ADD": // ADD は末尾に"_"が付く
					suffix = "_";
					break;
				default:
					break;
			}
			const prefix_sca = prefix + aSCA + suffix;
			// 項目部
			$("#" + prefix_sca + "Caption").parents(".td").addClass("focus");
			// 値(R/L)
			Object.keys(aIsSelectEyes).forEach(function(aEye){
				const bIsSelect = this[aEye];
				if (!bIsSelect) return;
				$("#" + prefix_sca + aEye).parents(".td").addClass("focus");
			}, aIsSelectEyes);
		}, aIsSelectSCAs);
	}
	
	/*!
	 * @brief メインの色の更新を行う(単体)
	 *
	 * @param[in,out] element $labelMain 対象のラベル
	 */
	function _updateMainColor($labelMain)
	{
		if (becky.assertion.isNullOrEmpty($labelMain)) {
			return;
		}
	
		const dataText = $labelMain.attr("data-text");
		if (modelHelper.isUndefined(dataText)) {
			return;
		}
	
		// 値が +/- で使用するクラスを取得する
		const dataClassPlus  = $labelMain.attr("data-class-plus" );
		const dataClassMinus = $labelMain.attr("data-class-minus");
		if (modelHelper.isUndefined(dataClassPlus ) ||
			modelHelper.isUndefined(dataClassMinus)) {
			return;
		}
	
		const $parents_td = $labelMain.parents(".td");
		if (becky.assertion.isNullOrEmpty($parents_td)) {
			return;
		}
	
		let dataTextFloat = parseFloat(dataText);
		if (isNaN(dataTextFloat)) {
			$parents_td.removeClass(dataClassPlus + " " + dataClassMinus);
		} else {
			const dataFround        = $labelMain.attr("data-fround"        );
			const dataFbankersRound = $labelMain.attr("data-fbankers-round");
				   if (!modelHelper.isUndefined(dataFround)) {
				dataTextFloat = modelHelper.fround(dataTextFloat, dataFround);
			} else if (!modelHelper.isUndefined(dataFbankersRound)) {
				dataTextFloat = modelHelper.fbankersRound(dataTextFloat, dataFbankersRound);
			} 
				   if (0.0 < dataTextFloat) {
				$parents_td.addClass(dataClassPlus).removeClass(dataClassMinus);
			} else if (0.0 > dataTextFloat) {
				$parents_td.addClass(dataClassMinus).removeClass(dataClassPlus);
			} else {
				$parents_td.removeClass(dataClassPlus + " " + dataClassMinus);
			}
		}
	}
	
	/*!
	 * @brief メインの色の更新を行う(全体)
	 */
	function _updateMainColors()
	{
		// 球面度数、乱視度数、加入度数
		$("[id^=labelMainSph], [id^=labelMainCyl], [id^=labelMainADD_]").each((i, element) => {
			_updateMainColor($(element));
		});
	}
	
	/*!
	 * @brief メインのクラス郡の更新を行う
	 *
	 * @param[in] array aIsSelectEyes R/L   の選択状態の配列
	 * @param[in] array aIsSelectSCAs S/C/A の選択状態の配列
	 */
	function _updateMainClasses(aIsSelectEyes, aIsSelectSCAs)
	{
		_updateMainFocus(aIsSelectEyes, aIsSelectSCAs);
		_updateMainColors();
	}
	
	/*!
	 * @brief クロスシリンダーのクラス郡の更新を行う
	 */
	function _updateCrossCylinderClasses()
	{
		if (_isSelectEyeB() ||
			_isSelectSph()) {
			return;
		}
	
		let classIconEyemarkBC = null;
		switch (_getCrossCylinderRG()) {
			case 1:
				classIconEyemarkBC = "icon-eyemark-b";
				break;
			case 2:
				classIconEyemarkBC = "icon-eyemark-c";
				break;
			default:
				becky.assertion.failure("unknown type CrossCylinderRG");
				break;
		}
			   if (_isSelectAxs()) {
			classIconEyemarkBC += "-axs";
		} else if (_isSelectCyl()) {
			classIconEyemarkBC += "-cyl";
		}
	
		const removeClasses = [
			"icon-eyemark-a",
			"icon-eyemark-b-axs",
			"icon-eyemark-c-axs",
			"icon-eyemark-b-cyl",
			"icon-eyemark-c-cyl",
		];
		$("#iconEyeMarkR, #iconEyeMarkL").removeClass(removeClasses.join(" "));
			   if (_isSelectEyeR()) {
			$("#iconEyeMarkR").addClass(classIconEyemarkBC)
			$("#iconEyeMarkL").addClass("icon-eyemark-a");
		} else if (_isSelectEyeL()) {
			$("#iconEyeMarkR").addClass("icon-eyemark-a");
			$("#iconEyeMarkL").addClass(classIconEyemarkBC);
		}
	}
	
	/*!
	 * @brief autoID をキーに視力表のデータを得る
	 *
	 * @param[in] array aArrayFlatChartPageParameter chartPage.parameter.json をフラットな構造にしたもの
	 * @param[in] int aAutoID 自動生成ID
	 * @return array 視力表のデータ
	 */
	function _getChartByAutoID(aArrayFlatChartPageParameter, aAutoID)
	{
		const charts = aArrayFlatChartPageParameter.filter(chart_ => aAutoID == chart_.autoID);
	
		// autoID は重複しないはずなので、最初の要素を得る
		if (becky.assertion.isFalse(1 === charts.length)) {
			// 複数要素は許さない
			return null;
		}
	
		return charts[0];
	}
	
	/*!
	 * @brief ResetBase コマンドを送信する
	 * X, Y, Z, θを指定
	 *
	 * @return Promise
	 */
	async function _postResetBaseXYZCommand()
	{
		const resetBaseJson = {
			X    : true,
			Y    : true,
			Z    : true,
		//	Theta: true, // 遠見に戻ってしまうため除外
		};
		await becky.LeanStartup.post("ResetBase", resetBaseJson);
		console.log("resetBase command");
		console.log(resetBaseJson);
	}
	
	/*!
	 * @brief ChronosAlignment2 コマンドを送信する
	 *
	 * @return Promise
	 */
	async function _postAlignmentCommand()
	{
		const alignmentJson = {
			RangeXY: 1.0,
			RangeZ : 1.0,
			infoForLog: becky.log.createCommandParamInfoForLog(new Date()),
		};
		let postPos/* = ""*/;
		if (_isSelectMono() && !_isSelectEyeB()) {
			// 片眼遮蔽かつ両眼以外なら、アライメントは片眼のみ
			postPos = _getSelectEye();
		}
		console.log("alignment json command");
		console.log(alignmentJson);
		await becky.LeanStartup.post("ChronosAlignment2", alignmentJson, postPos);
	}
	
	/*!
	 * @brief ChartID を生成する(片眼)
	 *
	 * @param[in] array chartTable chartPage.parameter.json の chartPageN の単一要素
	 * @param[in] int aFlatFusionFrameID 融像枠のID
	 * @param[in] bool aIsSelectEye 対象の眼が選択されているか？
	 * @return int ChartID
	 */
	function _createChartID_ByEye(chartTable, aFlatFusionFrameID, aIsSelectEye)
	{
		if (!aIsSelectEye) {
			const selectBinoMono = _getSelectBinoMono();
			switch (selectBinoMono) {
				case "bino":
					// 両眼開放
					return aFlatFusionFrameID; // 融像枠
				case "mono":
					// 片眼遮蔽
					return 0; // 黒画像
				default:
					becky.assertion.failure("un-known value _getSelectBinoMono()");
					break;
			}
		}
	
		return chartTable.chartID; // 視標ID
	}
	
	/*!
	 * @brief ChartIDs を生成する
	 *
	 * @param[in] array chartTable chartPage.parameter.json の chartPageN の単一要素
	 * @param[in] int aFlatFusionFrameID 融像枠のID
	 * @return object ChartIDs
	 */
	function _createChartIDs(chartTable, aFlatFusionFrameID)
	{
		return {
			R: _createChartID_ByEye(chartTable, aFlatFusionFrameID, _isSelectEyeR()),
			L: _createChartID_ByEye(chartTable, aFlatFusionFrameID, _isSelectEyeL()),
		};
	}
	
	/*!
	 * @brief Chart コマンドに渡すパラメータを生成
	 * 画面の状態に依存しているものが多いため呼び出し順はなるべく後が良い
	 *
	 * @param[in] array chartTable chartPage.parameter.json の chartPageN の単一要素
	 * @return array Chart コマンドに渡すパラメータ
	 */
	function _createChartParam(chartTable)
	{
		let chartIDs = null;
		switch (chartTable.chartID) {
			case 7000: // [遠]R/G テスト
				// RG視標専用融像枠(4)
				chartIDs = _createChartIDs(chartTable, 4);
				break;
			case 7030: // [遠]ウォース4点テスト
				// 融像枠の対応は不要
				chartIDs = {
					R: 7031,
					L: 7032,
				}
				break;
			default:
				// 汎用融像枠(1)
				chartIDs = _createChartIDs(chartTable, 1);
				break;
		}
	
		return {
			R: { chartID: chartIDs.R },
			L: { chartID: chartIDs.L },
		};
	}
	
	/*!
	 * @brief Chart コマンドを送信する
	 *
	 * @param[in] array chartTable chartPage.parameter.json の chartPageN の単一要素
	 * @return Promise
	 */
	async function _postChartCommand(chartTable)
	{
		const operatorLogNodes = [];
	
		try {
			const requestJson = _createChartParam(chartTable);
			console.log(requestJson);
			await becky.LeanStartup.postWithOperatorLog(
				"Chart", requestJson, "", new Date(), operatorLogNodes);
		} finally {
			// 操作ログ
			becky.operatorLog.pushSubjectiveCommandNodes(operatorLogNodes);
		}
	}
	
/*!
	 * @brief Create mask pattern
	 *
	 * @param[in] array chartTable chartPage.parameter.json の chartPageN の単一要素
	 * @return Promise
	 */
	
	function _createMaskParam(chartTable)
	{
		let chartIDs = null;
		switch (chartTable.chartID) {
			case 7000: // [遠]R/G テスト
				// RG視標専用融像枠(4)
				chartIDs = _createChartIDs(chartTable, 4);
				break;
			case 7030: // [遠]ウォース4点テスト
				// 融像枠の対応は不要
				chartIDs = {
					R: 7031,
					L: 7032,
				}
				break;
			default:
				// 汎用融像枠(1)
				chartIDs = _createChartIDs(chartTable, 1);
				break;
		}
	
		return {
				 chartID: chartIDs.R,
				 maskCellID: chartTable.maskCell,
				 Row: chartTable.Row,
				 Col: chartTable.Col
				 
			/* L: { chartID: chartIDs.L, 
				 maskCellID: chartTable.maskCell
				}, */
		};
	}
	
	
	/*!
	 * @brief Mask Send command
	 *
	 * @param[in] array chartTable chartPage.parameter.json の chartPageN の単一要素
	 * @return Promise
	 */
	 async function _postMaskCommand(chartTable){
		 const operatorLogNodes = [];
		 try {
			const requestJson = _createMaskParam(chartTable);
			console.log(requestJson);
			await becky.LeanStartup.postWithOperatorLog(
				"Chart", requestJson, "", new Date(), operatorLogNodes);
		} finally {
			// 操作ログ
			becky.operatorLog.pushSubjectiveCommandNodes(operatorLogNodes);
		}
	}
	
	/*!
	 * @brief _postLCOS_Command に渡すIDを生成
	 * もし、null が返ってきた場合は渡す必要が無い
	 * 
	 * @param[in] aBackupPP 直前の _createPhoropterParam 関数の値
	 * @param[in] aNewPP 新しい  _createPhoropterParam 関数の値
	 * @return integer | null
	 */
	function _createLCOS_CommandID(aBackupPP, aNewPP)
	{
		const statuses = [
			aBackupPP.crossCylinder.status,
			   aNewPP.crossCylinder.status,
		];
		statuses.sort();
		if (1 === statuses[0] && 2 === statuses[1]) {
			// クロスシリンダーの 乱視←→軸 へ切り替え時
			return 1; // 融像枠
		}
	
		const diffChecker = {
			isExamDistance   : aBackupPP.distance         !== aNewPP.distance,
			isCrossCylinderRG: aBackupPP.crossCylinder.RG !== aNewPP.crossCylinder.RG,
			//! 差があるか？
			someDiff: function(){
				return Object.keys(this).some(function(propertyName_){
					if (!modelHelper.isBoolean(this[propertyName_])) {
						return false;
					}
					return this[propertyName_];
				}, this);
			},
		};
	
		if (!diffChecker.someDiff()) {
			// 変化が無いのでコマンド送信の必要が無い
			return null;
		}
		if (diffChecker.isExamDistance) {
			// 検査距離に変化あり
			return 0; // 消灯
		}
		if (diffChecker.isCrossCylinderRG) {
			// クロスシリンダーのRGに変化あり
			return 1; // 融像枠
		}
		console.log("LCOS command");
		console.log(diffChecker);
	
		// 実装ミス
		becky.assertion.failure("_getLCOS_CommandID add switch");
		return null;
	}
	
	/*!
	 * @brief LCOS コマンドを送信する
	 * といっても Chart コマンド
	 *
	 * @param[in] int aID 画像ID (0:黒, 1:融像枠)
	 * @return Promise
	 */
	async function _postLCOS_Command(aID)
	{
		const operatorLogNodes = [];
		try {
			await becky.LeanStartup.postWithOperatorLog(
				"Chart", {
					R: { chartID: aID },
					L: { chartID: aID },
				}, "", new Date(), operatorLogNodes);
		} finally {
			// 操作ログ
			becky.operatorLog.pushSubjectiveCommandNodes(operatorLogNodes);
		}
	}
	
	/*!
	 * @brief Phoropter コマンドに渡すパラメータを生成
	 * 画面の状態に依存しているものが多いため呼び出し順はなるべく後が良い
	 *
	 * @param[in] array chartTable chartPage.parameter.json の chartPageN の単一要素
	 * @return array Phoropter コマンドに渡すパラメータ
	 */
	function _createPhoropterParam(chartTable)
	{
		const newJson = _updateDataMeasurementValue();
	
		let nEye = 0;
		const eyeValue = _getSelectEye();
		switch (eyeValue) {
			case "B":
				nEye = 2;
				break;
			case "R":
				nEye = 0;
				break;
			case "L":
				nEye = 1;
				break;
			default:
				becky.assertion.failure("unknown eye");
				break;
		}
	
		let nDistance = 0;
		const strSelectFarNear = _getSelectFarNear();
		switch (strSelectFarNear) {
			case "far":
			case "near":
				nDistance = $("#inputExaminationDistancePoint_" + strSelectFarNear).val();
				break;
			default:
				becky.assertion.failure("un-known value _getSelectFarNear()");
				break;
		}
		const nVD = becky.settingJson.objective.vd;
		const nPD = $("#labelPD").attr("data-text");
		const nSphR = _isSelectFar() ? newJson.SphR : newJson.SphR + newJson.ADD_R;
		const nSphL = _isSelectFar() ? newJson.SphL : newJson.SphL + newJson.ADD_L;
		const nRGFilter = _getRGFilter(chartTable);
		const crossCylinderJson = _getCrossCylinderByPhoropter(chartTable);
	
		const requestJson = {
			eye: nEye,
			distance: nDistance,
			vd: nVD,
			pd: nPD,
			R: {
				sphere  :        nSphR,
				cylinder: newJson.CylR,
				axis    : newJson.AxsR,
			},
			L: {
				sphere  :        nSphL,
				cylinder: newJson.CylL,
				axis    : newJson.AxsL,
			},
			crossCylinder: crossCylinderJson,
			RGFilter: nRGFilter,
		};
	
		// データの正規化
		becky.jsonHelper.normalization(requestJson);
		console.log("phoropter param command:");
		console.log(requestJson);
	
		return requestJson;
	}
	
	/*!
	 * @brief Phoropter コマンドを送信する
	 *
	 * @param[in] array chartTable chartPage.parameter.json の chartPageN の単一要素
	 * @return Promise
	 */
	async function _postPhoropterCommand(chartTable)
	{
		const operatorLogNodes = [];
	
		try {
			const requestJson = _createPhoropterParam(chartTable);
			await becky.LeanStartup.postWithOperatorLog(
				"Phoropter", requestJson, "", new Date(), operatorLogNodes);
		} finally {
			// 操作ログ
			becky.operatorLog.pushSubjectiveCommandNodes(operatorLogNodes);
		}
	}
	
	/*!
	 * @brief ボタンクリック時に背景を変更する
	 *
	 * @param[in] element $btn 対象のボタン
	 */
	function _buttonClickBackGroundOverlay($btn)
	{
		if (becky.assertion.isNullOrEmpty($btn)) {
			return;
		}
	
		viewHelper.eventRegistrationTouchDownUp($btn,
			function(){ $(this).addClass   ("active"); },
			function(){ $(this).removeClass("active"); });
	}
	
	/*!
	 * @brief 計測データ・画面状態を WebStorage(Web browser) に保存
	 * リロード対策
	 *
	 * @return void
	 */
	function _saveDataToWebStorage()
	{
		becky.WebStorage.local.setJson("subjective.update.data", _updateData());
	}
	
	/*!
	 * @brief 更新(計測データ)
	 *
	 * @param[in] object aModel 引数が未指定:View→Model, 引数有り:Model→View
	 * @return object 戻り値が存在するのは View→Model のみ
	 */
	function _updateDataMeasurementValue(aModel)
	{
		// 属性の入出力
		const jQattrIO = (id_, key_, val_) => {
			if (modelHelper.isUndefined(val_)) {
				// get
				return $(id_).attr(key_);
			} else {
				// set
				$(id_).attr(key_, val_);
			}
		};
		const jQattrDataText  = (id_, val_) => jQattrIO(id_, "data-text" , val_);
		const jQattrDataValue = (id_, val_) => jQattrIO(id_, "data-value", val_);
		const jQattrDataUnit  = (id_, val_) => jQattrIO(id_, "data-unit" , val_);
	
		// value の入出力
		const jQvalIO = (id_, val_) => {
			if (modelHelper.isUndefined(val_)) {
				// get
				return $(id_).val();
			} else {
				// set
				$(id_).val(val_);
			}
		};
	
		const update = {
			SphL        : val_ => jQattrDataText("#labelMainSphL"    , val_),
			CylL        : val_ => jQattrDataText("#labelMainCylL"    , val_),
			AxsL        : val_ => jQattrDataText("#labelMainAxsL"    , val_),
			ADD_L       : val_ => jQattrDataText("#labelMainADD_L"   , val_),
			H_L         : val_ => jQattrDataText("#labelMainH_L"     , val_),
			V_L         : val_ => jQattrDataText("#labelMainV_L"     , val_),
			VA_FarL     : val_ => jQattrDataText("#labelMainVA_FarL" , val_),
			VA_UnitFarL : val_ => jQattrDataUnit("#labelMainVA_FarL" , val_),
			VA_NearL    : val_ => jQattrDataText("#labelMainVA_NearL", val_),
			VA_UnitNearL: val_ => jQattrDataUnit("#labelMainVA_NearL", val_),
	
			SphR        : val_ => jQattrDataText("#labelMainSphR"    , val_),
			CylR        : val_ => jQattrDataText("#labelMainCylR"    , val_),
			AxsR        : val_ => jQattrDataText("#labelMainAxsR"    , val_),
			ADD_R       : val_ => jQattrDataText("#labelMainADD_R"   , val_),
			H_R         : val_ => jQattrDataText("#labelMainH_R"     , val_),
			V_R         : val_ => jQattrDataText("#labelMainV_R"     , val_),
			VA_FarR     : val_ => jQattrDataText("#labelMainVA_FarR" , val_),
			VA_UnitFarR : val_ => jQattrDataUnit("#labelMainVA_FarR" , val_),
			VA_NearR    : val_ => jQattrDataText("#labelMainVA_NearR", val_),
			VA_UnitNearR: val_ => jQattrDataUnit("#labelMainVA_NearR", val_),
	
			VA_FarB     : val_ => jQattrDataText("#labelMainVA_FarB" , val_),
			VA_UnitFarB : val_ => jQattrDataUnit("#labelMainVA_FarB" , val_),
			VA_NearB    : val_ => jQattrDataText("#labelMainVA_NearB", val_),
			VA_UnitNearB: val_ => jQattrDataUnit("#labelMainVA_NearB", val_),
	
			PD          : val_ => jQattrDataText("#labelPD"          , val_),
	
			// 検査距離
			ExamDistanceFar : val_ => jQvalIO("#inputExaminationDistancePoint_far" , val_),
			ExamDistanceNear: val_ => jQvalIO("#inputExaminationDistancePoint_near", val_),
	
			// ウォース4点テスト
			Worth4DotsResult: val_ => jQattrDataValue("#btnMenuChartID9_ResultValue", val_),
			// クロスシリンダー power
			CC_Power        : val_ => jQattrDataValue("#btnMenuCC_Power", val_),
		};
		if (modelHelper.isUndefined(aModel)) {
			// View -> Model
			const json = {};
			Object.getOwnPropertyNames(update).forEach(name_ => {
				json[name_] = update[name_]();
			});
			// データの正規化
			becky.jsonHelper.normalization(json);
			return json;
		} else {
			// Model -> View
			Object.getOwnPropertyNames(update).forEach(name_ => {
				update[name_](aModel[name_]);
			});
			// UI の色を更新
			// (この処理を外に追い出す事はできないだろうか……)
			_updateMainColors();
		}
	}
	
	/*!
	 * @brief 更新(画面の状態)
	 *
	 * @param[in] object aModel 引数が未指定:View→Model, 引数有り:Model→View
	 * @return object 戻り値が存在するのは View→Model のみ
	 */
	function _updateDataScreenState(aModel)
	{
		if (modelHelper.isUndefined(aModel)) {
			// View -> Model
			const json = {
				//isBgInvert  : $(".chart-table .bg").hasClass("bg-invert"),
				//isBgRG      : $(".chart-table .bg").hasClass("bg-rg"),
				examTitle: $("#labelExamTitle").attr("data-text"),
				farNear: _getSelectFarNear(),
				binoMono: _getSelectBinoMono(),
				crossCylinderIndex: $("#groupCrossCylinder").attr("data-select-index"),
				currentEye: _getSelectEye(),
				currentSCA: _getSelectSCA(),
				currentAutoID: $("#currentAutoID").attr("data-value"),
			};
			// データの正規化
			becky.jsonHelper.normalization(json);
			return json;
		} else {
			// Model -> View
	
			// Todo. リーンスタートアップでは isBgInvert, isBgRG は保留
	
			$("#labelExamTitle").attr("data-text", aModel.examTitle);
			$("#btnMenuFarNear").val(aModel.farNear);
			$("#btnMenuBinoMono").val(aModel.binoMono);
			$("#groupCrossCylinder").attr("data-select-index", aModel.crossCylinderIndex);
			_setSelectEye(aModel.currentEye);
			_setSelectSCA(aModel.currentSCA);
			$("#currentAutoID").attr("data-value", aModel.currentAutoID);
		}
	}
	
	/*!
	 * @brief 更新(全て)
	 *
	 * @param[in] object aModel 引数が未指定:View→Model, 引数有り:Model→View
	 * @return object 戻り値が存在するのは View→Model のみ
	 */
	function _updateData(aModel)
	{
		if (modelHelper.isUndefined(aModel)) {
			// View -> Model
			return {
				sessionPatientID: becky.session.sessionPatientID,
				measurementValue: _updateDataMeasurementValue(),
				screenState     : _updateDataScreenState     (),
			};
		} else {
			// Model -> View
			_updateDataMeasurementValue(aModel.measurementValue);
			_updateDataScreenState     (aModel.screenState     );
		}
	}
	
	$(document).ready(function(){
	
		// 端末に一時保存されているものがあれば復元
		{
			const updateDataJson = becky.WebStorage.local.getJson("subjective.update.data");
			if (!modelHelper.isNullOrEmpty(updateDataJson) &&
				becky.session.sessionPatientID === updateDataJson.sessionPatientID) {
				_updateData(updateDataJson);
			}
		}
	
		// data-text 属性を監視するオプション(MutationObserverInit)
		const optionsAttributeFilterDataValue = {
			attributes: true,
			attributeFilter: [ "data-value" ],
		};
	
		(async function(){
			try {
				becky.operatorLog.createSubjectiveNode();
	
				const resetOptParamLR = {
					LED: {
						Fixation: "Off",
					},
					OpticalPath: false,
				};
				await becky.LeanStartup.post("ResetOpt", {
					L: resetOptParamLR,
					R: resetOptParamLR,
				});
	
				// 視標の設定
				await _postChartCommand(_currentChart);
				// フォロプター
				await _postPhoropterCommand(_currentChart);
				// 端末に一時保存(リロード対策)
				_saveDataToWebStorage();
			} catch (resultJson) {
				// 失敗
				// エラーメッセージ表示
				becky.LeanStartup.alertErrorMessage(resultJson);
			} finally {
				// 次へ遷移可能
				becky.navi.showNext();
			}
		}());
	
		//! @brief 近見が(一度でも)選択されたか？
		let isSelectedNear = false;
	
		// クリック時にカレントの切り替えを行う
		$(".current").parent().children().click(function(){
			viewHelper.selectClassSingle("current", $(this));
		});
	
		// タブヘッダ(Tab header)
		$(".tab-box .tab-header").click(function(){
			const $tabHeader = $(this);
			$("#tabChart").attr("data-tab-index", $tabHeader.index());
		});
		{
			const optionsAttributeFilterTabIndex = {
				attributes: true,
				attributeFilter: [ "data-tab-index" ],
			};
			becky.MutationObserver.byID(
				"#tabChart",
				records => records.forEach(record_ => {
					const target = record_.target;
					const tabIndex = target.dataset.tabIndex;
					const $tab = $(".tab-box .tab-content-group .tab-content").eq(tabIndex);
					if (!becky.assertion.isNullOrEmpty($tab)) {
						viewHelper.selectClassSingle("current", $tab);
						
					}
					const $tabHead = $(".tab-box .tab-header-group .tab-header").eq(tabIndex);
					if (!becky.assertion.isNullOrEmpty($tabHead)) {
						viewHelper.selectClassSingle("current", $tabHead);
						
					}
				}),
				optionsAttributeFilterTabIndex);
		}
	
		// ドロップダウンリスト
		$(".select-box .select-title").each((i, element) => {
			_updateSelectTitle($(element));
		});
		$(".select-box .select-selector").change(function(){
			_updateSelectTitle($(this).siblings(".select-title"));
		});
	
		{
			// 左右両眼の監視
			becky.MutationObserver.byID(
				"#currentEye",
				records => records.forEach(record_ => {
					const target = record_.target;
					const value = target.dataset.value;
					switch (value) {
						case "R":
							_setSelectEyeR_FromEvent();
							break;
						case "L":
							_setSelectEyeL_FromEvent();
							break;
						case "B":
							_setSelectEyeB_FromEvent();
							break;
						default:
							becky.assertion.failure("unknown eye");
							break;
					}
					// クロスシリンダー
					_updateCrossCylinderClasses();
				}),
				optionsAttributeFilterDataValue);
			// 左右両眼の変更イベントを呼ぶ(初期化)
			becky.dataSync.callChangeEventAttr(document.getElementById("currentEye"), "data-value");
			// SCA の監視
			becky.MutationObserver.byID(
				"#currentSCA",
				records => records.forEach(record_ => {
					const target = record_.target;
					const value = target.dataset.value;
					switch (value) {
						case "Sph":
							_setSelectSph_FromEvent();
							break;
						case "Cyl":
							_setSelectCyl_FromEvent();
							break;
						case "Axs":
							_setSelectAxs_FromEvent();
							break;
						case "ADD":
							_setSelectADD_FromEvent();
							break;
						default:
							becky.assertion.failure("unknown eye");
							break;
					}
					// クロスシリンダー
					_updateCrossCylinderClasses();
					// +/- ボタンの中央部
					$(".icon.icon-axis").html(_getDefMessageBySubjective("controller" + value.toUpperCase()));
				}),
				optionsAttributeFilterDataValue);
			// SCA の変更イベントを呼ぶ(初期化)
			becky.dataSync.callChangeEventAttr(document.getElementById("currentSCA"), "data-value");
			// AutoID の監視
			becky.MutationObserver.byID(
				"#currentAutoID",
				records => records.forEach(record_ => {
					const target = record_.target;
					const value = target.dataset.value;
					const chart = _getChartByAutoID(becky.subjective.arrayFlatChartPageParameter, value);
					if (becky.assertion.isUndefined(chart)) {
						return;
					}
					// 操作コントローラーのレイアウトの更新
					_updateChartTable(chart);
					_updateControllerLayout(chart);
					_updateMenuInit(chart);
					_updateSelectSCA_FromChart(chart);
					// カレント更新
					_setCurrentChart(chart);
				
					// 視標のサムネイル
					const $tabContent = $("[data-auto-id=" + chart.autoID + "]");
					if (!modelHelper.isNull($tabContent)) {
						if (!$tabContent.hasClass("current")) {
							// 枠
							$("[data-auto-id]").removeClass("current");
							$tabContent.addClass("current");
							// タブ
							const $tabContentParent = $tabContent.parent();
							const tabIndex = $tabContentParent.parent().children().index($tabContentParent);
							if (tabIndex != $("#tabChart").attr("data-tab-index")) {
								// 差がある場合のみ反映
								$("#tabChart").attr("data-tab-index", tabIndex);
							}
						}
					}
				}),
				optionsAttributeFilterDataValue);
			// ChartID の変更イベントを呼ぶ(初期化)
			becky.dataSync.callChangeEventAttr(document.getElementById("currentAutoID"), "data-value");
		}
	
		// 軸(x) の更新処理
		becky.MutationObserver.byID(
			"btnMenuA",
			records => records.forEach(record_ => {
				const target = record_.target;
				const value = target.dataset.value;
				$("#labelMainAxsStep").text(value);
			}),
			optionsAttributeFilterDataValue);
	
		// Axis の値の監視
		{
			// data-text 属性を監視するオプション(MutationObserverInit)
			const optionsAttributeFilterDataText = {
				attributes: true,
				attributeFilter: [ "data-text" ],
				attributeOldValue: true, // 値の変化量が必要
			};
			becky.MutationObserver.bySelectorAll(
				"#labelMainAxsR, #labelMainAxsL",
				records => records.forEach(record_ => {
					const target = record_.target;
					const nOldValue = parseInt(record_.oldValue   , 10);
					const nNewValue = parseInt(target.dataset.text, 10);
					if (nOldValue === nNewValue) {
						// 差が無い
						return;
					}
					const strRL = target.id.slice(-1);
					const icon = document.getElementById("iconEyeMark" + strRL);
					let nDeg = 0;
					if (isNaN(nOldValue)) {
						// 絶対値
						nDeg = -nNewValue; // 逆回転
					} else {
						// 相対値
						let nDiffValue = nOldValue - nNewValue;
							   if (-90 > nDiffValue) {
							// 想定パターン:5 -> 180
							nDiffValue = 180 + nDiffValue;
						} else if ( 90 < nDiffValue) {
							// 想定パターン:180 -> 5
							nDiffValue = nDiffValue - 180;
						}
						nDeg = parseInt(icon.dataset.rotate, 10) + nDiffValue;
					}
					icon.style.transform = "rotate(" + nDeg + "deg)";
					icon.dataset.rotate = nDeg;
				}),
				optionsAttributeFilterDataText);
		}
	
		// メインデータの球面度数エリア
		$("#trMainSph").click(function(){
			if (_isSelectSph()) {
				return;
			}
			const backupSS = _updateDataScreenState(); // 戻せるように記憶しておく
			const backupPP = _createPhoropterParam(_currentChart);
			$("#btnMenuFarNear").val("far");
			_setSelectSCA("Sph");
			//$("#groupCrossCylinder").attr("data-select-index", 0); // クロスシリンダー(1)に戻す
			_updateControllerLayout({examID: 1000});
			const newPP = _createPhoropterParam(_currentChart);
			if (becky.jsonHelper.isEquals(backupPP, newPP)) {
				// フォロプターコマンドを呼ぶ必要はない
				return;
			}
			(async function(){
				// ボタンを無効化
				const pointerEvents = _getPointerEventsByCommand();
				pointerEvents.begin();
				try {
					const nLCOS_ID = _createLCOS_CommandID(backupPP, newPP);
					if (!modelHelper.isNull(nLCOS_ID)) {
						// LCOS消灯
						await _postLCOS_Command(nLCOS_ID);
						try {
							// フォロプター
							await _postPhoropterCommand(_currentChart);
						} finally {
							// LCOS復帰
							await _postChartCommand(_currentChart);
						}
					} else {
						// フォロプター
						await _postPhoropterCommand(_currentChart);
					}
					// 端末に一時保存(リロード対策)
					_saveDataToWebStorage();
				} catch (resultJson) {
					// 失敗したら値を戻す
					_updateDataScreenState(backupSS);
					// エラーメッセージ表示
					becky.LeanStartup.alertErrorMessage(resultJson);
				} finally {
					// 完了時にボタンを有効化
					pointerEvents.end();
				}
			}());
		});
	
		// メインデータの乱視度数エリア
		$("#trMainCyl").click(function(){
			if (_isSelectCyl()) {
				return;
			}
			const backupSS = _updateDataScreenState(); // 戻せるように記憶しておく
			const backupPP = _createPhoropterParam(_currentChart);
			$("#btnMenuFarNear").val("far");
			_setSelectSCA("Cyl");
			$("#groupCrossCylinder").attr("data-select-index", 0); // クロスシリンダー(1)に戻す
			switch (_currentChart.examID) {
				case 1020: // [遠]乱視テスト
					_updateControllerLayout({examID: _currentChart.examID});
					break;
				case 1021: // [遠]ジャクソンクロスシリンダー
					_updateControllerLayout({examID: _currentChart.examID});
					break;
				default:
					_updateControllerLayout({examID: 1020});
					break;
			}
			const newPP = _createPhoropterParam(_currentChart);
			if (becky.jsonHelper.isEquals(backupPP, newPP)) {
				// フォロプターコマンドを呼ぶ必要はない
				return;
			}
			(async function(){
				// ボタンを無効化
				const pointerEvents = _getPointerEventsByCommand();
				pointerEvents.begin();
				try {
					const nLCOS_ID = _createLCOS_CommandID(backupPP, newPP);
					if (!modelHelper.isNull(nLCOS_ID)) {
						// LCOS消灯
						await _postLCOS_Command(nLCOS_ID);
						try {
							// フォロプター
							await _postPhoropterCommand(_currentChart);
						} finally {
							// LCOS復帰
							await _postChartCommand(_currentChart);
						}
					} else {
						// フォロプター
						await _postPhoropterCommand(_currentChart);
					}
					// 端末に一時保存(リロード対策)
					_saveDataToWebStorage();
				} catch (resultJson) {
					// 失敗したら値を戻す
					_updateDataScreenState(backupSS);
					// エラーメッセージ表示
					becky.LeanStartup.alertErrorMessage(resultJson);
				} finally {
					// 完了時にボタンを有効化
					pointerEvents.end();
				}
			}());
		});
	
		// メインデータの乱視軸エリア
		$("#trMainAxs").click(function(){
			if (_isSelectAxs()) {
				return;
			}
			const backupSS = _updateDataScreenState(); // 戻せるように記憶しておく
			const backupPP = _createPhoropterParam(_currentChart);
			$("#btnMenuFarNear").val("far");
			_setSelectSCA("Axs");
			$("#groupCrossCylinder").attr("data-select-index", 0); // クロスシリンダー(1)に戻す
			switch (_currentChart.examID) {
				case 1020: // [遠]乱視テスト
					_updateControllerLayout({examID: _currentChart.examID});
					break;
				case 1021: // [遠]ジャクソンクロスシリンダー
					_updateControllerLayout({examID: _currentChart.examID});
					break;
				default:
					_updateControllerLayout({examID: 1020});
					break;
			}
			const newPP = _createPhoropterParam(_currentChart);
			if (becky.jsonHelper.isEquals(backupPP, newPP)) {
				// フォロプターコマンドを呼ぶ必要はない
				return;
			}
			(async function(){
				// ボタンを無効化
				const pointerEvents = _getPointerEventsByCommand();
				pointerEvents.begin();
				try {
					const nLCOS_ID = _createLCOS_CommandID(backupPP, newPP);
					if (!modelHelper.isNull(nLCOS_ID)) {
						// LCOS消灯
						await _postLCOS_Command(nLCOS_ID);
						try {
							// フォロプター
							await _postPhoropterCommand(_currentChart);
						} finally {
							// LCOS復帰
							await _postChartCommand(_currentChart);
						}
					} else {
						// フォロプター
						await _postPhoropterCommand(_currentChart);
					}
					// 端末に一時保存(リロード対策)
					_saveDataToWebStorage();
				} catch (resultJson) {
					// 失敗したら値を戻す
					_updateDataScreenState(backupSS);
					// エラーメッセージ表示
					becky.LeanStartup.alertErrorMessage(resultJson);
				} finally {
					// 完了時にボタンを有効化
					pointerEvents.end();
				}
			}());
		});
	
		// コントローラーの位置
		{
			// 位置は端末毎に記録されている
			const classModeL = "mode-left";
			const classModeR = "mode-right";
			const $modeLeftRight = $("." + classModeL + ", ." + classModeR);
			const webStorageIO = becky.WebStorage.local.IO("subjective.controller.position");
			let controllerPos = webStorageIO.getString();
			if ("R" === controllerPos) {
				$modeLeftRight.toggleClass(classModeL + " " + classModeR);
			}
			$(".btn-changelayout").click(function(){
				$modeLeftRight.toggleClass(classModeL + " " + classModeR);
					   if ($modeLeftRight.hasClass(classModeL)) {
					controllerPos = "L";
				} else if ($modeLeftRight.hasClass(classModeR)) {
					controllerPos = "R";
				} else {
					becky.assertion.failure("unknown mode-*");
				}
				webStorageIO.setString(controllerPos);
			});
		}
	
		// コントローラーの左右(両)眼
		$("[id^=btnControllerEye]").click(function(){
			const backupSS = _updateDataScreenState(); // 戻せるように記憶しておく
			const strRLB = $(this).attr("id").slice(-1);
			_setSelectEye(strRLB);
	
			(async function(){
				// ボタンを無効化
				const pointerEvents = _getPointerEventsByCommand();
				pointerEvents.begin();
				try {
					// 視標の設定
					await _postChartCommand(_currentChart);
					// フォロプター
					await _postPhoropterCommand(_currentChart);
					// 端末に一時保存(リロード対策)
					_saveDataToWebStorage();
				} catch (resultJson) {
					// 失敗したら値を戻す
					_updateDataScreenState(backupSS);
					// エラーメッセージ表示
					becky.LeanStartup.alertErrorMessage(resultJson);
				} finally {
					// 完了時にボタンを有効化
					pointerEvents.end();
				}
			}());
		});
	
		// コントローラーの調整ボタン
		$("[id^=btnControllerAdjust]").click(function(){
			const $btnControllerAdjust = $(this);
			const vector = parseInt($btnControllerAdjust.val(), 10);
			becky.assertion.assert(1 === vector || -1 === vector);
	
			let target = null;
			let step   = null;
			const currentSCA = _getSelectSCA();
			switch (currentSCA) {
				case "Sph":
					target = "labelMainSph";
					step   = "btnMenuS";
					break;
				case "Cyl":
					target = "labelMainCyl";
					step   = "btnMenuC";
					break;
				case "Axs":
					target = "labelMainAxs";
					step   = "btnMenuA";
					break;
				case "ADD":
					target = "labelMainADD_";
					step   = "btnMenuS"; // 加入(ADD)は Sph のステップを使用する
					break;
				default:
					becky.assertion.failure("unknown select type");
					return;
			}
	
			const stepValue  = $("#" + step).attr("data-value");
			const fStepValue = parseFloat(stepValue);
			const fAddValue  = fStepValue * vector;
	
			let $labels = null;
			const eyeValue = _getSelectEye();
			switch (eyeValue) {
				case "B":
					$labels = $("[id^=" + target + "]");
					break;
				case "R":
				case "L":
					$labels = $("#" + target + eyeValue);
					break;
				default:
					becky.assertion.failure("unknown eye");
					break;
			}
			if (becky.assertion.isNullOrEmpty($labels)) {
				return;
			}
	
			// 値変更前
			const orgJson = _updateDataMeasurementValue();
	
			$labels.each((i, element) => {
				const $label = $(element);
				const dValue = $label.attr("data-text");
				if (modelHelper.isUndefined(dValue)) {
					return;
				}
				let fValue = parseFloat(dValue);
				fValue += fAddValue;
	
				const dMin  = $label.attr("data-min" );
				const dMax  = $label.attr("data-max" );
				const dLoop = $label.attr("data-loop");
				const isDefMin  = !modelHelper.isUndefined(dMin );
				const isDefMax  = !modelHelper.isUndefined(dMax );
				const isDefLoop = !modelHelper.isUndefined(dLoop);
				if (isDefMin) {
					const nMin = Number(dMin);
					if (nMin > fValue) {
						if (isDefLoop && isDefMax) {
							// 最大値が無いとループできない
							const nMax = Number(dMax);
							fValue = nMax + fValue;
						} else {
							fValue = nMin;
						}
					}
				}
				if (isDefMax) {
					const nMax = Number(dMax);
					if (nMax < fValue) {
						if (isDefLoop && isDefMin) {
							// 最小値が無いとループできない
							const nMin = Number(dMin);
							fValue = nMin + fValue - nMax - 1;
						} else {
							fValue = nMax;
						}
					}
				}
	
				$label.attr("data-text", fValue);
				_updateMainColor($label);
			});
	
			if (isSelectedNear && _isSelectSph()) {
				// 例外
				// 近見が(一度でも)選択された場合
				// Sph の変更と一緒に加入(ADD)も変更する！？
				let $labelADDs = null;
				switch (eyeValue) {
					case "B":
						$labelADDs = $("[id^=labelMainADD_]");
						break;
					case "R":
						$labelADDs = $("#labelMainADD_R");
						break;
					case "L":
						$labelADDs = $("#labelMainADD_L");
						break;
					default:
						becky.assertion.failure("unknown eye");
						break;
				}
				if (becky.assertion.isNullOrEmpty($labelADDs)) {
					return;
				}
				$labelADDs.each((i, element) => {
					const $labelADD = $(element);
					const dValue = $labelADD.attr("data-text");
					if (modelHelper.isUndefined(dValue)) {
						return;
					}
					let fValue = parseFloat(dValue);
					fValue -= fAddValue; // 値の増減は逆
					$labelADD.attr("data-text", fValue);
					_updateMainColor($labelADD);
				});
			}
	
			if (1021 == _currentChart.examID) {
				// 例外
				// クロスシリンダー時
				// Cyl の変更と一緒に Sph も変更する
				becky.assertion.assert("B" !== eyeValue, '"B" !== eyeValue'); // 両眼は無いはず
				const nowJson = _updateDataMeasurementValue();
					   if (_isSelectSph()) {
					// 途中で Sph が変更された場合を考慮
					["Sph", "Cyl"].forEach(sc_ => {
						const key = sc_ + eyeValue;
						_crossCylinderBase[key] = nowJson[key];
					});
				} else if (_isSelectCyl()) {
					const moveStep = 0.5; // 刻みで変動
					const diffCyl = _crossCylinderBase["Cyl" + eyeValue] - nowJson["Cyl" + eyeValue];
					const addSph = Math.trunc(diffCyl / moveStep) * (moveStep / 2);
					const newSph = _crossCylinderBase["Sph" + eyeValue] + addSph;
					{
						const $labelSph = $("#labelMainSph" + eyeValue);
						$labelSph.attr("data-text", newSph);
						_updateMainColor($labelSph);
					}
				}
			}
	
			if (_isSelectCyl()) {
				// 例外
				// Cyl が 0 を超える場合はキャンセルする
				const cylValues = [];
				$labels.each((i, element) => {
					const $label = $(element);
					const dValue = $label.attr("data-text");
					const strID  = $label.attr("id");
					if (modelHelper.isUndefined(dValue)) {
						return;
					}
					if (becky.assertion.isNull(strID.match(/labelMainCyl/))) {
						return;
					}
					cylValues.push(dValue);
				});
				const isCylOver0 = cylValues.some(cylValue_ => 0 < cylValue_);
				if (isCylOver0) {
					// 値を戻す
					_updateDataMeasurementValue(orgJson);
					return;
				}
			}
	
			(async function(){
				// ボタンを無効化
				const pointerEvents = _getPointerEventsByCommand();
				pointerEvents.begin();
				try {
					// フォロプター
					await _postPhoropterCommand(_currentChart);
					// 端末に一時保存(リロード対策)
					_saveDataToWebStorage();
				} catch (resultJson) {
					// 失敗したら値を戻す
					_updateDataMeasurementValue(orgJson);
					// エラーメッセージ表示
					becky.LeanStartup.alertErrorMessage(resultJson);
				} finally {
					// 完了時にボタンを有効化
					pointerEvents.end();
				}
			}());
		});
	
		// クロスシリンダー回転
		$(".btn-group-switch-circle .btn").click(function(){
			const backupSS = _updateDataScreenState(); // 戻せるように記憶しておく
			$("#groupCrossCylinder").attr("data-select-index", $(this).index());
			(async function(){
				// ボタンを無効化
				const pointerEvents = _getPointerEventsByCommand();
				pointerEvents.begin();
				try {
					// LCOS消灯
					// ただし、融像を維持するため、黒画像ではなく融像枠画像
					await _postLCOS_Command(1);
					try {
						// フォロプター
						await _postPhoropterCommand(_currentChart);
					} finally {
						// LCOS復帰
						await _postChartCommand(_currentChart);
					}
					// 端末に一時保存(リロード対策)
					_saveDataToWebStorage();
				} catch (resultJson) {
					// 失敗したら値を戻す
					_updateDataScreenState(backupSS);
					// エラーメッセージ表示
					becky.LeanStartup.alertErrorMessage(resultJson);
				} finally {
					// 完了時にボタンを有効化
					pointerEvents.end();
				}
			}());
		});
		{
			const optionsAttributeFilter = {
				attributes: true,
				attributeFilter: [ "data-select-index" ],
			};
			const idCrossCylinder = "groupCrossCylinder";
			becky.MutationObserver.byID(
				idCrossCylinder,
				records => records.forEach(record_ => {
					const target = record_.target;
					const selectIndex = target.dataset.selectIndex;
					const $btn = $(".btn-group-switch-circle .btn").eq(selectIndex);
					if (!becky.assertion.isNullOrEmpty($btn)) {
						viewHelper.selectClassSingle("current", $btn);
					}
					_updateCrossCylinderClasses();
				}),
				optionsAttributeFilter);
				// 変更イベントを呼ぶ(初期化)
				becky.dataSync.callChangeEventAttr(document.getElementById(idCrossCylinder), "data-select-index");
		}
	
		// 乱視/軸の切り替え
		$(".btn-astigmat-axis").click(function(){
			const backupSS = _updateDataScreenState(); // 戻せるように記憶しておく
			const backupPP = _createPhoropterParam(_currentChart);
			_toggleSelectCylAxs();
			$("#groupCrossCylinder").attr("data-select-index", 0); // クロスシリンダー(1)に戻す
			const newPP = _createPhoropterParam(_currentChart);
			if (becky.jsonHelper.isEquals(backupPP, newPP)) {
				// フォロプターコマンドを呼ぶ必要はない
				return;
			}
			(async function(){
				// ボタンを無効化
				const pointerEvents = _getPointerEventsByCommand();
				pointerEvents.begin();
				try {
					const nLCOS_ID = _createLCOS_CommandID(backupPP, newPP);
					if (!modelHelper.isNull(nLCOS_ID)) {
						// LCOS消灯
						await _postLCOS_Command(nLCOS_ID);
						try {
							// フォロプター
							await _postPhoropterCommand(_currentChart);
						} finally {
							// LCOS復帰
							await _postChartCommand(_currentChart);
						}
					} else {
						// フォロプター
						await _postPhoropterCommand(_currentChart);
					}
					// 端末に一時保存(リロード対策)
					_saveDataToWebStorage();
				} catch (resultJson) {
					// 失敗したら値を戻す
					_updateDataScreenState(backupSS);
					// エラーメッセージ表示
					becky.LeanStartup.alertErrorMessage(resultJson);
				} finally {
					// 完了時にボタンを有効化
					pointerEvents.end();
				}
			}());
		});
	
		// タブ内の視力表(サムネイル)
		$("[data-auto-id]").click(function(){
			if (becky.assertion.isNullOrEmpty(becky.subjective.arrayFlatChartPageParameter)) {
				return;
			}
			const backupSS = _updateDataScreenState(); // 戻せるように記憶しておく
			const backupPP = _createPhoropterParam(_currentChart);
			const $btn = $(this);
			const autoID = $btn.attr("data-auto-id");
			const chart = _getChartByAutoID(becky.subjective.arrayFlatChartPageParameter, autoID);
			if (chart.autoID === _currentChart.autoID) {
				// 同じ視標が選択された
				return;
			}
			const nExamID = chart.examID;
			const strTitle = _getDefMessageBySubjective("titleExamID" + nExamID);
			// 検査名
			$("#labelExamTitle").attr("data-text", strTitle);
	
			// 例外:[近]加入度測定
			if (2030 === chart.examID) {
				// 強制的に近見に切り替える
				$("#btnMenuFarNear").val("near");
			}
	
			// 選択眼/SCAの選択状態の更新(Chartから)
			_updateSelectEyeFromChart(chart);
			_updateSelectSCA_FromChart(chart);
	
			$("#groupCrossCylinder").attr("data-select-index", 0); // クロスシリンダー(1)に戻す
			$("#currentAutoID").attr("data-value", chart.autoID);
			const newPP = _createPhoropterParam(chart);
			(async function(){
				// ボタンを無効化
				const pointerEvents = _getPointerEventsByCommand();
				pointerEvents.begin();
				try {
					// Todo. 素直にbool型で判定できるようにしたい
					if ("on_" === becky.settingJson.subjective.alignmentWhenSightMarksAreSelected) {
						// アライメント
						await _postAlignmentCommand();
					}
	
					const nLCOS_ID = _createLCOS_CommandID(backupPP, newPP);
					if (!modelHelper.isNull(nLCOS_ID)) {
						// LCOS消灯
						await _postLCOS_Command(nLCOS_ID);
						try {
							// フォロプター
							await _postPhoropterCommand(chart);
						} catch (resultJson) {
							// LCOS復帰
							await _postChartCommand(_currentChart);
						}
						// 視標の設定
						await _postChartCommand(chart);
					} else {
						// 視標の設定
						await _postChartCommand(chart);
						// フォロプター
						await _postPhoropterCommand(chart);
					}
					// 端末に一時保存(リロード対策)
					_saveDataToWebStorage();
				} catch (resultJson) {
					// 失敗したら値を戻す
					_updateDataScreenState(backupSS);
					// エラーメッセージ表示
					becky.LeanStartup.alertErrorMessage(resultJson);
				} finally {
					// 完了時にボタンを有効化
					pointerEvents.end();
				}
			}());
			_resetChartRG();
		});
	
		$("#btnChartInvert").click(function(){
			const $chartTableBg = $(".chart-table .bg");
			$chartTableBg.toggleClass("bg-invert");
			const isBgInvert = $chartTableBg.hasClass("bg-invert");
			const strParam = isBgInvert ? "1" : "0";
			$(".chart-table .image img").attr("style", "filter: Invert(" + strParam + ")");
			// RG は排他なので無効化
			_resetChartRG();
		});
	
		$("#btnChartRG").click(function(){
			const $chartTableBg = $(".chart-table .bg");
			$chartTableBg.toggleClass("bg-rg");
			// 通常状態に戻す
			$(".chart-table div").removeClass("active");
			$(".chart-table .hitarea div").addClass("active");
			// 反転は排他なので無効化
			_resetChartInvert();
		});
	
		{
			/*!
			 * @brief メニューの選択状態を解除する
			 */
			function _deselectMenu()
			{
				$(".menu-item").removeClass("current");
				$(".menu-slidenavi").hide();
			}
	
			$(".btn-menu-bar, .btn-menu").click(function(){
				const $this = $(this);
				const $menuitem = $this.parent();
				const isThisCurrent = $menuitem.hasClass("current");
	
				_deselectMenu();
	
				const $menuNavi = $this.prev(".menu-slidenavi");
				if (!isThisCurrent && !modelHelper.isNullOrEmpty($menuNavi)) {
					$menuNavi.fadeIn("fast"); // show() の仲間
					$menuitem.addClass("current");
				}
			});
	
			// メニュー領域外をクリックしたらメニューを閉じる
			let bIsMenuIn = false;
			$(".btn-menu-bar, .btn-menu, .menu-slidenavi").hover(function(){
				bIsMenuIn = true;
			}, function(){
				bIsMenuIn = false;
			});
			$("body").click(function() {
				if (!bIsMenuIn) {
					_deselectMenu();
				}
			});
		}
	
		// SCAのステップ数の変更
		["btnMenuS", "btnMenuC", "btnMenuA"].forEach(idMenu_ => {
			becky.MutationObserver.byID(idMenu_,
				records => records.forEach(record_ => _onUpdateHtmlMenuStep(record_.target, idMenu_)),
				optionsAttributeFilterDataValue);
			// 変更イベントを呼ぶ(初期化)
			becky.dataSync.callChangeEventAttr(document.getElementById(idMenu_), "data-value");
			// メニューアイテムの選択時
			$("[data-for=" + idMenu_ + "] .slidenavi-item").click(function(){
				// 新しい値を反映
				$("#" + idMenu_).attr("data-value", $(this).attr("data-value"));
			});
		});
	
		// ウォース4点テスト 専用
		{
			const idResultValue = "btnMenuChartID9_ResultValue";
			becky.MutationObserver.byID(idResultValue,
				records => records.forEach(record_ => {
					const target = record_.target;
					const value = target.dataset.value;
					let itemText = "";
					if (modelHelper.isNullOrEmpty(value)) {
						$("[data-for=btnMenuChartID9] .slidenavi-item").removeClass("current");
						$("#btnMenuChartID9_ResultValue").removeClass("current");
					} else {
						const $currentItem = $("[data-for=btnMenuChartID9] [data-value='" + value + "']");
						$currentItem.addClass("current").siblings().removeClass("current");
						$("#btnMenuChartID9_ResultValue").addClass("current");
						itemText = $currentItem.text();
					}
					$("#btnMenuChartID9_ResultValue > div").attr("data-text", itemText);
				}),
				optionsAttributeFilterDataValue);
			// 変更イベントを呼ぶ(初期化)
			becky.dataSync.callChangeEventAttr(document.getElementById(idResultValue), "data-value");
			// メニューアイテムの選択時(When selecting a menu item)
			
			$("[data-for=btnMenuChartID9] .slidenavi-item").click(function(){
				const $this = $(this);
				$("#btnMenuChartID9_ResultValue").attr("data-value", $this.attr("data-value"));
			});
		}
	
		// ジャクソンクロスシリンダー 専用
		{
			const idMenu = "btnMenuCC_Power";
			becky.MutationObserver.byID(idMenu,
				records => records.forEach(record_ => _onUpdateHtmlMenuStep(record_.target, idMenu)),
				optionsAttributeFilterDataValue);
			// 変更イベントを呼ぶ(初期化)
			becky.dataSync.callChangeEventAttr(document.getElementById(idMenu), "data-value");
			// メニューアイテムの選択時
			$("[data-for=" + idMenu + "] .slidenavi-item").click(function(){
				const backupCC = $("#" + idMenu).attr("data-value"); // 戻せるように記憶しておく
				const backupPP = _createPhoropterParam(_currentChart);
				// 新しい値を反映
				$("#" + idMenu).attr("data-value", $(this).attr("data-value"));
				const newPP = _createPhoropterParam(_currentChart);
				if (becky.jsonHelper.isEquals(backupPP, newPP)) {
					// フォロプターコマンドを呼ぶ必要はない
					return;
				}
				(async function(){
					// ボタンを無効化
					const pointerEvents = _getPointerEventsByCommand();
					pointerEvents.begin();
					try {
						// フォロプター
						await _postPhoropterCommand(_currentChart);
						// 端末に一時保存(リロード対策)
						_saveDataToWebStorage();
					} catch (resultJson) {
						// 失敗したら値を戻す
						$("#" + idMenu).attr("data-value", backupCC);
						// エラーメッセージ表示
						becky.LeanStartup.alertErrorMessage(resultJson);
					} finally {
						// 完了時にボタンを有効化
						pointerEvents.end();
					}
				}());
			});
		}
	
		// メニューアイテムの選択時
		$(".slidenavi-item").click(function(){
			// 選択した項目を見せるために緩急を付けて閉じる
			asyncHelper.delay(150).then(function(){
				$(".menu-item").removeClass("current");
				$(".menu-slidenavi").hide();
			});
		});
	
		// 参照データ
		$("#btnMenuReferenceData").click(function(){
			// show / hide
			$(".area-side-a, .area-side-b").fadeToggle("fast"); // toggle() の仲間
		});
	
		// value 属性を監視するオプション(MutationObserverInit)
		const optionsAttributeFilterValue = {
			attributes: true,
			attributeFilter: [ "value" ],
		};
	
		// 遠見/近見
		const idFarNear = "#btnMenuFarNear";
		becky.MutationObserver.byID(
			idFarNear,
			records => records.forEach(record_ => {
				_updateLblFarNear(record_.target);
	
				const newVal = record_.target.value;
				const oldVal = _toggleVal_FarNear(newVal);
				$("#trMainVA" + newVal).show();
				$("#trMainVA" + oldVal).hide();
				$("#inputExaminationDistancePoint_" + newVal).show();
				$("#inputExaminationDistancePoint_" + oldVal).hide();
	
				//_updateChartTable(_currentChart);
				_updateControllerLayout(_currentChart);
				//_updateMenuInit(_currentChart);
				_updateSelectSCA_FromFarNear();
	
				if (_isSelectNear()) {
					// 近見が(一度でも)選択された事を記録
					isSelectedNear = true;
				}
			}),
			optionsAttributeFilterValue);
		const $btnFarNear = $(idFarNear);
		$btnFarNear.val($btnFarNear.val()); // 更新イベントを発生させる
		$btnFarNear.click(function(){
			const $btn = $(this);
			const val = $btn.val();
			const newVal = _toggleVal_FarNear(val);
			// 新しい値を反映
			$btn.val(newVal);
	
			(async function(){
				// ボタンを無効化
				const pointerEvents = _getPointerEventsByCommand();
				pointerEvents.begin();
				try {
					// LCOS消灯
					await _postLCOS_Command(0);
					try {
						// フォロプター
						await _postPhoropterCommand(_currentChart);
					} finally {
						// LCOS復帰
						await _postChartCommand(_currentChart);
					}
					// 端末に一時保存(リロード対策)
					_saveDataToWebStorage();
				} catch (resultJson) {
					// 失敗したら値を戻す
					$btn.val(val);
					// エラーメッセージ表示
					becky.LeanStartup.alertErrorMessage(resultJson);
				} finally {
					// 完了時にボタンを有効化
					pointerEvents.end();
				}
			}());
		});
	
		// 両眼開放/片眼遮蔽
		//Blink open/eye mask
		const idBinoMono = "#btnMenuBinoMono";
		becky.MutationObserver.byID(
			idBinoMono,
			records => records.forEach(record_ => {
				_updateLblBinoMono(record_.target);
			}),
			optionsAttributeFilterValue);
		const $btnBinoMono = $(idBinoMono);
		$btnBinoMono.val($btnBinoMono.val()); // 更新イベントを発生させる
		$btnBinoMono.click(function(){
			const backupSS = _updateDataScreenState(); // 戻せるように記憶しておく
			const backupCP = _createChartParam(_currentChart);
			const $btn = $(this);
			const val = $btn.val();
			const newVal = _toggleVal_BinoMono(val);
			// 新しい値を反映
			$btn.val(newVal);
			const newCP = _createChartParam(_currentChart);
			if (becky.jsonHelper.isEquals(backupCP, newCP)) {
				// Chart コマンドを呼ぶ必要はない
				return;
			}
			(async function(){
				// ボタンを無効化
				const pointerEvents = _getPointerEventsByCommand();
				pointerEvents.begin();
				try {
					// 視標の設定
					await _postChartCommand(_currentChart);
					// 端末に一時保存(リロード対策)
					_saveDataToWebStorage();
				} catch (resultJson) {
					// 失敗したら値を戻す
					_updateDataScreenState(backupSS);
					// エラーメッセージ表示
					becky.LeanStartup.alertErrorMessage(resultJson);
				} finally {
					// 完了時にボタンを有効化
					pointerEvents.end();
				}
			}());
		});
	
		// オートアライメント
		$("#btnAutoAlignment").click(function(){
			(async function(){
				// ボタンを無効化
				const pointerEvents = _getPointerEventsByCommand();
				pointerEvents.begin();
				// 再び、ボタンが押せるようになるまで暗くする
				const $btnLabel = $("#btnAutoAlignment > div");
				$btnLabel.attr("style", "color: #1a1a1a; text-shadow: 1px 1px #ccc4"); // ccc + 4
				try {
					// アライメント
					await _postAlignmentCommand();
				} catch (resultJson) {
					// エラーメッセージ表示
					becky.LeanStartup.alertErrorMessage(resultJson);
				} finally {
					// 暗くしたものを戻す
					$btnLabel.removeAttr("style");
					// 完了時にボタンを有効化
					pointerEvents.end();
				}
			}());
		});
	
		// 駆動リセット
		$("#btnResetBaseXYZ").click(function(){
			(async function(){
				// ボタンを無効化
				const pointerEvents = _getPointerEventsByCommand();
				pointerEvents.begin();
				// 再び、ボタンが押せるようになるまで暗くする
				const $btnLabel = $("#btnResetBaseXYZ > div");
				$btnLabel.attr("style", "color: #1a1a1a; text-shadow: 1px 1px #ccc4"); // ccc + 4
				try {
					// リセットベース
					await _postResetBaseXYZCommand();
				} catch (resultJson) {
					// エラーメッセージ表示
					becky.LeanStartup.alertErrorMessage(resultJson);
				} finally {
					// 暗くしたものを戻す
					$btnLabel.removeAttr("style");
					// 完了時にボタンを有効化
					pointerEvents.end();
				}
			}());
		});
	
		// 検査距離
		{
			let nBackupValue = 0;
			$("[id^=inputExaminationDistancePoint_]").focus(function(){
				nBackupValue = parseInt($(this).val(), 10);
			}).blur(function(){
				const newValue = $(this).val().trim();
				if (modelHelper.isNullOrEmpty(newValue)) {
					$(this).val(nBackupValue); // 値を戻す
					return;
				}
				const pattern = /^([1-9]\d*|0)$/;
				if (!pattern.test(newValue)) {
					// 不正値
					$(this).val(nBackupValue); // 値を戻す
					return;
				}
				let nNewValue = parseInt(newValue, 10);
				{
					// 最小値と最大値で値を丸め込む
					//Round the value to the minimum and maximum
					const nMin = parseInt($(this).attr("min"), 10);
					const nMax = parseInt($(this).attr("max"), 10);
					nNewValue = Math.min(Math.max(nMin, nNewValue), nMax);
				}
				if (nBackupValue === nNewValue) {
					// 変化が無い場合
					$(this).val(nBackupValue); // 値を戻す
					return;
				}
				// 新しい値を反映
				//Reflect new value
				$(this).val(nNewValue);
				(async function(){
					// ボタンを無効化
					const pointerEvents = _getPointerEventsByCommand();
					pointerEvents.begin();
					try {
						// LCOS消灯
						await _postLCOS_Command(0);
						try {
							// フォロプター
							await _postPhoropterCommand(_currentChart);
						} finally {
							// LCOS復帰
							await _postChartCommand(_currentChart);
						}
						// 端末に一時保存(リロード対策)
						_saveDataToWebStorage();
					} catch (resultJson) {
						// 失敗したら値を戻す
						$(this).val(nBackupValue);
						// エラーメッセージ表示
						becky.LeanStartup.alertErrorMessage(resultJson);
					} finally {
						// 完了時にボタンを有効化
						pointerEvents.end();
					}
				}());
			}).keyup(function(event){
				// Enter
				if (13 === event.keyCode) {
					$(this).blur(); // フォーカスを外す
					return;
				}
			});
		}
	
		const $btnNaviNext = $("#btnNaviNext");
		$btnNaviNext.attr("href", "#"); // href によるリンクを無効化
		$btnNaviNext.click(function(){
			const $form = $("<form/>", {
				action: "subjective.php",
				method: "post",
				});
			const measurementValueJson = _updateDataMeasurementValue();
			Object.getOwnPropertyNames(measurementValueJson).forEach(name_ => {
				$("<input/>", {
					type : "hidden",
					name : name_,
					value: measurementValueJson[name_],
				}).appendTo($form);
			});
			// 登録という事を識別する為の情報
			//Information to identify registration
			$("<input/>").attr({
				type : "hidden",
				name : "subjective_register",
				value: "Register",
			}).appendTo($form);
			$form.appendTo(document.body);
			$form.submit();
			// 次へのタッチイベントを無効化
			becky.navi.disableNext();
		});
	
		// data-* Create a change event
		becky.dataSync.createChangeEvent();
	
		// Change button background processing
		_buttonClickBackGroundOverlay($("[id^=btnControllerAdjust], .btn-changelayout, .btn-astigmat-axis, #btnChartInvert, #btnChartRG, #btnMenuReferenceData, #btnMenuFarNear, #btnMenuBinoMono, #btnAutoAlignment, #btnResetBaseXYZ"));
    });


    /*!
    * Left, Right, Up and Down buttons visible on page load and chart change
    */
    function _visibleChartButtonsOnLoad(transnextChartID, transprevChartID) {

        $(".left").hide();
        $(".right").hide();

        if (transnextChartID == 0) {
            $(".down").hide();
        }
        else
        {
            $(".down").show();
        }

        if (transprevChartID == 0)
        {
            $(".up").hide();
        }
        else {
            $(".up").show();
        }
       
        
    };
    /*!
	 * Left, Right, Up and Down buttons visible on mask selection
	 */
    function _visibleChartButtonsOnMaskSelection(chartRow, chartCol, transnextChartID, transprevChartID, selIndex, selIsTop) {
        $(".up").show();
        $(".down").show();
        $(".left").show();
        $(".right").show();

        const $this = $(".chart-table .side .active");
        const isSide = $this.parent().hasClass("side");
        const isThisActive = $this.hasClass("active");
        const $hitarea_div = $(".chart-table .hitarea div");
        const hitAreaActive = $hitarea_div.hasClass("active");
        const $chartTableActive = $(".chart-table .active");
        const index = $this.index();
        const index2 = $(".chart-table .hitarea .active").index();

        //No Mask Selected
        if (selIndex == -1) {
            $(".up").hide();
            $(".down").hide();
            $(".left").hide();
            $(".right").hide();
        }

        //IsTop true=Column and False=Row
        if (selIsTop == 1) {
            //No Mask Selected
            if (selIndex == 0) {
                //If previous chart not available
                if (transprevChartID == 0) {
                    $(".up").hide();
                    $(".left").hide();
                }
                $(".down").show();
                $(".right").show();
            }
            else if (selIndex + 1 == chartCol) {
                if (transnextChartID == 0) {
                    $(".down").hide();
                    $(".right").hide();
                }
                $(".up").show();
                $(".left").show();
            }
            else {
                $(".up").show();
                $(".down").show();
                $(".left").show();
                $(".right").show();
            }


            //Start row  Up and Left
            if (transprevChartID == 0) {
                $(".up").hide();

                if (selIndex == 0) {
                    $(".left").hide();                    
                }
                else {
                    $(".left").show();
                }
            }

            //End Column Down and Right
            if (transnextChartID == 0) {
                $(".down").hide();

                if (selIndex + 1 == chartCol) {
                    $(".right").hide();
                }
                else
                {
                    $(".right").show();
                }
            }
		}
		//IsTop false=Column and true=Row
        else {
			$(".left").hide();
			$(".right").hide();
            if (selIndex == 0) {
                //If previous chart not available
                if (transprevChartID == 0) {
                    $(".up").hide();
                    $(".left").hide();
                }
                $(".down").show();
            }
            else if (selIndex + 1 == chartRow) {
                if (transnextChartID == 0) {
					if(selIndex<chartRow){
						$(".down").show();
					}
					else
                    $(".down").hide();
                    $(".right").hide();
                }
                $(".up").show();
            }
            else {
                $(".up").show();
                $(".down").show();
            }

            //Start row  Up and Left
            if (transprevChartID == 0) {
				if(selIndex>0){
					$(".up").show();
				}
				else
                $(".up").hide();

                if (selIndex == 0) {
                    $(".up").hide();
                }
                else {
                    $(".up").show();
                }
            }

            //End Column Down and Right
            if (transnextChartID == 0) {
				if(selIndex<chartRow){
					$(".down").show();
				}
				else
                $(".down").hide();

                if (selIndex + 1 == chartRow) {
                    $(".down").hide();
                }
                else {
                    $(".down").show();
                }
            }
        }
    };

     /*!
	 * Left, Right, Up and Down buttons visible on mask single cell selection
	 */
	function _visibleChartButtonsOnCellSelection(chartRow, chartCol, transnextChartID, transprevChartID
		) {

        $(".up").show();
        $(".down").show();
        $(".left").show();
        $(".right").show();

        const $this = $(".chart-table .top .active");
        const isTop = $this.parent().hasClass("top");
        const isThisActive = $this.hasClass("active");
        const $hitarea_div = $(".chart-table .hitarea div");
        const hitAreaActive = $hitarea_div.hasClass("active");
        const $chartTableActive = $(".chart-table .active");
        const index = $this.index();
        const index2 = $(".chart-table .hitarea .active").index();
        let nActiveCount = 0;

        //No Mask Selected
        if (index2 == 0) {
            //If previous chart not available
            if (transprevChartID == 0)
            {
                $(".up").hide();
                $(".left").hide();
            }             
            $(".down").show();           
            $(".right").show();
        }
        else if ((index2 + 1 == (chartRow * chartCol)) && chartRow>2) {
            if (transnextChartID == 0)
            {
                $(".down").hide();
                $(".right").hide();
            }
            $(".up").show();
            $(".left").show();
		}
		else if (chartRow<=2){
			if(index2 + 1 == (chartRow * chartCol)){
				if (transnextChartID == 0)
				{
					$(".down").hide();
					$(".right").hide();
				}
				$(".up").show();
				$(".left").show();
			}
			if(index2>=chartCol*(chartRow-1)){
				if (transnextChartID == 0)
				{
					$(".down").hide();
				}
			}
		}
		else if (chartRow>2){
			if(index2 + 1 == (chartRow * chartCol)){
				if (transnextChartID == 0)
				{
					$(".down").hide();
					$(".right").hide();
				}
				$(".up").show();
				$(".left").show();
			}
			if(index2>=chartCol*(chartRow-1)){
				if (transnextChartID == 0)
				{
					$(".down").hide();
				}
			}
		}

        else
        {
            $(".up").show();
            $(".down").show();
            $(".left").show();
            $(".right").show();
        }

         //Start Cell Column Up and Left
        if (transprevChartID == 0)
        {
            if (index2 < chartCol) {
                $(".up").hide();
                if (index2 ==0) {
                    $(".left").hide();
                }
                else {
					if (index2 >= 0){
                    $(".left").show();
				}
			}
            }
            else {
                $(".up").show();
                $(".left").show();
            }
        }

    };;

    function _visibleChartButtonsUpdateChart(refChartID) {
        const chartParameterItem = becky.subjective.arrayChartParameter.chartParameter.filter(
            chartParameterItem_ => chartParameterItem_.chartID === refChartID)[0];
        if (becky.assertion.isUndefined(chartParameterItem)) {
            return;
        }
        let transnextChartID = chartParameterItem.transition.nextChartID;
        let transprevChartID = chartParameterItem.transition.prevChartID;
    }
    
	
	$(window).on('load', function(){
		// Set the URL of the live image
		["L", "R"].forEach(pos => {
			document.getElementById("imgEye" + pos).setAttribute("src", becky.liveHttpUri[pos]);
		});
	});
	
	}());//即時関数の終端
	