<?php
/*! @file
 * @brief モデルユーティリティ
 */

namespace ModelUtil;

/*!
 * @brief 配列か連想配列かを判定
 * 添え字が0から連続する数値(=配列とみなせる)ときに真
 *
 * @param[in] array $arr 調査対象の配列及び連想配列
 * @retval bool true  配列
 * @retval bool false 連想配列
 */
function is_vector(array $arr)
{
	return array_values($arr) === $arr;
}

/*!
 * @brief 再帰的なempty.
 *
 * @param[in] mixed $input 調査対象
 * @retval bool true  全てがempty判定
 * @retval bool false emptyではない物を含んでいる
 */
function empty_recursive($input)
{
	if (!is_array($input)) {
		if (!empty($input)) {
			return false;
		}
	} else {
		foreach ($input as $child) {
			if (!empty_recursive($child)) {
				return false;
			}
		}
	}
	return true;
}

/*!
 * @brief 連想配列の値の文字列をトリムする
 *
 * @param[in,out] array $row 対象の連想配列
 * @return void
 */
function array_trim(array &$row)
{
	if (is_vector($row)) {
		// 配列はサポートしない
		return;
	}
	// 添字が整数の場合に削除
	foreach (array_keys($row) as $key) {
		if (!is_int($key)) {
			continue;
		}
		unset($row[$key]);
	}
	// 各要素をトリムする
	array_walk(
		$row,
		function (&$value) {
			$value = trim($value);
		}
	);
}

/*!
 * @brief 型を取得する
 * ただし、整数と実数は区別しない
 *
 * @param[in] mixed $value 調査対象
 * @return string 型名
 */
function gettype_ignore_numeric($value)
{
	$type = gettype($value);
	switch ($type) {
		case 'integer':
		case 'double':
			$type = 'numeric';
			break;
		default:
			break;
	}

	return $type;
}

/*!
 * @brief 値を取得する(配列向け)
 *
 * @param[in] mixed $value 対象(Notice エラーを回避するため参照渡し)
 * @param[in] mixed $default 取得できない場合の値
 *
 * @return mixed 取得した値
 */
function array_get(&$value, $default)
{
	if (!isset($value)) {
		return $default;
	}
	assert(gettype_ignore_numeric($value) === gettype_ignore_numeric($default));

	return $value;
}

/*!
 * @breif 数値に変換できる場合は変換する
 *
 * @param[in] string $value 変換元
 * @return int or float or string
 */
function toNumericIfPossible($value)
{
	$trimedValue = trim($value);
	if (preg_match('/^[+,-]?([1-9]\d*|0)$/', $trimedValue)) {
		return intval($trimedValue);
	}
	if (preg_match('/^[+,-]?\d*(\.\d+)+$/', $trimedValue)) {
		return floatval($trimedValue);
	}
	return $value;
}

/*!
 * @brief 実数値を四捨五入する
 *
 * @param[in] numeric $number 対象の値
 * @param[in] numeric $significance 丸め込む単位
 *
 * @return double 丸め込んだ値
 */
function fround($number, $significance)
{
	if ('numeric' !== gettype_ignore_numeric($number) ||
	    'numeric' !== gettype_ignore_numeric($significance)) {
		return false;
	}

	$halfSignificance = $significance / 2;
	$mod = fmod(abs($number), $significance);

	$isRoundUp = $halfSignificance > $mod;
	if (0 < $number) {
		$isRoundUp = !$isRoundUp;
	}

	if ($isRoundUp) {
		return ceil($number / $significance) * $significance;
	} else {
		return floor($number / $significance) * $significance;
	}
}
