<?php
/*! @file
 * @brief ファイルに関するユーティリティ
 */

//namespace becky\File; 冗長だと感じた
namespace becky;

require_once 'systemUtil.php';

// ... による可変個引数関数は、PHP 5.6.x から
//function file_put_contents_and_sync($filename, $data, ...$args)
//{
//	$ret = file_put_contents($filename, $data, ...$args);
//	if (false === $ret) {
//		return false;
//	}
//	if (!\becky\System\sync()) {
//		return false;
//	}
//	return $ret;
//}
//function file_put_contents_and_syncBackgroundExecute($filename, $data, ...$args)
//{
//	$ret = file_put_contents($filename, $data, ...$args);
//	if (false === $ret) {
//		return false;
//	}
//	\becky\System\syncBackgroundExecute();
//	return $ret;
//}

/*!
 * @brief ファイルを出力後に sync(同期) を実行する
 * 引数/戻り値は file_put_contents と同じ
 * 
 * @return int ファイルに書き込まれたバイト数
 * @retval false 失敗(sync の結果も含めて)
 */
function file_put_contents_and_sync()
{
	$ret = call_user_func_array('file_put_contents', func_get_args());
	if (false === $ret) {
		return false;
	}
	if (!\becky\System\sync()) {
		return false;
	}
	return $ret;
}

/*!
 * @brief ファイルを出力後に sync(非同期) を実行する
 * 引数/戻り値は file_put_contents と同じ
 * 
 * @return int ファイルに書き込まれたバイト数
 * @retval false 失敗(sync の結果は含めない)
 */
function file_put_contents_and_syncBackgroundExecute()
{
	$ret = call_user_func_array('file_put_contents', func_get_args());
	if (false === $ret) {
		return false;
	}
	\becky\System\syncBackgroundExecute();
	return $ret;
}
