<?php
/*! @file
 * @brief 根幹のシステムに関するユーティリティ
 */

namespace becky\System;

//! @brief Windows 判定のキャッシュ
$_isWindows = null;

/*!
 * @brief 稼動しているサーバーが Windows か？
 * 開発環境か？くらいの精度で使用する
 * 
 * @retval true Windows
 * @retval false Windows以外
 */
function isWindows()
{
	global $_isWindows;
	if (null === $_isWindows) {
		$_isWindows = 'WIN' === strtoupper(substr(PHP_OS, 0, 3));
	}
	return $_isWindows;
}

/*!
 * @brief sync を実行(同期)
 *
 * @retval true 成功
 * @retval false 失敗
 */
function sync()
{
	if (isWindows()) {
		return true;
	}
	$output = [];
	$return_var = 0;
	exec('sync', $output, $return_var);
	return 0 === $return_var;
}

/*!
 * @brief sync をバックグラウンド実行(非同期)
 *
 * @return void
 */
function syncBackgroundExecute()
{
	if (isWindows()) {
		return;
	}
	exec('nohup sync > /dev/null &');
}
