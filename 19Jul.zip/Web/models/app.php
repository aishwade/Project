<?php
/*! @file
 * @brief アプリケーション全体で使用する基本的な関数郡
 */

/*!
 * @global array $app
 * アプリケーション全体で共有する連想配列
 * 'topUri'	アプリケーションの最上位 URI
 * 'topDir'	アプリケーションの最上位ディレクトリ（サーバー内パス）
 * 'styles'	スタイルシート
 * 'scripts'	スクリプト(.js)
 *
 * 'sessionDir'	セッション用の最上位ディレクトリ
 */
$app = [];

/*!
 * @brief アプリケーションの初期化
 */
function init($frontScript)
{
	global $app;

	error_reporting((E_ALL | E_STRICT) & ~E_NOTICE);
	// mb_internal_encoding('UTF-8'); 本番環境に mb_string が無い？

	$app['topUri'] = str_replace($frontScript, '', $_SERVER['SCRIPT_NAME']);
	$app['topDir'] = str_replace($frontScript, '', $_SERVER['SCRIPT_FILENAME']);

	// PHPセッションに関する設定
	$app['sessionDir'] = topDir() . 'contents/session/';
	initSession(topDir() . 'contents/settings/app.setting.json');

	session_start();

	setTimezone($app['session']);
	initMessage();
	loadTranslateMessage();
}

/*!
 * @brief アプリケーションの最上位URLを返す.
 *
 * @global array $app アプリケーション変数
 * @return string 最上位URL (プロトコル指定なし)
 */
function topUri()
{
	global $app;
	return $app['topUri'];
}

/*!
 * @brief アプリケーションの最上位ディレクトリを返す.
 * サーバー内ファイルシステムのフルパス
 *
 * @global array $app アプリケーション変数
 * @return string 最上位ディレクトリ
 */
function topDir()
{
	global $app;
	return $app['topDir'];
}

/*!
 * @brief 外部スクリプトファイルを追加する
 *
 * @global array $app
 * @param[in] array $scripts 追加する外部スクリプトファイル (最上位URLからの相対指定)
 */
function addScripts($scripts)
{
	global $app;
	foreach ($scripts as $js) {
		$app['scripts'][] = $js;
	}
}

/*!
 * @brief 外部スタイルシートを追加する
 *
 * @global array $app
 * @param[in] array $styles 追加する外部スタイルシート (最上位URLからの相対指定)
 */
function addStyles($styles)
{
	global $app;
	foreach ($styles as $css) {
		$app['styles'][] = $css;
	}
}

/*!
 * @brief PHPセッションに関連するアプリケーション設定.
 * sesston_start() の直前で設定する.
 */
function initSession($configFile)
{
	global $app;

	// 設定の読み出し
	$config = getConfig(topDir() . 'contents/settings/app.setting.json');
	// セッション保存用パス
	$sessSaveDir = sessionDir() . 'sess';

	if (!file_exists($sessSaveDir)) {
		mkdir($sessSaveDir, 0777, true);
	}

	// セッションの設定
	session_set_cookie_params(0);
	session_save_path($sessSaveDir);
	// 有効期限(秒)
	if (isset($config['cleanup'])) {
		ini_set('session.gc_maxlifetime', $config['cleanup']);
	}
	if (isset($config['gc_probability'])) {
		ini_set('session.gc_probability', $config['gc_probability']);
	}
	if (isset($config['gc_divisor'])) {
		ini_set('session.gc_divisor', $config['gc_divisor']);
	}

	$app['session'] = $config;
}

/*!
 * @brief TimeZoneの設定
 *
 * @param[in] unknown $config
 */
function setTimezone($config)
{
	$tz = 'GMT';
	if (isset($config['timeZone'])) {
		$tz = trim($config['timeZone']);
	}
	// タイムゾーンを指定の値に変換
	if (date_default_timezone_set($tz) == false) {
		// timezone is not valid.
		$config['timeZone'] = 'GMT';
	}
}

/*!
 * @brief デバッグ用ダンプ
 *
 * @global type $app
 *  アプリケーション変数
 *
 * @param[in] boolean $default デフォルトは非表示(FALSE)
 */
function printDebug($default = false)
{
	if (!$default) {
		return;
	}
	global $app;
	var_dump($_SESSION);
	var_dump($app);
	var_dump($_SERVER);
}

/*!
 * @brief 設定ファイル(JSON形式)からの読み出し
 *
 * @return array 設定の連想配列
 */
function getConfig($configFile)
{
	// defaults
	$config = [
		'autoLogout' => '900',	// 15min
		'cleanup' => '14400',	// 4h
		'gc_probability' => '1',
		'gc_divisor' => '1'
	];

	if (isset($configFile) and file_exists($configFile)) {
		$content = file_get_contents($configFile);
		if (false !== $settingString) {
			$items = json_decode($content, true);
			foreach ($items as $key => $value) {
				$config[$key] = $value;
			}
		}
	}

	// セッション期限切れ時間がアプリ期限より小さい場合はアプリ期限より大きい値に変更
	if ((int)$config['cleanup'] < (int)$config['autoLogout']) {
		$config['cleanup'] = max((int)$config['autoLogout'], 14400);
	}

	return $config;
}

/*!
 * @brief セッション用の最上位ディレクトリ
 */
function sessionDir()
{
	global $app;
	return $app['sessionDir'];
}

/*!
 * @brief アプリケーション用テンポラリディレクトリを返す.
 */
function tempDir()
{
	return topDir() . 'temp/' . getSessionDate() . '/' . getSessionPatientID() . '/';
}

/*!
 * @brief アプリケーションRuntime用一時ディレクトリを返す.
 */
function runtimeTempDir()
{
	return sessionDir() . 'temp/';
}

/*!
 * @brief ログディレクトリを返す.
 */
function logDir()
{
	return topDir() . 'contents/temp/log';
}

/*!
 * @breif セッションの日付をリセット
 * セッションに sessionDate という名前で記録される
 *
 * @param[in] string $sessionDate 設定するセッションの日付
 * @return void
 */
function setSessionDate($sessionDate)
{
	$_SESSION['sessionDate'] = $sessionDate;
}

/*!
 * @breif セッションの日付を得る
 *
 * @return string セッションの日付
 */
function getSessionDate()
{
	$key = 'sessionDate';
	if (!array_key_exists($key, $_SESSION)) {
		// バグの可能性あり
		setSessionDate(date('Ymd')); // 仕方ないのでサーバーのローカルタイムを設定
	}
	return $_SESSION[$key];
}

/*!
 * @breif セッションの時間をリセット
 * セッションに sessionTime という名前で記録される
 *
 * @param[in] string $sessionTime 設定するセッションの時間
 * @return void
 */
function setSessionTime($sessionTime)
{
	$_SESSION['sessionTime'] = $sessionTime;
}

/*!
 * @breif セッションの時間を得る
 *
 * @return string セッションの時間
 */
function getSessionTime()
{
	$key = 'sessionTime';
	if (!array_key_exists($key, $_SESSION)) {
		// バグの可能性あり
		setSessionTime(date('His')); // 仕方ないのでサーバーのローカルタイムを設定
	}
	return $_SESSION[$key];
}

/*!
 * @breif セッションの患者IDを設定する
 * セッションに sessionPatientID という名前で記録される
 *
 * @param[in] string $patientID 設定する患者ID
 * @return void
 */
function setSessionPatientID($patientID)
{
	$_SESSION['sessionPatientID'] = $patientID;
}

/*!
 * @breif セッションの患者IDを得る
 *
 * @return string セッションの患者ID
 */
function getSessionPatientID()
{
	$key = 'sessionPatientID';
	if (!array_key_exists($key, $_SESSION)) {
		// バグの可能性あり
		setSessionPatientID('');
	}
	return $_SESSION[$key];
}

/*!
 * @brief リージョンファイルのパスを取得
 *
 * @param[in] string $regionID リージョンID
 * @return string リージョンファイルのフルパス
 */
function getRegionFilePath($regionID)
{
	return topDir() . 'contents/message/' . $regionID . '.ini';
}

/*!
 * @brief アプリケーション変数にデフォルトメッセージ文字列(英語)を設定する。
 * メッセージ文字列は app['messages'] に連想配列として格納される。
 *
 * @global array $app['mesagges']
 */
function initMessage()
{
	global $app;
	$regionFilePath = getRegionFilePath('US');
	$app['messages'] = parse_ini_file($regionFilePath, true);
}

/*!
 * @brief 設定の値が有効とされるか
 *
 * @param[in] string $value 設定値
 * @return bool true:有効, false:無効
 */
function isEnableSettingValue($value)
{
	// 有効とされるパターンが増える可能性あり
	if (0 === strcmp('on_', $value)) {
		return true;
	}

	return false;
}

/*!
 * @brief 設定の値が無効とされるか
 *
 * @param[in] string $value 設定値
 * @return bool true:無効, false:有効
 */
function isDisableSettingValue($value)
{
	return !isEnableSettingValue($value);
}

/*!
 * @brief JSONファイルから連想配列を得る
 *
 * @param[in] string $jsonFilePath ファイルパス
 * @return array 連想配列
 */
function getMapFromJsonFile($jsonFilePath)
{
	if (!is_file($jsonFilePath)) {
		return null;
	}

	$settingJSON = file_get_contents($jsonFilePath);
	if (false === $settingJSON) {
		return null;
	}

	$settingMap = json_decode($settingJSON, true);
	if (!$settingMap) {
		return null;
	}

	return $settingMap;
}

/*!
 * @brief 設定ファイルから連想配列を得る
 *
 * @param[in] string $filePrefix 設定ファイルの接頭語
 * @return array 連想配列
 */
function getMapFromSettingFile($filePrefix)
{
	$settingFilePath = topDir() . 'contents/settings/' . $filePrefix . '.setting.json';

	return getMapFromJsonFile($settingFilePath);
}

/*!
 * @brief 患者JSONファイルから連想配列を得る
 *
 * @return array 連想配列
 */
function getMapFromPatientJsonFile()
{
	$jsonFilePath = tempDir() . 'patient.json';

	return getMapFromJsonFile($jsonFilePath);
}

/*!
 * @brief 設定ファイルから値を得る
 *
 * @param[in] string $filePrefix 設定ファイルの接頭語
 * @param[in] string $key        設定キー
 * @return string 値
 */
function getValueFromSettingFile($filePrefix, $key)
{
	$settingMap = getMapFromSettingFile($filePrefix);
	if (!$settingMap) {
		return null;
	}

	if (!array_key_exists($key, $settingMap)) {
		return null;
	}

	return $settingMap[$key];
}

/*!
 * @brief 設定からリージョンIDを得る
 *
 * @return string リージョンID
 */
function getRegionIDFromSetting()
{
	return getValueFromSettingFile('region', 'regionID');
}

/*!
 * @brief リージョン設定にマッチする翻訳メッセージを app['messages'] 設定する。
 *
 * この関数はapp['messages'] に翻訳済みメッセージのみを上書きするように動作する。
 * initMessage() の呼び出し後に本関数を呼び出すことで、未翻訳のメッセージを英語で
 * 表示することができるようになる。
 *
 * @global array $app['messages']
 */
function loadTranslateMessage()
{
	global $app;

	$lang = getRegionIDFromSetting();

	$msgFile = getRegionFilePath($lang);
	if (!file_exists($msgFile)) {
		return;
	}
	$transMsg = parse_ini_file($msgFile, true);
	if (!$transMsg) {
		return;
	}

	array_merge_ex($app['messages'], $transMsg);
}

/*!
 * @brief 入れ子になった配列を結合する。
 * array_merge() を入れ子配列に対応させたもの。
 *
 * @param[in,out] array $arr1
 * @param[in] array $arr2
 */
function array_merge_ex(&$arr1, $arr2)
{
	foreach ($arr2 as $key => $value) {
		if (isset($arr1[$key])) {
			if (is_array($value)) {
				array_merge_ex($arr1[$key], $value);
			} else {
				$arr1[$key] = $value;
			}
		}
	}
}

/*!
 * @brief アプリケーション変数からメッセージを取得する。
 * 翻訳済みメッセージを取得したい場合は本関数呼び出し前に、loadTranslateMessage() を
 * 呼び出しておく必要がある。
 *
 * @global array $app['messages']
 * @param[in] string $section メッセージのセクション名。 通常はページの名称。
 * @param[in] string $name    メッセージ名
 * @return string 取得したメッセージ。指定メッセージが存在しない場合は空文字列を返す。
 */
function _m($section, $name)
{
	global $app;
	if (is_null($app['messages'])) {
		initMessage();
	}
	return $app['messages'][$section][$name];
}

/*!
 * @brief エラーメッセージ向けに文字列を装飾する
 *
 * @param[in] string $text 修飾対象の文字列
 * @return string
 */
function wrappingError($text)
{
	return '<span class="errorText">' . $text . '</span>';
}

/*!
 * @brief アプリケーション変数からエラーメッセージを取得する。
 *
 * @param[in] string $section メッセージのセクション名。 通常はページの名称。
 * @param[in] string $name    メッセージ名
 * @return string
 */
function _mError($section, $name)
{
	return wrappingError(_m($section, $name));
}

/*!
 * @brief エラー画面遷移
 *
 * @param[in] array $err
 * 'redirectUri'
 *	リダイレクト先のURI
 * 'redirectWait'
 *	リダイレクトまでの待機時間(s)
 * 'title'
 *	エラーメッセージのタイトル
 * 'msg'
 *	エラーメッセージ
 */
function displayError($err)
{
	session_start();
	$_SESSION['error'] = $err;
	header('location:' . topUri() . 'sub/error.php');
}
