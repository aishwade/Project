<?php

require_once '../models/app.php';

init('sub/' . basename(__FILE__));

?>
<!DOCTYPE html>
<html>
	<body>
		<canvas id="canvasL" width="480px" height="480px">
		</canvas>
		<canvas id="canvasR" width="480px" height="480px">
		</canvas>
	</body>
		<script language="JavaScript">

		var refreshCanvas = function(ctx, img) {
			ctx.drawImage(img, 0, 0);
		}

		function drawStream(id, src) {
			var ctx = document.getElementById(id).getContext("2d");
			ctx.beginPath();
			ctx.arc(240, 240, 240, 0, Math.PI * 2, false);
			ctx.clip();

			var img = new Image();
			img.src    = src;
			img.onload = function() {
				window.setInterval(function(){refreshCanvas(ctx, img)}, 1000 / 24);
			};
		}

		drawStream("canvasL", "<?php echo topUri() . 'contents/stream/getStream.php' ?>");
		drawStream("canvasR", "<?php echo topUri() . 'contents/stream/getStream.php' ?>");

	</script>
</html>
