<?php
/*! @file
 * @brief 他覚画面
 */

require_once '../models/app.php';
require_once '../views/htmlUtil.php';

init('sub/' . basename(__FILE__));

include_once topDir() . 'contents/objective/view-single.php';
