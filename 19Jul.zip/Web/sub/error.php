<?php
/*! @file
 * @brief エラー情報画面
 */

require_once '../models/app.php';
require_once '../views/htmlUtil.php';
init('sub/' . basename(__FILE__));

//traceLog('Error' . (isset($_SESSION['error']) ? (' error.title=' .$_SESSION['error']['title']) : ''));

if (!isset($_SESSION['error'])) {
	header('Location: ' . topUri() . 'index.php'); // 表示エラーなしの場合はトップURLへ
}

include_once topDir() . 'contents/_head.php';

addStyles([
	'css/color-theme.css',
	'css/error.css',
]);
//addScripts(array(
//	'js/error.js'));

$redirectUri  = $_SESSION['error']['redirectUri'];
$redirectWait = $_SESSION['error']['redirectWait'];
$msgTitle     = $_SESSION['error']['title'];
$msg          = $_SESSION['error']['msg'];

unset($_SESSION['error']); // Todo. ここで unset しているので、ページリロードするとトップに転送されてしまう。問題ないか？
?>
<!DOCTYPE html>
<html>
	<head>
		<?php outputHeadContents(); ?>
		<?php if ($redirectWait > 0) : ?>
		<meta http-equiv="refresh" content="<?php echo $redirectWait; ?>; url=<?php echo $redirectUri; ?>">
		<?php endif; ?>
		<title><?php echo _m('error', 'title'); ?></title>
	</head>
	<body>
		<div id="error">
			<h1><?php echo $msgTitle; ?></h1>
			<div id="message">
				<p><?php echo $msg; ?></p>
				<br>
				<p><a href="<?php echo $redirectUri; ?>">
					<?php if (!empty($redirectUri)) { echo _m('error', 'goBack'); } ?>
				</a></p>
			</div>
		</div>
		<footer></footer>
		<?php if ($redirectWait > 0) : ?>
		<script language="javaScript">
			var jumpUri=<?php echo $redirectUri; ?>;
			var jumpWait=<?php echo $redirectWait; ?>;
			function autoJump(uri){ location.href=uri; }
			setTimeout('autoJump(jumpUri)', jumpWait*1000);
		</script>
		<?php endif; ?>
	</body>
</html>
