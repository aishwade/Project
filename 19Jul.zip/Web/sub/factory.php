<?php
/*! @file
 * @brief 工具ツール画面
 */

require_once '../models/app.php';
require_once '../views/htmlUtil.php';

init('sub/' . basename(__FILE__));

include_once topDir() . 'contents/factory/view.php';
