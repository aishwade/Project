<?php
/*! @file
 * @brief リージョン設定画面
 */

require_once '../models/app.php';
require_once '../views/htmlUtil.php';

init('sub/' . basename(__FILE__));

include_once topDir() . 'contents/region/view.php';
