$(document).ready(function(){
	const $textarea = $("textarea");
	becky.WebSocket.build(event => {
		switch (event.type) {
			case "open":
				const json = {
					command: "getText",
				};
				becky.WebSocket.post(json).then(aResultJson => {
					const resultValue = aResultJson.value;
					if (!modelHelper.isUndefined(resultValue)) {
						viewHelper.setAttDisabled($textarea, false);
						$textarea.val(resultValue);
					}
				});
				break;
			case "close":
				viewHelper.setAttDisabled($textarea);
				break;
			case "message":
				// ブロードキャストで受信
				const resultJsonString = event.data;
				const resultJson = JSON.parse(resultJsonString);
				const resultValue = resultJson.value;
				if (!modelHelper.isUndefined(resultValue)) {
					$textarea.val(resultValue);
				}
				break;
		}
	});
	$textarea.bind("change keyup", function(){
		const json = {
			command: "setText",
			value: $(this).val(),
		};
		becky.WebSocket.post(json).catch(() => {
			aleat("送信失敗！");
		});
	});
});
