<?php
use Ratchet\Server\IoServer;
use Ratchet\Http\HttpServer;
use Ratchet\WebSocket\WsServer;
use becky\MBoard;

require_once '../vendorComposer/autoload.php';
require_once '_mboard.php';

$server = IoServer::factory(
	new HttpServer(
		new WsServer(
			new MBoard()
		)
	), 8080
);

$server->run();
