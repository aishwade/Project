<?php
namespace becky;
use Ratchet\MessageComponentInterface;
use Ratchet\ConnectionInterface;

require_once dirname(__FILE__) . '/views/jsonHelper.php';

function sendJson($client, $json)
{
	// JSON 文字列化とエスケープ
	$jsonString = json_encode_and_escape($json);

	$client->send($jsonString);
}

class MBoard implements MessageComponentInterface
{
	protected $clients;

	private $latestText = '';

	public function __construct()
	{
		$this->clients = new \SplObjectStorage;
	}

	public function onOpen(ConnectionInterface $conn)
	{
		// Store the new connection to send messages to later
		$this->clients->attach($conn);

		echo 'New connection! (' . $conn->resourceId . ')' . PHP_EOL;
	}

	public function onMessage(ConnectionInterface $from, $msg)
	{
		$requestJson = json_decode($msg, true);
		$requestID      = @$requestJson['requestID'];
		$requestCommand = @$requestJson['command'  ];
		$requestValue   = @$requestJson['value'    ];

		switch ($requestCommand) {
			case 'getText':
				foreach ($this->clients as $client) {
					if ($from === $client) {
						$json = [
							'requestID' => $requestID,
							'return' => 'success',
							'value'  => $this->latestText,
						];
						sendJson($client, $json);
					} else {
						// 何もしない
					}
				}
				break;
			case 'setText':
				$this->latestText = $requestValue;
				foreach ($this->clients as $client) {
					if ($from === $client) {
						$json = [
							'requestID' => $requestID,
							'return' => 'success',
						];
						sendJson($client, $json);
					} else {
						$json = [
							'requestID' => $requestID,
							'return' => 'success',
							'value'  => $requestValue,
						];
						sendJson($client, $json);
					}
				}
			default:
				break;
		}

		// Ratchet v0.3→v0.4 に変更してからメモリが開放されなくなった!?
		gc_collect_cycles();
	}

	public function onClose(ConnectionInterface $conn)
	{
		// The connection is closed, remove it, as we can no longer send it messages
		$this->clients->detach($conn);

		echo 'Connection ' . $conn->resourceId . ' has disconnected' . PHP_EOL;
	}

	public function onError(ConnectionInterface $conn, \Exception $e)
	{
		echo 'An error has occurred: ' . $e->getMessage() . PHP_EOL;

		$conn->close();
	}
}
