<!DOCTYPE html>
<html lang="ja-JP">
	<head>
		<meta charset="utf-8">
		<title>メッセージボード</title>
		<link rel="stylesheet" type="text/css" href="index.css">
		<script src="../vendor/jqueryui/js/jquery-3.2.1.min.js"></script>
		<script src="../js/modelHelper.js"></script>
		<script src="../js/beckyAssertion.js"></script>
		<script src="../js/beckyDynamic.js.php"></script>
		<script src="../js/viewHelper.js"></script>
		<script src="../js/asyncHelper.js"></script>
		<script src="../js/beckyIDHelper.js"></script>
		<script src="../js/beckyJsonHelper.js"></script>
		<script src="../js/beckyWebSocketIF.js"></script>
		<script src="./index.js"></script>
	</head>
	<body>
		<textarea placeholder="空" autofocus disabled></textarea>
	</body>
</html>
