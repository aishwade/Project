<?php
/*! @file
 * @brief sync コマンドを叩くテスト
 */

require_once dirname(__FILE__) . '/../models/pathUtil.php';

$thisDir = realpath(dirname(__FILE__));
$filePath = \becky\Path\combine($thisDir, 'sync.txt');

file_put_contents($filePath, 'sync sync sync!');

$cmd = 'sync ' . $filePath;

$output = [];
$return_var = 0;
exec($cmd, $output, $return_var);

header('Content-Type: text/plain');

if (!empty($output)) {
	foreach ($output as $line) {
		echo $stdout . PHP_EOL;
	}
}
echo $return_var . PHP_EOL;
