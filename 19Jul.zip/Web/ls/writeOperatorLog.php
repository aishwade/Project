<?php
/*! @file
 * @brief 操作ログを書き込む
 */

// エラー発生時に JSON 形式でデータを返せなくなるので
// 全てのエラー出力をオフにする
error_reporting(0);

require_once dirname(__FILE__) . '/../models/pathUtil.php';
require_once dirname(__FILE__) . '/../models/systemUtil.php';
require_once dirname(__FILE__) . '/../models/patientUtil.php';
require_once dirname(__FILE__) . '/../views/jsonHelper.php';

/*!
 * @brief 操作ログを書き込む
 * 
 * @param[in] string $jsonString 操作ログのJSON文字列
 * @retval true 成功
 * @retval false 失敗
 */
function writeOperatorLog($jsonString)
{
	if (empty($jsonString)) {
		return false;
	}

	$json = json_decode($jsonString, true);
	if (!$json) {
		return false;
	}

	$homeDir = realpath(\becky\Path\combine(dirname(__FILE__), '..', '..', '..'));
	$logRootDir = \becky\Path\combine($homeDir, 'chronos', 'log');

	foreach ($json as &$oneCycleJson) {
		$sessionDate = $oneCycleJson['private']['sessionDate'];
		$sessionTime = $oneCycleJson['private']['sessionTime'];
		$patientID   = $oneCycleJson['private']['patientID'  ];
		$sessionPatientID = \becky\Patient\toSessionPatientID($patientID, $sessionTime);

		$logDir = \becky\Path\combine($logRootDir, $sessionDate, $sessionPatientID);
		$fileName = 'log.json';
		$filePath = \becky\Path\combine($logDir, $fileName);

		if (file_exists($filePath)) {
			// 同名のファイルが存在する場合
			$backupFileName = $fileName;

			// ファイルの末尾(ファイル名と拡張子の間)に付加する文字
			$backupSuffix = '.' . $sessionTime;
			if (!empty($backupSuffix)) {
				$pathInfos = pathinfo($backupFileName);
				$backupFileName = $pathInfos['filename'] . $backupSuffix . '.' . $pathInfos['extension'];
			}

			// リネームする
			$backupFilePath = \becky\Path\combine($logDir, $backupFileName);
			if ($filePath != $backupFilePath &&
			    !rename($filePath, $backupFilePath)) {
				return false;
			}
		}

		if (!file_exists($logDir) &&
		    !mkdir($logDir, 0777, true)) {
			return false;
		}

		// JSON 文字列化
		$writeJsonString = json_encode_and_escape($oneCycleJson);
		if (false === file_put_contents($filePath, $writeJsonString)) {
			return false;
		}
	}

	// sync で速やかに SD カードに書き込む
	\becky\System\sync();

	return true;
}

$jsonString = file_get_contents('php://input'); // POST の生データ

if (!writeOperatorLog($jsonString)) {
	http_response_code(500);
	exit;
}

$resultJson = [
	'return' => true,
];

header('Content-Type: application/json; charset=utf-8');

// JSON 文字列化とエスケープ
echo json_encode_and_escape($resultJson);
