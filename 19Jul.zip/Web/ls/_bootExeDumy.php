<?php
/*! @file
 * @brief 実行ファイルを起動し標準出力の内容をJSON形式という想定でHTTPレスポンスとして返す(ダミー)
 */

// エラー発生時に JSON 形式でデータを返せなくなるので
// 全てのエラー出力をオフにする
error_reporting(0);

require_once '../models/modelUtil.php';
require_once '../models/pathUtil.php';

/*!
 * @brief 標準エラー出力
 *
 * @param[in] string $val 出力内容
 * @return void;
 */
function echoSTDERR($val)
{
	fputs(STDERR, $val);
}

/*!
 * @brief 標準エラー出力(改行)
 *
 * @param[in] string $val 出力内容
 * @return void;
 */
function echoLineSTDERR($val)
{
	echoSTDERR($val . PHP_EOL);
}

/*!
 * @brief ログを追記
 *
 * @param[in] string $path ファイルパス
 * @param[in] mixed $data 書き込む内容
 * @return void;
 */
function appendLog($path, $data)
{
	if (empty($data)) {
		return;
	}
	if (false === file_put_contents($path, $data, FILE_APPEND | LOCK_EX)) {
		echoLineSTDERR('Error! appendLog ' . $path);
	}
}

$jsonString = file_get_contents('php://input'); // POST の生データ
if (empty($jsonString)) {
	http_response_code(500);
	echoLineSTDERR('php://input is empty');
	exit;
}

$json = json_decode($jsonString, true);

$command = \ModelUtil\array_get($json['command'], '');
if (empty($command)) {
	http_response_code(500);
	echoLineSTDERR('command is empty');
	exit;
}

// セキュリティ対策
// 登録している実行ファイルしか動かさない
$exes = [
	'stdoutjson',        // 動作確認用
	'HeadPositionJson',  // 動作確認用
	'ErrorTest',         // 動作確認用
	'ChronosAlignment2', // 前眼部アライメント
	'ChronosRef2',       // 他覚屈折力測定(レフ)
	'Chart',             // 指標表示
	'Phoropter',         // フォロプター制御
	'ResetBase',         // Base-PCBのモーターを原点復帰
	'ResetOpt',          // OPT-PCBリセット
	'GetBaseSubVer',     // BaseSub ファームウェアバージョン取得
	'GetOptSubVer',      // OptSub ファームウェアバージョン取得
	'ChronosAlignment2ModelEye', // 前眼部アライメント(模型眼モード)
];
$index = array_search($command, $exes);
if (false === $index) {
	http_response_code(500);
	echoLineSTDERR('un-known command ' . $command);
	exit;
}

$stdin = '';
if (array_key_exists('json', $json)) {
	$stdin = json_encode($json['json']);
}
$enableStdin = !empty($stdin);

//// ログファイル
//$logDir = \becky\Path\combine(dirname(__FILE__), '..');
//$pathLog       = \becky\Path\combine($logDir, 'log' . $command             . '.txt');
//$pathLogStdin  = \becky\Path\combine($logDir, 'log' . $command . '.stdin'  . '.txt');
//$pathLogStdout = \becky\Path\combine($logDir, 'log' . $command . '.stdout' . '.txt');
//$pathLogStderr = \becky\Path\combine($logDir, 'log' . $command . '.stderr' . '.txt');
//// ログファイルは蓄積させない方針
//if (file_exists($pathLog      )) unlink($pathLog      );
//if (file_exists($pathLogStdin )) unlink($pathLogStdin );
//if (file_exists($pathLogStdout)) unlink($pathLogStdout);
//if (file_exists($pathLogStderr)) unlink($pathLogStderr);
//
//if ($enableStdin) {
//	appendLog($pathLogStdin, $stdin);
//}
//
$stdout = '';
$stderr = '';

if ($enableStdin) {
	$stdinJson = json_decode($stdin, true);
	if (\ModelUtil\array_get($stdinJson['GetVersion'], false)) {
		$versions = [
			'Major' => 0,
			'Minor' => 0,
			'Build' => 0,
			'Revision' => 0,
		];
		$stdoutJson = [ 'return' => true, 'Version' => $versions, ];
		$stdout = json_encode($stdoutJson);
		header('Content-Type: application/json; charset=utf-8');
		echo $stdout;
		exit;
	}
}

switch ($command) {
	case 'Chart':
	case 'Phoropter':
	case 'ResetBase':
	case 'ResetOpt':
		$stdout = '{"return":true}';
		//$stdout = '{"return":false,"error":{"code":209,"message": "Initialize VCC2 Motor error."}}';
		//$stdout = '{"return":false,{"code":209,"message":"Initialize VCC2 Motor error."}';
		break;
	case 'ChronosAlignment2':
	case 'ChronosAlignment2ModelEye':
		$hpd = [
			"unit"  => "mm",
			"value" => mt_rand(100, 499) / 10, // 10.0 ～ 49.9
		];
		$stdoutJson = [ 'return' => true, 'HPD' => $hpd, ];
		$stdout = json_encode($stdoutJson);
		break;
	case 'ChronosRef2':
		//$stdout = '{"return":true,"Median":{"Sphere":{"value":' . $sph . '},"Cylinder":{"value":' . $cyl . '},"Axis":{"value":' . $axs . '}}}';
		$records = [];
		for ($i = 0; $i < 3; ++$i) {
			$sph = mt_rand(-1000, 1000) / 100; // -10.00 ～ 10.00
			$cyl = mt_rand(-1000, 1000) / 100; // -10.00 ～ 10.00
			$axs = mt_rand(1, 180);
			$record = [
				'Sphere' => [
					'unit'  => 'D',
					'value' => $sph,
				//	'error' => [ 'message' => 'ERR' ],
				],
				'Cylinder' => [
					'unit'  => 'D',
					'value' => $cyl,
				//	'error' => [ 'message' => 'ERR' ],
				],
				'Axis' => [
					'unit'  => 'deg',
					'value' => $axs,
				//	'error' => [ 'message' => 'ERR' ],
				],
			];
			$records[] = $record;
		}
		$sphNo = mt_rand(0, 2);
		$cylNo = mt_rand(0, 2);
		$axsNo = mt_rand(0, 2);
		$median = [
			'Sphere' => [
				'unit'  => 'D',
				'value' => $records[$sphNo]['Sphere']['value'],
			//	'error' => [ 'message' => 'ERR' ],
			],
			'Cylinder' => [
				'unit'  => 'D',
				'value' => $records[$cylNo]['Cylinder']['value'],
			//	'error' => [ 'message' => 'ERR' ],
			],
			'Axis' => [
				'unit'  => 'deg',
				'value' => $records[$axsNo]['Axis']['value'],
			//	'error' => [ 'message' => 'ERR' ],
			],
		];
		$stdoutJson = [ 'return' => true, 'Records' => $records, 'Median' => $median, ];
		$stdout = json_encode($stdoutJson);
		break;
	case 'ErrorTest':
		$inputError = $json['json']['error'];
		if (1 === count($inputError)) {
			$stdout = '{"return":false,"error":{"code":' . $inputError[0]['code'] . '}}';
		} else {
			$stdoutJson = [ 'return' => false, 'error' => $inputError, ];
			$stdout = json_encode($stdoutJson);
		}
		break;
	default:
		$stdout = '{"return":false}';
		break;
}

//appendLog($pathLog      , $stdout);
//appendLog($pathLogStdout, $stdout);
//
$stdout = trim($stdout);
if (empty($stdout)) {
	$stdout = '{}';
}

$contentType = '';
if (null === json_decode($stdout, true)) {
	// Json 形式ではない(ルール違反)
	echoLineSTDERR('Warning! not json format');
	$contentType = 'text/plain';
} else {
	$contentType = 'application/json; charset=utf-8';
}

header('Content-Type: ' . $contentType);
echo $stdout;
