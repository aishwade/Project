<?php
/*! @file
 * @brief 踏んだ IP アドレスを記録
 */

require_once '../models/modelUtil.php';
require_once '../models/pathUtil.php';
require_once '../views/jsonHelper.php';

// ログファイル
$logDir = \becky\Path\combine(dirname(__FILE__), '../temp');
$pathLog = \becky\Path\combine($logDir, 'logStumpIP.txt');

// クライアントのIPアドレスを記録
$clientIpAddress = $_SERVER['REMOTE_ADDR'];
$result_file_put_contents = file_put_contents($pathLog, $clientIpAddress);

$resultJson = [
	'return' => false !== $result_file_put_contents && !empty($clientIpAddress),
];

header('Content-Type: application/json; charset=utf-8');

// JSON 文字列化とエスケープ
echo json_encode_and_escape($resultJson);
