<?php
/*! @file
 * @brief ログのバックアップの Ajax リクエスト受付
 */

// エラー発生時に JSON 形式でデータを返せなくなるので
// 全てのエラー出力をオフにする
error_reporting(0);

require_once dirname(__FILE__) . '/../models/pathUtil.php';
require_once dirname(__FILE__) . '/../models/fileUtil.php';

define('CHRONOS_HOME'  , '/home/root/chronos');
define('LOG_PATH'      , \becky\Path\combine(CHRONOS_HOME, 'log'));
define('BACKUP_SH_PATH', \becky\Path\combine(CHRONOS_HOME, 'log_backup.sh'));
define('NOHUP_OUT'     , \becky\Path\combine(CHRONOS_HOME, 'nohup_log_backup.out'));

define('USB_STORAGE_ROOT', '/media/sda1');

/*!
 * @brief 進捗
 *
 * @param[in] array $posts $_POST を設定
 * @param[out] string $result
 * @retval true 成功
 * @retval false 失敗
 */
function progress($posts, &$result)
{
	// ps の COMMAND フィールドに log_backup.sh があるか？
	$command = 'ps | grep -v grep | awk \'{$1=$2=$3=$4="";print}\' | grep ' . BACKUP_SH_PATH;

	$output = [];
	$return_var = 0;
	exec($command, $output, $return_var);

	// パイプの最後(grep)の戻り値
	// 0:一致する
	// 1:一致しない もしくは エラー
	$bRunning = 0 === $return_var;
	$strStdout = file_get_contents(NOHUP_OUT, false, null, $posts['offset']);

	$result = [
		'running' => $bRunning,
	];
	if (false !== $strStdout) {
		$result['stdout'] = $strStdout;
	}

	return true;
}

/*!
 * @brief バックアップ
 *
 * @param[in] array $posts $_POST を設定
 * @param[out] string $result
 * @retval true 成功
 * @retval false 失敗
 */
function backup($posts, &$result)
{
	// 前回の実行結果の削除
	if (file_exists(NOHUP_OUT)) {
		unlink(NOHUP_OUT);
	}

	// ログの存在を確認
	{
		$scanDirLog = scandir(LOG_PATH);
		if (false === $scanDirLog) {
			$result = 'Can not access ' . LOG_PATH;
			return false;
		}
		$logSubDirs = array_filter($scanDirLog, function($item_) {
			return !in_array($item_, ['.', '..']);
		});
		if (empty($logSubDirs)) {
			$result = 'Log dir was empty!';
			return false;
		}
	}

	$pathTo = USB_STORAGE_ROOT;

	// マウント状態の確認
	{
		$command = 'mountpoint ' . $pathTo;
		$output = [];
		$return_var = 0;
		exec($command, $output, $return_var);
		if (0 !== $return_var) {
			$result = 'Not mounted ' . $pathTo;
			return false;
		}
	}

	// eth0 でサブディレクトリを作成する
	{
		$ifEth0 = getenv('IF_ETH0');
		if ('' === $ifEth0) {
			$ifEth0 = 'unknown';
		}

		$pathTo = \becky\Path\combine($pathTo, $ifEth0);
		if (!file_exists($pathTo) &&
		    !mkdir($pathTo, 0777)) { // 再帰的に作る必要はない
			$result = 'Can not mkdir ' . $pathTo;
			return false;
		}
	}

	// nohup を使い log_backup.sh をバックグラウンド実行
	{
		$command = join(' ', [ 'nohup', BACKUP_SH_PATH, LOG_PATH, $pathTo, '>', NOHUP_OUT, '&' ]);
		$output = [];
		$return_var = 0;
		exec($command, $output, $return_var);
		if (0 !== $return_var) {
			$result = 'log_backup.sh return ' . $return_var;
			return false;
		}
	}

	return true;
}

/*!
 * @brief コマンド分岐
 *
 * @param[in] array $posts $_POST を設定
 * @param[out] string $result
 * @retval true 成功
 * @retval false 失敗
 */
function commandSwitch($posts, &$result)
{
	return call_user_func_array($posts['command'], [ $posts, &$result ]); // $result のみ参照渡し
}

header('Content-Type: application/json; charset=utf-8');

$resultJson = null;
$result = '';
if (!commandSwitch($_POST, $result)) {
	$resultJson = [
		'return' => false,
		'error' => [
			'message' => $result,
		],
	];
} else {
	$resultJson = [
		'return' => true,
	];
	if (!empty($result)) {
		// 結合
		$resultJson += $result;
	}
}

// 可能な限りのエスケープを行い、JSON 形式で結果を返します。
echo json_encode(
	$resultJson,
	JSON_HEX_TAG  | // すべての < および > をそれぞれ \u003C および \u003E に変換します。(v5.3.0 以降)
	JSON_HEX_AMP  | // すべての & を \u0026 に変換します。(v5.3.0 以降)
	JSON_HEX_APOS | // すべての ' を \u0027 に変換します。(v5.3.0 以降)
	JSON_HEX_QUOT   // すべての " を \u0022 に変換します。(v5.3.0 以降)
);
