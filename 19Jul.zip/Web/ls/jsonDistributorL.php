<?php
/*! @file
 * @brief JSON 分配器(左ヘッドのみ)
 */

// エラー発生時に JSON 形式でデータを返せなくなるので
// 全てのエラー出力をオフにする
error_reporting(0);

require_once '../defs/defData.php';
require_once '../models/pathUtil.php';
require_once '../models/systemUtil.php';
require_once '../views/jsonHelper.php';
require_once '../ls/jsonDistributorUtil.php';

// ログファイル
$logDir  = \becky\Path\combine(dirname(__FILE__), '..');
$pathLog = \becky\Path\combine($logDir, 'logjsonDistributor.txt');
//// ログファイルは蓄積させない方針
//if (file_exists($pathLog)) unlink($pathLog);

$ipPorts = [];
{
	$port = $_SERVER['SERVER_PORT'];
	if (\becky\System\isWindows()) {
		// おそらく開発環境
		$ipPorts['L'] = '127.0.0.1' . ':' . $port;
	} else {
		// たぶん実機
		$ipPorts['L'] = PrivateIpAdress::Left  . ':' . $port;
	}
}

$jsonString = file_get_contents("php://input"); // POST の生データ
$resultJson = broadcastHttpRequest($ipPorts, $jsonString, $pathLog);
if (!$resultJson) {
	http_response_code(500);
	exit;
}

header('Content-Type: application/json; charset=utf-8');

// JSON 文字列化とエスケープ
echo json_encode_and_escape($resultJson);
