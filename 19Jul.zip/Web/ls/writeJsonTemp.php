<?php
/*! @file
 * @brief JSON ライター
 */

// エラー発生時に JSON 形式でデータを返せなくなるので
// 全てのエラー出力をオフにする
error_reporting(0);

require_once '../models/app.php';
require_once '../models/modelUtil.php';
require_once '../models/fileUtil.php';
require_once '../views/jsonHelper.php';

init('ls/' . basename(__FILE__));

// セッションを更新しないのですぐに閉じる
session_write_close();

function echoSTDERR($val)
{
	fputs(STDERR, $val);
}

function echoLineSTDERR($val)
{
	echoSTDERR($val . PHP_EOL);
}

/*!
 * @brief 一時データを書き込む
 * 
 * @param[in] string $jsonString 一時データのJSON文字列
 * @retval true 成功
 * @retval false 失敗
 */
function writeJsonTemp($jsonString)
{
	if (empty($jsonString)) {
		echoLineSTDERR('php://input is empty');
		return false;
	}

	$json = json_decode($jsonString, true);

	$fileName = \ModelUtil\array_get($json['fileName'], '');
	if (empty($fileName)) {
		echoLineSTDERR('fileName is empty');
		return false;
	}

	$writeJsonString = json_encode($json['json']);
	if (empty($writeJsonString)) {
		echoLineSTDERR('json is empty');
		return false;
	}

	$tempDir = tempDir();
	$filePath = $tempDir . $fileName;

	if (file_exists($filePath)) {
		// 同名のファイルが存在する場合
		$backupFileName = $fileName;

		// ファイルの末尾(ファイル名と拡張子の間)に付加する文字
		$backupSuffix = \ModelUtil\array_get($json['backupSuffix'], '');
		$backupSuffix = date($backupSuffix); // 時間フォーマットを適用
		if (!empty($backupSuffix)) {
			$pathInfos = pathinfo($backupFileName);
			$backupFileName = $pathInfos['filename'] . $backupSuffix . '.' . $pathInfos['extension'];
		}

		// ファイルの先頭に付加する文字
		$backupPrefix = \ModelUtil\array_get($json['backupPrefix'], '');
		$backupPrefix = date($backupPrefix); // 時間フォーマットを適用
		if (!empty($backupPrefix)) {
			$backupFileName = $backupPrefix . $backupFileName;
		}

		// リネームする
		$backupFilePath = $tempDir . $backupFileName;
		if ($filePath != $backupFilePath &&
		    !rename($filePath, $backupFilePath)) {
			echoLineSTDERR('can not file rename.');
			return false;
		}
	}

	if (!file_exists($tempDir) &&
	    !mkdir($tempDir, 0777, true)) {
		echoLineSTDERR('can not create dir.');
		return false;
	}

	return false !== \becky\file_put_contents_and_sync($filePath, $writeJsonString);
}

$jsonString = file_get_contents("php://input"); // POST の生データ

if (!writeJsonTemp($jsonString)) {
	http_response_code(500);
	exit;
}

$resultJson = [
	'return' => true,
];

header('Content-Type: application/json; charset=utf-8');

// JSON 文字列化とエスケープ
echo json_encode_and_escape($resultJson);
