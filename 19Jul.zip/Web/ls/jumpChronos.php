<?php
/*! @file
 * @brief Chronos のトップページにジャンプ
 * stumpIP.php を踏んだ Chronos
 */

require_once '../models/modelUtil.php';
require_once '../models/pathUtil.php';

// ログファイル
$logDir = \becky\Path\combine(dirname(__FILE__), '../temp');
$pathLog = \becky\Path\combine($logDir, 'logStumpIP.txt');

$chronosIpAddress = file_get_contents($pathLog);
$chronosIpAddress = trim($chronosIpAddress);

$jumpUrl = 'http://' . $chronosIpAddress . '/topcon/';
header('Location: ' . $jumpUrl);
