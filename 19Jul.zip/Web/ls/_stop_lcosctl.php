<?php
/*! @file
 * @brief LCOS の停止コマンドを叩く
 */

$path = '/home/root/chronos/lcosctl';
if (!file_exists($path)) {
	http_response_code(404);
	exit;
}

$cmd = $path . ' stop';

$output = [];
$return_var = 0;
exec($cmd, $output, $return_var);

header('Content-Type: text/plain');

if (!empty($output)) {
	foreach ($output as $line) {
		echo $stdout . PHP_EOL;
	}
}
echo $return_var . PHP_EOL;
