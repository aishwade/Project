<?php
/*! @file
 * @brief JSON リーダー
 */

// エラー発生時に JSON 形式でデータを返せなくなるので
// 全てのエラー出力をオフにする
error_reporting(0);

require_once '../models/app.php';
require_once '../models/modelUtil.php';

init('ls/' . basename(__FILE__));

// セッションを更新しないのですぐに閉じる
session_write_close();

function echoSTDERR($val)
{
	fputs(STDERR, $val);
}

function echoLineSTDERR($val)
{
	echoSTDERR($val . PHP_EOL);
}

$jsonString = file_get_contents("php://input"); // POST の生データ
if (empty($jsonString)) {
	http_response_code(500);
	echoLineSTDERR('php://input is empty');
	exit;
}

$json = json_decode($jsonString, true);

$fileName = \ModelUtil\array_get($json['fileName'], '');
if (empty($fileName)) {
	http_response_code(500);
	echoLineSTDERR('fileName is empty');
	exit;
}

$filePath = tempDir() . $fileName;
if (!file_exists($filePath)) {
	http_response_code(404);
	echoLineSTDERR('File Not found! ' . $filePath);
	exit;
}

header('Content-Type: application/json; charset=utf-8');
header('Content-Length: ' . filesize($filePath));

readfile($filePath);
